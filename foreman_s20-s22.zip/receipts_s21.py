"""
Receipts for notebook section 21 (python-flint and the standard library only).   Run:  python receipts_s21.py
  1. The five-mark frame X of Remark 20.16 is a product of Beta corners.
  2. Example 20.7 read from its gauge end: closings, two recurrences (modular nullspaces, CRT), the density
     equation, its exponents, the Hessian, the series at f*, the values, both corners; the share side as a check.
  3. The three-mark centre from its gauge end: l, l', l'' with no corner datum, and their relations at level six.
  4. The denominators of the three-mark centre ray.
  5. The five-mark centre (n = 5, odd) read from its gauge end: the germ that extends by zero.
  6. The germ at the gauge end is local data at alpha*: the first Laplace correction from the cumulants of the letters
     against the law's formal solution at f*.
Section numbers 20.x refer to the entry of 23 October 2026 ("Eight questions after the examination").
"""
import time
from math import comb, gcd, lcm, log, factorial, isqrt
from fractions import Fraction
from flint import (arb, acb, ctx, fmpq, fmpz, fmpq_poly, fmpz_poly, arb_poly, arb_mat, nmod_mat, fmpz_mat)

T0 = time.time()
def say(*a): print(*a, flush=True)

# ------------------------------------------------------------------------------------------------ 1
say('1. The five-mark frame (Remark 20.16)')
ctx.prec = 400
g = lambda a, b: (arb(a) / b).gamma()
X = g(1, 15) * g(2, 15) * g(4, 15) * g(8, 15) * g(1, 5) * g(2, 5) * g(3, 5) * g(4, 5) / g(1, 2) ** 4 / 120
Beta = lambda a, b, c, d: g(a, b) * g(c, d) / (arb(a) / b + arb(c) / d).gamma()
rhs = g(1, 2) ** 2 * Beta(1, 15, 4, 15) * Beta(2, 15, 8, 15) / (15 * arb(15).sqrt())
say('   X =', X.str(30), '   Gamma(1/2)^2 B(1/15,4/15) B(2/15,8/15)/(15 sqrt15) =', rhs.str(30), '   difference', (X - rhs).str(3))
# the invariant of a Gamma monomial up to algebraic factors: F(t) = sum_a n_a <t a>, t prime to 30
def F(mono, t): return sum(n * (Fraction(t) * a - int(Fraction(t) * a)) for a, n in mono.items())
monoX = {Fraction(a, 15): 1 for a in (1, 2, 4, 8)} | {Fraction(a, 5): 1 for a in (1, 2, 3, 4)}
monoX[Fraction(1, 2)] = -4
monoR = {Fraction(1, 2): 2, Fraction(1, 15): 1, Fraction(4, 15): 1, Fraction(5, 15): -1, Fraction(2, 15): 1, Fraction(8, 15): 1,
         Fraction(10, 15): -1}
units = [t for t in range(1, 30) if gcd(t, 30) == 1]
say('   F_X(t) - F_R(t) over t in (Z/30)^x:', sorted(set(F(monoX, t) - F(monoR, t) for t in units)),
    '  (constant: the ratio is algebraic);   top minus bottom of X:', sum(a * n for a, n in monoX.items() if n > 0) + sum(Fraction(1, 2) * n for a, n in monoX.items() if n < 0))

# ------------------------------------------------------------------------------------------------ 2
say('2. Example 20.7 read from its gauge end')
J = 420
Xc = [sum(comb(3 * j, 2 * j + b) * comb(j, b) * comb(2 * j - 2 * b, j - b) ** 2 for b in range(j + 1)) for j in range(J)]
say('   closings:', Xc[:5])
def primes_below(n, k):
    out = []; p = n
    while len(out) < k:
        p -= 1
        if fmpz(p).is_prime(): out.append(p)
    return out
def nullvec_mod(h, D, p, neq):
    nunk = (h + 1) * (D + 1)
    M = nmod_mat(neq, nunk, p)
    for j in range(neq):
        for i in range(h + 1):
            xi = Xc[j + i] % p; pw = 1
            for e in range(D + 1):
                M[j, i * (D + 1) + e] = xi * pw % p; pw = pw * j % p
    R, rank = M.rref()
    assert nunk - rank == 1
    piv = []; r = 0
    for c in range(nunk):
        if r < rank and int(R[r, c]) != 0: piv.append(c); r += 1
    free = [c for c in range(nunk) if c not in piv][0]
    v = [0] * nunk; v[free] = 1
    for i, c in enumerate(piv): v[c] = (-int(R[i, free])) % p
    return v
def ratrec(a, m):
    a %= m; r0, r1, s0, s1 = m, a, 0, 1; bound = isqrt(m // 2)
    while r1 > bound:
        q_ = r0 // r1; r0, r1 = r1, r0 - q_ * r1; s0, s1 = s1, s0 - q_ * s1
    if s1 == 0 or abs(s1) > bound: return None
    return Fraction(r1, s1)
def exact_law(h, D):
    nunk = (h + 1) * (D + 1); val = None; mod = 1; prev = None
    for k, p in enumerate(primes_below(2 ** 62, 80)):
        v = nullvec_mod(h, D, p, nunk + 30)
        if val is None: val, mod = v, p
        else:
            inv = pow(mod, -1, p); val = [a + mod * (((b - a) * inv) % p) for a, b in zip(val, v)]; mod *= p
        if k % 4 == 3:
            rec = [ratrec(a, mod) for a in val]
            if None not in rec and rec == prev:
                L = 1
                for r_ in rec: L = lcm(L, r_.denominator)
                ints = [int(r_ * L) for r_ in rec]; gg = 0
                for t_ in ints: gg = gcd(gg, t_)
                return [t_ // gg for t_ in ints], k + 1
            prev = rec
law = {}
for (h, D) in ((4, 25), (19, 10)):
    v, used = exact_law(h, D)
    ok = all(sum(v[i * (D + 1) + e] * Xc[j + i] * j ** e for i in range(h + 1) for e in range(D + 1)) == 0 for j in range(J - h))
    say(f'   recurrence of the closings, order {h}, degree {D}: {used} primes, largest coefficient {max(len(str(abs(c))) for c in v)} digits, '
        f'exact on all {J - h} closings: {ok}')
    law[(h, D)] = [fmpq_poly([v[i * (D + 1) + e] for e in range(D + 1)]) for i in range(h + 1)]
# the density equation  L = sum_i t^i Q_i(theta),  Q_i(z) = p_{h-i}(z - h + i + 1)  (Proposition 20.17 read on the closings)
h, D = 19, 10
p = law[(h, D)]; z = fmpq_poly([0, 1])
Q = [p[h - i](z + (-h + i + 1)) for i in range(h + 1)]
bad = sum(1 for M in range(300) if sum(Q[i](M - i - 1) * Xc[M - i] for i in range(h + 1) if M - i >= 0) != 0)
say('   L annihilates sum_N x_N t^(N-1):', bad == 0)
toZ = lambda P_: fmpz_poly([int(c * P_.denom()) for c in P_.coeffs()])
sym = fmpq_poly([Q[i].coeffs()[D] if Q[i].degree() >= D else 0 for i in range(h + 1)])
say('   symbol of L (coefficient of theta^10) factors as', [(str(f_) if f_.degree() <= 2 else f'degree {f_.degree()}', e_) for f_, e_ in toZ(sym).factor()[1]])
p4 = law[(4, 25)]
sym4 = fmpq_poly([p4[4 - i].coeffs()[25] * (-1) ** 25 for i in range(5)])
say('   symbol of the law of order 4 factors as', [(str(f_), e_) for f_, e_ in toZ(sym4).factor()[1]], '(so the degree-15 factor carries no native value)')
say('   indicial polynomial at t = 0 factors as', [(str(f_), e_) for f_, e_ in toZ(Q[0]).factor()[1]])
# local analysis at f*:  theta = (s - f*) d/ds,  L(s^nu) = sum_d T_d(nu) s^(nu+d)
ctx.prec = 2400
r19 = arb(19).sqrt()
fs = (7643 + 1064 * r19) / 1366875; fc = (7643 - 1064 * r19) / 1366875
nu = arb_poly([0, 1])
c = [[arb_poly([1])] + [arb_poly([0])] * D]
for r in range(D):
    new = [arb_poly([0])] * (D + 1)
    for j in range(D + 1):
        new[j] = new[j] + c[r][j] * (nu - j)
        if j + 1 <= D: new[j + 1] = new[j + 1] - fs * c[r][j] * (nu - j)
    c.append(new)
T = {}
for i in range(h + 1):
    W = [arb_poly([0])] * (D + 1)
    for r in range(D + 1):
        if r > Q[i].degree() or Q[i].coeffs()[r] == 0: continue
        cr = arb(Q[i].coeffs()[r].p) / arb(Q[i].coeffs()[r].q)
        for j in range(D + 1): W[j] = W[j] + cr * c[r][j]
    for l in range(i + 1):
        b = comb(i, l) * fs ** (i - l) * (-1) ** l
        for j in range(D + 1): T[l - j] = T.get(l - j, arb_poly([0])) + b * W[j]
dlo, dhi = -D + 1, max(T)
I = T[dlo]
say(f'   at f*: T_(-10) vanishes ({T[-10](arb(1) / 3).str(3)}); indicial polynomial of degree {I.degree()}, zero at 0..8: '
    f'{all(abs(I(arb(x))) < arb(10) ** -300 for x in range(9))}, tenth exponent {(-(I.coeffs()[-2] / I.coeffs()[-1]) - 36).str(20)}')
# the Hessian of -log f at alpha* = (x0, x0, 1, 1), chart y_3 = 0, H = 3 Cov_K + Cov_Psi
x0 = (r19 - 4) / 3
def cov(mons):
    Z = sum((w for _, w in mons), arb(0))
    m1 = [sum((w * e[i] for e, w in mons), arb(0)) / Z for i in range(4)]
    return [[sum((w * e[i] * e[j] for e, w in mons), arb(0)) / Z - m1[i] * m1[j] for j in range(4)] for i in range(4)], m1
CK, mK = cov([((1, 0, 1, 0), x0), ((1, 0, 0, 1), x0), ((0, 1, 1, 0), x0), ((0, 1, 0, 1), x0), ((0, 0, 1, 1), arb(1))])
CP, mP = cov([((1, 0, 1, 0), x0), ((1, 0, 0, 1), x0), ((0, 1, 1, 0), x0), ((0, 1, 0, 1), x0), ((1, 1, 0, 0), x0 * x0)])
grad = max(abs(3 * mK[i] + mP[i] - (1, 1, 3, 3)[i]) for i in range(4))
detH = arb_mat([[3 * CK[i][j] + CP[i][j] for j in range(3)] for i in range(3)]).det()
say('   alpha* critical:', grad < arb(10) ** -700, '  det H =', detH.str(25), '  (376096 sqrt19 - 1614848)/151875 =', ((376096 * r19 - 1614848) / 151875).str(25))
# the series at f*: rho = s^(1/2) sum e_m s^m, e_0 = 2 pi (2/f*)^(3/2)/sqrt(det H); midpoints, checked at a second precision
def series(NMAX):
    e = [2 * arb.pi() * (2 / fs) ** arb(1.5) / detH.sqrt()]
    half = arb(1) / 2; Tv = []
    for M in range(NMAX + 1):
        Tv.append([T[d](M + half) if d in T else arb(0) for d in range(dlo, dhi + 1)])
        if M == 0: continue
        acc = arb(0)
        for d in range(dlo + 1, dhi + 1):
            n = M + dlo - d
            if n < 0: break
            acc += e[n] * Tv[n][d - dlo]
        e.append((-acc / Tv[M][0]).mid())
    return e
NMAX = 1600
e = series(NMAX)
say('   m, e_m f*^m, e_m (f* - conjugate)^m:')
for m in (50, 100, 200, 400, 800, 1600):
    say(f'      {m:5d}  {(e[m] * fs ** m).str(10):>28s}  {(e[m] * (fs - fc) ** m).str(5):>26s}')
cc4 = [law[(4, 25)][4 - i](-z - 4) for i in range(5)]       # the order-4 law: sum_i c_i(k) P(k+i) = 0
cev = lambda i, k: arb(cc4[i](k).p) / arb(cc4[i](k).q)
def values_from(K0):
    half = arb(1) / 2; vals = {}
    for K in range(K0, K0 + 4):
        Bn = arb(K + 1).gamma() * arb(1.5).gamma() / (arb(K) + arb(2.5)).gamma()
        s_ = arb(0); fp = fs ** (K + half + 1)
        for m in range(NMAX + 1):
            term = e[m] * fp * Bn; s_ += term
            Bn = Bn * (m + arb(1.5)) / (K + m + arb(2.5)); fp *= fs
        vals[K] = s_
    tail = term / vals[K0 + 3]
    for k in range(K0 - 1, 0, -1):
        vals[k] = -sum((cev(i, k) * vals[k + i] for i in range(1, 5)), arb(0)) / cev(0, k)
    return vals, tail
r0 = arb(cc4[0].coeffs()[3].p) / arb(cc4[0].coeffs()[3].q)
assert all(x == 0 for x in cc4[0].coeffs()[:3])
for K0 in (80, 120):
    vals, tail = values_from(K0)
    say(f'   from K0 = {K0} (last Beta term / P = {tail.str(3)}):')
    say('      P(1) =', vals[1].mid().str(70, radius=False))
    say('      P(2) =', vals[2].mid().str(70, radius=False))
    say('      Cor = -sum_i c_i(0) P(i) / [k^3] c_0 =', (-sum((cev(i, 0) * vals[i] for i in range(1, 5)), arb(0)) / r0).mid().str(40, radius=False), '  (160/27 = 5.9259259...)')
    say('      12610378582200 P(1) - 133936231480200 P(2) + 160181043750000 P(3) - 5981712159277 =',
        (12610378582200 * vals[1] - 133936231480200 * vals[2] + 160181043750000 * vals[3] - 5981712159277).mid().str(3, radius=False))
    if K0 == 80: v80 = vals[1]
say('   P(1) from K0 = 80 minus P(1) from K0 = 120:', (v80 - vals[1]).mid().str(3, radius=False))
# the share side (Example 20.7(iii)), an independent check
ctx.prec = 240
def share(k):
    f_ = lambda tau, an: ((acb(arb(1) / 2) + acb(0, 1) * tau).gamma() ** 6 * (3 * k - acb(arb(1) / 2) - acb(0, 1) * tau).gamma()
                          * (k - acb(arb(1) / 2) - acb(0, 1) * tau).gamma() / (2 * (acb(arb(1) / 2) + acb(0, 1) * tau)).gamma() ** 2)
    return acb.integral(f_, -34, 34, rel_tol=arb(2) ** -230).real / (2 * arb.pi()) / (arb(3 * k).gamma() * arb(k).gamma())
say('   share side: P(1) =', share(1).str(62))
say('               P(2) =', share(2).str(62))

# ------------------------------------------------------------------------------------------------ 3
say('3. The three-mark centre from its gauge end')
ctx.prec = 2400
f3 = arb(1) / 9
def shift_poly(pp, a, sign):
    out = [fmpq(0)] * len(pp)
    for i, cq in enumerate(pp):
        for j in range(i + 1): out[j] += fmpq(cq) * comb(i, j) * fmpq(a) ** (i - j) * fmpq(sign) ** j
    return out
a9 = fmpq(1, 9)
q2 = shift_poly([0, 0, 1, -10, 9], a9, -1); q1 = [-x for x in shift_poly([0, 3, -40, 45], a9, -1)]; q0 = shift_poly([1, -23, 36], a9, -1)
e3 = [fmpq(1)]
N3 = 2200
for N in range(N3):
    s_ = fmpq(0)
    for d, pd in ((2, q2), (1, q1), (0, q0)):
        for j, pj in enumerate(pd):
            m = N - j + d
            if pj == 0 or m < 0 or m > len(e3) - 1: continue
            ff = 1
            for qq in range(m - d + 1, m + 1): ff *= qq
            s_ += pj * ff * e3[m]
    e3.append(-s_ / (q2[1] * (N + 1) * N + q1[0] * (N + 1)))
E3 = [27 * arb(3).sqrt() * arb.pi() * arb(x.p) / arb(x.q) for x in e3]   # rho(1/9) = 2 pi/(f* sqrt det H), det H = 4/27
def moments3(K):
    B = arb(1) / (K + 1); lf = f3.log(); psiK1 = arb(K + 1).digamma(); psit = arb(K + 2).digamma(); tri = arb(1) / arb(K + 1) ** 2
    S = [arb(0)] * 3; fp = f3 ** (K + 1)
    for m in range(N3 + 1):
        term = E3[m] * fp * B; gg = lf + psiK1 - psit
        S[0] += term; S[1] += term * gg; S[2] += term * (gg * gg + tri)
        B = B * (m + 1) / (K + m + 2); psit += arb(1) / (K + m + 2); tri += arb(1) / arb(K + m + 2) ** 2; fp *= f3
    return S, term / S[0]
K0 = 300
P0, P1_, P2_ = {}, {}, {}
for K in (K0, K0 + 1):
    (P0[K], P1_[K], P2_[K]), tail = moments3(K)
cf = [lambda k: arb(k) ** 2, lambda k: -(10 * arb(k) ** 2 + 10 * arb(k) + 3), lambda k: 9 * (arb(k) + 1) ** 2]
cd = [lambda k: 2 * arb(k), lambda k: -(20 * arb(k) + 10), lambda k: 18 * (arb(k) + 1)]
cdd = [2, -20, 18]
for k in range(K0 - 1, 0, -1):
    P0[k] = -(cf[1](k) * P0[k + 1] + cf[2](k) * P0[k + 2]) / cf[0](k)
    P1_[k] = -(cf[1](k) * P1_[k + 1] + cf[2](k) * P1_[k + 2] + sum((cd[i](k) * P0[k + i] for i in range(3)), arb(0))) / cf[0](k)
    P2_[k] = -(cf[1](k) * P2_[k + 1] + cf[2](k) * P2_[k + 2] + 2 * sum((cd[i](k) * P1_[k + i] for i in range(3)), arb(0))
               + sum((cdd[i] * P0[k + i] for i in range(3)), arb(0))) / cf[0](k)
ell, d1, d2 = P0[1], P1_[1], P2_[1]
say(f'   K0 = {K0}, last term / P = {tail.str(3)};  the slope relation of Prop. 20.10(i): 3P\'(1) - 9P\'(2) + 4l + 12 = {(3 * d1 - 9 * P1_[2] + 4 * ell + 12).str(3)}')
say('   the corner as an output (the law at k = 0, not used above): 3P(1) - 9P(2) =', (3 * P0[1] - 9 * P0[2]).str(40))
say('   l   =', ell.str(60)); say("   l'  =", d1.str(60)); say("   l'' =", d2.str(60))
ctx.prec = 1360
ell, d1, d2 = arb(ell.mid().str(392, radius=False)), arb(d1.mid().str(392, radius=False)), arb(d2.mid().str(392, radius=False))
pi = arb.pi(); r3 = arb(3).sqrt(); L3 = arb(3).log(); L2 = arb(2).log(); z3 = arb(3).zeta()
Lam = lambda s_: (arb(s_).zeta(arb(1) / 3) - arb(s_).zeta(arb(2) / 3)) / arb(3) ** s_      # sum_n (-3/n) n^-s
W = 1 - acb(0, 2 * pi / 3).exp()
G = -W.log() ** 2 * (1 - W).log() - 2 * W.log() * W.polylog(2) + 2 * W.polylog(3)
S3 = -(acb(0, 1) * G).real - ((2 * pi / 3 - pi) ** 3 + pi ** 3) / 12            # -int_0^{2pi/3} log^2(2 sin(x/2)) dx
t1 = time.time()
th = 2 * pi / 3
S4 = -acb.integral(lambda w, an: (-w).exp() * ((((-w).exp()) / 2).sin() * 2).log() ** 3, -th.log(), 960, rel_tol=arb(2) ** -1330).real
S3q = -acb.integral(lambda w, an: (-w).exp() * ((((-w).exp()) / 2).sin() * 2).log() ** 2, -th.log(), 960, rel_tol=arb(2) ** -1330).real
say(f'   S_3 = {S3.str(30)} (polylog) = {S3q.str(30)} (quadrature);  S_4 = {S4.str(30)}  ({time.time() - t1:.0f}s)')
def lll(vals, digits):
    sc = arb(10) ** digits; n = len(vals)
    M = fmpz_mat([[1 if j == i else 0 for j in range(n)] + [int((v * sc).mid().floor().unique_fmpz())] for i, v in enumerate(vals)]).lll()
    best = None
    for i in range(n):
        row = [int(M[i, j]) for j in range(n)]
        if row[0] == 0: continue
        hgt = max(abs(x) for x in row)
        if best is None or hgt < best[0]: best = (hgt, row, sum((arb(cq) * v for cq, v in zip(row, vals)), arb(0)))
    return best
Q1 = d1 + 2 * L3 * ell; Q2 = d2 + 4 * L3 * d1 + 4 * L3 ** 2 * ell
basis = {'1': arb(1), 'l': ell, 'l log2': ell * L2, 'l log3': ell * L3, 'l pi': ell * pi, 'l pi/r3': ell * pi / r3, 'zeta3': z3,
         'pi^2': pi ** 2, 'pi^2 log2': pi ** 2 * L2, 'pi^2 log3': pi ** 2 * L3, 'pi^3': pi ** 3, 'pi^3/r3': pi ** 3 / r3, 'pi/r3': pi / r3,
         'pi log2/r3': pi * L2 / r3, 'pi log3/r3': pi * L3 / r3, 'pi log2^2/r3': pi * L2 ** 2 / r3, 'pi log2 log3/r3': pi * L2 * L3 / r3,
         'pi log3^2/r3': pi * L3 ** 2 / r3, 'S3/r3': S3 / r3, 'S3': S3, 'log2': L2, 'log3': L3, 'log2^2': L2 ** 2, 'log2 log3': L2 * L3,
         'log3^2': L3 ** 2, 'log2^3': L2 ** 3, 'log2^2 log3': L2 ** 2 * L3, 'log2 log3^2': L2 * L3 ** 2, 'log3^3': L3 ** 3}
hgt, row, res = lll([d1] + list(basis.values()), 370)
say(f"   l' against {len(basis)} numbers (370 digits): height {hgt}, residual {res.str(3)}:", {(["l'"] + list(basis))[i]: row[i] for i in range(len(row)) if row[i]})
basis4 = {'1': arb(1), 'l': ell, 'pi^2': pi ** 2, 'pi/r3': pi / r3, 'zeta3': z3, 'pi^3/r3': pi ** 3 / r3, 'pi^3': pi ** 3, 'S3/r3': S3 / r3,
          'S3': S3, 'pi^4': pi ** 4, 'pi^4/r3': pi ** 4 / r3, 'l^2': ell ** 2, 'l pi^2': ell * pi ** 2, 'l pi/r3': ell * pi / r3,
          'l pi': ell * pi, 'zeta3 pi/r3': z3 * pi / r3, 'zeta3 pi': z3 * pi, 'pi S3/r3': pi * S3 / r3, 'pi S3': pi * S3,
          'Lam4': Lam(4), 'Lam4 r3': Lam(4) * r3, 'S4/r3': S4 / r3, 'S4': S4}
hgt, row, res = lll([Q2] + list(basis4.values()), 370)
say(f"   Q''(1) against {len(basis4)} numbers (370 digits): height {hgt}, residual {res.str(3)}:", {(["Q''"] + list(basis4))[i]: row[i] for i in range(len(row)) if row[i]})
say("   Q'(1) - (27/2)Lam(3) - 4 sqrt3 S_3 =", (Q1 - arb(27) / 2 * Lam(3) - 4 * r3 * S3).str(3))
say("   Q''(1) + pi^2 l/3 + 27 Lam(4) - (32/sqrt3)(S_4 - pi zeta3) =", (Q2 + pi ** 2 * ell / 3 + 27 * Lam(4) - 32 / r3 * (S4 - pi * z3)).str(3))
say('   Lam(3) - 4 pi^3/(81 sqrt3) =', (Lam(3) - 4 * pi ** 3 / (81 * r3)).str(3), ';  3 Lam(2) - l =', (3 * Lam(2) - ell).str(3))
say("   the relation for l'' itself (height 144): 3l'' + pi^2 l + 81 Lam(4) - 96 S_4/sqrt3 + 96 pi zeta3/sqrt3 + 8 pi^3 log3/sqrt3 + 144 S_3 log3/sqrt3 - 12 l log3^2 =",
    (3 * d2 + pi ** 2 * ell + 81 * Lam(4) - 96 * S4 / r3 + 96 * pi * z3 / r3 + 8 * pi ** 3 * L3 / r3 + 144 * S3 * L3 / r3 - 12 * ell * L3 ** 2).str(3))
b3 = {k: v for k, v in basis.items() if not k.startswith('S3')}
hgt, row, res = lll([S3 / r3] + list(b3.values()), 370)
say(f'   S_3/sqrt3 against the {len(b3)} other numbers of the first basis: smallest relation of height ~10^{len(str(hgt)) - 1} (none small)')
b4 = {k: v for k, v in basis4.items() if not k.startswith('S4')}
b4 |= {'z3 log3': z3 * L3, 'pi^3 log3/r3': pi ** 3 * L3 / r3, 'l log3^2': ell * L3 ** 2, 'S3 log3/r3': S3 * L3 / r3}
hgt, row, res = lll([S4 / r3] + list(b4.values()), 370)
say(f'   S_4/sqrt3 against {len(b4)} numbers of weight at most four: smallest relation of height ~10^{len(str(hgt)) - 1} (none small)')

# ------------------------------------------------------------------------------------------------ 4
say('4. The denominators of the three-mark centre ray')
KM = 702
cR = {1: Fraction(1), 2: Fraction(1, 3)}; rR = {1: Fraction(0), 2: Fraction(-2, 3)}
for k in range(1, KM):
    cR[k + 2] = ((10 * k * k + 10 * k + 3) * cR[k + 1] - k * k * cR[k]) / (9 * (k + 1) ** 2)
    rR[k + 2] = ((10 * k * k + 10 * k + 3) * rR[k + 1] - k * k * rR[k]) / (9 * (k + 1) ** 2)
xc = [sum(comb(j, k) ** 2 * comb(2 * k, k) for k in range(j + 1)) for j in range(KM + 1)]   # = sum (j!/(a!b!c!))^2
say('   closings sum_k C(j,k)^2 C(2k,k) = sum_{a+b+c=j} (j!/(a!b!c!))^2 for j <= 30:',
    all(xc[j] == sum((factorial(j) // (factorial(a) * factorial(b) * factorial(j - a - b))) ** 2 for a in range(j + 1) for b in range(j + 1 - a)) for j in range(31)))
say(f'   c(K) = x_(K-1)/9^(K-1) for K <= {KM}:', all(cR[K] == Fraction(xc[K - 1], 9 ** (K - 1)) for K in range(1, KM + 1)))
def v3(n):
    v = 0
    while n % 3 == 0: n //= 3; v += 1
    return v
Dd = {K: lcm(cR[K].denominator, rR[K].denominator) for K in range(1, KM + 1)}
say(f'   v3(D_K) = 2(K-1) - v3(x_(K-1)) for 2 <= K <= {KM}:', all(v3(Dd[K]) == 2 * (K - 1) - v3(xc[K - 1]) for K in range(2, KM + 1)),
    '   max v3(x_j):', max(v3(xc[j]) for j in range(KM)))
Lk = 1; lc = {}
for i in range(1, KM + 1): Lk = lcm(Lk, i); lc[i] = Lk
say(f'   the part of D_K prime to 3 divides lcm(1..K)^2 for every K <= {KM}:', all((lc[K] ** 2) % (Dd[K] // 3 ** v3(Dd[K])) == 0 for K in range(1, KM + 1)))
for K in (200, 300, 400, 500, 600, 700):
    say(f'   K = {K}: (1/K) log D_K = {log(Dd[K]) / K:.3f}, merit estimate log 9 - (1/K) log D_K = {log(9) - log(Dd[K]) / K:+.3f}')
for (K1, K2) in ((200, 240), (240, 280), (300, 360), (400, 440), (600, 640)):
    tot = (log(Dd[K2]) - log(Dd[K1])) / (K2 - K1)
    say(f'   window {K1}..{K2}: (log D_K2 - log D_K1)/(K2 - K1) = {tot:.3f}, "merit" {log(9) - tot:+.3f}')

# ------------------------------------------------------------------------------------------------ 5
say('5. The five-mark centre read from its gauge end (n = 5)')
J5 = 160
Sq = fmpq_poly([fmpq(1, factorial(m) ** 2) for m in range(J5)])
Pw = fmpq_poly([1])
for _ in range(5): Pw = fmpq_poly((Pw * Sq).coeffs()[:J5])
X5 = [int(Pw.coeffs()[j] * factorial(j) ** 2) for j in range(J5)]
say('   closings:', X5[:6])
h5, D5 = 3, 4
nunk = (h5 + 1) * (D5 + 1)
from flint import fmpq_mat
Mq = fmpq_mat(nunk + 20, nunk, [fmpq(X5[j + i] * j ** e) for j in range(nunk + 20) for i in range(h5 + 1) for e in range(D5 + 1)])
Rq, rk = Mq.rref()
assert nunk - rk == 1
piv = []; r = 0
for col in range(nunk):
    if r < rk and Rq[r, col] != 0: piv.append(col); r += 1
fr = [col for col in range(nunk) if col not in piv][0]
vq = [fmpq(0)] * nunk; vq[fr] = fmpq(1)
for i, pc in enumerate(piv): vq[pc] = -Rq[i, fr]
L_ = 1
for x in vq: L_ = lcm(L_, int(x.q))
vi = [int(x * L_) for x in vq]; gg = 0
for x in vi: gg = gcd(gg, x)
vi = [x // gg for x in vi]
say('   recurrence of order 3, degree 4, exact at all', J5 - h5, 'shifts:',
    all(sum(vi[i * (D5 + 1) + e] * X5[j + i] * j ** e for i in range(h5 + 1) for e in range(D5 + 1)) == 0 for j in range(J5 - h5)))
p5 = [fmpq_poly([vi[i * (D5 + 1) + e] for e in range(D5 + 1)]) for i in range(h5 + 1)]
for i in range(h5 + 1): say(f'      p_{i}(j) =', toZ(p5[i]).factor())
Q5 = [p5[h5 - i](z + (-h5 + i + 1)) for i in range(h5 + 1)]
c5 = [p5[h5 - i](-z - h5) for i in range(h5 + 1)]
sym5 = fmpq_poly([Q5[i].coeffs()[D5] if Q5[i].degree() >= D5 else 0 for i in range(h5 + 1)])
say('   density equation: symbol', toZ(sym5).factor(), '; indicial polynomial at 0', toZ(Q5[0]).factor())
f5 = fmpq(1, 25)
nuq = fmpq_poly([0, 1])
Cq = [[fmpq_poly([1])] + [fmpq_poly([0])] * D5]
for r in range(D5):
    new = [fmpq_poly([0])] * (D5 + 1)
    for j in range(D5 + 1):
        new[j] = new[j] + Cq[r][j] * (nuq - j)
        if j + 1 <= D5: new[j + 1] = new[j + 1] - f5 * Cq[r][j] * (nuq - j)
    Cq.append(new)
T5 = {}
for i in range(h5 + 1):
    W = [fmpq_poly([0])] * (D5 + 1)
    for r in range(D5 + 1):
        if r > Q5[i].degree() or Q5[i].coeffs()[r] == 0: continue
        for j in range(D5 + 1): W[j] = W[j] + Q5[i].coeffs()[r] * Cq[r][j]
    for l in range(i + 1):
        b = comb(i, l) * f5 ** (i - l) * (-1) ** l
        for j in range(D5 + 1): T5[l - j] = T5.get(l - j, fmpq_poly([0])) + b * W[j]
dl5 = 1 - D5; dh5 = max(T5)
assert T5[-D5] == 0
say('   indicial polynomial at f* = 1/25:', toZ(T5[dl5]).factor())
NF = D5 + 2
def nullsp(rows):
    Mm = fmpq_mat(len(rows), NF, [x for rw in rows for x in rw])
    Rr, rkk = Mm.rref()
    pv = []; r = 0
    for col in range(NF):
        if r < rkk and Rr[r, col] != 0: pv.append(col); r += 1
    out = []
    for fc in [col for col in range(NF) if col not in pv]:
        vec = [fmpq(0)] * NF; vec[fc] = fmpq(1)
        for i, pc in enumerate(pv): vec[pc] = -Rr[i, fc]
        out.append(vec)
    return out
frob = []
for N in range(NF):
    rw = [fmpq(0)] * NF
    for d in range(dl5, dh5 + 1):
        m = N + dl5 - d
        if 0 <= m < NF and d in T5: rw[m] += T5[d](m)
    frob.append(rw)
mass = []
for j in range(1, D5):
    rw = [fmpq(0)] * NF
    for m in range(0, D5 - j): rw[m] += T5[-m - j].derivative()(m)
    mass.append(rw)
hol = nullsp(frob); V0 = nullsp(frob + mass)
say(f'   holomorphic solutions at f*: dimension {len(hol)}; extending by zero: dimension {len(V0)}, germ h_0 = {V0[0][0]}')
chi5 = fmpq_poly([c5[i].coeffs()[D5] if c5[i].degree() >= D5 else 0 for i in range(h5 + 1)])
chi51 = fmpq_poly([c5[i].coeffs()[D5 - 1] if c5[i].degree() >= D5 - 1 else 0 for i in range(h5 + 1)])
say('   formal solution of the law at 1/25: rho =', -chi51(f5) / (f5 * chi5.derivative()(f5)))
ctx.prec = 1600
fsa = arb(1) / 25
g0 = (2 * arb.pi() / fsa) ** 2 / (arb(16) / 3125).sqrt()        # det H = 2^4/5^5
germ = V0[0]
sc = g0 / (arb(germ[1].p) / arb(germ[1].q))
e5 = [sc * arb(x.p) / arb(x.q) for x in germ]
N5 = 1200
for M in range(len(e5), N5 + 1):
    acc = arb(0)
    for d in range(dl5 + 1, dh5 + 1):
        m = M + dl5 - d
        if m < 0: break
        if d in T5:
            tv = T5[d](m); acc += e5[m] * arb(tv.p) / arb(tv.q)
    tm = T5[dl5](M)
    e5.append((-acc / (arb(tm.p) / arb(tm.q))).mid())
say('   e_m f*^m at m = 100, 400, 1200:', [(e5[m] * fsa ** m).str(8) for m in (100, 400, 1200)])
cv5 = lambda i, k: arb(c5[i](k).p) / arb(c5[i](k).q)
for K0 in (150, 250):
    vals = {}
    for K in range(K0, K0 + h5):
        B = arb(1) / (K + 1); fp = fsa ** (K + 1); s_ = arb(0)
        for m in range(N5 + 1):
            term = e5[m] * fp * B; s_ += term; B = B * (m + 1) / (K + m + 2); fp *= fsa
        vals[K] = s_
    for k in range(K0 - 1, 0, -1):
        vals[k] = -sum((cv5(i, k) * vals[k + i] for i in range(1, h5 + 1)), arb(0)) / cv5(0, k)
    say(f'   from K0 = {K0} (last term / P = {(term / vals[K0 + h5 - 1]).str(3)}): P(1) =', vals[1].mid().str(60, radius=False))
r04 = arb(c5[0].coeffs()[4].p) / arb(c5[0].coeffs()[4].q)
say('   Cor = -sum_i c_i(0) P(i) / [k^4] c_0 =', (-sum((cv5(i, 0) * vals[i] for i in range(1, h5 + 1)), arb(0)) / r04).mid().str(30, radius=False))
ctx.prec = 240
I1 = acb.integral(lambda u, an: (-2 * u).exp() * ((-u).exp()).bessel_k(0) ** 5, 0, 160, rel_tol=arb(2) ** -230)
I2 = acb.integral(lambda x, an: x * x.bessel_k(0) ** 5, 1, 40, rel_tol=arb(2) ** -230)
say('   share side, Gamma(1)^2 P(1) = int_0^oo G(1,y)^5 dy = 16 int_0^oo x K_0(x)^5 dx =', (16 * (I1 + I2)).real.str(60))

# ------------------------------------------------------------------------------------------------ 6
say('6. The germ at the gauge end is local data at alpha*')
import itertools
ctx.prec = 300
def jet_c1(letters, d):
    # letters: (strength, [(exponent tuple in the chart coordinates, weight at alpha*)]); returns det H and c_1
    H = {kk: arb(0) for kk in itertools.product(range(d), repeat=2)}
    h3 = {kk: arb(0) for kk in itertools.product(range(d), repeat=3)}
    h4 = {kk: arb(0) for kk in itertools.product(range(d), repeat=4)}
    for st, mons in letters:
        Z = sum((w for _, w in mons), arb(0))
        m1 = [sum((w * e[a] for e, w in mons), arb(0)) / Z for a in range(d)]
        cen = [([e[a] - m1[a] for a in range(d)], w / Z) for e, w in mons]
        def mom(idx):
            tot = arb(0)
            for x, w in cen:
                pr = w
                for i in idx: pr = pr * x[i]
                tot += pr
            return tot
        k2 = {kk: mom(kk) for kk in H}
        for kk in H: H[kk] += st * k2[kk]
        for kk in h3: h3[kk] -= st * mom(kk)
        for (a, b, c_, e_) in h4:
            h4[(a, b, c_, e_)] -= st * (mom((a, b, c_, e_)) - k2[(a, b)] * k2[(c_, e_)] - k2[(a, c_)] * k2[(b, e_)] - k2[(a, e_)] * k2[(b, c_)])
    G = arb_mat([[H[(a, b)] for b in range(d)] for a in range(d)]).inv()
    Rg = range(d)
    t1 = sum((h4[(a, b, c_, e_)] * G[a, b] * G[c_, e_] for a in Rg for b in Rg for c_ in Rg for e_ in Rg), arb(0)) / 8
    vv = [sum((h3[(a, b, c_)] * G[a, b] for a in Rg for b in Rg), arb(0)) for c_ in Rg]
    t2 = sum((vv[c_] * vv[f_] * G[c_, f_] for c_ in Rg for f_ in Rg), arb(0)) / 8
    t3 = sum((h3[(a, b, c_)] * h3[(e_, f_, q_)] * G[a, e_] * G[b, f_] * G[c_, q_]
              for a in Rg for b in Rg for c_ in Rg for e_ in Rg for f_ in Rg for q_ in Rg), arb(0)) / 12
    return arb_mat([[H[(a, b)] for b in range(d)] for a in range(d)]).det(), t1 + t2 + t3
def law_a1(cpolys, lam, rho):
    # formal solution lam^k k^rho (1 + a1/k + ...) of sum_i c_i(k) P(k+i) = 0: a1 from the third order
    Dg = max(cp.degree() for cp in cpolys)
    cc = [[arb(x.p) / arb(x.q) for x in cp.coeffs()] + [arb(0)] * (Dg + 1 - len(cp.coeffs())) for cp in cpolys]
    def bino(x, r):
        o = arb(1)
        for q_ in range(r): o = o * (x - q_) / (q_ + 1)
        return o
    def coeff(N, a1):
        tot = arb(0)
        for i in range(len(cc)):
            for e_ in range(Dg + 1):
                if cc[i][e_] == 0: continue
                for j, aj in ((0, arb(1)), (1, a1)):
                    r_ = e_ - j - (Dg - N)
                    if 0 <= r_ <= 3: tot += cc[i][e_] * lam ** i * aj * bino(arb(rho) - j, r_) * arb(i) ** r_
        return tot
    y0, y1 = coeff(2, arb(0)), coeff(2, arb(1))
    return coeff(0, arb(0)), coeff(1, arb(0)), -y0 / (y1 - y0)
E5 = [tuple(1 if j == i else 0 for j in range(4)) for i in range(4)] + [(0, 0, 0, 0)]     # chart alpha_5 = 1
dH5, c1_5 = jet_c1([(1, [(e, arb(1)) for e in E5]), (1, [(tuple(-x for x in e), arb(1)) for e in E5])], 4)
o0, o1, a1_5 = law_a1(c5, arb(1) / 25, -2)
say('   five-mark centre: det H =', dH5.str(12), '; law at 1/25: orders 0 and 1 vanish', (o0.str(3), o1.str(3)), '; a_1/a_0 =', a1_5.str(30))
say('                     c_1 from the cumulants of the letters =', c1_5.str(30))
x0j = (arb(19).sqrt() - 4) / 3; fsj = (7643 + 1064 * arb(19).sqrt()) / 1366875
mK = [((1, 0, 1), x0j), ((1, 0, 0), x0j), ((0, 1, 1), x0j), ((0, 1, 0), x0j), ((0, 0, 1), arb(1))]
mP = [((1, 0, 1), x0j), ((1, 0, 0), x0j), ((0, 1, 1), x0j), ((0, 1, 0), x0j), ((1, 1, 0), x0j * x0j)]
dH7, c1_7 = jet_c1([(3, mK), (1, mP)], 3)
c4l = [p4[4 - i](-z - 4) for i in range(5)]
o0, o1, a1_7 = law_a1(c4l, fsj, arb(-3) / 2)
say('   Example 20.7: det H =', dH7.str(12), '; law at f*: orders 0 and 1 vanish', (o0.str(3), o1.str(3)), '; a_1/a_0 =', a1_7.str(30))
say('                 c_1 from the cumulants of the letters =', c1_7.str(30))
say(f'total {time.time() - T0:.0f}s')
