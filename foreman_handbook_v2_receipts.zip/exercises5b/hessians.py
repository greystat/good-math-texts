"""The Hessian H of -log f at log alpha* on the chart alpha_n = 1 (Theorem thm:branch: the covariances of the
indicators under the basis law and the cobasis law at alpha*, weighted by s and t), exactly where alpha* is
known in closed form (N6 at both directions, V8 at (1;0,2)), and det H, f* in floating point for the others
(the ray reader's Newton step).  Run: python3 hessians.py > hessians.out"""
import itertools, sys
import sympy as sp
import mpmath as mp
from listsb import N6, V8, Q6, N7, load_list
sys.path.insert(0, '/home/claude/v2/receipts_src/rayreader/rayreader')
from rr.gauge import native_gauge  # noqa: E402


def hessian(lst, alpha, s, t):
    n = lst.n
    H = sp.zeros(n - 1, n - 1)
    for coef, cob in ((s, False), (t, True)):
        if coef == 0:
            continue
        sets = [tuple(i for i in range(n) if (i in T) != cob) for T in lst.bases]
        w = [sp.Mul(*[alpha[i] for i in S]) for S in sets]
        W = sum(w)
        X = [[1 if i in S else 0 for i in range(n - 1)] for S in sets]
        mean = [sum(wi * x[e] for wi, x in zip(w, X)) / W for e in range(n - 1)]
        for e in range(n - 1):
            for f in range(n - 1):
                H[e, f] += coef * (sum(wi * x[e] * x[f] for wi, x in zip(w, X)) / W - mean[e] * mean[f])
    return H


def main():
    x = sp.symbols('x')
    # N6 lean: alpha* = (x,x,x,1,1,1), x = (sqrt 21 - 3)/2
    r = (sp.sqrt(21) - 3) / 2
    H = hessian(N6(), [r, r, r, 1, 1, 1], 0, 2)
    d = sp.nsimplify(sp.radsimp(sp.simplify(H.det())))
    print('N6 (1;0,2): det H =', d, '=', sp.N(d, 30))
    # N6 centre: alpha* = 1, H = covariances under the weight laws (s = t = 1)
    H = hessian(N6(), [1] * 6, 1, 1)
    print('N6 (1;1,1): H =', H.tolist(), '; det H =', H.det(), '=', sp.N(H.det(), 30))
    # V8 lean: alpha* = (x 1_{P1 u P2}, 1_{P3 u P4}), x^3 + 8x^2 - 8 = 0
    H = hessian(V8(), [x] * 4 + [1] * 4, 0, 2)
    dV = sp.together(H.det())
    num, den = sp.fraction(dV)
    m = sp.Poly(x**3 + 8 * x**2 - 8, x)
    numr = sp.Poly(num, x).rem(m); denr = sp.Poly(den, x).rem(m)
    # invert den modulo the cubic
    inv = sp.invert(denr.as_expr(), m.as_expr(), x)
    red = sp.Poly(sp.expand(numr.as_expr() * inv), x).rem(m).as_expr()
    print('V8 (1;0,2): det H reduced in Q(x), x^3 + 8x^2 - 8 = 0:', sp.factor(red))
    for rt in m.nroots(n=30):
        if rt > 0:
            print('   at x =', rt, ': det H =', sp.N(red.subs(x, rt), 30))
    for name, L, mm, s, t in (('Q6', Q6(), (1, 3, 2, 3, 1, 2), 2, 2), ('N7', N7(), (1, 2, 2, 1, 2, 1, 1), 2, 1),
                              ('V8', V8(), (1,) * 8, 0, 2), ('N6 lean', N6(), (1,) * 6, 0, 2)):
        a, fstar, detH, G = native_gauge(L, mm, s, t, ([0] * L.n, 0, 0), 30)
        print(f'{name}: f* = {mp.nstr(fstar, 20)}, det H = {mp.nstr(detH, 20)}, alpha* = {[mp.nstr(z, 12) for z in a]}')


if __name__ == '__main__':
    main()
