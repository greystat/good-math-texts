"""The rows of the one-step matrix of a run, each written as one rational factor times a row of polynomials
(the factor: the gcd of the numerators over the lcm of the denominators), in LaTeX.
Usage: python3 matrix_rows_tex.py RUN_DIR"""
import os, pickle, sys
from functools import reduce
import sympy as sp

run = sys.argv[1]
with open(os.path.join(run, 'B_exact.pkl'), 'rb') as fh:
    B = pickle.load(fh)['B']
k = sp.symbols('k')
mu = int(round(len(B) ** 0.5))
for i in range(mu):
    ents = []
    for l in range(mu):
        P, Q = B[(i, l)]
        ents.append(sp.cancel(sum(sp.Rational(c.numerator, c.denominator) * k**e for e, c in enumerate(P)) /
                              sum(sp.Rational(c.numerator, c.denominator) * k**e for e, c in enumerate(Q))))
    nums = [sp.fraction(e)[0] for e in ents]; dens = [sp.fraction(e)[1] for e in ents]
    g = reduce(sp.gcd, [n for n in nums if n != 0])
    L = reduce(sp.lcm, dens)
    fac = sp.factor(g / L)
    rest = [sp.factor(sp.cancel(e / fac)) for e in ents]
    print(f'row {i + 1}: factor {sp.latex(fac)} ; entries ' + r',\ '.join(sp.latex(r) for r in rest))
