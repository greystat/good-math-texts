"""N6 at its centre (1;1,1): the slice (x,x,x,1,1,1), its critical points and native values; the values of the
spanning set at the signs, and B(oo) on them (exact, sympy).  Run: python3 nsix_centre_exact.py RUN_DIR"""
import os, pickle, sys, itertools
import sympy as sp
from listsb import N6, symmetries

run = sys.argv[1]
L = N6(); n = 6
x = sp.symbols('x')
f = x**3 / ((9*x**2 + 9*x + 1) * (x**3 + 9*x**2 + 9*x))
num = sp.factor(sp.numer(sp.together(sp.diff(sp.log(f), x))))
print('slice: f =', sp.factor(f), '; numerator of d log f/dx:', num)
for fac, e in sp.factor_list(sp.numer(sp.together(sp.diff(sp.log(f), x))))[1]:
    for r in sp.solve(fac, x):
        print('   root', r, ' f =', sp.nsimplify(sp.radsimp(sp.simplify(f.subs(x, r)))))
with open(os.path.join(run, 'masters.pkl'), 'rb') as fh:
    us = [u for (u, a, b) in pickle.load(fh)['masters']]
with open(os.path.join(run, 'B_exact.pkl'), 'rb') as fh:
    B = pickle.load(fh)['B']
mu = len(us); k = sp.symbols('k')
Binf = sp.zeros(mu, mu)
for (j, l), (P, Q) in B.items():
    Pk = sum(sp.Rational(c.numerator, c.denominator) * k**e for e, c in enumerate(P))
    Qk = sum(sp.Rational(c.numerator, c.denominator) * k**e for e, c in enumerate(Q))
    Binf[j, l] = sp.limit(Pk / Qk, k, sp.oo)
G = symmetries(L, (1,) * 6)
def beta(pt):
    out = []
    for u in us:
        vals = []
        for g in G:
            w = [0] * n
            for i in range(n):
                w[g[i]] = u[i]
            vals.append(sp.Mul(*[sp.nsimplify(pt[i])**w[i] for i in range(n)]))
            # Cremona: alpha -> alpha^-1 keeps the centre ray; its image of alpha^w is alpha^-w
            vals.append(sp.Mul(*[sp.nsimplify(pt[i])**(-w[i]) for i in range(n)]))
        out.append(sp.nsimplify(sum(vals) / len(vals)))
    return sp.Matrix(out)
print('masters:', us)
for eta in [(1, 1, 1, 1, 1, 1), (1, 1, 1, -1, -1, 1), (1, -1, -1, 1, 1, 1), (1, 1, -1, 1, -1, 1),
            (1, 1, 1, 1, -1, 1), (1, 1, -1, 1, 1, 1), (1, 1, -1, -1, -1, 1), (-1, -1, -1, 1, 1, 1)]:
    Kv = sum(sp.Mul(*[eta[i] for i in T]) for T in L.bases)
    b = beta(eta)
    lam = Kv**2
    print(f'sign {eta}: K = {Kv}; B(oo) beta - K^2 beta = 0: {list(Binf * b - lam * b) == [0] * mu}')
r = (-5 - sp.sqrt(21)) / 2
b = beta([r, r, r, 1, 1, 1])
print('slice point x = (-5 - sqrt 21)/2: B(oo) beta + 80 beta = 0:', all(sp.simplify(z) == 0 for z in (Binf * b + 80 * b)))
M = sp.Matrix.hstack(*[beta(e) for e in [(1, 1, 1, 1, 1, 1), (1, 1, 1, -1, -1, 1), (1, -1, -1, 1, 1, 1), (1, 1, -1, 1, -1, 1)]] + [b])
print('rank of these five vectors:', M.rank(simplify=True))
