"""The law of N6 against its constant terms (Corollary cor:rays-lowend(i)): sum_i c_i(-j) CT(f^(i-j)) = 0 for
every j in N, checked exactly for j <= J with the constant terms of exercise ex:listsb-nletters.
Usage: python3 nsix_ctcheck.py RUN_DIR (lean|centre) J"""
import os, pickle, sys
from nsix_exact import ct_centre, ct_lean

run, which, J = sys.argv[1], sys.argv[2], int(sys.argv[3])
with open(os.path.join(run, 'law_exact.pkl'), 'rb') as fh:
    c = pickle.load(fh)['c']
h = len(c) - 1
ct = ct_lean if which == 'lean' else ct_centre
x = [ct(j) for j in range(J + 1)]
def ev(p, k):
    acc = 0
    for a in reversed(p):
        acc = acc * k + a
    return acc
bad = [j for j in range(J + 1) if sum(ev(c[i], -j) * x[j - i] for i in range(0, min(h, j) + 1)) != 0]
print(f'N6 {which}: law of order {h}; constant terms x_0..x_{J} (x_{J} has {len(str(x[J]))} digits); '
      f'sum_i c_i(-j) x_(j-i) = 0 for j = 0..{J}: {"all" if not bad else "fails at " + str(bad[:5])}')
