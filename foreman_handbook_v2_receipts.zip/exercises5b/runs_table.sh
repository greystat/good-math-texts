#!/bin/sh
# The ray reader on every ray of the exercises of XI.5 (second half): items 33, 34 and 36.
# Each run keeps its log, its law and its value in RUNS/<name>/; the printed output is RUNS/<name>.stdout.
# Usage: sh runs_table.sh RUNS [WORKERS]
RR=/home/claude/v2/receipts_src/rayreader/rayreader
RUNS=${1:-runs}
W=${2:-2}
mkdir -p "$RUNS"
run() {  # name list direction
  ( cd "$RR" && python3 rayreader.py "$2" "$3" --digits 30 --workers "$W" --run "$RUNS/$1" ) > "$RUNS/$1.stdout" 2>&1
  tail -1 "$RUNS/$1.stdout"
}
run three_centre three "1 1 1 ; 1 1"
run banana4_centre banana4 "1 1 1 1 ; 1 1"
run MK4_lean MK4 "1 1 1 1 1 1 ; 0 2"
run banana5_centre banana5 "1 1 1 1 1 ; 1 1"
run three_lean three "2 2 2 ; 4 1"
run H_centre H "1 1 1 1 ; 1 1"
run H_slit H "1 1 3 3 ; 3 1"
run U25_centre U25 "1 1 1 1 1 ; 1 1"
run N_lean N "1 1 1 1 1 1 ; 0 2"
run N_centre N "1 1 1 1 1 1 ; 1 1"
run three_half three "1/2 1 3/2 ; 1 1"
run U24_lean /home/claude/v2/new/exercises5b/scripts/U24.json "1 1 1 1 ; 0 2"
run U24_centre /home/claude/v2/new/exercises5b/scripts/U24.json "1 1 1 1 ; 1 1"
run V_lean V "1 1 1 1 1 1 1 1 ; 0 2"
# The table at 60 digits: each finished run copied to RUNS/d60/<name> and read again with --digits 60 (the law
# is reused, so only the gauge end runs); then table_summary.py RUNS/d60, table_check.py RUNS/d60,
# table_masters.py (one call per ray, as in table_masters.out) and tests/check_run.py RUNS/d60/<name> 3.
