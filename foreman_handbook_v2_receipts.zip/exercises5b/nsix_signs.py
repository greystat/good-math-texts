"""The signs of the centre ray of N6 (Theorem thm:signgauges): K(eta) at the 32 signs of the chart eta_6 = 1,
their orbits under the 36 automorphisms, the native values K(eta)^-2, and the determinant of the Hessian of
log f at each (in the chart alpha_e = eta_e e^(y_e), Theorem thm:signgauges(ii)).  Exact (sympy).
Run: python3 nsix_signs.py > nsix_signs.out"""
import itertools
import sympy as sp
from listsb import N6, symmetries

L = N6(); n = 6
G = symmetries(L, (1,) * 6)
y = sp.symbols('y1:6')
def K_at(al):
    return sum(sp.Mul(*[al[i] for i in T]) for T in L.bases)
def P_at(al):
    return sum(sp.Mul(*[al[i] for i in range(n) if i not in T]) for T in L.bases)
signs = [tuple(list(e) + [1]) for e in itertools.product((1, -1), repeat=5)]
seen = {}
orbits = []
for eta in signs:
    key = None
    for g in G:
        w = [0] * n
        for i in range(n):
            w[g[i]] = eta[i]
        w = tuple(x * w[5] for x in w)      # back to the chart eta_6 = 1
        if w in seen:
            key = seen[w]; break
    if key is None:
        key = len(orbits); orbits.append([])
    seen[eta] = key; orbits[key].append(eta)
for o in orbits:
    eta = o[0]
    Kv = K_at(eta); Pv = P_at(eta)
    al = [eta[i] * sp.exp(y[i]) for i in range(5)] + [1]
    logf = sp.log(sp.Mul(*al)) - sp.log(K_at(al)) - sp.log(P_at(al))
    Hs = sp.Matrix(5, 5, lambda i, j: sp.diff(logf, y[i], y[j])).subs({v: 0 for v in y})
    print(f'orbit of {eta}: {len(o)} signs; K = {Kv}, Psi = {Pv}; native value f = {sp.Rational(1, Kv * Pv) if Kv * Pv else "inf"}; '
          f'det of the Hessian of log f = {sp.nsimplify(Hs.det())}')
