"""The native gauges of a direction by a Groebner basis over Q (Singular, characteristic 0): the critical
equations at the direction's own exponents, a_e K Psi - s (x_e d_e K) Psi - t K (x_e d_e Psi) = 0 on the chart
alpha_n = 1 (one letter dropped when its exponent is 0), saturated by the coordinates and by both letters
(the letter complement X_F of Definition def:ray inverts every letter).  Prints the dimension of the ideal
and, when it is 0, its vdim: the number of native gauges counted with multiplicity.  An exact computation.

Usage: python3 gb_direction.py LIST "m_1 ... m_n ; s t" [--char P] [--timeout SEC]"""
import argparse, subprocess, tempfile, os, time
from gb_count import poly_str
from listsb import load_list

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('list'); ap.add_argument('direction')
    ap.add_argument('--char', type=int, default=0)
    ap.add_argument('--timeout', type=int, default=3600)
    args = ap.parse_args()
    lst = load_list(args.list); n = lst.n
    left, right = args.direction.split(';')
    m = [int(x) for x in left.split()]; s, t = [int(x) for x in right.split()]
    vars_ = ','.join(f'x{i + 1}' for i in range(n - 1))
    L = ['LIB "elim.lib";', f'ring r = {args.char}, ({vars_}), dp;', 'option(redSB);',
         f'poly K = {poly_str(lst, "K")};', f'poly P = {poly_str(lst, "P")};']
    eqs = []
    for e in range(n - 1):
        xe = f'x{e + 1}'
        if s and t:
            eqs.append(f'{m[e]}*K*P - {s}*{xe}*diff(K,{xe})*P - {t}*K*{xe}*diff(P,{xe})')
        elif t:
            eqs.append(f'{m[e]}*P - {t}*{xe}*diff(P,{xe})')
        else:
            eqs.append(f'{m[e]}*K - {s}*{xe}*diff(K,{xe})')
    L.append('ideal I = ' + ', '.join(eqs) + ';')
    L.append('def Js = sat(I, ' + '*'.join(f'x{i + 1}' for i in range(n - 1)) + '*K*P);')
    L.append('ideal J; if (typeof(Js) == "list") { J = Js[1]; } else { J = Js; }')
    L.append('ideal G = std(J);')
    L.append('print("dim"); print(dim(G)); print("vdim"); print(vdim(G));')
    L.append('quit;')
    with tempfile.NamedTemporaryFile('w', suffix='.sing', delete=False) as fh:
        fh.write('\n'.join(L) + '\n'); path = fh.name
    t0 = time.time()
    try:
        out = subprocess.run(['Singular', '-q', path], capture_output=True, text=True, timeout=args.timeout,
                             stdin=subprocess.DEVNULL).stdout
    except subprocess.TimeoutExpired:
        out = 'timeout'
    os.unlink(path)
    print(f'{lst.name} at ({" ".join(map(str, m))}; {s}, {t}), characteristic {args.char}:',
          out.strip().replace('\n', ' '), f'[{time.time() - t0:.0f}s]')

if __name__ == '__main__':
    main()
