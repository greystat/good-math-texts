"""The lists of exercises XI.5 (second half), defined by their marks and bases, with exact helpers.

Marks are numbered 0..n-1 here (mark i is the mark i+1 of the text).  The lists:

  N6  rank 3 on 6 marks, bases: every triple but {1,2,3}            (text: N_6)
  N7  rank 3 on 7 marks, bases: every triple but {1,2,5}            (text: N_7)
  Q6  rank 3 on 6 marks, bases: every triple but {1,3,6},{2,3,4},{2,5,6}   (text: Q_6)
  V8  rank 4 on 8 marks, pairs P1={1,2},P2={3,4},P3={5,6},P4={7,8}; bases: the 4-sets
      other than the five unions P_i u P_j with {i,j} != {3,4}       (text: V_8)

The ray reader's own definitions (rr/lists.py) give N6 and V8 as 'N' and 'V'; Q6 and N7 are written as JSON
files for it by write_json() below.  Everything here is exact (fractions, integers)."""
import itertools, json, os, sys
from fractions import Fraction as Fr

RR = '/home/claude/v2/receipts_src/rayreader/rayreader'
sys.path.insert(0, RR)
from rr.lists import List, load_list  # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))


def N6():
    return List(6, [T for T in itertools.combinations(range(6), 3) if T != (0, 1, 2)], 'N6')


def N7():
    return List(7, [T for T in itertools.combinations(range(7), 3) if T != (0, 1, 4)], 'N7')


def Q6():
    bad = {(0, 2, 5), (1, 2, 3), (1, 4, 5)}
    return List(6, [T for T in itertools.combinations(range(6), 3) if T not in bad], 'Q6')


def V8():
    P = [(0, 1), (2, 3), (4, 5), (6, 7)]
    bad = {tuple(sorted(P[i] + P[j])) for i, j in itertools.combinations(range(4), 2) if {i, j} != {2, 3}}
    return List(8, [T for T in itertools.combinations(range(8), 4) if T not in bad], 'V8')


def write_json(lst, path):
    with open(path, 'w') as fh:
        json.dump(lst.to_json(), fh)
    return path


def walls(lst, m, s, t):
    """kappa_{1,S} = m(S) - s d(S) - t d*(S) for every nonempty proper S (d, d*: least traces of a basis and
    of a cobasis on S), as a dict frozenset -> Fraction"""
    n, r = lst.n, lst.r
    out = {}
    full = set(range(n))
    for k in range(1, n):
        for S in itertools.combinations(range(n), k):
            S = frozenset(S)
            d = min(len(S & set(T)) for T in lst.bases)            # least trace of a basis
            dstar = min(len(S - set(T)) for T in lst.bases)        # least trace of a cobasis
            out[S] = sum(Fr(m[i]) for i in S) - s * d - t * dstar
    return out


def volume(lst, m, s, t):
    """V_1 = sum over orders pi of prod_{l=2}^n kappa_{1,U_l}^{-1}, U_l the tails, by the recursion over chains
    F(U) = kappa(U)^{-1} sum_{e in U} F(U - e), F({e}) = kappa({e})^{-1}, V_1 = sum_e F(E - e)"""
    n = lst.n
    w = walls(lst, m, s, t)
    F = {}
    for k in range(1, n):
        for S in itertools.combinations(range(n), k):
            S = frozenset(S)
            if k == 1:
                F[S] = 1 / w[S]
            else:
                F[S] = sum(F[S - {e}] for e in S) / w[S]
    full = frozenset(range(n))
    return sum(F[full - {e}] for e in range(n))


def symmetries(lst, m):
    return [g for g in lst.automorphisms() if all(m[g[i]] == m[i] for i in range(lst.n))]


def heights(w):
    """the walls by height, as a sorted list of (height, count)"""
    c = {}
    for v in w.values():
        c[v] = c.get(v, 0) + 1
    return sorted(c.items())
