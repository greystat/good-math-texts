"""Integer relations among the values of N6 at (1;0,2) and at (1;1,1), by lattice reduction (exercise on N_6,
the value span).  Floating point enters only here, and only as a search: every relation printed is a vector
of integers, and its residual on values read to DIGITS digits is printed beside it.

1. The values P(1), ..., P(h+1) at DIGITS digits by the gauge end (the ray reader's stage 5, on the run
   directories of runs_table.sh, whose law is cached).
2. The low-end relation [k^(n-1)] c_0 * V_1 + sum_i c_i(0) P(i) = 0 checked on them (V_1 = 66, 63).
3. LLL on the lattice of the vectors (x, round(X * <x, v>)) for v = (1, P(1), ..., P(N)) and a scale X = 10^E,
   E below the digits: the short vectors with residual near 10^-DIGITS are relations; the next ones show the
   size of the generic vectors.
4. The same with the three-mark centre l = P_{binom[3]1}(1;1,1) and the Trailmoment T3 = Tx3(I_Z)(0) adjoined
   (both by their closed forms in arb: l = (zeta(2,1/3) - zeta(2,2/3))/3, T3 = zeta(3)).

Usage: python3 valuespan_N.py RUNROOT DIGITS > valuespan_N.out"""
import os, pickle, sys
from fractions import Fraction as Fr
from flint import arb, fmpz_mat, ctx
RR = '/home/claude/v2/receipts_src/rayreader/rayreader'
sys.path.insert(0, RR)
import rayreader  # noqa: E402


def values(run, direction, digits):
    res = rayreader.main(['N', direction, '--digits', str(digits), '--run', run, '--workers', '1'])
    with open(os.path.join(run, 'law_exact.pkl'), 'rb') as fh:
        law = pickle.load(fh)
    P = {int(k): v for k, v in res['values'].items()}
    return P, law['c']


def lll_relations(nums, E, names):
    """LLL on the rows (e_i, round(10^E * nums_i)); returns the reduced rows as integer vectors with the
    residuals sum_i x_i nums_i"""
    N = len(nums)
    X = arb(10) ** E
    rows = []
    for i, v in enumerate(nums):
        r = [0] * N; r[i] = 1
        r.append(int((v * X).mid().floor().unique_fmpz()))
        rows.append(r)
    M = fmpz_mat(rows).lll()
    out = []
    for i in range(M.nrows()):
        x = [int(M[i, j]) for j in range(N)]
        res = sum((arb(c) * v for c, v in zip(x, nums)), arb(0))
        height = max(abs(c) for c in x)
        out.append((height, x, res))
    out.sort(key=lambda z: z[0])
    return out


def show(title, rel, names, nmax=6):
    print(title)
    for height, x, res in rel[:nmax]:
        terms = ' '.join(f'{c:+d}*{nm}' for c, nm in zip(x, names) if c)
        r = abs(res).mid()
        print(f'   height {float(height):.3e}  residual {r.str(3, radius=False)}:  {terms if len(terms) < 900 else terms[:900] + " ..."}')


def main():
    root, digits = sys.argv[1], int(sys.argv[2])
    ctx.prec = int(3.33 * (digits + 30))
    ell = (arb(2).zeta(arb(1) / 3) - arb(2).zeta(arb(2) / 3)) / 3
    T3 = arb(3).zeta()
    print(f'l = {ell.mid().str(40, radius=False)}...; T3 = {T3.mid().str(40, radius=False)}...')
    for tag, direction, V1, N in (('lean', '1 1 1 1 1 1 ; 0 2', 66, 6), ('centre', '1 1 1 1 1 1 ; 1 1', 63, 12)):
        P, c = values(os.path.join(root, f'N_{tag}'), direction, digits)
        ctx.prec = int(3.33 * (digits + 30))
        n = 6
        h = len(c) - 1
        low = arb(c[0][n - 1]) * V1 + sum((arb(c[i][0]) * P[i] for i in range(1, h + 1)), arb(0))
        big = max(abs(arb(c[i][0]) * P[i]).mid() for i in range(1, h + 1))
        print(f'\nN6 {tag}: law of order {h}; c_0 vanishes to order {n - 1} at 0: {all(x == 0 for x in c[0][:n - 1])}; '
              f'[k^5]c_0 = {c[0][n - 1]}; c_i(0) = {[c[i][0] for i in range(1, h + 1)]}')
        print(f'   low-end relation on the values: {low.mid().str(3, radius=False)} (terms up to {arb(big).str(3, radius=False)})')
        for k in sorted(P):
            print(f'   P({k}) = {P[k].mid().str(70, radius=False)}...')
        E = digits - 40
        nums = [arb(1)] + [P[i] for i in range(1, N + 1)]
        names = ['1'] + [f'P({i})' for i in range(1, N + 1)]
        show(f'   relations among {", ".join(names)} (scale 10^{E}):', lll_relations(nums, E, names), names, N + 1)
        if tag == 'lean':
            nums = [arb(1), P[1], P[2], P[3], ell]
            names = ['1', 'P(1)', 'P(2)', 'P(3)', 'l']
        else:
            nums = [arb(1)] + [P[i] for i in range(1, 9)] + [ell, T3]
            names = ['1'] + [f'P({i})' for i in range(1, 9)] + ['l', 'T3']
        show(f'   relations among {", ".join(names)} (scale 10^{E}):', lll_relations(nums, E, names), names, len(nums))


if __name__ == '__main__':
    main()
