"""The native gauges of a direction reached from the generic critical points along several paths: every
generic solution saved by critpoints.py is carried from p0 to the direction's exponents along the broken
segment p0 -> p_mid -> p_dir for several random complex p_mid; the points reached by any path are united,
polished, and sorted into orbits and native values.  Each nondegenerate native gauge is the end of exactly
one path from the generic solutions along any one route that misses the exceptional parameters; a path that
stops early (step size underflow) is a tracking failure, and another route catches its end.  Floating point:
a numerical census.

Usage: python3 census_paths.py CENSUS.json [ROUTES] [--out FILE]"""
import argparse, json, time
import numpy as np
from listsb import load_list, symmetries
from critpoints import System, track, newton, canon, dist, census as _unused  # noqa: F401


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('census'); ap.add_argument('routes', nargs='?', type=int, default=4)
    ap.add_argument('--seed', type=int, default=11)
    ap.add_argument('--out', default=None)
    args = ap.parse_args()
    d = json.load(open(args.census))
    lst = load_list(d['list'])
    left, right = d['direction'].split(';')
    mvec = [float(x) for x in left.split()]; s, t = [float(x) for x in right.split()]
    sysm = System(lst, s != 0, t != 0)
    n = lst.n
    p0 = np.array([complex(a, b) for a, b in d['p0']])
    sols = np.array([[complex(a, b) for a, b in v] for v in d['generic solutions y']])
    pd = np.zeros(n + 2, complex); pd[:n] = mvec
    if sysm.useK:
        pd[n] = s
    if sysm.useP:
        pd[n + 1] = t
    rng = np.random.default_rng(args.seed)
    T0 = time.time()
    found = []
    for r in range(args.routes):
        if r == 0:
            Y, done, tau = track(sysm, sols, p0, pd)
        else:
            pm = p0.copy()
            pm[:n] = pd[:n] + (rng.normal(size=n) + 1j * rng.normal(size=n)) * 0.7
            if sysm.useK:
                pm[n] = pd[n] + (rng.normal() + 1j * rng.normal()) * 0.7
            if sysm.useP:
                pm[n + 1] = pd[n + 1] + (rng.normal() + 1j * rng.normal()) * 0.7
            pm[n - 1] += (pm[n] * lst.r + pm[n + 1] * (n - lst.r)) - pm[:n].sum()
            Y, done1, _ = track(sysm, sols, p0, pm)
            Y2, done, tau = track(sysm, Y[done1], pm, pd)
            Y = Y2; done = done
        Yd, res, J = newton(sysm, Y, pd)
        sv = np.linalg.svd(J, compute_uv=False)[:, -1]
        ok = done & np.isfinite(res) & (res < 1e-11) & (np.abs(Yd.real).max(axis=1) < 40) & (sv > 1e-8)
        stopped = (~done).sum()
        new = 0
        for v in canon(Yd[ok]):
            if not found or dist(np.array(found), v).min() > 1e-6:
                found.append(v); new += 1
        print(f'route {r}: {int(ok.sum())} nondegenerate ends, {int(stopped)} paths not reaching the end; '
              f'{new} new; union {len(found)} [{time.time() - T0:.0f}s]', flush=True)
    pts = np.array(found)
    vals = []
    for v in pts:
        al = np.exp(np.append(v, 0))
        Kv = sum(np.prod([al[i] for i in T]) for T in lst.bases)
        Pv = sum(np.prod([al[i] for i in range(n) if i not in T]) for T in lst.bases)
        vals.append(np.prod(al ** np.array(mvec)) / (Kv ** s * Pv ** t))
    vals = np.array(vals)
    G = symmetries(lst, [int(round(x)) for x in mvec])
    def act(g, v):
        al = np.append(v, 0.0); w = np.empty(n, complex)
        for i in range(n):
            w[g[i]] = al[i]
        w = w - w[n - 1]
        return canon(w[None, :n - 1])[0]
    lab = -np.ones(len(pts), int); norb = 0; closed = True
    for i in range(len(pts)):
        if lab[i] >= 0:
            continue
        for g in G:
            w = act(g, pts[i]); dd = dist(pts, w); j = int(np.argmin(dd))
            if dd[j] < 1e-5:
                lab[j] = norb
            else:
                closed = False
        norb += 1
    dv = []
    for v in vals:
        if not dv or min(abs(v - w) / abs(v) for w in dv) > 1e-8:
            dv.append(v)
    sizes = sorted(int((lab == o).sum()) for o in range(norb))
    print(f'union: {len(pts)} native gauges, {norb} orbits of the {len(G)} automorphisms (sizes {sizes}); '
          f'every orbit complete: {closed}; {len(dv)} distinct native values')
    for v in sorted(dv, key=lambda z: (abs(z), z.real)):
        cnt = sum(1 for w in vals if abs(w - v) <= 1e-8 * abs(v))
        orbs = len({int(lab[i]) for i in range(len(vals)) if abs(vals[i] - v) <= 1e-8 * abs(v)})
        print(f'   {v.real:+.12e} {v.imag:+.6e}i: {cnt} gauges in {orbs} orbit(s)')
    if args.out:
        json.dump({'census': args.census, 'routes': args.routes, 'gauges': len(pts), 'orbits': norb,
                   'orbit sizes': sizes, 'complete orbits': closed,
                   'native values': [[float(v.real), float(v.imag)] for v in vals], 'orbit labels': lab.tolist(),
                   'points y': [[[float(z.real), float(z.imag)] for z in v] for v in pts]}, open(args.out, 'w'), indent=1)


if __name__ == '__main__':
    main()
