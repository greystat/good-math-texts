"""Where the paths that do not arrive end: every generic solution of a census is carried to the direction,
and for each path that stops before tau = 1 the tau reached, the largest |Re y| (a coordinate running to 0 or
infinity) and the smallest |letter| are printed in summary.  Floating point.
Usage: python3 escape_check.py CENSUS.json"""
import json, sys
import numpy as np
from listsb import load_list
from critpoints import System, track

d = json.load(open(sys.argv[1]))
lst = load_list(d['list'])
left, right = d['direction'].split(';')
mvec = [float(x) for x in left.split()]; s, t = [float(x) for x in right.split()]
sysm = System(lst, s != 0, t != 0); n = lst.n
p0 = np.array([complex(a, b) for a, b in d['p0']])
sols = np.array([[complex(a, b) for a, b in v] for v in d['generic solutions y']])
pd = np.zeros(n + 2, complex); pd[:n] = mvec
if sysm.useK: pd[n] = s
if sysm.useP: pd[n + 1] = t
Y, done, tau = track(sysm, sols, p0, pd, hmin=1e-13, ymax=200.0)
lK, lP = sysm.letters_log(Y)
bad = ~done
big = np.abs(Y.real).max(axis=1)
print(f'{len(sols)} paths; {int(done.sum())} reach tau = 1; {int(bad.sum())} stop')
if bad.any():
    print('   tau at the stops: quantiles', np.round(np.quantile(tau[bad], [0, 0.25, 0.5, 0.75, 1]), 8).tolist())
    print('   largest |Re y| at the stops: quantiles', np.round(np.quantile(big[bad], [0, 0.25, 0.5, 0.75, 1]), 2).tolist())
    print('   log|Psi| at the stops: quantiles', np.round(np.quantile(lP[bad], [0, 0.25, 0.5, 0.75, 1]), 2).tolist())
    print('   stops with largest |Re y| > 30:', int((big[bad] > 30).sum()), '; with tau > 0.999999:', int((tau[bad] > 0.999999).sum()))
