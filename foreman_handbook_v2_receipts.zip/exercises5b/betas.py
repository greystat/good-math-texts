"""The values of the spanning set of an accepted box at the native gauges of a census (Proposition
prop:rays-spectrum): for one point of every orbit, the vector beta_c = (b_l(alpha_c))_l of the orbit averages
of the masters' monomials, polished at 40 digits; the rank of the matrix of these vectors and its smallest
singular value, and, when B is regular at infinity, the check B(oo) beta_c = f(alpha_c)^-1 beta_c.
Floating point (mpmath, 40 digits): a numerical check.

Usage: python3 betas.py RUN_DIR CENSUS.json"""
import json, os, pickle, sys
import mpmath as mp
from listsb import load_list, symmetries
from polish import polish


def main():
    run, cpath = sys.argv[1], sys.argv[2]
    mp.mp.dps = 40
    d = json.load(open(cpath))
    lst = load_list(d['list'])
    left, right = d['direction'].split(';')
    mvec = [int(x) for x in left.split()]; s, t = [int(x) for x in right.split()]
    n = lst.n
    G = symmetries(lst, mvec)
    with open(os.path.join(run, 'masters.pkl'), 'rb') as fh:
        M = pickle.load(fh)
    us = [u for (u, a, b) in M['masters']]
    mu = len(us)
    if os.path.exists(os.path.join(run, 'B_exact.pkl')):
        with open(os.path.join(run, 'B_exact.pkl'), 'rb') as fh:
            B = pickle.load(fh)['B']
        regular = all(len([c for c in P if c != 0]) == 0 or
                      max(i for i, c in enumerate(P) if c != 0) <= max(i for i, c in enumerate(Q) if c != 0)
                      for (P, Q) in B.values())
    else:
        B = {}; regular = False
        print('no B_exact.pkl yet: the vectors beta_c only')
    Binf = None
    if regular:
        Binf = mp.matrix(mu, mu)
        for (j, l), (P, Q) in B.items():
            dp = max([i for i, c in enumerate(P) if c != 0], default=-1)
            dq = max(i for i, c in enumerate(Q) if c != 0)
            if dp == dq:
                Binf[j, l] = mp.mpf(P[dp].numerator) / P[dp].denominator / (mp.mpf(Q[dq].numerator) / Q[dq].denominator)
    labels = d['census']['orbit labels']; pts = d['census']['points y']
    reps = {}
    for lab, y in zip(labels, pts):
        reps.setdefault(lab, y)
    rows = []; worst = mp.mpf(0)
    for lab in sorted(reps):
        y, fval, dt, Kv, Pv, res = polish(lst, mvec, s, t, reps[lab], 40)
        al = [mp.e ** y[i] for i in range(n - 1)] + [mp.mpf(1)]
        beta = []
        for u in us:
            vals = []
            for g in G:
                # the monomial alpha^(u o g^-1): u_e moved to g(e)
                w = [0] * n
                for i in range(n):
                    w[g[i]] = u[i]
                vals.append(mp.fprod(al[i] ** w[i] for i in range(n)))
            beta.append(mp.fsum(vals) / len(vals))
        rows.append(beta)
        if Binf is not None:
            bv = mp.matrix(beta)
            r = Binf * bv - bv / fval
            worst = max(worst, mp.norm(r) / mp.norm(bv))
        print(f'orbit {lab}: native value {mp.nstr(fval, 15)}; |det Hessian| {mp.nstr(abs(dt), 6)}')
    A = mp.matrix(rows)
    S = mp.svd_c(A, compute_uv=False)
    print(f'{len(rows)} orbit vectors of length {mu}; singular values: {[mp.nstr(S[i], 6) for i in range(min(A.rows, A.cols))]}')
    if Binf is not None:
        print(f'B is regular at infinity; largest relative |B(oo) beta - beta/f| over the orbits: {mp.nstr(worst, 5)}')


if __name__ == '__main__':
    main()
