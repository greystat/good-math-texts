"""The one-step matrix of a run over its monic common denominator Q_c: the numerators Q_c(k) B_il(k) as
polynomials in k with integer (or rational) coefficients, printed as LaTeX rows.
Usage: python3 matrix_tex.py RUN_DIR"""
import os, pickle, sys
from fractions import Fraction as Fr
import sympy as sp

run = sys.argv[1]
with open(os.path.join(run, 'B_exact.pkl'), 'rb') as fh:
    B = pickle.load(fh)['B']
k = sp.symbols('k')
mu = int(round(len(B) ** 0.5))
ent = {}
Qc = sp.Integer(1)
for key, (P, Q) in B.items():
    Pk = sum(sp.Rational(c.numerator, c.denominator) * k**e for e, c in enumerate(P))
    Qk = sum(sp.Rational(c.numerator, c.denominator) * k**e for e, c in enumerate(Q))
    ent[key] = sp.cancel(Pk / Qk)
    Qc = sp.lcm(Qc, sp.fraction(ent[key])[1])
Qc = sp.Poly(Qc, k).monic().as_expr()
print('Q_c =', sp.factor(Qc), '=', sp.expand(Qc))
for i in range(mu):
    row = []
    for l in range(mu):
        num = sp.expand(sp.cancel(ent[(i, l)] * Qc))
        row.append(sp.latex(sp.Poly(num, k).as_expr()) if num != 0 else '0')
    print(f'row {i + 1}:', ' & '.join(row))
