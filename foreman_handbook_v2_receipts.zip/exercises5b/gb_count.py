"""The number of critical points of alpha^a K^-bK Psi^-bP for random exponents, by a Groebner basis modulo a
prime (Singular): an exact count over the algebraic closure of F_p, independent of the monodromy census.

On the chart alpha_n = 1 the critical equations are, for e = 1, ..., n-1,
    a_e K Psi - bK (x_e d_e K) Psi - bP K (x_e d_e Psi) = 0
(only the letters the direction uses; with one letter the factor of the other is dropped), and the ideal is
saturated by the coordinates and the letters used.  Its vdim is the number of solutions with multiplicity
in the torus off the letters, the generic count when the exponents are generic: random exponents modulo p
are generic outside a proper Zariski-closed set, so a second draw that agrees is the check.

Usage: python3 gb_count.py LIST "s t" [--prime P] [--seed S] [--timeout SEC]"""
import argparse, random, subprocess, tempfile, os, time
from listsb import load_list


def poly_str(lst, which):
    n = lst.n
    terms = []
    for T in lst.bases:
        S = T if which == 'K' else tuple(i for i in range(n) if i not in T)
        mon = '*'.join(f'x{i + 1}' for i in S if i < n - 1)
        terms.append(mon if mon else '1')
    return '+'.join(terms)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('list'); ap.add_argument('st')
    ap.add_argument('--prime', type=int, default=32003)
    ap.add_argument('--seed', type=int, default=1)
    ap.add_argument('--timeout', type=int, default=3600)
    args = ap.parse_args()
    lst = load_list(args.list)
    s, t = [int(x) for x in args.st.split()]
    n = lst.n; p = args.prime
    rnd = random.Random(args.seed)
    bK = rnd.randrange(1, p) if s else 0
    bP = rnd.randrange(1, p) if t else 0
    a = [rnd.randrange(1, p) for _ in range(n - 1)]
    vars_ = ','.join(f'x{i + 1}' for i in range(n - 1))
    lines = [f'LIB "elim.lib";', f'ring r = {p}, ({vars_}), dp;', 'option(redSB);']
    lines.append(f'poly K = {poly_str(lst, "K")};')
    lines.append(f'poly P = {poly_str(lst, "P")};')
    eqs = []
    for e in range(n - 1):
        xe = f'x{e + 1}'
        if s and t:
            eqs.append(f'{a[e]}*K*P - {bK}*{xe}*diff(K,{xe})*P - {bP}*K*{xe}*diff(P,{xe})')
        elif t:
            eqs.append(f'{a[e]}*P - {bP}*{xe}*diff(P,{xe})')
        else:
            eqs.append(f'{a[e]}*K - {bK}*{xe}*diff(K,{xe})')
    lines.append('ideal I = ' + ', '.join(eqs) + ';')
    sat_by = '*'.join(f'x{i + 1}' for i in range(n - 1)) + ('*K' if s else '') + ('*P' if t else '')
    lines.append(f'def Js = sat(I, {sat_by});')
    lines.append('ideal J; if (typeof(Js) == "list") { J = Js[1]; } else { J = Js; }')
    lines.append('ideal G = std(J);')
    lines.append('print("dim"); print(dim(G)); print("vdim"); print(vdim(G));')
    lines.append('quit;')
    with tempfile.NamedTemporaryFile('w', suffix='.sing', delete=False) as fh:
        fh.write('\n'.join(lines) + '\n'); path = fh.name
    t0 = time.time()
    try:
        out = subprocess.run(['Singular', '-q', path], capture_output=True, text=True, timeout=args.timeout, stdin=subprocess.DEVNULL).stdout
    except subprocess.TimeoutExpired:
        out = 'timeout'
    os.unlink(path)
    print(f'{lst.name}, letters used: {"K " if s else ""}{"Psi" if t else ""}; prime {p}, seed {args.seed}, '
          f'exponents a = {a}, bK = {bK}, bP = {bP}')
    print(out.strip().replace('\n', ' '), f'[{time.time() - t0:.0f}s]')


if __name__ == '__main__':
    main()
