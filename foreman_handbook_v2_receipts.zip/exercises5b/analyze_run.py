"""Exact data read off a finished run of the ray reader: the box, the spanning set, the matrix B over Q(k)
(its common denominator Q_c factored over Q, the largest degree d_B of an entry in lowest terms, B at
infinite strength and its characteristic polynomial factored over Q when B is regular there), and the law
(order, degree, the largest coefficient, c_0 and c_h factored over Q, the order of c_0 at k = 0, the symbol
factored, and the coefficients of the low-end relation).  Everything exact (fmpz_poly / fmpq_poly).

Usage: python3 analyze_run.py RUN_DIR [n]   (n: the number of marks, for the low-end relation)"""
import os, pickle, sys
from fractions import Fraction as Fr
from math import lcm
from flint import fmpz_poly, fmpq_poly, fmpq_mat, fmpz, fmpq


def load(run, name):
    with open(os.path.join(run, name), 'rb') as fh:
        return pickle.load(fh)


def qpoly(coeffs):
    """fmpq_poly from a list of Fractions, lowest degree first"""
    return fmpq_poly([fmpq(int(c.numerator), int(c.denominator)) for c in coeffs])


def zfactor(p):
    """factor an fmpq_poly over Q: (content, [(factor, multiplicity)]) with primitive integer factors"""
    den = 1
    for c in p.coeffs():
        den = lcm(den, int(c.q))
    z = fmpz_poly([int(c * den) for c in p.coeffs()])
    c, fac = z.factor()
    return fmpq(int(c), den), fac


def fstr(content, fac, var='k', maxlen=400):
    parts = []
    for f, e in sorted(fac, key=lambda fe: (fe[0].degree(), str(fe[0]))):
        s = str(f).replace('x', var)
        if len(s) > maxlen:
            s = f'[irreducible of degree {f.degree()}, coefficients up to {max(len(str(abs(int(x)))) for x in f.coeffs())} digits]'
        else:
            s = f'({s})'
        parts.append(s + (f'^{e}' if e > 1 else ''))
    return f'{content} * ' + ' * '.join(parts)


def main():
    run = sys.argv[1]
    n = int(sys.argv[2]) if len(sys.argv) > 2 else None
    mres = load(run, 'masters.pkl')
    print(f'run {run}')
    print(f'box (t; a, b) = {mres["box"]}; spanning set ({len(mres["masters"])}): ' +
          ', '.join(f'alpha^{tuple(int(x) for x in u)}' for (u, a, b) in mres['masters'][:20]) +
          (' ...' if len(mres['masters']) > 20 else ''))
    info = mres.get('info', {})
    print(f'   box data: {info}')
    Bd = load(run, 'B_exact.pkl')['B']
    mu = len(mres['masters'])
    ent = {}
    Qc = fmpq_poly([1])
    dB = 0; vanish = 0
    for (j, l), (P, Q) in Bd.items():
        Pp, Qp = qpoly(P), qpoly(Q)
        if Pp == 0:
            vanish += 1; ent[(j, l)] = (Pp, fmpq_poly([1])); continue
        g = Pp.gcd(Qp)
        Pp, Qp = Pp / g, Qp / g        # exact division
        ent[(j, l)] = (Pp, Qp)
        dB = max(dB, Pp.degree(), Qp.degree())
        Qc = Qc * Qp / Qc.gcd(Qp)
    Qc = Qc / Qc.coeffs()[-1]
    num_deg = max(((ent[x][0] * (Qc / ent[x][1])).degree() for x in ent if ent[x][0] != 0), default=0)
    print(f'B: {mu}x{mu}, {vanish} entries vanish; largest degree of a numerator or denominator in lowest terms '
          f'd_B = {dB}; common denominator Q_c of degree {Qc.degree()}, numerators over it of degree at most {num_deg}')
    c, fac = zfactor(Qc)
    print(f'   Q_c = {fstr(c, fac)}')
    regular = all(ent[x][0].degree() <= ent[x][1].degree() for x in ent if ent[x][0] != 0)
    if regular:
        Binf = fmpq_mat(mu, mu)
        for (j, l), (Pp, Qp) in ent.items():
            if Pp != 0 and Pp.degree() == Qp.degree():
                Binf[j, l] = Pp.coeffs()[-1] / Qp.coeffs()[-1]
        cp = Binf.charpoly()
        c2, fac2 = zfactor(fmpq_poly(cp.coeffs()))
        print(f'   B is regular at infinity; det(lambda - B(oo)) = {fstr(c2, fac2, "lambda")}')
        if mu <= 8:
            print(f'   B(oo) = {Binf.tolist()}')
    else:
        excess = max(ent[x][0].degree() - ent[x][1].degree() for x in ent if ent[x][0] != 0)
        print(f'   B is not regular at infinity: an entry grows like k^{excess}')
    law = load(run, 'law_exact.pkl')
    cc = law['c']; h = law['order']
    D = max(len(x) for x in cc) - 1
    big = max(len(str(abs(int(x)))) for x in sum(cc, []))
    print(f'law: sum_j c_j(k) <1>_(k+j) = 0, order {h}, degree {D}, coefficients up to {big} digits')
    ps = [fmpz_poly([int(x) for x in cj]) for cj in cc]
    for idx in (0, h):
        cz, fz = ps[idx].factor()
        print(f'   c_{idx} = {fstr(cz, fz, maxlen=200)}')
    sym = fmpz_poly([int(ps[j].coeffs()[D]) if ps[j].degree() == D else 0 for j in range(h + 1)])
    cs, fs = sym.factor()
    print(f'   symbol sum_j [k^{D}]c_j lambda^j = {fstr(cs, fs, "lambda")}')
    ordz = next(i for i, x in enumerate(cc[0]) if x != 0)
    print(f'   c_0 vanishes to order {ordz} at k = 0')
    if n is not None:
        print(f'   low-end relation: [k^{n - 1}]c_0 = {cc[0][n - 1]}; c_i(0) = {[cc[i][0] for i in range(1, h + 1)]}')
    with open(os.path.join(run, 'value.txt')) as fh:
        print('value.txt:', fh.read().strip().replace('\n', ' | ')[:600])


if __name__ == '__main__':
    main()
