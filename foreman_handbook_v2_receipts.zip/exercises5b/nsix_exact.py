"""Exact computations for the exercises on N6 (rank three on [6], every triple a basis but a = {1,2,3}):
the constant terms of the reciprocal strides at the centre and at the full lean (1;0,2), by the bilinear
formula through the three-mark numbers g(i,l) and by direct expansion; the walls and the volume V_1 by types
(|S n a|, |S n b|); the eigenvector of B(oo) at the native gauge of the lean (from the run of the reader).
Run: python3 nsix_exact.py RUN_DIR_OF_N_LEAN > nsix_exact.out"""
import itertools, os, pickle, sys
from fractions import Fraction as Fr
from math import comb
import sympy as sp
from listsb import N6


def g(i, l):
    """the coefficient of alpha^(D 1) in Psi^i K^l on binom([3],1), D = (2i+l)/3 (0 unless 3 | 2i+l)"""
    if i < 0 or l < 0 or (2 * i + l) % 3:
        return 0
    D = (2 * i + l) // 3
    if (l - i) % 3:
        return 0
    return sum(comb(i, w) * comb(l, w + (l - i) // 3) * comb(2 * D - 2 * w, D - w)
               for w in range(0, i + 1) if 0 <= w + (l - i) // 3 <= l and D - w >= 0)


def g_direct(i, l):
    a = sp.symbols('a1:4')
    K = sum(a); P = a[0] * a[1] + a[0] * a[2] + a[1] * a[2]
    D = (2 * i + l) // 3
    return sp.Poly(sp.expand(P**i * K**l), *a).coeff_monomial(a[0]**D * a[1]**D * a[2]**D)


def ct_centre(j):
    return sum(comb(j, p) * comb(j, q) * comb(p + q, 2 * q - p) * g(2 * q - p, 2 * p - q) * g(2 * p - q, 2 * q - p)
               for p in range(j + 1) for q in range(j + 1) if 0 <= 2 * q - p <= p + q)


def ct_lean(j):
    return sum(comb(2 * j, p) * comb(p, 2 * p - 3 * j) * g(2 * p - 3 * j, 3 * j - p) * g(3 * j - p, 2 * p - 3 * j)
               for p in range(2 * j + 1) if 0 <= 2 * p - 3 * j <= p)


def ct_direct(j, which):
    """[alpha^(j 1)] (K Psi)^j or Psi^(2j) by a truncated expansion (exponents above j dropped)"""
    L = N6(); n = 6
    K = {tuple(1 if i in T else 0 for i in range(n)): 1 for T in L.bases}
    P = {tuple(0 if i in T else 1 for i in range(n)): 1 for T in L.bases}
    facs = [K, P] * j if which == 'centre' else [P] * (2 * j)
    cur = {(0,) * n: 1}
    for F in facs:
        new = {}
        for u, c in cur.items():
            for v, d in F.items():
                w = tuple(x + y for x, y in zip(u, v))
                if max(w) <= j:
                    new[w] = new.get(w, 0) + c * d
        cur = new
    return cur.get((j,) * n, 0)


def walls_by_type():
    L = N6()
    out = {}
    for which, (s, t) in (('lean', (0, 2)), ('centre', (1, 1))):
        tab = {}
        for k in range(1, 6):
            for S in itertools.combinations(range(6), k):
                S = set(S)
                i, jj = len(S & {0, 1, 2}), len(S & {3, 4, 5})
                d = min(len(S & set(T)) for T in L.bases); ds = min(len(S - set(T)) for T in L.bases)
                kap = len(S) - s * d - t * ds
                tab.setdefault((i, jj), set()).add(kap)
        assert all(len(v) == 1 for v in tab.values())
        kap = {k: v.pop() for k, v in tab.items()}
        F = {}
        for tot in range(1, 6):
            for i in range(0, 4):
                jj = tot - i
                if not 0 <= jj <= 3:
                    continue
                if tot == 1:
                    F[(i, jj)] = Fr(1, kap[(i, jj)])
                else:
                    F[(i, jj)] = (i * F.get((i - 1, jj), 0) + jj * F.get((i, jj - 1), 0)) / kap[(i, jj)]
        V1 = 3 * F[(2, 3)] + 3 * F[(3, 2)]
        out[which] = (kap, F, V1)
    return out


def main():
    print('three-mark numbers g(i,l), formula against expansion:')
    for (i, l) in [(0, 0), (1, 1), (0, 3), (3, 0), (2, 2), (4, 1), (1, 4), (3, 3), (5, 2), (2, 5), (4, 4), (6, 0), (0, 6)]:
        print(f'   g({i},{l}) = {g(i, l)} (expansion {g_direct(i, l)})')
    print('constant terms at the centre, formula:', [ct_centre(j) for j in range(8)])
    print('                         expansion:', [ct_direct(j, 'centre') for j in range(5)])
    print('constant terms at the lean, formula:  ', [ct_lean(j) for j in range(8)])
    print('                         expansion:', [ct_direct(j, 'lean') for j in range(5)])
    for which, (kap, F, V1) in walls_by_type().items():
        print(f'{which}: walls by type (|S n a|, |S n b|) -> kappa_1:', dict(sorted(kap.items())))
        print(f'   F by type:', {k: str(v) for k, v in sorted(F.items())})
        print(f'   V_1 = 3 F(2,3) + 3 F(3,2) = {V1}')
    if len(sys.argv) > 1:
        run = sys.argv[1]
        with open(os.path.join(run, 'masters.pkl'), 'rb') as fh:
            M = pickle.load(fh)
        with open(os.path.join(run, 'B_exact.pkl'), 'rb') as fh:
            B = pickle.load(fh)['B']
        mu = len(M['masters'])
        Binf = sp.zeros(mu, mu)
        k = sp.symbols('k')
        for (j, l), (P, Q) in B.items():
            Pk = sum(sp.Rational(c.numerator, c.denominator) * k**e for e, c in enumerate(P))
            Qk = sum(sp.Rational(c.numerator, c.denominator) * k**e for e, c in enumerate(Q))
            Binf[j, l] = sp.limit(Pk / Qk, k, sp.oo)
        x = (sp.sqrt(21) - 3) / 2
        beta = sp.Matrix([x**sum(u[:3]) for (u, a, b) in M['masters']])
        lam = sp.radsimp(1 / (x / (x**2 + 9 * x + 9)**2))
        print('masters (exponent vectors):', [u for (u, a, b) in M['masters']])
        print('B(oo) =', Binf.tolist())
        print('beta at the native gauge (x,x,x,1,1,1), x = (sqrt 21 - 3)/2:', [sp.nsimplify(sp.radsimp(v)) for v in beta])
        print('1/f* =', sp.simplify(lam))
        print('B(oo) beta - (1/f*) beta =', sp.simplify(sp.expand(Binf * beta - lam * beta)).T)


if __name__ == '__main__':
    main()
