"""One box of a ray, tested as the ray reader's masters stage does (Definition def:box-reduction): its relations
and symbols counted modulo the automorphisms fixing the masses (and the Cremona at a centre), one elimination
modulo 2^61 - 1 at a random strength, and for each spanning bound s = t-1, ..., 0 the free Laurent orbits of
wall degree at most s and whether their targets lie in the box and reduce to them.

Usage: python3 box_test.py LIST "m_1 ... m_n ; s t" T A B [--seed S]"""
import argparse, random, sys, time
sys.path.insert(0, '/home/claude/v2/receipts_src/rayreader/rayreader')
from rr.lists import load_list
from rr.ray import Ray
from rr.system import build_system
from rr.elim import run_cp

P61 = (1 << 61) - 1

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('list'); ap.add_argument('direction'); ap.add_argument('T', type=int)
    ap.add_argument('A', type=int); ap.add_argument('B', type=int); ap.add_argument('--seed', type=int, default=1)
    a = ap.parse_args()
    lst = load_list(a.list)
    left, right = a.direction.split(';')
    m = [int(x) for x in left.split()]; s, t = [int(x) for x in right.split()]
    ray = Ray(lst, m, s, t)
    log = lambda msg: print(msg, flush=True)
    log(f'ray: {ray.describe()}')
    t0 = time.time()
    rels, cols, info = build_system(ray, a.T, a.A, a.B, log)
    terms = [len(r) for r in rels]
    log(f'   relations {len(rels)}, symbols {len(cols)}, terms per relation: max {max(terms)}, mean {sum(terms) / len(terms):.1f}')
    rnd = random.Random(a.seed)
    colset = set(cols)
    cand = [x for x in cols if x[1] == 0 and x[2] == 0 and ray.deg(*x) <= a.T - 1 + 1e-9]
    k1 = rnd.randrange(10 ** 6, P61)
    res = run_cp(rels, cols, [{x: 1} for x in cand], [k1], P61)
    free = [x for x, nf in zip(cand, res[0]['nf']) if nf == {x: 1}]
    log(f'   one elimination modulo 2^61-1 at a random strength: rank {res[0]["rank"]}; '
        f'{len(cand)} Laurent orbits of wall degree <= {a.T - 1}, {len(free)} free ({time.time() - t0:.0f}s)')
    targets = {x: ray.target(x[0]) for x in free}
    inside = [x for x in free if all(y in colset for y in targets[x])]
    k2 = rnd.randrange(10 ** 6, P61)
    nfs = dict(zip(inside, run_cp(rels, cols, [targets[x] for x in inside], [k2], P61)[0]['nf'])) if inside else {}
    for D in range(a.T - 1, -1, -1):
        ms = [x for x in free if ray.deg(*x) <= D + 1e-9]
        out = [x for x in ms if x not in nfs]
        mset = set(ms)
        bad = [x for x in ms if x in nfs and not set(nfs[x]) <= mset]
        log(f'   s = {D}: {len(ms)} free Laurent orbits; targets outside the box {len(out)}; '
            f'targets inside that do not reduce to them {len(bad)}; accepted: {not out and not bad}')
    log(f'done ({time.time() - t0:.0f}s)')

if __name__ == '__main__':
    main()
