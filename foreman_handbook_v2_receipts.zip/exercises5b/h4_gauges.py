"""The native gauges of H_4 (rank two on {1,2,3,4}, bases the pairs other than {1,2}) at its centre (1;1,1)
and along (1,1,3,3;3,1), exactly (sympy): the slice (x,x,1,1), the points (-c i, c i, -1, 1) at which two
paths of the census meet, the gradient of log f in y = log alpha, the native values, and the Hessian of
log f on the chart alpha_4 = 1.  Run: python3 h4_gauges.py > h4_gauges.out"""
import sympy as sp

a = sp.symbols('a1:5')
y = sp.symbols('y1:4')
K = (a[0] + a[1]) * (a[2] + a[3]) + a[2] * a[3]
P = (a[0] + a[1]) * (a[2] + a[3]) + a[0] * a[1]
for name, m, s, t, pts in (
        ('centre (1;1,1)', (1, 1, 1, 1), 1, 1,
         [(1, 1, 1, 1), (-1, -1, 1, 1), (-sp.I, sp.I, -1, 1), (sp.I, -sp.I, -1, 1)]),
        ('(1,1,3,3;3,1)', (1, 1, 3, 3), 3, 1,
         [((-4 + sp.sqrt(19)) / 3, (-4 + sp.sqrt(19)) / 3, 1, 1), ((-4 - sp.sqrt(19)) / 3, (-4 - sp.sqrt(19)) / 3, 1, 1),
          (-sp.I / sp.sqrt(3), sp.I / sp.sqrt(3), -1, 1), (sp.I / sp.sqrt(3), -sp.I / sp.sqrt(3), -1, 1)])):
    logf = sum(mi * sp.log(ai) for mi, ai in zip(m, a)) - s * sp.log(K) - t * sp.log(P)
    sub = {a[0]: sp.exp(y[0]), a[1]: sp.exp(y[1]), a[2]: sp.exp(y[2]), a[3]: 1}
    L = logf.subs(sub)
    grad = [sp.diff(L, v) for v in y]
    H = sp.Matrix(3, 3, lambda i, j: sp.diff(L, y[i], y[j]))
    print(name)
    for p in pts:
        ys = {y[0]: sp.log(p[0]), y[1]: sp.log(p[1]), y[2]: sp.log(p[2])}
        g = [sp.nsimplify(sp.simplify(sp.expand_complex(gi.subs(ys)))) for gi in grad]
        fv = sp.radsimp(sp.simplify(sp.Mul(*[pi ** mi for pi, mi in zip(p, m)]) / (K.subs(dict(zip(a, p))) ** s * P.subs(dict(zip(a, p))) ** t)))
        dH = sp.radsimp(sp.simplify(H.subs(ys).det()))
        print(f'   alpha = {p}: gradient {g}; native value {fv} = {sp.N(fv, 15)}; det Hessian {dH}')
