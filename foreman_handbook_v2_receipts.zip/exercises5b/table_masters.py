"""Are the spanning sets of the table's runs sets of masters?  (Exercise ex:listsb-table; Proposition
prop:rays-spectrum(i) and Corollary cor:symbol.)

For a run directory of the ray reader and the direction of its ray (origin 0, or the direction the reader
reads with an origin):
  1. the native gauges of the direction, by the monodromy census of critpoints.py (generic critical points
     carried to the direction);
  2. each one polished at 40 digits (polish.py): native value, determinant of the Hessian of log f on the
     chart (nondegenerate when it is not 0);
  3. the number of distinct native values among the nondegenerate native gauges (a lower bound for the order
     of every relation in L, Corollary cor:symbol);
  4. for the nondegenerate ones, the vectors beta_c = (b_l(alpha_c))_l of the run's spanning set, each b_l the
     average of its monomial over the reader's symmetries of the ray (the automorphisms fixing the masses and
     the origin, and the Cremona u -> -u at a centre), their rank and singular values; rank = m means the
     spanning set is a set of masters (Proposition prop:rays-spectrum(i));
  5. when B is regular at infinity, the largest relative |B(oo) beta_c - beta_c / f(alpha_c)|.
Floating point (numpy for the paths, mpmath at 40 digits for the rest): a numerical check.

Usage: python3 table_masters.py RUN LIST "m_1 ... m_n ; s t" [--cremona] [--trivial] [--seed S]"""
import argparse, os, pickle, sys
import mpmath as mp
from listsb import load_list, symmetries
from polish import polish
import critpoints


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('run'); ap.add_argument('list'); ap.add_argument('direction')
    ap.add_argument('--cremona', action='store_true'); ap.add_argument('--trivial', action='store_true')
    ap.add_argument('--seed', type=int, default=3)
    a = ap.parse_args()
    lst = load_list(a.list); n = lst.n
    left, right = a.direction.split(';')
    mvec = [int(x) for x in left.split()]; s, t = [int(x) for x in right.split()]
    import io, contextlib
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        cen = critpoints.main([a.list, a.direction, '--seed', str(a.seed)])
    for line in buf.getvalue().splitlines():
        if 'generic critical points' in line or 'arrive' in line or 'distinct points' in line:
            print('   ' + line.split('] ', 1)[1])
    G = [tuple(range(n))] if a.trivial else symmetries(lst, mvec)
    with open(os.path.join(a.run, 'masters.pkl'), 'rb') as fh:
        us = [u for (u, aa, bb) in pickle.load(fh)['masters']]
    with open(os.path.join(a.run, 'B_exact.pkl'), 'rb') as fh:
        B = pickle.load(fh)['B']
    mu = len(us)
    mp.mp.dps = 40
    regular = True; Binf = mp.matrix(mu, mu)
    for (j, l), (P, Q) in B.items():
        dp = max([i for i, c in enumerate(P) if c != 0], default=-1)
        dq = max(i for i, c in enumerate(Q) if c != 0)
        if dp > dq:
            regular = False
        elif dp == dq:
            Binf[j, l] = mp.mpf(P[dp].numerator) / P[dp].denominator / (mp.mpf(Q[dq].numerator) / Q[dq].denominator)
    c = cen['census']
    pts = c['points y']; labels = c['orbit labels']
    reps = {}
    for i, (lab, y) in enumerate(zip(labels, pts)):
        reps.setdefault(i if a.trivial else lab, y)
    rows = []; vals_nd = []; worst = mp.mpf(0); ndeg = 0
    for key in sorted(reps):
        y, fval, dt, Kv, Pv, res = polish(lst, mvec, s, t, reps[key], 40)
        if abs(dt) < mp.mpf(10) ** -20:
            ndeg += 1
            continue
        al = [mp.e ** y[i] for i in range(n - 1)] + [mp.mpf(1)]
        beta = []
        for u in us:
            terms = []
            for g in G:
                w = [0] * n
                for i in range(n):
                    w[g[i]] = u[i]
                terms.append(mp.fprod(al[i] ** w[i] for i in range(n)))
                if a.cremona:
                    terms.append(mp.fprod(al[i] ** (-w[i]) for i in range(n)))
            beta.append(mp.fsum(terms) / len(terms))
        rows.append(beta)
        if all(abs(fval - v) > mp.mpf(10) ** -25 * abs(fval) for v in vals_nd):
            vals_nd.append(fval)
        if regular:
            bv = mp.matrix(beta)
            r = Binf * bv - bv / fval
            worst = max(worst, mp.norm(r) / mp.norm(bv))
    A = mp.matrix(rows)
    S = mp.svd_c(A, compute_uv=False)
    sv = [S[i] for i in range(min(A.rows, A.cols))]
    rank = sum(1 for x in sv if x > mp.mpf(10) ** -25 * sv[0])
    print(f'   {len(reps)} {"points" if a.trivial else "orbits"} of native gauges, {ndeg} degenerate; '
          f'{len(vals_nd)} distinct nondegenerate native values: {[mp.nstr(v, 12) for v in vals_nd]}')
    print(f'   {len(rows)} vectors beta_c of length {mu}; rank {rank}; singular values {[mp.nstr(x, 4) for x in sv]}')
    if regular:
        print(f'   B regular at infinity; largest relative |B(oo) beta - beta/f|: {mp.nstr(worst, 3)}')
    else:
        print('   B not regular at infinity')


if __name__ == '__main__':
    main()
