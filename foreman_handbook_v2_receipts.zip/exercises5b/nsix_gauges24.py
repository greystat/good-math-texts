"""N6 at (1;0,2): the two orbits of native gauges of native value 1/24 are rational points; check exactly that
they are native gauges (every defect 1 - 2 R*_e vanishes), their native value, the Hessian determinant, and
that the values of the spanning set there are eigenvectors of B(oo) for the eigenvalue 24, independent.
Run: python3 nsix_gauges24.py RUN_DIR_OF_N_LEAN"""
import os, pickle, sys
import sympy as sp
from listsb import N6, symmetries

def main(run):
    L = N6(); n = 6
    al = sp.symbols('a1:7')
    P = sum(sp.Mul(*[al[i] for i in range(n) if i not in T]) for T in L.bases)
    with open(os.path.join(run, 'masters.pkl'), 'rb') as fh:
        us = [u for (u, a, b) in pickle.load(fh)['masters']]
    with open(os.path.join(run, 'B_exact.pkl'), 'rb') as fh:
        B = pickle.load(fh)['B']
    mu = len(us); k = sp.symbols('k')
    Binf = sp.zeros(mu, mu)
    for (j, l), (Pn, Qn) in B.items():
        Pk = sum(sp.Rational(c.numerator, c.denominator) * k**e for e, c in enumerate(Pn))
        Qk = sum(sp.Rational(c.numerator, c.denominator) * k**e for e, c in enumerate(Qn))
        Binf[j, l] = sp.limit(Pk / Qk, k, sp.oo)
    G = symmetries(L, (1,) * 6)
    betas = []
    for pt in ([-1, sp.Rational(3, 2), -1, 1, 1, 1], [-1, -1, -1, 1, sp.Rational(-2, 3), 1]):
        sub = dict(zip(al, pt))
        Rs = [sp.simplify((al[e] * sp.diff(P, al[e]) / P).subs(sub)) for e in range(n)]
        f = sp.Mul(*pt) / P.subs(sub)**2
        # Hessian of log f in y on the chart y_6 = 0: -2 times the covariance of the cobasis indicators
        y = sp.symbols('y1:6')
        Py = P.subs({al[i]: sp.exp(y[i]) * pt[i] for i in range(5)} | {al[5]: 1})
        logf = sum(y) - 2 * sp.log(Py)
        Hs = sp.Matrix(5, 5, lambda i, j: sp.diff(logf, y[i], y[j])).subs({yy: 0 for yy in y})
        beta = []
        for u in us:
            vals = []
            for g in G:
                w = [0] * n
                for i in range(n):
                    w[g[i]] = u[i]
                vals.append(sp.Mul(*[sp.Rational(pt[i])**w[i] for i in range(n)]))
            beta.append(sum(vals) / len(vals))
        beta = sp.Matrix(beta)
        betas.append(beta)
        print('point', pt, ': occupations R*_e =', Rs, '; f =', f, '; det of the Hessian of log f =', sp.nsimplify(Hs.det()))
        print('   beta =', list(beta), '; B(oo) beta - 24 beta =', list(Binf * beta - 24 * beta))
    print('rank of the two vectors:', sp.Matrix.hstack(*betas).rank())

if __name__ == '__main__':
    main(sys.argv[1])
