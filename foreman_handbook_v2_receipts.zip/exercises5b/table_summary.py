"""The table of rays read by the ray reader (exercise ex:listsb-table): for each run directory the box, its
relations and symbols modulo the symmetries, the size of the spanning set, d_B (the largest degree of a
numerator or denominator of B in lowest terms), the law (order, degree), the spectrum of B at infinite
strength (exact, factored) or 'not regular', the value read, and its distance to an independent value.
Usage: python3 table_summary.py RUNS > table_summary.out"""
import os, pickle, sys
from fractions import Fraction as Fr
from flint import arb, ctx, fmpq_poly, fmpq_mat, fmpq
import mpmath as mp
from analyze_run import load, qpoly, zfactor, fstr

ctx.prec = 400
mp.mp.dps = 100
ell = (arb(2).zeta(arb(1) / 3) - arb(2).zeta(arb(2) / 3)) / 3
z3 = arb(3).zeta()
quad = mp.quad(lambda u: 2 * mp.log((1 + u * u) ** 2 / (u * u)) / (1 + u * u + u ** 4), [0, 0.5, 1, 2, mp.inf])
REF = {
    'three_centre': (ell, 'l (closed form)'),
    'banana4_centre': (7 * z3, '7 T3'),
    'MK4_lean': (6 * z3, '6 T3'),
    'banana5_centre': (arb('39.9455880119962456989440284984239958918497829247698595723666'), 'notebook value (share side)'),
    'H_centre': (arb('4.09623699833788285005555322835126863763467089557118852982109538511623755787'), 'notebook value'),
    'H_slit': (arb('0.4883031948952688838854146439601090087435403192204289752456214192664684'), 'notebook value'),
    'N_lean': (arb('4.75680256375822944340803728605708480533517181028275669568732032161931988849'), 'notebook value'),
    'N_centre': (arb('4.57891247888240480638020373022855744921869580872760320929687575903522507540'), 'notebook value'),
    'three_half': (arb(mp.nstr(quad, 90)), 'quadrature'),
    'U24_lean': (ell, 'l (closed form)'),
    'U24_centre': (ell, 'l (closed form)'),
}
ORDER = ['three_centre', 'banana4_centre', 'MK4_lean', 'banana5_centre', 'three_lean', 'H_centre', 'H_slit',
         'U25_centre', 'N_lean', 'N_centre', 'three_half', 'U24_lean', 'U24_centre', 'V_lean']


def summary(run):
    m = load(run, 'masters.pkl')
    info = m.get('info', {})
    Bd = load(run, 'B_exact.pkl')['B']
    mu = len(m['masters'])
    dB = 0; regular = True; ent = {}
    for key, (P, Q) in Bd.items():
        Pp, Qp = qpoly(P), qpoly(Q)
        if Pp == 0:
            ent[key] = None; continue
        g = Pp.gcd(Qp); Pp, Qp = Pp / g, Qp / g
        ent[key] = (Pp, Qp)
        dB = max(dB, Pp.degree(), Qp.degree())
        if Pp.degree() > Qp.degree():
            regular = False
    spec = 'not regular at infinity'
    if regular:
        Bi = fmpq_mat(mu, mu)
        for (j, l), e in ent.items():
            if e is not None and e[0].degree() == e[1].degree():
                Bi[j, l] = e[0].coeffs()[-1] / e[1].coeffs()[-1]
        c, fac = zfactor(fmpq_poly(Bi.charpoly().coeffs()))
        spec = fstr(c, fac, 'lambda')
    law = load(run, 'law_exact.pkl')
    h = law['order']; D = max(len(x) for x in law['c']) - 1
    val = open(os.path.join(run, 'value.txt')).read().split('\n')[1].split()[1]
    return info, mu, dB, (h, D), spec, val


def main():
    root = sys.argv[1]
    for name in ORDER:
        run = os.path.join(root, name)
        if not os.path.exists(os.path.join(run, 'value.txt')):
            print(f'{name}: not finished'); continue
        info, mu, dB, hd, spec, val = summary(run)
        line = (f'{name}: box {info.get("box")}, relations {info.get("relations")}, symbols {info.get("unknowns")}, '
                f'stems {info.get("top seeds")}, spanning set {mu}, d_B {dB}, law {hd}; spectrum {spec}; value {val}')
        if name in REF:
            ref, lab = REF[name]
            d = abs(arb(val) - ref)
            line += f'; against {lab}: |difference| {d.mid().str(3, radius=False)}'
        print(line)


if __name__ == '__main__':
    main()
