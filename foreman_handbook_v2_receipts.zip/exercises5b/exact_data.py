"""Exact data of the rays of exercises XI.5 (second half): walls by height, the least wall, the volume of the
direction V_1 (exact), the symmetries fixing the masses, and for N6 and V8 the slice computations and the
letters.  Run:  python3 exact_data.py > exact_data.out"""
import itertools
from fractions import Fraction as Fr
import sympy as sp
from listsb import N6, N7, Q6, V8, walls, volume, symmetries, heights, load_list

RAYS = [
    ('N6', N6, (1, 1, 1, 1, 1, 1), 0, 2),
    ('N6', N6, (1, 1, 1, 1, 1, 1), 1, 1),
    ('V8', V8, (1,) * 8, 0, 2),
    ('V8', V8, (1,) * 8, 1, 1),
    ('Q6', Q6, (1, 3, 2, 3, 1, 2), 2, 2),
    ('N7', N7, (1, 2, 2, 1, 2, 1, 1), 2, 1),
    ('N7 (0-based {1,2,5})', lambda: __import__('listsb').List(
        7, [T for T in itertools.combinations(range(7), 3) if T != (1, 2, 5)], 'N7b'), (1, 2, 2, 1, 2, 1, 1), 2, 1),
    ('three', lambda: load_list('three'), (1, 1, 1), 1, 1),
    ('banana4', lambda: load_list('banana4'), (1, 1, 1, 1), 1, 1),
    ('banana5', lambda: load_list('banana5'), (1, 1, 1, 1, 1), 1, 1),
    ('three', lambda: load_list('three'), (2, 2, 2), 4, 1),
    ('H', lambda: load_list('H'), (1, 1, 1, 1), 1, 1),
    ('H', lambda: load_list('H'), (1, 1, 3, 3), 3, 1),
    ('MK4', lambda: load_list('MK4'), (1,) * 6, 0, 2),
    ('U25', lambda: load_list('U25'), (1,) * 5, 1, 1),
]


def main():
    for name, mk, m, s, t in RAYS:
        L = mk()
        w = walls(L, m, s, t)
        bal = sum(m) == s * L.r + t * (L.n - L.r)
        print(f'{name} at ({" ".join(map(str, m))}; {s}, {t}): n = {L.n}, rank {L.r}, {len(L.bases)} bases; '
              f'balance {bal}; {len(w)} walls')
        print(f'   walls by height (count): {", ".join(f"{h}({c})" for h, c in heights(w))}; least {min(w.values())}')
        print(f'   V_1 = {volume(L, m, s, t)}')
        print(f'   automorphisms fixing the masses: {len(symmetries(L, m))}')

    # N6: letters through the triples a = {1,2,3}, b = {4,5,6}
    a = sp.symbols('a1:4'); b = sp.symbols('b1:4')
    al = list(a) + list(b)
    L = N6()
    K = sum(sp.Mul(*[al[i] for i in T]) for T in L.bases)
    Psi = sum(sp.Mul(*[al[i] for i in range(6) if i not in T]) for T in L.bases)
    Ka, Pa, ea = sum(a), a[0]*a[1] + a[0]*a[2] + a[1]*a[2], a[0]*a[1]*a[2]
    Kb, Pb, eb = sum(b), b[0]*b[1] + b[0]*b[2] + b[1]*b[2], b[0]*b[1]*b[2]
    Q = Pa*Kb + Ka*Pb
    print('N6: K = Q + alpha^b:', sp.expand(K - Q - eb) == 0, '; Psi = Q + alpha^a:', sp.expand(Psi - Q - ea) == 0)
    x = sp.symbols('x', positive=True)
    sl = {a[0]: x, a[1]: x, a[2]: x, b[0]: 1, b[1]: 1, b[2]: 1}
    fl = sp.factor(sp.Mul(*al).subs(sl) / Psi.subs(sl)**2)
    print('N6 lean slice: f =', fl, '; d log f / dx numerator:', sp.factor(sp.numer(sp.together(sp.diff(sp.log(fl), x)))))
    r = (sp.sqrt(21) - 3) / 2
    fstar = sp.nsimplify(sp.radsimp(fl.subs(x, r)))
    print('   x =', r, ' f* =', sp.radsimp(fl.subs(x, r)), '=', sp.N(fl.subs(x, r), 25))
    # V8 slice: x on P1 u P2, 1 on P3 u P4
    L = V8()
    v = sp.symbols('v1:9')
    PsiV = sum(sp.Mul(*[v[i] for i in range(8) if i not in T]) for T in L.bases)
    slv = {v[0]: x, v[1]: x, v[2]: x, v[3]: x, v[4]: 1, v[5]: 1, v[6]: 1, v[7]: 1}
    print('V8 slice: Psi =', sp.factor(PsiV.subs(slv)))
    fv = sp.factor(x**4 / PsiV.subs(slv)**2)
    print('   f =', fv, '; d log f / dx numerator:', sp.factor(sp.numer(sp.together(sp.diff(sp.log(fv), x)))))
    cub = sp.Poly(x**3 + 8*x**2 - 8, x)
    p = sp.Poly(x**3 + 16*x**2 + 32*x + 16, x)
    print('   x^3+16x^2+32x+16 mod x^3+8x^2-8 =', p.rem(cub).as_expr(), '=', sp.factor(p.rem(cub).as_expr()))
    for rt in sp.Poly(cub).nroots(n=20):
        print('   root', rt, ' f =', sp.N(rt**2 / (64 * (rt + 1)**2 * (rt + 3)**2), 20))
    # V8 cobases and x_1
    cob = [tuple(i for i in range(8) if i not in T) for T in L.bases]
    print('   cobases whose complement is a cobasis:', sum(1 for C in cob if tuple(sorted(set(range(8)) - set(C))) in set(cob)))


if __name__ == '__main__':
    main()
