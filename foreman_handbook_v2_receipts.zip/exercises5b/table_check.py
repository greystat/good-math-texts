"""Checks for the table of rays read by the procedure (exercise ex:listsb-table), at 60 digits.

For each run directory of runs_table.sh, copied and read again with --digits 60 (the law is cached, so only
the gauge end runs again):
  1. the values <1>_1, ..., <1>_h from the gauge end (the ray reader's stage 5);
  2. V_1 exactly, from the walls (listsb.volume), and the low-end relation of Corollary cor:rays-lowend(ii),
     [k^(n-1)] c_0 * V_1 + sum_i c_i(0) <1>_i = 0, on these values, with its residual relative to the
     largest term; only for the rays with origin 0 (the ray with masses (1/2, 1, 3/2) is read with an origin);
  3. <1>_1 against an independent value where one is at hand:
       l = (1/3) (Tx2 of the lattice input on 1/3 + Z  -  Tx2 of the lattice input on 2/3 + Z), at the cut 0,
       7 Tx3(I_Z)(0) and 6 Tx3(I_Z)(0), all from their series in arb (Hurwitz zeta values);
       the one-dimensional integral int_0^oo 2 log((1+u^2)^2/u^2) du/(1+u^2+u^4) by mpmath quadrature at
       90 digits, for the masses (1/2, 1, 3/2);
  4. the limit at k = oo of det(lambda - B(k)) where B is not regular at infinity (exact, sympy).
Floating point (arb balls, mpmath quadrature) only in 1 and 3; 2 and 4 use the exact law and B.

Usage: python3 table_check.py RUNS60 > table_check.out"""
import contextlib, os, pickle, sys
from fractions import Fraction as Fr
from flint import arb, ctx
import mpmath as mp
import sympy as sp
RR = '/home/claude/v2/receipts_src/rayreader/rayreader'
sys.path.insert(0, RR)
import rayreader  # noqa: E402
from rr.lists import load_list  # noqa: E402
from listsb import volume  # noqa: E402

U24 = '/home/claude/v2/new/exercises5b/scripts/U24.json'
RAYS = [  # name, list, direction, origin 0?
    ('three_centre', 'three', '1 1 1 ; 1 1', True),
    ('banana4_centre', 'banana4', '1 1 1 1 ; 1 1', True),
    ('MK4_lean', 'MK4', '1 1 1 1 1 1 ; 0 2', True),
    ('banana5_centre', 'banana5', '1 1 1 1 1 ; 1 1', True),
    ('three_lean', 'three', '2 2 2 ; 4 1', True),
    ('H_centre', 'H', '1 1 1 1 ; 1 1', True),
    ('H_slit', 'H', '1 1 3 3 ; 3 1', True),
    ('U25_centre', 'U25', '1 1 1 1 1 ; 1 1', True),
    ('N_lean', 'N', '1 1 1 1 1 1 ; 0 2', True),
    ('N_centre', 'N', '1 1 1 1 1 1 ; 1 1', True),
    ('three_half', 'three', '1/2 1 3/2 ; 1 1', False),
    ('U24_lean', U24, '1 1 1 1 ; 0 2', True),
    ('U24_centre', U24, '1 1 1 1 ; 1 1', True),
    ('V_lean', 'V', '1 1 1 1 1 1 1 1 ; 0 2', True),
]


def refs(prec_digits):
    ctx.prec = int(3.33 * (prec_digits + 30))
    ell = (arb(2).zeta(arb(1) / 3) - arb(2).zeta(arb(2) / 3)) / 3
    z3 = arb(3).zeta()
    mp.mp.dps = prec_digits + 30
    quad = mp.quad(lambda u: 2 * mp.log((1 + u * u) ** 2 / (u * u)) / (1 + u * u + u ** 4), [0, 0.25, 0.5, 1, 2, 4, mp.inf])
    return {'three_centre': (ell, 'l'), 'U24_lean': (ell, 'l'), 'U24_centre': (ell, 'l'),
            'banana4_centre': (7 * z3, '7 T3'), 'MK4_lean': (6 * z3, '6 T3'),
            'three_half': (arb(mp.nstr(quad, prec_digits + 25)), 'quadrature')}


def charpoly_limit(run):
    with open(os.path.join(run, 'B_exact.pkl'), 'rb') as fh:
        B = pickle.load(fh)['B']
    with open(os.path.join(run, 'masters.pkl'), 'rb') as fh:
        mu = len(pickle.load(fh)['masters'])
    k, lam = sp.symbols('k lambda')
    M = sp.zeros(mu, mu)
    for (j, l), (P, Q) in B.items():
        Pk = sum(sp.Rational(c.numerator, c.denominator) * k**e for e, c in enumerate(P))
        Qk = sum(sp.Rational(c.numerator, c.denominator) * k**e for e, c in enumerate(Q))
        M[j, l] = sp.cancel(Pk / Qk)
    cp = (lam * sp.eye(mu) - M).det(method='berkowitz')
    cp = sp.Poly(sp.together(sp.expand(cp)).as_numer_denom()[0], lam), sp.together(sp.expand(cp)).as_numer_denom()[1]
    num, den = cp
    coeffs = [sp.limit(sp.cancel(c / den), k, sp.oo) for c in num.all_coeffs()]
    return sp.factor(sum(c * lam**(len(coeffs) - 1 - i) for i, c in enumerate(coeffs)))


def main():
    root = sys.argv[1]
    digits = 60
    R = refs(digits)
    for name, lname, direction, origin0 in RAYS:
        run = os.path.join(root, name)
        if not os.path.exists(os.path.join(run, 'law_exact.pkl')):
            print(f'{name}: no law in {run}'); continue
        with open(os.path.join(root, 'table_check.log'), 'a') as lg, contextlib.redirect_stdout(lg):
            res = rayreader.main([lname, direction, '--digits', str(digits), '--run', run, '--workers', '1'])
        ctx.prec = int(3.33 * (digits + 30))
        P = {int(kk): v for kk, v in res['values'].items()}
        with open(os.path.join(run, 'law_exact.pkl'), 'rb') as fh:
            law = pickle.load(fh)
        c = law['c']; h = len(c) - 1; D = max(len(x) for x in c) - 1
        lst = load_list(lname)
        n = lst.n
        left, right = direction.split(';')
        m = [Fr(x) for x in left.split()]; s, t = [Fr(x) for x in right.split()]
        V1 = volume(lst, m, s, t)
        line = [f'{name}: n = {n}, law ({h}, {D}), V_1 = {V1}']
        if origin0:
            order0 = next(i for i, x in enumerate(c[0]) if x != 0)
            lead = c[0][n - 1]
            low = arb(lead.numerator) / lead.denominator * arb(V1.numerator) / V1.denominator
            terms = []
            for i in range(1, h + 1):
                ci0 = c[i][0]
                terms.append(arb(ci0.numerator) / ci0.denominator * P[i])
            low = low + sum(terms, arb(0))
            big = max(abs(x).mid() for x in terms)
            rel = abs(low).mid() / big if big != 0 else abs(low).mid()
            line.append(f'c_0 vanishes at 0 to order {order0} (n - 1 = {n - 1}); low-end relation: residual '
                        f'{abs(low).mid().str(3, radius=False)}, relative {arb(rel).str(3, radius=False)}')
        v1 = P[1]
        line.append(f'<1>_1 = {v1.mid().str(digits + 2, radius=False)}')
        if name in R:
            ref, lab = R[name]
            d = abs(v1 - ref).mid()
            line.append(f'against {lab}: |difference| {arb(d).str(3, radius=False)}')
        print('\n   '.join(line), flush=True)
        if name in ('MK4_lean', 'banana5_centre', 'U24_lean'):
            print(f'   B not regular at infinity; lim det(lambda - B(k)) as k -> oo: {charpoly_limit(run)}', flush=True)


if __name__ == '__main__':
    main()
