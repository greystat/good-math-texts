"""Critical points of a product of powers of the letters and the marks, counted by monodromy, and carried to
the exponents of a direction (reading_cost section 8, redone).

For a list with letters K, Psi and exponents p = (a; bK, bP), |a| = bK r + bP (n - r), the critical points of
alpha^a K^-bK Psi^-bP on the torus modulo scaling solve
    a_e - bK R_e(alpha) - bP R*_e(alpha) = 0     (e in E),
R_e, R*_e the occupations; the equations are linear in p.  Only the letters that the direction uses are kept
(bK = 0 when s = 0, bP = 0 when t = 0), as in reading_cost.  Coordinates: y = log alpha on the chart
y_(n-1) = 0.  Floating point throughout: this is a numerical census, not a proof.

Method.  A seed: a random point y0 and random bK, bP, with a chosen so that y0 is critical.  Monodromy: the
solutions at p0 are carried around random triangles p0 -> p1 -> p2 -> p0 in the complex parameters (straight
segments), new endpoints added, until `quiet` loops in a row add nothing.  Then every solution is carried along
the straight segment from p0 to the direction's exponents; a path either arrives (converges, letters nonzero,
Jacobian nonsingular) or escapes (a coordinate or a letter runs to 0 or infinity).

A parameter is one complex vector (a_0, ..., a_(n-1), bK, bP).

Usage:  python3 critpoints.py LIST "m_1 ... m_n ; s t" [--seed S] [--quiet Q] [--out FILE]
LIST as for the ray reader (a name or a JSON file)."""
import argparse, json, time
import numpy as np
from listsb import load_list, symmetries

np.seterr(all='ignore')


class System:
    def __init__(self, lst, useK, useP):
        self.lst = lst
        self.n = lst.n; self.r = lst.r; self.m = lst.n - 1
        MK = np.array([[1.0 if i in T else 0.0 for i in range(lst.n)] for T in lst.bases])
        self.MKfull = MK; self.MPfull = 1.0 - MK
        self.MK = MK[:, :self.m]; self.MP = (1.0 - MK)[:, :self.m]
        self.useK, self.useP = useK, useP

    @staticmethod
    def _occ(M, y):
        """occupations and covariances of the letter with exponent matrix M at the points y (N x m)"""
        e = y @ M.T
        e = e - e.real.max(axis=1, keepdims=True)
        w = np.exp(e)
        p = w / w.sum(axis=1)[:, None]
        R = p @ M
        C = np.einsum('nb,bi,bj->nij', p, M, M) - R[:, :, None] * R[:, None, :]
        return R, C

    def FJ(self, y, P):
        """F (N x m), J (N x m x m) and the occupations at the points y and parameters P (N x (n+2))"""
        m = self.m
        F = P[:, :m].copy(); J = np.zeros((y.shape[0], m, m), dtype=complex)
        RK = RP = None
        if self.useK:
            RK, CK = self._occ(self.MK, y)
            F -= P[:, self.n, None] * RK; J -= P[:, self.n, None, None] * CK
        if self.useP:
            RP, CP = self._occ(self.MP, y)
            F -= P[:, self.n + 1, None] * RP; J -= P[:, self.n + 1, None, None] * CP
        return F, J, RK, RP

    def dF(self, dP, RK, RP):
        d = dP[:, :self.m].copy()
        if RK is not None:
            d -= dP[:, self.n, None] * RK
        if RP is not None:
            d -= dP[:, self.n + 1, None] * RP
        return d

    def letters_log(self, y):
        """log |K| and log |Psi| on the chart (alpha_(n-1) = 1)"""
        out = []
        for M in (self.MK, self.MP):
            e = y @ M.T
            mx = e.real.max(axis=1)
            out.append(mx + np.log(np.abs(np.exp(e - mx[:, None]).sum(axis=1)) + 1e-300))
        return out


def rand_par(rng, sysm):
    n, r = sysm.n, sysm.r
    P = np.zeros(n + 2, complex)
    if sysm.useK:
        P[n] = rng.normal() + 1j * rng.normal()
    if sysm.useP:
        P[n + 1] = rng.normal() + 1j * rng.normal()
    a = rng.normal(size=n) + 1j * rng.normal(size=n)
    a += (P[n] * r + P[n + 1] * (n - r) - a.sum()) / n
    P[:n] = a
    return P


def _solve(J, F):
    try:
        return np.linalg.solve(J, F[:, :, None])[:, :, 0]
    except np.linalg.LinAlgError:
        out = np.full_like(F, np.nan)
        for i in range(F.shape[0]):
            try:
                out[i] = np.linalg.solve(J[i], F[i])
            except np.linalg.LinAlgError:
                pass
        return out


def track(sysm, y, pa, pb, tmax=1.0, h0=0.02, hmin=1e-10, tol=1e-9, maxsteps=100000, ymax=60.0):
    """carry the solutions y (N x m) from the parameter pa to pb (vectors of length n+2) along the straight
    segment; returns the endpoints, the mask of paths that reached tmax, and the tau reached"""
    N = y.shape[0]
    dP = (pb - pa)[None, :]
    tau = np.zeros(N); h = np.full(N, h0); y = y.copy()
    alive = np.ones(N, bool); done = np.zeros(N, bool)

    def vel(yy, tt):
        P = pa[None, :] + tt[:, None] * dP
        F, J, RK, RP = sysm.FJ(yy, P)
        return -_solve(J, sysm.dF(np.repeat(dP, len(tt), axis=0), RK, RP))

    steps = 0
    while steps < maxsteps:
        act = np.where(alive & ~done)[0]
        if len(act) == 0:
            break
        steps += 1
        hh = np.minimum(h[act], tmax - tau[act])
        y0 = y[act]; t0 = tau[act]
        k1 = vel(y0, t0)
        k2 = vel(y0 + 0.5 * hh[:, None] * k1, t0 + 0.5 * hh)
        k3 = vel(y0 + 0.5 * hh[:, None] * k2, t0 + 0.5 * hh)
        k4 = vel(y0 + hh[:, None] * k3, t0 + hh)
        y1 = y0 + hh[:, None] * (k1 + 2 * k2 + 2 * k3 + k4) / 6
        t1 = t0 + hh
        P1 = pa[None, :] + t1[:, None] * dP
        d = np.zeros_like(y1)
        for _ in range(3):
            F, J, _, _ = sysm.FJ(y1, P1)
            d = _solve(J, F)
            y1 = y1 - d
        F, J, _, _ = sysm.FJ(y1, P1)
        res = np.abs(F).max(axis=1); corr = np.abs(d).max(axis=1)
        step = np.abs(y1 - y0).max(axis=1)
        good = np.isfinite(res) & np.isfinite(step) & (res < tol) & (corr < 1e-7) & (step < 0.3)
        gi = act[good]; bi = act[~good]
        y[gi] = y1[good]; tau[gi] = t1[good]
        h[gi] = np.minimum(h[gi] * 1.5, 0.05)
        h[bi] = h[bi] / 2
        alive[bi[h[bi] < hmin]] = False
        done[gi[tau[gi] >= tmax - 1e-14]] = True
        alive &= ~(np.abs(y.real).max(axis=1) > ymax)
    return y, done, tau


def canon(y):
    """wrap the imaginary parts into (-pi, pi]"""
    return y.real + 1j * (np.mod(y.imag + np.pi, 2 * np.pi) - np.pi)


def dist(A, v):
    return np.abs(A.real - v.real).max(axis=1) + np.abs(np.angle(np.exp(1j * (A.imag - v.imag)))).max(axis=1)


def dedupe(Y, tol=1e-6):
    out = []
    for v in canon(Y):
        if not out or dist(np.array(out), v).min() > tol:
            out.append(v)
    return np.array(out).reshape(-1, Y.shape[1])


def newton(sysm, y, P, iters=40):
    PP = np.repeat(P[None, :], y.shape[0], axis=0)
    for _ in range(iters):
        F, J, _, _ = sysm.FJ(y, PP)
        d = _solve(J, F)
        bad = ~np.isfinite(d).all(axis=1)
        d[bad] = 0
        y = y - d
    F, J, _, _ = sysm.FJ(y, PP)
    return y, np.abs(F).max(axis=1), J


def census(sysm, sols, p0, pd, mvec, s, t, G, log):
    lst = sysm.lst; n = sysm.n
    Y, done, tau = track(sysm, sols, p0, pd, tmax=1.0)
    Yd, resd, Jd = newton(sysm, Y, pd)
    lK, lP = sysm.letters_log(Yd)
    sv = np.linalg.svd(Jd, compute_uv=False)
    fin = done & np.isfinite(resd) & (resd < 1e-11) & (np.abs(Yd.real).max(axis=1) < 40)
    log(f'paths that arrive at the direction: {int(fin.sum())} of {len(sols)}; the others escape or stop '
        f'(their tau: {np.round(np.sort(tau[~fin])[:5], 6).tolist()} ...)')
    arrive = canon(Yd[fin]); smin = sv[fin, -1]
    lKa, lPa = lK[fin], lP[fin]
    # distinct points
    pts = []; mult = []; smins = []; lets = []
    for v, sm, a1, a2 in zip(arrive, smin, lKa, lPa):
        if pts:
            dd = dist(np.array(pts), v)
            j = int(np.argmin(dd))
            if dd[j] < 1e-5:
                mult[j] += 1; continue
        pts.append(v); mult.append(1); smins.append(sm); lets.append((a1, a2))
    pts = np.array(pts).reshape(-1, sysm.m)
    vals = []
    for v in pts:
        al = np.exp(np.append(v, 0))
        Kv = sum(np.prod([al[i] for i in T]) for T in lst.bases)
        Pv = sum(np.prod([al[i] for i in range(n) if i not in T]) for T in lst.bases)
        vals.append(np.prod(al ** np.array(mvec)) / (Kv ** s * Pv ** t))
    vals = np.array(vals)
    # orbits under the automorphisms fixing the masses
    def act(g, v):
        al = np.append(v, 0.0)
        w = np.empty(n, complex)
        for i in range(n):
            w[g[i]] = al[i]
        w = w - w[n - 1]
        return canon(w[None, :n - 1])[0]
    lab = -np.ones(len(pts), int); norb = 0
    for i in range(len(pts)):
        if lab[i] >= 0:
            continue
        for g in G:
            w = act(g, pts[i])
            dd = dist(pts, w)
            j = int(np.argmin(dd))
            if dd[j] < 1e-5:
                lab[j] = norb
        norb += 1
    # distinct native values
    dv = []
    for v in vals:
        if not dv or min(abs(v - w) / max(abs(v), 1e-300) for w in dv) > 1e-8:
            dv.append(v)
    return {'arrive': int(fin.sum()), 'points': int(len(pts)), 'multiplicities': [int(x) for x in mult],
            'smallest singular values': [float(x) for x in smins],
            'log|K|, log|Psi| at the points (min)': [float(min(a for a, b in lets)) if lets else None,
                                                     float(min(b for a, b in lets)) if lets else None],
            'native values': [[float(v.real), float(v.imag)] for v in vals],
            'distinct native values': [[float(v.real), float(v.imag)] for v in dv],
            'orbits': int(norb), 'orbit sizes': sorted([int((lab == o).sum()) for o in range(norb)]),
            'orbit labels': lab.tolist(), 'points y': [[[float(z.real), float(z.imag)] for z in v] for v in pts]}


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument('list'); ap.add_argument('direction')
    ap.add_argument('--seed', type=int, default=1)
    ap.add_argument('--quiet', type=int, default=4)
    ap.add_argument('--out', default=None)
    ap.add_argument('--maxloops', type=int, default=400)
    args = ap.parse_args(argv)
    lst = load_list(args.list)
    left, right = args.direction.split(';')
    mvec = [float(x) for x in left.split()]; s, t = [float(x) for x in right.split()]
    sysm = System(lst, s != 0, t != 0)
    rng = np.random.default_rng(args.seed)
    n, m = lst.n, lst.n - 1
    T0 = time.time()
    lines = []
    def log(msg):
        line = f'[{time.time() - T0:7.1f}s] {msg}'
        print(line, flush=True); lines.append(line)
    log(f'{lst.name}: n = {n}, rank {lst.r}, {len(lst.bases)} bases; direction {args.direction}; '
        f'letters used: {"K " if sysm.useK else ""}{"Psi" if sysm.useP else ""}; seed {args.seed}')
    # seed point and parameter
    y0 = (rng.normal(size=(1, m)) + 1j * rng.normal(size=(1, m))) * 0.5
    p0 = rand_par(rng, sysm)
    _, _, RK, RP = sysm.FJ(y0, p0[None, :])
    p0[:m] = (p0[n] * RK[0] if RK is not None else 0) + (p0[n + 1] * RP[0] if RP is not None else 0)
    p0[m] = p0[n] * lst.r + p0[n + 1] * (n - lst.r) - p0[:m].sum()
    F, _, _, _ = sysm.FJ(y0, p0[None, :])
    log(f'seed residual {np.abs(F).max():.1e}')
    sols = canon(y0); quiet = 0; loops = 0
    while quiet < args.quiet and loops < args.maxloops:
        loops += 1
        p1 = rand_par(rng, sysm); p2 = rand_par(rng, sysm)
        Y = sols; ok = np.ones(len(Y), bool)
        for (pa, pb) in ((p0, p1), (p1, p2), (p2, p0)):
            Y, done, _ = track(sysm, Y, pa, pb)
            ok &= done
        before = len(sols)
        Yn, rn, _ = newton(sysm, Y[ok], p0, iters=8)
        Yn = Yn[np.isfinite(rn) & (rn < 1e-12)]
        sols = dedupe(np.vstack([sols, Yn]))
        quiet = quiet + 1 if len(sols) == before else 0
        log(f'loop {loops}: {len(sols)} solutions ({int((~ok).sum())} paths lost)')
    sols, res, J = newton(sysm, sols, p0)
    sv = np.linalg.svd(J, compute_uv=False)
    log(f'generic critical points: {len(sols)}; largest residual {res.max():.1e}; smallest singular value '
        f'of the Jacobian {sv[:, -1].min():.1e}')
    G = symmetries(lst, [int(round(x)) for x in mvec])
    pd = np.zeros(n + 2, complex); pd[:n] = mvec
    if sysm.useK:
        pd[n] = s
    if sysm.useP:
        pd[n + 1] = t
    c = census(sysm, sols, p0, pd, mvec, s, t, G, log)
    log(f'distinct points reached {c["points"]} (multiplicities > 1: {[x for x in c["multiplicities"] if x > 1]}); '
        f'distinct native values {len(c["distinct native values"])}; orbits of the {len(G)} automorphisms '
        f'fixing the masses: {c["orbits"]}, of sizes {c["orbit sizes"]}')
    out = {'list': args.list, 'direction': args.direction, 'seed': args.seed, 'loops': loops,
           'generic': int(len(sols)), 'symmetries': len(G), 'census': c, 'log': lines,
           'p0': [[float(z.real), float(z.imag)] for z in p0],
           'generic solutions y': [[[float(z.real), float(z.imag)] for z in v] for v in sols],
           'seconds': round(time.time() - T0, 1)}
    if args.out:
        with open(args.out, 'w') as fh:
            json.dump(out, fh, indent=1)
    return out


if __name__ == '__main__':
    main()
