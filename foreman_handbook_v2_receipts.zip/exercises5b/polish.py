"""Polish the native gauges of a census (critpoints.py output) by Newton's method in multiprecision at the
direction itself, and report each one's native value, the determinant of the Hessian of log f on the chart,
and the letters there.  Floating point (mpmath), a numerical check.

Usage: python3 polish.py CENSUS.json [DIGITS] [other CENSUS.json ...]  (other censuses of the same ray are
compared with the first: same native values?)"""
import json, sys
import mpmath as mp
from listsb import load_list


def polish(lst, mvec, s, t, y, dps):
    mp.mp.dps = dps
    n = lst.n; m = n - 1
    B = [tuple(T) for T in lst.bases]
    y = mp.matrix([mp.mpc(a, b) for a, b in y])
    def occ(yy):
        al = [mp.e ** yy[i] for i in range(m)] + [mp.mpf(1)]
        out = []
        for useM, coef in ((s, 'K'), (t, 'P')):
            if useM == 0:
                out.append(None); continue
            mons = [[1 if (i in T) == (coef == 'K') else 0 for i in range(n)] for T in B]
            w = [mp.fprod(al[i] ** v[i] for i in range(n)) for v in mons]
            W = mp.fsum(w)
            R = [mp.fsum(wi * v[e] for wi, v in zip(w, mons)) / W for e in range(m)]
            C = [[mp.fsum(wi * v[e] * v[f] for wi, v in zip(w, mons)) / W - R[e] * R[f] for f in range(m)] for e in range(m)]
            out.append((W, R, C))
        return al, out
    for it in range(60):
        al, o = occ(y)
        F = mp.matrix([mp.mpf(mvec[e]) for e in range(m)])
        J = mp.matrix(m, m)
        for wgt, M in ((s, o[0]), (t, o[1])):
            if M is None:
                continue
            W, R, C = M
            for e in range(m):
                F[e] -= wgt * R[e]
                for f in range(m):
                    J[e, f] -= wgt * C[e][f]
        d = mp.lu_solve(J, F)
        y = y - d
        if mp.norm(d) < mp.mpf(10) ** (-dps + 8):
            break
    al, o = occ(y)
    F = mp.matrix([mp.mpf(mvec[e]) for e in range(m)])
    for wgt, M in ((s, o[0]), (t, o[1])):
        if M is not None:
            for e in range(m):
                F[e] -= wgt * M[1][e]
    Kv = mp.fsum(mp.fprod(al[i] for i in T) for T in B)
    Pv = mp.fsum(mp.fprod(al[i] for i in range(n) if i not in T) for T in B)
    fval = mp.fprod(al[i] ** mvec[i] for i in range(n)) / (Kv ** s * Pv ** t)
    return y, fval, mp.det(J), Kv, Pv, mp.norm(F)


def main():
    path = sys.argv[1]; dps = int(sys.argv[2]) if len(sys.argv) > 2 else 40
    d = json.load(open(path))
    lst = load_list(d['list'])
    left, right = d['direction'].split(';')
    mvec = [int(x) for x in left.split()]; s, t = [int(x) for x in right.split()]
    vals = []; worst = 0; mindet = None; minlet = None
    for y in d['census']['points y']:
        yy, f, dt, Kv, Pv, res = polish(lst, mvec, s, t, y, dps)
        vals.append(f)
        worst = max(worst, float(res))
        mindet = abs(dt) if mindet is None else min(mindet, abs(dt))
        lk = min(abs(Kv), abs(Pv)); minlet = lk if minlet is None else min(minlet, lk)
    mp.mp.dps = dps
    vs = sorted(vals, key=lambda z: (float(mp.re(z)), float(mp.im(z))))
    sep = min(abs(vs[i] - vs[j]) for i in range(len(vs)) for j in range(i + 1, len(vs))) if len(vs) > 1 else None
    print(f'{path}: {len(vals)} points polished at {dps} digits; largest residual {mp.nstr(worst, 3)}; '
          f'smallest |det J| {mp.nstr(mindet, 5)}; smallest letter modulus {mp.nstr(minlet, 5)}; '
          f'smallest distance between native values {mp.nstr(sep, 5)}')
    for z in vs:
        print('   ', mp.nstr(z, 25))
    for other in sys.argv[3:]:
        d2 = json.load(open(other))
        v2 = [complex(a, b) for a, b in d2['census']['native values']]
        miss = [z for z in vs if min(abs(complex(z) - w) for w in v2) > 1e-9 * abs(complex(z))]
        print(f'against {other}: {len(v2)} native values there; values of {path} not among them: {len(miss)}')


if __name__ == '__main__':
    main()
