"""Exact linear algebra on the integer relations of valuespan_N.out: the lattice they span, whether the
low-end relation and the law read at k = 1 lie in its rational span, and the value span they leave (the
reduced echelon form over Q).  Run: python3 valuespan_exact.py RUN_LEAN RUN_CENTRE"""
import os, pickle, sys
import sympy as sp

def law(run):
    with open(os.path.join(run, 'law_exact.pkl'), 'rb') as fh:
        return pickle.load(fh)['c']
def ev(p, k):
    acc = 0
    for a in reversed(p):
        acc = acc * k + a
    return acc

lean = [[15476, -3451, 556832, -17388081, 111849150, -425617416, -2986275600],
        [84581, -18857, 3035312, -97811235, 798867930, -5212068120, 1459458000],
        [5489069, -1222045, 190733734, -4628283534, 13506396540, -1721929104, -44906400]]
centre = [[79020065234686399, -17464588652505675, 415792452354276751, 176949772936033239707, -1722198765305110051011, -21704281231136966050421, 156232109212484759250335, -328500739603638028551750, 357237460740389101110658, -270938479973580210289309, -123205931301600621183465, 535250446961465973112200, -303452504151235406352000],
          [190327501228102482, -41727192765294000, 58264645688427972, 431655143601538927359, -2344329239150646241017, -79120584002932233331372, 446620575270336413342860, -611946245678856015897165, 7142842759160802391903, 19497134931807231736466, 562902799782877071538410, -181624984176824776522800, -163082639392686094752000],
          [-175283669568094110, 39244593965539170, -2344187007518568784, -368396921257801284947, 6409872701744655637511, -7649279152620240537706, 18999619616209976897570, -351178104664460857179570, 746276757547103252215666, -147326321955136144663363, -352774247663162114187255, -262722632275776443934600, 351615525660140510736000],
          [7487472498692621, -2213347070724810, 1605361006451376260, -330969124188540848, -3097589157472793111506, 50303421048314470767230, -229704557590515699931750, 295145754901990490479755, 352980190479803513930635, -1126283071908267615269575, 725053534327443775771125, 94175394268754425995000, -158557271464947049200000]]
for name, rows, run, V1, N in (('lean', lean, sys.argv[1], 66, 6), ('centre', centre, sys.argv[2], 63, 12)):
    c = law(run); h = len(c) - 1
    M = sp.Matrix(rows)
    low = [c[0][5] * V1] + [c[i][0] for i in range(1, h + 1)] + [0] * (N - h)
    inspan = sp.Matrix.vstack(M, sp.Matrix([low])).rank() == M.rank()
    print(f'{name}: {M.rows} relations of rank {M.rank()}; the low-end relation in their span: {inspan}')
    if N > h:
        lawk1 = [0] + [ev(c[j], 1) for j in range(h + 1)]
        print(f'   the law at k = 1 in their span: {sp.Matrix.vstack(M, sp.Matrix([lawk1[:N + 1]])).rank() == M.rank()}')
    # express the last unknowns through 1, P(1), ...: reduced echelon form with P(N), P(N-1), ... eliminated first
    perm = list(range(N, 0, -1)) + [0]
    R = M[:, perm].rref()[0]
    names = [f'P({i})' for i in range(N, 0, -1)] + ['1']
    for r in range(R.rows):
        piv = next(j for j in range(R.cols) if R[r, j] != 0)
        rhs = ' '.join(f'+({-R[r, j]})*{names[j]}' for j in range(piv + 1, R.cols) if R[r, j] != 0)
        print(f'   {names[piv]} = {rhs}')
