"""The low-end relation of a run in primitive integer form, [k^(n-1)]c_0 V_1 + sum_i c_i(0) P(i) = 0
divided by the gcd of its coefficients, and the shift that carries the large factor of c_0 into c_h.
Usage: python3 lowend_forms.py RUN_DIR n V1"""
import os, pickle, sys
from fractions import Fraction as Fr
from math import gcd
from functools import reduce
from flint import fmpz_poly

run, n, V1 = sys.argv[1], int(sys.argv[2]), Fr(sys.argv[3])
with open(os.path.join(run, 'law_exact.pkl'), 'rb') as fh:
    c = pickle.load(fh)['c']
h = len(c) - 1
const = c[0][n - 1] * V1
coef = [c[i][0] for i in range(1, h + 1)]
assert const.denominator == 1
g = reduce(gcd, [abs(int(const))] + [abs(x) for x in coef])
print(f'h = {h}; gcd = {g}')
print(f'low-end relation / gcd: constant {int(const) // g}; coefficients of P(1..h): {[x // g for x in coef]}')
ps = [fmpz_poly([int(x) for x in cj]) for cj in c]
big0 = max((f for f, e in ps[0].factor()[1]), key=lambda f: f.degree())
bigh = max((f for f, e in ps[h].factor()[1]), key=lambda f: f.degree())
print(f'largest factor of c_0: degree {big0.degree()}; of c_h: degree {bigh.degree()}')
for sh in range(-h - 2, h + 3):
    # big0(k + sh) as a polynomial
    q = fmpz_poly([0])
    for i, a in enumerate(big0.coeffs()):
        q += a * fmpz_poly([sh, 1]) ** i
    if q.content() != 0 and (bigh * q.leading_coefficient() - q * bigh.leading_coefficient()) == 0:
        print(f'   the large factor of c_h is that of c_0 at k + {sh}')
