# Receipts for the Foreman handbook, version 2

Each folder holds the scripts that compute the numbers in the named part of the handbook, in exact arithmetic (python-flint, sympy, fractions) unless a script says it renders floats. Run a script with python3 from its own folder; the receipts of version 1 and of the notebooks are the ones already supplied with them.

## exercises1/

Part XI, chapters "Exercises on tables, families and classification" and "Exercises on evaluation and construction"

- `ex01_share_side.py`: Receipt for Exercise ex:cls-share (the list binom([2],1) on its share side).
- `ex02_pins.py`: Receipt for Exercise ex:cls-pins (the pins of the atom formula of six lists).
- `ex03_tree_u14.py`: Receipt for Exercise ex:cls-u14tree (the Foreman trees of binom([4],1)).
- `ex04_five_marks.py`: Receipt for Exercise ex:cls-five (the list P_5 of rank two on five marks without the basis {1,2}).
- `ex05_six_marks.py`: Receipt for Exercises ex:cls-sixtree and ex:cls-sixsplit (the list T_6 of rank three on six marks without
- `ex06_skeleton_u24.py`: Receipt for Exercise ex:cls-u24skel (Skeleton values of binom([4],2) along {1,2}).
- `ex07_record.py`: Receipt for Exercise ex:cls-record (peeling with and without the record).
- `ex08_transverse.py`: Receipt for Exercise ex:con-transverse (one share per station at a set of width two).
- `ex09_width_subst.py`: Receipt for Exercise ex:con-widthbound (the width of the marks left in place).
- `ex10_fusion_u25.py`: Receipt for Exercise ex:con-fusion (fusing binom([5],2)).
- `listkit.py`: Exact toolkit for the exercise receipts of ch:exclass and ch:exconstruct.

## exercises3/

Part XI, chapter "Exercises on the motive and the arithmetic of values"

- `ex1_series_u23.py`: Receipt for Exercise ex:mot-series: binom([3],2) at its centre, read at the root bunch {1,2}.
- `ex2_dualpair_u24.py`: Receipt for Exercise ex:mot-dualpair: binom([4],2) at its centre, its dual-pair cells, and its pairs.
- `ex3_critical_u14.py`: Receipt for Exercise ex:mot-critical: binom([4],1) at its full leans and at its centre.
- `ex4_substitution.py`: Receipt for Exercise ex:mot-substitution: the lists P_5 and M_8 at their centres.
- `ex5_fulllean.py`: Receipt for Exercise ex:mot-fulllean: lists at (s,t) = (0,2) with unit masses; the list D_10.
- `listkit.py`: Exact toolkit for the exercise receipts of ch:exclass and ch:exconstruct.
- `subst.py`: Substitution of cells into a core (Definition def:substitution), exact, for the receipts of ch:exmotive.

## exercises4a/

Part XI, chapter "Exercises on rays: the small centres" (three marks)

- `boxkit.py`: The box of a ray (Definition def:raybox) and its reduction (Definition def:box-reduction), exact over Q(k).
- `ex18_centre_bracket.py`: Receipt for Exercise ex:smallc-bracket: the centre ray of binom([3],1), bracketed.
- `ex19_centre_box.py`: Receipt for Exercise ex:smallc-box: the centre of binom([3],1) by the box.
- `ex20_gauge_end.py`: Receipt for Exercise ex:smallc-gauge: the centre of binom([3],1) read from its gauge end.
- `ex21_torus.py`: Receipt for Exercise ex:smallc-torus: the torus at three marks.
- `ex22_lean.py`: Receipt for Exercise ex:smallc-lean: the lean (2 1; 4, 1) of binom([3],1).
- `ex23_directions.py`: Receipt for Exercise ex:smallc-directions: the balanced directions of binom([3],1).
- `kit3.py`: Shared exact tools for the exercises on the list binom([3],1) (marks 1, 2, 3, bases the singletons, unit weights).

## exercises4b/

Part XI, chapter "Exercises on rays: the small centres" (four and five marks, W_3, positivity)

- `common.py`: Shared exact tools for the exercises of chapter XI.4, second half (python-flint, sympy).
- `ex24a_halflattice.py`: Exercise ex:cfour-halflattice: the centre of binom([4],1) at strength one, closed on the half-lattice.
- `ex24b_law.py`: Exercise ex:cfour-law: the law of the centre ray of binom([4],1), its closings, its symbol,
- `ex24c_row.py`: Exercise ex:cfour-row: the row of the four-mark centre at every step (exact arithmetic).
- `ex24d_closing.py`: Exercise ex:cfour-closing: the coefficient of the coordinate of the four-mark centre ray is a closing.
- `ex24e_clearing.py`: Exercise ex:cfour-clearing: the clearing of the rows of the four-mark centre.
- `ex25a_law.py`: Exercise ex:cfive-law: the law of the centre ray of binom([5],1), its closings and symbol, the low-end
- `ex25b_pairing.py`: Exercise ex:cfive-pairing: the exact pairing of the values of the centre ray of binom([5],1) with its
- `ex25c_lowered.py`: Exercise ex:cfive-lowered: the lowered settings of five marks, their low-end coefficients, their rates,
- `ex25d_gauge.py`: Exercise ex:cfive-gauge: the centre ray of binom([5],1) read from its gauge end (Theorem gaugeend):
- `ex25e_slope.py`: Exercise ex:cfive-slope: the five-mark centre at strength one as a Trailmoment of the slope input of
- `ex26a_box.py`: Exercise ex:wthree-box: W_3 at (1;0,2) read from its list by the box of the walls.
- `ex26b_bracket.py`: Exercise ex:wthree-bracket: W_3 at (1;0,2): the low-end relation, the first bracket, the brackets of the
- `ex27_positivity.py`: Exercise ex:cthree-positivity: positivity against the gauge end on the centre ray of binom([3],1).
- `w3common.py`: The wheel W_3 at (1;0,2): marks, bases, walls, symbols of the box (shared by the W_3 receipts).

## twoends_ed/

Chapter "The two ends of a ray" (the box) and Part XI, section "What the closings see"

- `B_H.pkl`
- `B_Hlean.pkl`
- `B_U36.pkl`
- `B_W3.pkl`
- `B_W3x.pkl`
- `B_banana4.pkl`
- `B_banana5.pkl`
- `B_three.pkl`
- `H.sing`
- `Hlean.sing`
- `N.sing`
- `W3.sing`
- `binf_exact.out`
- `binf_exact.py`: B(infinity) of the box at the centres of binom([5],2) and binom([6],3), exactly, with its eigenvalues and
- `blind2_all.out`
- `boxes_all.py`: The boxes of Exercise ex:closingssee, built and eliminated exactly over Q(k) from Definition def:raybox
- `boxes_big.out`
- `boxexact.py`: Exact boxes of a ray of one table (Definitions def:raybox and def:box-reduction of ch:twoends), over Q(k).
- `ell_check.out`
- `ell_check.py`: The element l = sum_{i!=j} a_i/a_j - (2k/(k-1)) (e1 e2/e3 + e3 e4/(e2 e5)) = 3 (1 - E) sum_{i!=j} a_i/a_j,
- `latex_snippets.py`: LaTeX of the exact quantities displayed in ex_closingssee.tex (from B_*.pkl of boxes_all.py and the runs).
- `make_patch.py`: Assemble /home/claude/v2/new/twoends_ed/patches_twoends_ed.tex: the REPLACE old texts are copied byte for byte
- `n_exchange.py`: The centre of N_6 (bases: the triples of {0..5} other than {0,1,2}) with G = automorphisms and Cremona: the action
- `oddcentre_hessian.out`
- `oddcentre_hessian.py`: Check of Proposition prop:onemarkhidden (ii) for r = 2..6, exactly: the covariances of the indicators at the sign
- `olds.pkl`
- `run_blind2.sh`
- `signs_span.py`: Signs as native gauges of a centre ray (Theorem thm:signgauges) and the independence of a box's spanning set
- `summary.py`: For each box of Exercise ex:closingssee: the monic common denominator Q0 of B and its roots, D0, the law of [1]
- `three_exact.out`
- `three_exact.py`: The centre of binom([3],1), exactly over Q (Exercise ex:closingssee, part (i), the worked list).
- `u25.sing`
- `u25_B.pkl`
- `u25_box.py`: The centre of binom([5],2): the box B_3(1,1) modulo G = S_5 x <cr>, eliminated exactly over Q(k).
- `u25_core.out`
- `u25_core.py`: The centre of binom([5],2), exactly (Exercise ex:closingssee, part (iii)).
- `u36.sing`
- `u36_lift.out`
- `u36_lift.py`: The native gauges of the centre of binom([5],2) lifted to the centre of binom([6],3) (Proposition prop:onemark (i)):

## exercises5a/

Part XI, chapter "Exercises on rays: other lists" (H_4 and the five-mark lists)

- `common.py`: Shared tools for the receipts of Chapter ch:exlists (exercises on rays: other lists).
- `ex28_h4_centre.py`: Receipt for Exercise ex:lista-hcentre: the list H_4 at its centre.
- `ex29_h4_lean.py`: Receipt for Exercise ex:lista-hslit: the list H_4 on the ray (1,1,3,3;3,1).
- `ex29_law.txt`
- `ex29_telescoper_A.txt`
- `ex30_trees.py`: Receipt for Exercise ex:lista-trees: the five-mark lists along their hinge trees.

## exercises5b/

Part XI, chapter "Exercises on rays: other lists", section "Larger lists and the cost of a reading"

- `N7.json`
- `Q6.json`
- `U24.json`
- `analyze_run.py`: Exact data read off a finished run of the ray reader: the box, the spanning set, the matrix B over Q(k)
- `betas.py`: The values of the spanning set of an accepted box at the native gauges of a census (Proposition
- `betas_V8.out`
- `box_N7_211.out`
- `box_Q6_211.out`
- `box_test.py`: One box of a ray, tested as the ray reader's masters stage does (Definition def:box-reduction): its relations
- `census_V8_routes.json`
- `census_paths.py`: The native gauges of a direction reached from the generic critical points along several paths: every
- `crit_N6_centre.json`
- `crit_N6_lean.json`
- `crit_N7.json`
- `crit_N7.log`
- `crit_Q6.json`
- `crit_Q6_seed2.json`
- `crit_Q6_seed3.json`
- `crit_V8_lean.json`
- `crit_V8_lean.log`
- `crit_V8_lean_seed2.json`
- `crit_V8_lean_seed2.log`
- `critpoints.py`: Critical points of a product of powers of the letters and the marks, counted by monodromy, and carried to
- `escape_V8.out`
- `escape_check.py`: Where the paths that do not arrive end: every generic solution of a census is carried to the direction,
- `exact_data.out`
- `exact_data.py`: Exact data of the rays of exercises XI.5 (second half): walls by height, the least wall, the volume of the
- `gb_V8_direction_p.out`
- `gb_V8_lean.out`
- `gb_count.py`: The number of critical points of alpha^a K^-bK Psi^-bP for random exponents, by a Groebner basis modulo a
- `gb_direction.py`: The native gauges of a direction by a Groebner basis over Q (Singular, characteristic 0): the critical
- `h4_gauges.out`
- `h4_gauges.py`: The native gauges of H_4 (rank two on {1,2,3,4}, bases the pairs other than {1,2}) at its centre (1;1,1)
- `hessians.out`
- `hessians.py`: The Hessian H of -log f at log alpha* on the chart alpha_n = 1 (Theorem thm:branch: the covariances of the
- `listsb.py`: The lists of exercises XI.5 (second half), defined by their marks and bases, with exact helpers.
- `lowend_forms.py`: The low-end relation of a run in primitive integer form, [k^(n-1)]c_0 V_1 + sum_i c_i(0) P(i) = 0
- `matrix_rows_tex.py`: The rows of the one-step matrix of a run, each written as one rational factor times a row of polynomials
- `matrix_tex.py`: The one-step matrix of a run over its monic common denominator Q_c: the numerators Q_c(k) B_il(k) as
- `nsix_centre_exact.out`
- `nsix_centre_exact.py`: N6 at its centre (1;1,1): the slice (x,x,x,1,1,1), its critical points and native values; the values of the
- `nsix_ctcheck.py`: The law of N6 against its constant terms (Corollary cor:rays-lowend(i)): sum_i c_i(-j) CT(f^(i-j)) = 0 for
- `nsix_exact.out`
- `nsix_exact.py`: Exact computations for the exercises on N6 (rank three on [6], every triple a basis but a = {1,2,3}):
- `nsix_gauges24.py`: N6 at (1;0,2): the two orbits of native gauges of native value 1/24 are rational points; check exactly that
- `nsix_signs.out`
- `nsix_signs.py`: The signs of the centre ray of N6 (Theorem thm:signgauges): K(eta) at the 32 signs of the chart eta_6 = 1,
- `polish.py`: Polish the native gauges of a census (critpoints.py output) by Newton's method in multiprecision at the
- `polish_N6_lean.out`
- `polish_Q6.out`
- `runs_table.sh`
- `table_check.out`
- `table_check.py`: Checks for the table of rays read by the procedure (exercise ex:listsb-table), at 60 digits.
- `table_checkrun.out`
- `table_masters.out`
- `table_masters.py`: Are the spanning sets of the table's runs sets of masters?  (Exercise ex:listsb-table; Proposition
- `table_summary.out`
- `table_summary.py`: The table of rays read by the ray reader (exercise ex:listsb-table): for each run directory the box, its
- `table_summary60.out`
- `valuespan_N.out`
- `valuespan_N.py`: Integer relations among the values of N6 at (1;0,2) and at (1;1,1), by lattice reduction (exercise on N_6,
- `valuespan_exact.out`
- `valuespan_exact.py`: Exact linear algebra on the integer relations of valuespan_N.out: the lattice they span, whether the
- `runlogs/H_centre.d60.stdout`
- `runlogs/H_centre.stdout`
- `runlogs/H_slit.d60.stdout`
- `runlogs/H_slit.stdout`
- `runlogs/MK4_lean.d60.stdout`
- `runlogs/MK4_lean.stdout`
- `runlogs/N_centre.check`
- `runlogs/N_centre.d60.stdout`
- `runlogs/N_centre.stdout`
- `runlogs/N_lean.check`
- `runlogs/N_lean.d60.stdout`
- `runlogs/N_lean.stdout`
- `runlogs/U24_centre.d60.stdout`
- `runlogs/U24_centre.stdout`
- `runlogs/U24_lean.d60.stdout`
- `runlogs/U24_lean.stdout`
- `runlogs/U25_centre.d60.stdout`
- `runlogs/U25_centre.stdout`
- `runlogs/V_lean.stdout`
- `runlogs/banana4_centre.d60.stdout`
- `runlogs/banana4_centre.stdout`
- `runlogs/banana5_centre.d60.stdout`
- `runlogs/banana5_centre.stdout`
- `runlogs/table_check.log`
- `runlogs/three_centre.d60.stdout`
- `runlogs/three_centre.stdout`
- `runlogs/three_half.d60.stdout`
- `runlogs/three_half.stdout`
- `runlogs/three_lean.d60.stdout`
- `runlogs/three_lean.stdout`

## exercises6/

Part XI, chapter "Exercises on the content"

- `ct_cutting.py`: The cutting rule (Definition def:ct-cutting) on the symbols of the trails Tx3(IZ,0) and of index 2 at the
- `ct_values.py`: The centre values of the lists of three and four marks read in the content: exact identities in Q(mu_3) and
