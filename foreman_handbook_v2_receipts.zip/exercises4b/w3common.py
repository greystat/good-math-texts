"""The wheel W_3 at (1;0,2): marks, bases, walls, symbols of the box (shared by the W_3 receipts)."""
import itertools
from fractions import Fraction as Fr
from math import factorial

# marks: spokes s1,s2,s3 (hub 0 to rim vertex i) and rims r1=(1,2), r2=(2,3), r3=(3,1)
MARKS = ['s1', 's2', 's3', 'r1', 'r2', 'r3']
EDGES = [(0, 1), (0, 2), (0, 3), (1, 2), (2, 3), (3, 1)]
n = 6

def is_tree(es):
    parent = list(range(4))
    def find(x):
        while parent[x] != x: x = parent[x]
        return x
    for (a, b) in es:
        ra, rb = find(a), find(b)
        if ra == rb: return False
        parent[ra] = rb
    return True

BASES = [frozenset(T) for T in itertools.combinations(range(6), 3) if is_tree([EDGES[i] for i in T])]
assert len(BASES) == 16
COBASES = [frozenset(range(6)) - T for T in BASES]   # exponents of Psi

def rank(S):
    return max(len(S & T) for T in BASES)

SUBSETS = [frozenset(S) for r in range(1, 6) for S in itertools.combinations(range(6), r)]
RANK = {S: rank(S) for S in SUBSETS}
KAPPA1 = {S: 2*RANK[S] - len(S) for S in SUBSETS}       # walls of the direction (1;0,2)
DSTAR = {S: len(S) - RANK[S] for S in SUBSETS}          # least trace of a cobasis on S

def V1():
    tot = Fr(0)
    for pi in itertools.permutations(range(6)):
        prod = Fr(1)
        for l in range(1, 6):
            U = frozenset(pi[l:])
            prod /= KAPPA1[U]
        tot += prod
    return tot

def vertex_perm_to_edge_perm(sigma):
    """sigma: permutation of vertices 0..3 -> permutation of marks (as a tuple beta with beta[e] = image edge)"""
    out = []
    for (a, b) in EDGES:
        im = (sigma[a], sigma[b])
        for j, (c, d) in enumerate(EDGES):
            if {c, d} == set(im): out.append(j); break
    return tuple(out)

AUTOS = sorted(set(vertex_perm_to_edge_perm(s) for s in itertools.permutations(range(4))))
assert len(AUTOS) == 24

def act(beta, u):
    """(u o beta^{-1}): the image of the exponent vector u under the mark permutation beta"""
    v = [0]*6
    for e in range(6): v[beta[e]] = u[e]
    return tuple(v)

def wall_degree_ok(u, b, t):
    """symbol (u;0,b): kappa_U(g) + t kappa_{1,U} >= 0 for all U"""
    for S in SUBSETS:
        kU = sum(u[e] for e in S) - b*DSTAR[S]
        if kU + t*KAPPA1[S] < 0: return False
    return True

def wall_degree(u, b):
    return max(Fr(-(sum(u[e] for e in S) - b*DSTAR[S]), KAPPA1[S]) for S in SUBSETS)

def symbols(t):
    lev0 = []; lev1 = []
    rng0 = range(-t, t+1)
    for u in itertools.product(range(-t, t+2), repeat=6):
        s_ = sum(u)
        if s_ == 0 and all(-t <= x <= t for x in u) and wall_degree_ok(u, 0, t): lev0.append(u)
        if s_ == 3 and wall_degree_ok(u, 1, t): lev1.append(u)
    return lev0, lev1

# ---------------- the box B_2 with one unit of Psi, modulo the automorphisms ----------------
COB = [tuple(1 if e in C else 0 for e in range(6)) for C in COBASES]
def addv(u, v): return tuple(a+b for a, b in zip(u, v))
def canon(u): return min(act(b, u) for b in AUTOS)

def build_box(t=2):
    """symbols, orbits and the averaged relations of the box B_t(0,1) modulo the 24 automorphisms.
    A relation is a dict {(level, canonical exponent): (a, b)} meaning the coefficient a + b k."""
    lev0, lev1 = symbols(t)
    set1 = set(lev1)
    orb = {}
    for u in lev0: orb.setdefault(('0', canon(u)), []).append(u)
    for u in lev1: orb.setdefault(('1', canon(u)), []).append(u)
    rels = []
    nletter = nmark = 0
    for u in lev0:                      # letter identities for Psi
        row = {}
        key = ('0', canon(u)); a, b = row.get(key, (0, 0)); row[key] = (a+1, b)
        for c in COB:
            w = addv(u, c); assert w in set1
            key = ('1', canon(w)); a, b = row.get(key, (0, 0)); row[key] = (a-1, b)
        rels.append(row); nletter += 1
    for u in lev0:                      # mark relations of the stems
        for e in range(6):
            row = {}
            key = ('0', canon(u)); a, b = row.get(key, (0, 0)); row[key] = (a+u[e], b+1)
            for C, c in zip(COBASES, COB):
                if e in C:
                    w = addv(u, c); assert w in set1
                    key = ('1', canon(w)); a, b = row.get(key, (0, 0)); row[key] = (a, b-2)
            rels.append(row); nmark += 1
    uniq = {}
    for r in rels:
        kr = tuple(sorted((kk, v) for kk, v in r.items() if v != (0, 0)))
        if kr: uniq[kr] = {kk: v for kk, v in kr}
    return lev0, lev1, orb, list(uniq.values()), (nletter, nmark)

def f_inverse_terms():
    """f^{-1} = Psi^2/alpha^1 as {exponent: coefficient}"""
    out = {}
    for c in COB:
        for c2 in COB:
            w = tuple(a+b-1 for a, b in zip(c, c2))
            out[w] = out.get(w, 0) + 1
    return out

def target_vector(orb, b_canon):
    """orbit coordinates of f^{-1} b, b the orbit average of alpha^{b_canon}"""
    members = orb[('0', b_canon)]
    finv = f_inverse_terms()
    vec = {}
    for u in members:
        for w, cf in finv.items():
            key = ('0', canon(addv(u, w)))
            vec[key] = vec.get(key, Fr(0)) + Fr(cf, len(members))
    return vec
