"""Exercise ex:cfour-law: the law of the centre ray of binom([4],1), its closings, its symbol,
the low-end relation and the rows in the one coordinate v = P(1). Exact arithmetic (sympy, fractions);
the decimals at the end are renderings and a quadrature check."""
import sys; sys.path.insert(0, '.')
from common import *

n = 4
R = R_operators(n)
for i in range(2, n + 2):
    print('R_%d =' % i, ' + '.join('y^%d*(%s)' % (m, sp.factor(q)) for m, q in sorted(R[i].items())))
Q, c = ri_law(n)
print('Q_4 = R_5: q_{4,k} =', {m: sp.factor(q) for m, q in sorted(Q.items())})

# Q_4 annihilates every product of four solutions of theta^2 u = y u: on the basis w_i = u^{4-i} (theta u)^i
A = sp.zeros(n + 1, n + 1)
for i in range(n + 1):
    if i + 1 <= n: A[i, i + 1] = n - i
    if i - 1 >= 0: A[i, i - 1] = i * y
rows = [sp.Matrix([[1] + [0] * n])]
for j in range(n + 1):
    r = rows[-1]
    rows.append(sp.Matrix([[sp.expand(y * sp.diff(r[cc], y)) for cc in range(n + 1)]]) + r * A)
tot = sp.zeros(1, n + 1)
for mm, Qm in Q.items():
    P = sp.Poly(Qm, th)
    for (jj,), cf in P.terms():
        tot += cf * y ** mm * rows[jj]
print('Q_4 applied to u^4, coefficients of the w_i:', [sp.expand(x) for x in tot])

print('c_{4,k}(s):', {kk: sp.factor(v) for kk, v in sorted(c.items())})
p = [sp.expand(c[i].subs(s, k)) for i in range(3)]

# closings and the reflected law
J = 40
C = multinomial_closings(n, J)
print('closings C_0..C_8:', C[:9])
for jj in (1, 2):
    terms = [(sp.Integer(c[i].subs(s, -jj)), C[jj - i]) for i in range(min(2, jj) + 1)]
    print('  j=%d: ' % jj, ' + '.join('(%s)*%s' % t for t in terms), '=', sum(a * b for a, b in terms))
ok = all(sum(c[i].subs(s, -jj) * C[jj - i] for i in range(min(2, jj) + 1)) == 0 for jj in range(J + 1))
print('sum_i c_{4,i}(-j) C_{j-i} = 0 for j <= 40:', ok)
# the same closings from the Taylor coefficients of h^4 (h(y) = sum y^m/m!^2), annihilated by Q_4
a = [sp.Rational(C[j], factorial(j) ** 2) for j in range(J + 1)]
print('Q_4 h^4 = 0 through y^40:', all(apply_operator_to_series(Q, a, JJ) == 0 for JJ in range(J + 1)))

# symbol
lam = sp.Symbol('lambda')
chi = sum(sp.Poly(p[i], k).coeff_monomial(k ** 3) * lam ** i for i in range(3))
print('symbol chi_4 =', sp.expand(chi), '=', sp.factor(chi), ' roots', sp.solve(chi, lam))

# low-end relation: V_1 = 4! = 24
print('[s^3] c_{4,0} =', sp.Poly(c[0], s).coeff_monomial(s ** 3), ' c_{4,1}(0) =', c[1].subs(s, 0), ' c_{4,2}(0) =', c[2].subs(s, 0))
print('low-end relation: -24 + 4 P(1) - 64 P(2) = 0, so P(2) = (P(1) - 6)/16')

# rows <1>_k = a_k v - b_k with v = P(1)
K = 12
aa = run_law(p, [1, Fraction(1, 16)], K)
bb = run_law(p, [0, Fraction(3, 8)], K)
for kk in range(1, 7):
    print('  k=%d  (a_k; b_k) = (%s; %s)' % (kk, aa[kk], bb[kk]))
print('law step used: P(k+2) = (-c_{4,0}(k) P(k) - c_{4,1}(k) P(k+1)) / c_{4,2}(k)')
for kk in (1, 2):
    print('  k=%d: c_{4,0}=%s c_{4,1}=%s c_{4,2}=%s' % (kk, c[0].subs(s, kk), c[1].subs(s, kk), c[2].subs(s, kk)))

# renderings and a check
import mpmath as mp
mp.mp.dps = 30
v = 7 * mp.zeta(3)
print('rendering v = P(1) =', mp.nstr(v, 25))
for kk in range(1, 6):
    print('  rendering <1>_%d = %s' % (kk, mp.nstr(mp.mpf(aa[kk].numerator) / aa[kk].denominator * v - mp.mpf(bb[kk].numerator) / bb[kk].denominator, 20)))
g1 = lambda yy: 2 * mp.besselk(0, 2 * mp.sqrt(yy))
P2 = mp.quad(lambda yy: yy * g1(yy) ** 4, [0, 1, mp.inf])
print('check: int_0^oo y g(y)^4 dy =', mp.nstr(P2, 20))
