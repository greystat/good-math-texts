"""Exercise ex:cfive-slope: the five-mark centre at strength one as a Trailmoment of the slope input of
four marks. Exact: the derivative of the four-mark law, the boundary relation at the cut, the rows of the
slopes in 1, v = P_4(1) and the first slope. Checks: quadrature (mpmath) and the gauge-end value of P_5(1)."""
import sys; sys.path.insert(0, '.')
from common import *
import mpmath as mp

_, c = ri_law(4)
cp = {i: sp.expand(sp.diff(c[i], s)) for i in c}
print("c_{4,i}'(s):", {i: sp.factor(v) for i, v in cp.items()})
print("c_{4,i}(0) =", [c[i].subs(s, 0) for i in range(3)], "  c_{4,i}'(0) =", [cp[i].subs(s, 0) for i in range(3)])
gam = sp.Poly(c[0], s)
print('c_{4,0} = -s^3: gamma_3 =', gam.coeff_monomial(s ** 3), ' gamma_4 =', gam.coeff_monomial(s ** 4), '; ell_1 = 0 (unit weights)')

# values p(m) = A_m v + B_m (rows of ex:cfour-law, v = P_4(1)), slopes pt(m) = al_m + be_m v + ga_m pt(1)
p = [sp.expand(c[i].subs(s, k)) for i in range(3)]
pp = [sp.expand(cp[i].subs(s, k)) for i in range(3)]
M = 70
aa = run_law(p, [1, Fraction(1, 16)], M + 3)
bb = run_law(p, [0, Fraction(3, 8)], M + 3)
val = {m: (-bb[m], aa[m]) for m in aa}                      # (constant, coefficient of v)
# boundary relation: c1(0) pt(1) + c2(0) pt(2) - c1'(0) p(1) - c2'(0) p(2) = gamma_3 ell_1 + gamma_4 V_1 = 0
c10, c20 = Fraction(int(c[1].subs(s, 0))), Fraction(int(c[2].subs(s, 0)))
d10, d20 = Fraction(int(cp[1].subs(s, 0))), Fraction(int(cp[2].subs(s, 0)))
# pt(2) = (d10 p(1) + d20 p(2) - c10 pt(1)) / c20 ; as (const, v, pt1)
p1, p2 = val[1], val[2]
sl = {1: (Fraction(0), Fraction(0), Fraction(1))}
sl[2] = ((d10 * p1[0] + d20 * p2[0]) / c20, (d10 * p1[1] + d20 * p2[1]) / c20, -c10 / c20)
print('pt(2) = %s + %s v + %s pt(1)' % sl[2])
for m in range(1, M + 1):
    ci = [Fraction(int(p[i].subs(k, m))) for i in range(3)]
    di = [Fraction(int(pp[i].subs(k, m))) for i in range(3)]
    # c0 pt(m) + c1 pt(m+1) + c2 pt(m+2) = d0 p(m) + d1 p(m+1) + d2 p(m+2)
    rhs = [sum(di[i] * val[m + i][t] for i in range(3)) for t in range(2)]
    sl[m + 2] = tuple(((rhs[t] if t < 2 else 0) - ci[0] * sl[m][t] - ci[1] * sl[m + 1][t]) / ci[2] for t in range(3))
for m in range(1, 6):
    print('  pt(%d) = %s + %s v + %s pt(1)' % ((m,) + sl[m]))

# numbers: v and pt(1) = -p'(1) by quadrature
mp.mp.dps = 40
g = lambda yy: 2 * mp.besselk(0, 2 * mp.sqrt(yy))
v = 7 * mp.zeta(3)
I_log = mp.quad(lambda yy: mp.log(yy) * g(yy) ** 4, [0, mp.mpf(1) / 100, 1, 10, 100, mp.inf])
pt1 = -(I_log - 2 * mp.digamma(1) * v)          # p'(1) = int log y g^4 - 2 psi(1) p(1)
print('rendering pt(1) = -p\'(1) =', mp.nstr(pt1, 30))
vals = {m: mp.mpf(sl[m][0].numerator) / sl[m][0].denominator + mp.mpf(sl[m][1].numerator) / sl[m][1].denominator * v
        + mp.mpf(sl[m][2].numerator) / sl[m][2].denominator * pt1 for m in sl}
for m in range(2, 6):
    print('  rendering pt(%d) = %s' % (m, mp.nstr(vals[m], 12)))
total = mp.fsum(vals[m] for m in range(1, M + 1))
print('sum_{m=1}^{%d} pt(m) =' % M, mp.nstr(total, 30))
print('live part sum_{m>=2} pt(m) =', mp.nstr(total - pt1, 20))
print('gauge-end value P_5(1) = 39.9455880119962456989440284984239958918497829247698595723666 (ex25d); difference:',
      mp.nstr(total - mp.mpf('39.9455880119962456989440284984239958918497829247698595723666'), 5))
# a direct check of pt(2) by quadrature
I2 = mp.quad(lambda yy: yy * mp.log(yy) * g(yy) ** 4, [0, mp.mpf(1) / 100, 1, 10, 100, mp.inf])
p2v = v / 16 - mp.mpf(3) / 8
pt2_quad = -(I2 - 2 * mp.digamma(2) * p2v)       # Gamma(2)^2 = 1
print('check pt(2): row =', mp.nstr(vals[2], 25), ' quadrature =', mp.nstr(pt2_quad, 25))
# Proposition ri-addmark(iii): 5 sum p - 5 sum (x-1) pt = sum pt
lhs = 5 * mp.fsum(mp.mpf(val[m][0].numerator) / val[m][0].denominator + mp.mpf(val[m][1].numerator) / val[m][1].denominator * v for m in range(1, M + 1)) \
    - 5 * mp.fsum((m - 1) * vals[m] for m in range(1, M + 1))
print('check: 5 sum p(x) - 5 sum (x-1) pt(x) - sum pt(x) =', mp.nstr(lhs - total, 5))
