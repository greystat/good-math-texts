"""Exercise ex:cfive-pairing: the exact pairing of the values of the centre ray of binom([5],1) with its
closings, and det H two ways. Exact arithmetic."""
import sys; sys.path.insert(0, '.')
from common import *

n = 5
Q, c = ri_law(n)
p = [sp.expand(c[i].subs(s, k)) for i in range(4)]
J = 60
C = multinomial_closings(n, J)
Cf = lambda m: C[m] if m >= 0 else 0

# rows P(m) = q + a P(1) + b P(2) as triples (q, a, b)
row = {1: (Fraction(0), Fraction(1), Fraction(0)), 2: (Fraction(0), Fraction(0), Fraction(1)),
       3: (Fraction(120, 900), Fraction(-5, 900), Fraction(285, 900))}
for kk in range(1, J + 2):
    cc = [Fraction(int(p[i].subs(k, kk))) for i in range(4)]
    row[kk + 3] = tuple(-(cc[0] * row[kk][t] + cc[1] * row[kk + 1][t] + cc[2] * row[kk + 2][t]) / cc[3] for t in range(3))

def B(sig):
    tot = [Fraction(0)] * 3
    for i in range(1, 4):
        for jj in range(1, i + 1):
            coef = Fraction(int(c[i].subs(s, sig - jj))) * Cf(sig - jj)
            if coef == 0: continue
            r = row[sig - jj + i]
            for t in range(3): tot[t] += coef * r[t]
    return tot
for sig in (1, 2, 3):
    terms = []
    for i in range(1, 4):
        for jj in range(1, i + 1):
            if sig - jj >= 0:
                terms.append('c_{5,%d}(%d) C_%d P(%d) = %s*%s*P(%d)' % (i, sig - jj, sig - jj, sig - jj + i, c[i].subs(s, sig - jj), Cf(sig - jj), sig - jj + i))
    print('B(%d): ' % sig + ';  '.join(terms))
    print('   in the span (1, P(1), P(2)):', [str(x) for x in B(sig)])
print('B(sigma) = -120 exactly in the span for 1 <= sigma <= 50:', all(B(sg) == [Fraction(-120), 0, 0] for sg in range(1, 51)))
# the telescoping identity, symbolically
sg = sp.Symbol('sigma')
Pf = sp.Function('P'); Cs = sp.Function('C')
Bs = lambda x: sum(c[i].subs(s, x - jj) * Cs(x - jj) * Pf(x - jj + i) for i in range(1, 4) for jj in range(1, i + 1))
diff = sp.expand(Bs(sg + 1) - Bs(sg) - (Cs(sg) * sum(c[i].subs(s, sg) * Pf(sg + i) for i in range(4))
                                           - Pf(sg) * sum(c[i].subs(s, sg - i) * Cs(sg - i) for i in range(4))))
print('B(sigma+1) - B(sigma) = C_sigma (law at sigma) - P(sigma) (adjoint law at sigma):', diff == 0)
print('adjoint coefficients c_{5,i}(sigma-i) = c_{5,i}(-sigma):', [sp.expand(c[i].subs(s, sg - i) - c[i].subs(s, -sg)) == 0 for i in range(4)])

# det H from the limit of the pairing (Proposition ri-pairing(iii))
lam = sp.Symbol('lambda')
chi = sp.expand(sum(sp.Poly(p[i], k).coeff_monomial(k ** 4) * lam ** i for i in range(4)))
ls = sp.Rational(1, 25)
dchi = sp.diff(chi, lam).subs(lam, ls)
print("chi(0) =", chi.subs(lam, 0), " chi'(1/25) =", dchi, " -lambda chi'/chi(0) =", -ls * dchi / chi.subs(lam, 0),
      " prod (1 - lambda*/lambda_c) =", (1 - ls * 9) * (1 - ls * 1))
detH = (-ls * dchi / chi.subs(lam, 0)) / 120
print('det H = (384/625)/120 =', detH)
# det H from the Hessian of -log f at 1 on the chart alpha_5 = 1
al = sp.symbols('a1:5')
yv = sp.symbols('y1:5')
Kp = sum(sp.exp(t) for t in yv) + 1
Km = sum(sp.exp(-t) for t in yv) + 1
mlogf = sp.log(Kp) + sp.log(Km)
H = sp.Matrix(4, 4, lambda i, j: sp.diff(mlogf, yv[i], yv[j]).subs({t: 0 for t in yv}))
print('H =', H.tolist(), ' = 2(I/5 - J/25):', H == 2 * (sp.eye(4) / 5 - sp.ones(4, 4) / 25), ' det H =', H.det())
print('Proposition ri-signs(ii) at eta = 1, sigma = 1: (2 sigma)^(n-1) / K(1)^n =', sp.Rational(2 ** 4, 5 ** 5))
# the other native values: signs with j marks at -1, K = 5 - 2j
for jneg in (1, 2):
    eta = [-1] * jneg + [1] * (5 - jneg)
    print('  sign with %d marks at -1: K = %d, native value %s' % (jneg, sum(eta), sp.Rational(1, sum(eta) ** 2)))
