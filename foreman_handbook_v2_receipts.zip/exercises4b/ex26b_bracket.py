"""Exercise ex:wthree-bracket: W_3 at (1;0,2): the low-end relation, the first bracket, the brackets of the
two positivity conditions at every K, their widths, and the value by positive selection. Exact
arithmetic (fractions); decimals are renderings."""
import sys; sys.path.insert(0, '.')
from common import *
import mpmath as mp

p = [k ** 5, -2 * (2 * k + 1) * (65 * k ** 4 + 130 * k ** 3 + 105 * k ** 2 + 40 * k + 6),
     16 * (k + 1) * (2 * k + 1) * (2 * k + 3) * (4 * k + 3) * (4 * k + 5)]
lam = sp.Symbol('lambda')
D = 5
chi = sp.expand(sum(sp.Poly(p[i], k).coeff_monomial(k ** D) * lam ** i for i in range(3)))
chi1 = sp.expand(sum(sp.Poly(sp.expand(p[i]), k).coeff_monomial(k ** (D - 1)) * lam ** i for i in range(3)))
print('symbol', sp.factor(chi), ' second symbol', sp.factor(chi1))
for root in (sp.Rational(1, 256), sp.Rational(1, 4)):
    print('  exponent at %s: -chi_1/(lambda chi\') =' % root, -chi1.subs(lam, root) / (root * sp.diff(chi, lam).subs(lam, root)))
V1 = 84
a = sp.Poly(p[0], k).coeff_monomial(k ** 5)
p10, p20 = p[1].subs(k, 0), p[2].subs(k, 0)
print('[k^5] p_0 =', a, ' p_1(0) =', p10, ' p_2(0) =', p20, ' low-end relation: %s*84 + %s P(1) + %s P(2) = 0' % (a, p10, p20))
fs = sp.Rational(1, 256)
lo = -a * V1 / p10
hi = -a * V1 / (p10 + fs * p20)
print('first bracket: -a V_1/p_1(0) =', lo, ' < P(1) < -a V_1/(p_1(0) + f* p_2(0)) =', hi, '  (p_1(0) + f* p_2(0) =', p10 + fs * p20, ')')

# c and r: P(K) = c(K) P(1) + r(K)
KMAX = 90
cc = run_law(p, [1, Fraction(1, 60)], KMAX)
rr = run_law(p, [0, Fraction(-7, 60)], KMAX)
print('c(K), K = 1..6:', [str(cc[K]) for K in range(1, 7)])
print('r(K), K = 1..6:', [str(rr[K]) for K in range(1, 7)])
print('low-end coefficients: of c:', -(int(p10) * cc[1] + int(p20) * cc[2]), ' of r:', -(int(p10) * rr[1] + int(p20) * rr[2]))
aK = {K: -rr[K] / cc[K] for K in range(2, KMAX + 1)}
bK = {K: (rr[K - 1] - 256 * rr[K]) / (256 * cc[K] - cc[K - 1]) for K in range(2, KMAX + 1)}
signs = all(cc[K] > 0 and 256 * cc[K] - cc[K - 1] > 0 for K in range(2, KMAX + 1))
print('c(K) > 0 and 256 c(K) - c(K-1) > 0 for 2 <= K <= %d:' % KMAX, signs)
print('K=2 bracket:', aK[2], '< P(1) <', bK[2])
mp.mp.dps = 80
w = {K: bK[K] - aK[K] for K in aK}
for K in (2, 3, 4, 5, 6, 8, 10, 12, 15, 20):
    print('  K=%2d: width %s' % (K, mp.nstr(mp.mpf(w[K].numerator) / w[K].denominator, 4)))
print('ratios of consecutive widths at K = 10, 20, 40, 80:', [mp.nstr(mp.mpf((w[K] / w[K - 1]).numerator) / (w[K] / w[K - 1]).denominator, 6) for K in (10, 20, 40, 80)], ' (1/64 = 0.015625)')
print('K=12: a_12 =', aK[12])
print('      b_12 =', bK[12])
print('nested: a_K increasing and b_K decreasing for 2 <= K <= %d:' % KMAX,
      all(aK[K] > aK[K - 1] for K in range(3, KMAX + 1)) and all(bK[K] < bK[K - 1] for K in range(3, KMAX + 1)))
val = mp.mpf(aK[KMAX].numerator) / aK[KMAX].denominator
print('P(1) rendered from a_%d:' % KMAX, mp.nstr(val, 62), '  width at K=%d:' % KMAX, mp.nstr(mp.mpf(w[KMAX].numerator) / w[KMAX].denominator, 4))
print('P(2) = (P(1) - 7)/60 rendered:', mp.nstr((val - 7) / 60, 60))
z6 = 6 * mp.zeta(3)
print('check: 6 T_3(Z) =', mp.nstr(z6, 62), ' in the bracket of K=12:',
      mp.mpf(aK[12].numerator) / aK[12].denominator < z6 < mp.mpf(bK[12].numerator) / bK[12].denominator)
# the continued fraction of Proposition rd-onemaster(iii): rho_1 = M_1 o ... o M_K(r), P(1) = -a V_1/(p_1(0) + p_2(0) rho_1)
def Mk(kk, r):
    return -Fraction(int(p[0].subs(k, kk))) / (Fraction(int(p[1].subs(k, kk))) + Fraction(int(p[2].subs(k, kk))) * r)
for K in (10, 40):
    r = Fraction(0)
    for kk in range(K, 0, -1):
        r = Mk(kk, r)
    P1 = Fraction(-int(a) * V1) / (int(p10) + int(p20) * r)
    print('continued fraction to depth %d (r = 0): P(1) = %s' % (K, mp.nstr(mp.mpf(P1.numerator) / P1.denominator, 40)))

# the constant terms CT(f^{-j}) = [alpha^{j 1}] Psi^{2j} and the reflected law (Corollary rays-lowend(i))
from w3common import COBASES
def ct_powers(J):
    out = [1]
    for jj in range(1, J + 1):
        states = {(0,) * 6: 1}
        for step in range(2 * jj):
            new = {}
            for e, cf in states.items():
                for T in COBASES:
                    e2 = list(e)
                    ok = True
                    for i in T:
                        e2[i] += 1
                        if e2[i] > jj: ok = False; break
                    if ok:
                        t2 = tuple(e2); new[t2] = new.get(t2, 0) + cf
            states = new
        out.append(states.get((jj,) * 6, 0))
    return out
CT = ct_powers(6)
print('CT(f^{-j}), j = 0..6:', CT)
ok = all(sum(int(p[i].subs(k, -jj)) * CT[jj - i] for i in range(min(2, jj) + 1)) == 0 for jj in range(7))
print('sum_i p_i(-j) CT(f^{i-j}) = 0 for j <= 6:', ok)
