"""Exercise ex:cfive-law: the law of the centre ray of binom([5],1), its closings and symbol, the low-end
relation, the value span and the rows at s = 3, 4. Exact arithmetic (sympy, fractions); the decimals
at the end are a quadrature check."""
import sys; sys.path.insert(0, '.')
from common import *

n = 5
R = R_operators(n)
for i in range(2, n + 2):
    print('R_%d =' % i, ' + '.join('y^%d*(%s)' % (m, sp.factor(q)) for m, q in sorted(R[i].items())))
Q, c = ri_law(n)
print('Q_5 = R_6: q_{5,k} =', {m: sp.expand(q) for m, q in sorted(Q.items())})
print('c_{5,k}(s):', {kk: sp.factor(v) for kk, v in sorted(c.items())})
# self-adjointness c_{5,i}(-s-i) = c_{5,i}(s)
print('c_{5,i}(-s-i) = c_{5,i}(s):', [sp.expand(c[i].subs(s, -s - i) - c[i]) == 0 for i in range(4)])
p = [sp.expand(c[i].subs(s, k)) for i in range(4)]

# closings and the reflected law
J = 40
C = multinomial_closings(n, J)
print('closings C_0..C_6:', C[:7])
ok = all(sum(c[i].subs(s, -jj) * C[jj - i] for i in range(min(3, jj) + 1)) == 0 for jj in range(J + 1))
print('sum_i c_{5,i}(-j) C_{j-i} = 0 for j <= 40:', ok)
a = [sp.Rational(C[j], factorial(j) ** 2) for j in range(J + 1)]
print('Q_5 h^5 = 0 through y^40:', all(apply_operator_to_series(Q, a, JJ) == 0 for JJ in range(J + 1)))

lam = sp.Symbol('lambda')
chi = sum(sp.Poly(p[i], k).coeff_monomial(k ** 4) * lam ** i for i in range(4))
print('symbol chi_5 =', sp.expand(chi), '=', sp.factor(chi), ' roots', sorted(sp.solve(chi, lam)))
print('[s^4] c_{5,0} =', sp.Poly(c[0], s).coeff_monomial(s ** 4), ' c_{5,i}(0) =', [c[i].subs(s, 0) for i in range(1, 4)])
print('low-end relation: 120 - 5 P(1) + 285 P(2) - 900 P(3) = 0')
print('c_{5,i}(1) =', [c[i].subs(s, 1) for i in range(4)], ' c_{5,i}(2) =', [c[i].subs(s, 2) for i in range(4)])

# rows in 1, P(1), P(2): P(k) = q_k + a_k P(1) + b_k P(2)
K = 12
row = {1: (Fraction(0), Fraction(1), Fraction(0)), 2: (Fraction(0), Fraction(0), Fraction(1))}
row[3] = (Fraction(120, 900), Fraction(-5, 900), Fraction(285, 900))
for kk in range(1, K - 2):
    cc = [Fraction(int(p[i].subs(k, kk))) for i in range(4)]
    row[kk + 3] = tuple(-(cc[0] * row[kk][t] + cc[1] * row[kk + 1][t] + cc[2] * row[kk + 2][t]) / cc[3] for t in range(3))
for kk in range(1, 6):
    g2 = factorial(kk - 1) ** 2
    print('  k=%d: P(k) = %s + %s P(1) + %s P(2);  Gamma(k)^2 P(k): (a,b,q) = (%s, %s, %s)' % (
        kk, row[kk][0], row[kk][1], row[kk][2], row[kk][1] * g2, row[kk][2] * g2, row[kk][0] * g2))

# quadrature check
import mpmath as mp
mp.mp.dps = 30
g1 = lambda yy: 2 * mp.besselk(0, 2 * mp.sqrt(yy))
Pq = {kk: mp.quad(lambda yy: yy ** (kk - 1) * g1(yy) ** 5, [0, 1, 10, mp.inf]) / mp.gamma(kk) ** 2 for kk in (1, 2, 3, 4)}
for kk in (1, 2, 3, 4):
    print('  quadrature P(%d) = %s' % (kk, mp.nstr(Pq[kk], 22)))
print('  check: 120 - 5P(1) + 285P(2) - 900P(3) =', mp.nstr(120 - 5 * Pq[1] + 285 * Pq[2] - 900 * Pq[3], 5))
r4 = row[4]
print('  check: row of P(4) - quadrature =', mp.nstr(mp.mpf(r4[0].numerator) / r4[0].denominator + mp.mpf(r4[1].numerator) / r4[1].denominator * Pq[1]
                                                    + mp.mpf(r4[2].numerator) / r4[2].denominator * Pq[2] - Pq[4], 5))
