"""Exercise ex:cfour-clearing: the clearing of the rows of the four-mark centre.
Checks 256^(k-1) d_(k-1)^3 b_k in Z and odd part of den(b_k) | d_(k-1)^3 (k <= 80), and every q-adic
estimate used in the proof (n <= 30, every odd prime q <= 2n; the prime 2)."""
import sys; sys.path.insert(0, '.')
from common import *
from fractions import Fraction as Fr
from flint import fmpq, fmpq_poly

def binom(a, b):
    return comb(a, b) if 0 <= b <= a else 0
def vq(x, q):
    x = Fr(x)
    if x == 0: return 10**9
    v = 0; a, b = x.numerator, x.denominator
    while a % q == 0: a //= q; v += 1
    while b % q == 0: b //= q; v -= 1
    return v
from functools import lru_cache
@lru_cache(maxsize=None)
def harmonic(m): return sum((Fr(1, i) for i in range(1, m+1)), Fr(0))
@lru_cache(maxsize=None)
def lam(i): return Fr(0) if i == 0 else Fr((-1)**i)*(harmonic(i-1)-1)/(i*(i+1))
def gbinom(p, r):
    if r < 0: return Fr(0)
    num = Fr(1)
    for i in range(r): num *= (p - i)
    return num/factorial(r)
def primes_upto(N):
    return [p for p in range(2, N+1) if all(p % d for d in range(2, int(p**0.5)+1))]

# rows from the law
_, cl4 = ri_law(4)
p = [sp.expand(cl4[i].subs(s, k)) for i in range(3)]
KMAX = 80
bb = run_law(p, [0, Fr(3, 8)], KMAX)
aa = run_law(p, [1, Fr(1, 16)], KMAX)
ok1 = all((Fr(256)**(kk-1)*d_lcm(kk-1)**3*bb[kk]).denominator == 1 for kk in range(1, KMAX+1))
def oddpart(x):
    while x % 2 == 0: x //= 2
    return x
ok2 = all(d_lcm(kk-1)**3 % oddpart(bb[kk].denominator) == 0 for kk in range(1, KMAX+1))
ok3 = all((Fr(64)**(kk-1)*aa[kk]).denominator == 1 for kk in range(1, KMAX+1))
print('256^(k-1) d_(k-1)^3 b_k integral, k<=%d:' % KMAX, ok1)
print('odd part of den(b_k) divides d_(k-1)^3, k<=%d:' % KMAX, ok2)
print('64^(k-1) a_k integral, k<=%d:' % KMAX, ok3)
for kk in (2, 3, 4, 5, 6):
    print('  k=%d: b_k=%s  den=%s  d_(k-1)^3=%s' % (kk, bb[kk], bb[kk].denominator, d_lcm(kk-1)**3))
for kk in range(2, 9):
    den = bb[kk].denominator; e2 = 0
    while den % 2 == 0: den //= 2; e2 += 1
    dd = d_lcm(kk-1)**3; f2 = 0
    while dd % 2 == 0: dd //= 2; f2 += 1
    print('  k=%d: den(b_k) = 2^%d * %d,  d_(k-1)^3 = 2^%d * %d,  256^(k-1) d_(k-1)^3 b_k = %s' % (kk, e2, den, f2, dd, Fr(256)**(kk-1)*d_lcm(kk-1)**3*bb[kk]))

# the q-adic estimates of the proof
def F_binomial_coeffs(n):
    vals = []
    for x in range(2*n+1):
        num = 1
        for i in range(n): num *= (x - 1 - i)
        vals.append(Fr(num, factorial(n))**2)
    f = []; cur = vals[:]
    for mm in range(2*n+1):
        f.append(cur[0]); cur = [cur[i+1]-cur[i] for i in range(len(cur)-1)]
    return f
def dd_coeffs(n, pp, f):
    """Coefficients of binom(sigma, i) in the divided difference F[sigma, pp] (Vandermonde twice)."""
    N = len(f)
    G1 = [gbinom(pp, r) for r in range(N)]
    G2 = [gbinom(-pp-1, r) for r in range(N)]
    A = [sum((f[mm]*G1[mm-t] for mm in range(t, N)), Fr(0)) for t in range(N)]
    return [sum((A[t]*G2[t-1-i]/t for t in range(i+1, N)), Fr(0)) for i in range(2*n)]
def dd_brute(n, pp, f):
    out = []
    for i in range(2*n):
        tot = Fr(0)
        for mm in range(len(f)):
            for t in range(i+1, mm+1):
                tot += f[mm]*Fr(1, t)*gbinom(pp, mm-t)*gbinom(-pp-1, t-1-i)
        out.append(tot)
    return out
allgood = True
for n in range(1, 7):
    f = F_binomial_coeffs(n)
    for l in range(n+1):
        assert dd_coeffs(n, Fr(2*l+1, 2), f) == dd_brute(n, Fr(2*l+1, 2), f)
print('divided-difference coefficients: fast form = direct double sum, n <= 6')
NMAX = 30
for n in range(1, NMAX+1):
    f = F_binomial_coeffs(n)
    DD = {l: dd_coeffs(n, Fr(2*l+1, 2), f) for l in range(n+1)}
    assert all(x.denominator == 1 for x in f)
    # f_m = sum (-1)^(i+i') binom(m,i) binom(i,m-i')
    assert all(f[mm] == sum((-1)**(i+ip)*binom(mm, i)*binom(i, mm-ip) for i in range(n+1) for ip in range(n+1)) for mm in range(2*n+1))
    for q in primes_upto(2*n):
        if q == 2: continue
        e = 1
        while q**e <= n: e += 1          # q^(e-1) <= n < q^e
        qe = q**e
        # q | f_m for m >= q^e
        allgood &= all(vq(f[mm], q) >= 1 for mm in range(qe, 2*n+1))
        for l in range(n+1):
            j = n - l
            cl = binom(2*l, l)*binom(2*j, j)
            Sl = Fr(factorial(2*l)*factorial(2*j), factorial(l)*factorial(j)*factorial(n))
            wl = Sl**2*cl
            if qe <= 2*l-1:
                allgood &= (vq(wl, q) >= 3 and vq(Sl, q) >= 1 and vq(binom(2*l, l), q) >= 1)
            co = DD[l]
            allgood &= all(vq(co[i], q) >= 1-e for i in range(len(co)))
            allgood &= all(vq(co[i], q) >= 2-e for i in range(qe, len(co)))
        allgood &= all(vq(lam(i), q) >= 2-2*e for i in range(1, min(qe, 2*n)))
        allgood &= all(vq(lam(i), q) >= 1-2*e for i in range(qe, 2*n))
        allgood &= vq(harmonic(qe-1), q) >= 2-e
    # the prime 2: moment sum 16^n sum_l c_l J[F[.,p_l]] has v_2 >= 1 - 3 floor(log2 n)
    L2 = n.bit_length()-1
    mom = Fr(0)
    for l in range(n+1):
        j = n-l
        cl = binom(2*l, l)*binom(2*j, j)
        co = DD[l]
        mom += cl*sum((co[i]*lam(i) for i in range(len(co))), Fr(0))
    allgood &= vq(Fr(16)**n*mom, 2) >= 1-3*L2
    # the bound of the solution, term by term: v_2(16^n c_l (Delta^i F[.,p_l])(0) lambda_i) >= -3 floor(log2 n)
    for l in range(n+1):
        j = n-l
        cl = binom(2*l, l)*binom(2*j, j)
        co = DD[l]
        allgood2 = all(vq(Fr(16)**n*cl*co[i]*lam(i), 2) >= -3*L2 for i in range(len(co)) if co[i] != 0 and lam(i) != 0)
        allgood &= allgood2
        allgood &= all(vq(co[i], 2) >= 2-4*n-L2 for i in range(len(co)))
print('all q-adic estimates of the proof hold for n <= %d:' % NMAX, allgood)
# H_{q^e - 1} valuations, a few
for q, e in ((3, 1), (3, 2), (3, 3), (5, 2), (7, 2)):
    print('  v_%d(H_%d) = %d >= 2-e = %d' % (q, q**e-1, vq(harmonic(q**e-1), q), 2-e))
