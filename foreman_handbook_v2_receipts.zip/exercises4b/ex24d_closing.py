"""Exercise ex:cfour-closing: the coefficient of the coordinate of the four-mark centre ray is a closing.
(i) by the reflexive law (Theorem ra-closingcoordinate); (ii) directly, by the WZ certificates of the
row formula of ex:cfour-row, verified here as identities of rational functions in (n, l). Exact arithmetic."""
import sys; sys.path.insert(0, '.')
from common import *

_, c = ri_law(4)
p = [sp.expand(c[i].subs(s, k)) for i in range(3)]

# reflexive: p_{2-i}(-k-1) = gamma lambda^i p_i(k)
gam = sp.cancel(p[2].subs(k, -k - 1) / p[0])
lamb = sp.cancel(p[1].subs(k, -k - 1) / p[1] / gam)
print('gamma =', gam, ' ratio lambda =', lamb,
      ' check i=2:', sp.expand(p[0].subs(k, -k - 1) - gam * lamb ** 2 * p[2]) == 0)

# (i) y_k = lambda^{k-1} C_{k-1} solves the law on k >= 1 with zero low-end coefficient
N = 40
C = multinomial_closings(4, N + 3)
yk = {kk: Fraction(C[kk - 1], 64 ** (kk - 1)) for kk in range(1, N + 4)}
ok = all(sum(Fraction(int(p[i].subs(k, kk))) * yk[kk + i] for i in range(3)) == 0 for kk in range(1, N + 1))
print('y_k = C_{k-1}/64^{k-1} solves the law for 1 <= k <= 40:', ok)
print('low-end coefficient of y: -(c_{4,1}(0) y_1 + c_{4,2}(0) y_2) = -(%s*%s + %s*%s) =' % (c[1].subs(s, 0), yk[1], c[2].subs(s, 0), yk[2]),
      -(int(c[1].subs(s, 0)) * yk[1] + int(c[2].subs(s, 0)) * yk[2]))
aa = run_law(p, [1, Fraction(1, 16)], N)
print('a_k = C_{k-1}/64^{k-1} for k <= 40:', all(aa[kk] == yk[kk] for kk in range(1, N + 1)))
# (iii) denominators 64^{k-1}/gcd(64^{k-1}, C_{k-1})
def v2(x):
    v = 0
    while x % 2 == 0: x //= 2; v += 1
    return v
print('k, C_{k-1}, v_2(C_{k-1}), den(a_k):')
for kk in range(1, 9):
    print('  ', kk, C[kk - 1], v2(C[kk - 1]), aa[kk].denominator, aa[kk].denominator == 64 ** (kk - 1) // gcd(64 ** (kk - 1), C[kk - 1]))

# (ii) CT[L^n] split across the hinge {1,2}|{3,4}: sum_l binom(n,l)^2 binom(2l,l) binom(2j,j)
U = [sum(comb(n_, l) ** 2 * comb(2 * l, l) * comb(2 * (n_ - l), n_ - l) for l in range(n_ + 1)) for n_ in range(N + 1)]
print('U(n) = C_n for n <= 40:', U == C[:N + 1], ' U(0..4) =', U[:5])
# the recurrence of the closings read at j = n+2
nn, ll = sp.symbols('n l')
rec = [sp.expand(c[i].subs(s, -nn - 2)) for i in range(3)]
print('c_{4,i}(-n-2), i = 0,1,2:', [sp.factor(r) for r in rec])

# WZ: summands, their ratios, the certificates
j = nn - ll
def tT(a, b):
    jj = a - b
    return sp.Rational(1, 4) ** a * (sp.gamma(2 * b + 1) * sp.gamma(2 * jj + 1) / (sp.gamma(b + 1) * sp.gamma(jj + 1) * sp.gamma(a + 1))) ** 2 \
        * sp.gamma(2 * b + 1) / sp.gamma(b + 1) ** 2 * sp.gamma(2 * jj + 1) / sp.gamma(jj + 1) ** 2
def tU(a, b):
    jj = a - b
    return (sp.gamma(a + 1) / (sp.gamma(b + 1) * sp.gamma(jj + 1))) ** 2 * sp.gamma(2 * b + 1) / sp.gamma(b + 1) ** 2 * sp.gamma(2 * jj + 1) / sp.gamma(jj + 1) ** 2
ratios = {}
for name, t, rl, rn in (('T', tT, (2 * ll + 1) ** 3 * j / ((ll + 1) * (2 * j - 1) ** 3), 2 * (2 * j + 1) ** 3 / ((j + 1) * (nn + 1) ** 2)),
                         ('U', tU, j ** 3 * (2 * ll + 1) / ((ll + 1) ** 3 * (2 * j - 1)), 2 * (nn + 1) ** 2 * (2 * j + 1) / (j + 1) ** 3)):
    ql = sp.simplify(sp.gammasimp(t(nn, ll + 1) / t(nn, ll)) - rl)
    qn = sp.simplify(sp.gammasimp(t(nn + 1, ll) / t(nn, ll)) - rn)
    print('ratios of t_%s: t(n,l+1)/t(n,l) =' % name, sp.factor(rl), ' t(n+1,l)/t(n,l) =', sp.factor(rn), ' checked:', ql == 0, qn == 0)
    ratios[name] = (sp.Lambda((nn, ll), rl), sp.Lambda((nn, ll), rn))
kapT = 12 * j ** 3 + 10 * ll * j ** 2 + 2 * ll ** 2 * j + 59 * j ** 2 + 33 * ll * j + 4 * ll ** 2 + 94 * j + 26 * ll + 49
kapU = 12 * j ** 3 + 10 * ll * j ** 2 + 2 * ll ** 2 * j + 62 * j ** 2 + 35 * ll * j + 3 * ll ** 2 + 104 * j + 30 * ll + 56
RT = 4 * ll * (2 * j + 1) ** 3 * kapT / ((nn + 1) ** 2 * (j + 1) * (j + 2))
RU = -4 * (nn + 1) ** 2 * ll ** 3 * (2 * j + 1) * kapU / ((j + 1) ** 3 * (j + 2) ** 3)
a2 = 64 * (nn + 1) ** 3
a1 = -2 * (2 * nn + 3) * (5 * nn ** 2 + 15 * nn + 12)
a0 = (nn + 2) ** 3
for name, R in (('T', RT), ('U', RU)):
    rl, rn = ratios[name]
    Rf = sp.Lambda((nn, ll), R)
    # interior: divided by t(n,l), for 0 <= l <= n-1
    interior = a2 + a1 * rn(nn, ll) + a0 * rn(nn, ll) * rn(nn + 1, ll) - Rf(nn, ll + 1) * rl(nn, ll) + Rf(nn, ll)
    num = sp.factor(sp.together(interior))
    # boundary: G(n,n) + the left side at l = n, n+1, n+2, divided by t(n,n)
    t_n1_n = rn(nn, nn)                       # t(n+1,n)/t(n,n)
    t_n1_n1 = rl(nn + 1, nn) * t_n1_n         # t(n+1,n+1)/t(n,n)
    t_n2_n = rn(nn + 1, nn) * t_n1_n          # t(n+2,n)/t(n,n)
    t_n2_n1 = rl(nn + 2, nn) * t_n2_n
    t_n2_n2 = rl(nn + 2, nn + 1) * t_n2_n1
    boundary = Rf(nn, nn) + a2 + a1 * (t_n1_n + t_n1_n1) + a0 * (t_n2_n + t_n2_n1 + t_n2_n2)
    print('WZ %s: interior identity (divided by t(n,l)) =' % name, num, ';  boundary identity (divided by t(n,n)) =', sp.factor(sp.together(boundary)))
    numer = sp.Poly(sp.fraction(sp.together(a2 * 0 + interior))[0], nn, ll)
print('initial values: T(0), T(1) =', sum(sp.Rational(1, 4) ** 0 * 1 for _ in [0]),
      sp.Rational(1, 4) * sum((sp.factorial(2 * l) * sp.factorial(2 * (1 - l)) / (sp.factorial(l) * sp.factorial(1 - l) * sp.factorial(1))) ** 2 * sp.binomial(2 * l, l) * sp.binomial(2 * (1 - l), 1 - l) for l in range(2)),
      ' U(0), U(1) =', U[0], U[1])
# certificate degree: the cleared interior identity is a polynomial identity of total degree
for name, R in (('T', RT), ('U', RU)):
    rl, rn = ratios[name]
    Rf = sp.Lambda((nn, ll), R)
    expr = sp.together(a2 + a1 * rn(nn, ll) + a0 * rn(nn, ll) * rn(nn + 1, ll) + Rf(nn, ll))
    rhs = sp.together(Rf(nn, ll + 1) * rl(nn, ll))
    nL, dL = sp.fraction(expr); nR, dR = sp.fraction(rhs)
    P = sp.Poly(sp.expand(nL * dR - nR * dL), nn, ll)
    print('  %s: cross-multiplied interior identity is the zero polynomial:' % name, P.is_zero)
