"""Exercise ex:cthree-positivity: positivity against the gauge end on the centre ray of binom([3],1).
Exact: the law, the rows P(K) = c(K) l + r(K), c(K) = 9^{1-K} C_{K-1}, the two-condition brackets, the
Hankel pencils of all positivity conditions of degree <= N and their determinants (exact polynomials in l);
their real roots are isolated with arb (python-flint). The gauge end gives l to 100 digits (mpmath).
Floating point only for renderings and checks."""
import sys; sys.path.insert(0, '.')
from common import *
import mpmath as mp
from flint import fmpz_poly, fmpq_poly, fmpq, fmpq_mat, arb, ctx

n = 3
Q, c = ri_law(n)
p = [sp.expand(c[i].subs(s, k)) for i in range(3)]
print('law: c_{3,k}(s) =', {i: sp.factor(v) for i, v in c.items()})
lam_ = sp.Symbol('lambda')
chi = sp.expand(sum(sp.Poly(p[i], k).coeff_monomial(k ** 2) * lam_ ** i for i in range(3)))
print('symbol', sp.factor(chi), ' roots', sorted(sp.solve(chi, lam_)))
print('low-end: [s^2]c_{3,0} =', sp.Poly(c[0], s).coeff_monomial(s ** 2), ' c_{3,1}(0) =', c[1].subs(s, 0), ' c_{3,2}(0) =', c[2].subs(s, 0), ' V_1 = 3! = 6')
KMAX = 40
cc = run_law(p, [1, Fraction(1, 3)], KMAX)
rr = run_law(p, [0, Fraction(-2, 3)], KMAX)
C = multinomial_closings(3, KMAX)
print('c(K) = 9^{1-K} C_{K-1} for K <= 40:', all(cc[K] == Fraction(C[K - 1], 9 ** (K - 1)) for K in range(1, KMAX + 1)), ' C_0..C_5 =', C[:6])
print('reflexive: c_{3,2}(-k-1) = 9 c_{3,0}(k):', sp.expand(c[2].subs(s, -s - 1) - 9 * c[0]) == 0,
      ' c_{3,1}(-k-1) = c_{3,1}(k):', sp.expand(c[1].subs(s, -s - 1) - c[1]) == 0)

# ---- the gauge end: l = P(1) to 100 digits ----
fs = sp.Rational(1, 9)
D = 2
t, x = sp.symbols('t x')
sv = sp.Symbol('s_')
def theta_poly_to_d(poly_theta):
    P = sp.Poly(poly_theta, th); out = {}
    for (m,), cf in P.terms():
        for jj in range(m + 1):
            out[jj] = out.get(jj, 0) + cf * sp.functions.combinatorial.numbers.stirling(m, jj)
    return out
a = {}
for i in range(3):
    for jj, cf in theta_poly_to_d(sp.expand(p[i].subs(k, -1 - i - th))).items():
        a[jj] = sp.expand(a.get(jj, 0) + t ** i * cf * t ** jj)
print('density operator a_j(t):', {jj: sp.factor(v) for jj, v in sorted(a.items())})
b = {jj: sp.expand((-1) ** jj * a[jj].subs(t, fs - sv)) for jj in a}
bjl = lambda jj, l: (sp.Poly(b[jj], sv).coeff_monomial(sv ** l) if (jj in b and l >= 0) else 0)
gamma = D - 1 - bjl(D - 1, 0) / bjl(D, 1)
print('b_{2,1} =', bjl(D, 1), ' gamma =', gamma, ' (n-3)/2 = 0')
def Rm(m):
    return sp.expand(sum(bjl(jj, m - D + 1 + jj) * sp.prod([x - i for i in range(jj)]) for jj in range(D + 1)))
Mmax = max(m for m in range(30) if Rm(m) != 0)
print('R_0(x) =', sp.factor(Rm(0)), '; R_m, m=1..', Mmax, ':', [sp.factor(Rm(m)) for m in range(1, Mmax + 1)])
NMAX = 500
Rp = [sp.Poly(Rm(m), x) for m in range(Mmax + 1)]
U = [Fraction(1)]
for N in range(D - 1, NMAX + 1):
    acc = sum((Fraction(Rp[m].eval(N - m)) * U[N - m] for m in range(1, min(N, Mmax) + 1)), Fraction(0))
    U.append(-acc / Fraction(Rp[0].eval(N)))
print('u_r/u_0, r = 0..4:', [str(v) for v in U[:5]])
print('g(0) = 2 pi/(f* sqrt(det H)), det H = 4/27:', sp.simplify(2 * sp.pi / (fs * sp.sqrt(sp.Rational(4, 27)))))
mp.mp.dps = 130
G0 = 27 * mp.sqrt(3) * mp.pi
fsm = mp.mpf(1) / 9
def beta_sum(K):
    return G0 * mp.fsum(mp.mpf(U[r].numerator) / U[r].denominator * fsm ** (K + r + 1) * mp.beta(K + 1, r + 1) for r in range(NMAX + 1))
cf = [sp.lambdify(k, p[i], 'mpmath') for i in range(3)]
def read(K):
    V = {K: beta_sum(K), K + 1: beta_sum(K + 1)}
    for kk in range(K - 1, 0, -1):
        V[kk] = -(cf[1](kk) * V[kk + 1] + cf[2](kk) * V[kk + 2]) / cf[0](kk)
    return V
V1r, V2r = read(200), read(300)
ell = V1r[1]
print('gauge end: l = P(1) =', mp.nstr(ell, 100))
print('two depths (200, 300) agree to', mp.nstr(abs(V1r[1] - V2r[1]), 3), '; low-end relation on the output: 3P(1) - 9P(2) =', mp.nstr(3 * V1r[1] - 9 * V1r[2], 40))

# ---- brackets ----
def x_of(K):            # P(K) = c(K) l + r(K)
    return (cc[K], rr[K])
fsq = Fraction(1, 9)
def two_cond(K):
    lo = -rr[K] / cc[K]
    hi = (rr[K - 1] - 9 * rr[K]) / (9 * cc[K] - cc[K - 1])
    return lo, hi
def pencil(N):
    """the two Hankel pencils equivalent to all conditions of degree <= N at K = 1 (Markov-Lukacs):
    N = 2m: [x(1+i+i')]_{0..m}, [f* x(2+i+i') - x(3+i+i')]_{0..m-1};
    N = 2m+1: [x(2+i+i')]_{0..m}, [f* x(1+i+i') - x(2+i+i')]_{0..m}. Entries are pairs (coefficient of l, constant)."""
    m = N // 2
    mats = []
    if N % 2 == 0:
        mats.append([[x_of(1 + i + j) for j in range(m + 1)] for i in range(m + 1)])
        if m >= 1:
            mats.append([[tuple(fsq * x_of(2 + i + j)[q] - x_of(3 + i + j)[q] for q in range(2)) for j in range(m)] for i in range(m)])
    else:
        mats.append([[x_of(2 + i + j) for j in range(m + 1)] for i in range(m + 1)])
        mats.append([[tuple(fsq * x_of(1 + i + j)[q] - x_of(2 + i + j)[q] for q in range(2)) for j in range(m + 1)] for i in range(m + 1)])
    return mats
def det_poly(M):
    """exact det(A + l B) as an fmpq_poly in l, by evaluation at size+1 points and interpolation"""
    sz = len(M)
    pts = list(range(sz + 1))
    vals = []
    for l0 in pts:
        mat = fmpq_mat(sz, sz, [fmpq(int((e[0] * l0 + e[1]).numerator), int((e[0] * l0 + e[1]).denominator)) for row in M for e in row])
        vals.append(mat.det())
    # Lagrange interpolation
    P = fmpq_poly([0])
    for i, li in enumerate(pts):
        term = fmpq_poly([vals[i]])
        for j, lj in enumerate(pts):
            if j != i:
                term *= fmpq_poly([-lj, 1]) / fmpq(li - lj)
        P += term
    return P
ctx.prec = 600
ell_arb = arb(mp.nstr(ell, 120))
def nearest_roots(P):
    num = fmpz_poly([int((P[i] * P.denom()).p) for i in range(P.degree() + 1)])
    roots = [r_.real for r_, mult in num.complex_roots() if r_.imag.contains(0)]
    below = [r_ for r_ in roots if r_ < ell_arb]
    above = [r_ for r_ in roots if r_ > ell_arb]
    key = lambda z: mp.mpf(z.mid().str(80, radius=False))
    return (max(below, key=key) if below else None), (min(above, key=key) if above else None)
def psd_at(M, l0):
    A = mp.matrix([[mp.mpf(e[0].numerator) / e[0].denominator * l0 + mp.mpf(e[1].numerator) / e[1].denominator for e in row] for row in M])
    return min(mp.eigsy(A)[0]) > 0
def pencil_all(N):
    """the four Hankel families of Proposition rd-moment(ii) at K = 1, of the sizes that degree <= N allows"""
    fam = []
    d_q2 = N // 2            # q^2, deg q <= N/2
    d_tq2 = (N - 1) // 2     # t q^2 and (f*-t) q^2
    d_ttq2 = (N - 2) // 2    # t (f*-t) q^2
    if d_q2 >= 0: fam.append([[x_of(1 + i + j) for j in range(d_q2 + 1)] for i in range(d_q2 + 1)])
    if d_tq2 >= 0:
        fam.append([[x_of(2 + i + j) for j in range(d_tq2 + 1)] for i in range(d_tq2 + 1)])
        fam.append([[tuple(fsq * x_of(1 + i + j)[q] - x_of(2 + i + j)[q] for q in range(2)) for j in range(d_tq2 + 1)] for i in range(d_tq2 + 1)])
    if d_ttq2 >= 0:
        fam.append([[tuple(fsq * x_of(2 + i + j)[q] - x_of(3 + i + j)[q] for q in range(2)) for j in range(d_ttq2 + 1)] for i in range(d_ttq2 + 1)])
    return fam
def bracket(mats):
    lo, hi = None, None
    for M in mats:
        assert psd_at(M, ell)
        rb, ra = nearest_roots(det_poly(M))
        if rb is not None and (lo is None or rb > lo): lo = rb
        if ra is not None and (hi is None or ra < hi): hi = ra
    return lo, hi
same = True
for N in range(1, 23):
    l2, h2 = bracket(pencil(N))
    l4, h4 = bracket(pencil_all(N))
    same &= bool(abs(l2 - l4) < arb(10) ** -100) and bool(abs(h2 - h4) < arb(10) ** -100)
print('the four families of Proposition rd-moment(ii) give the same brackets as the two pencils, N <= 22:', same)
rows_out = []
w_all = {}
for N in range(1, 23):
    lo2, hi2 = two_cond(N + 1)
    w2 = hi2 - lo2
    lo, hi = None, None
    for M in pencil(N):
        assert psd_at(M, ell)
        rb, ra = nearest_roots(det_poly(M))
        if rb is not None and (lo is None or rb > lo): lo = rb
        if ra is not None and (hi is None or ra < hi): hi = ra
    wa = hi - lo
    w_all[N] = wa
    rows_out.append((N, w2, wa, lo, hi))
for N, w2, wa, lo, hi in rows_out:
    ratio = '' if N == 1 else mp.nstr(mp.mpf((wa / w_all[N - 1]).mid().str(30, radius=False)), 4)
    print('N=%2d: two conditions (K=N+1) width %s;  all conditions width %s;  ratio %s;  contains l: %s' % (
        N, mp.nstr(mp.mpf(w2.numerator) / w2.denominator, 3), mp.nstr(mp.mpf(wa.mid().str(30, radius=False)), 3), ratio,
        bool(lo < ell_arb < hi)))
print('the two-condition brackets at K = N+1 contain l:', all(two_cond(N + 1)[0] < Fraction(mp.nstr(ell, 60)) < two_cond(N + 1)[1] for N in range(1, 23)))
lo2, hi2 = two_cond(2)
print('N=1 (K=2): two conditions', lo2, '< l <', hi2)
for N in (1, 2):
    for M in pencil(N):
        P = det_poly(M)
        print('  N=%d pencil of size %d: det =' % (N, len(M)), P)
print('rate: e^{-g(1)} = 17 - 12 sqrt 2 =', mp.nstr(17 - 12 * mp.sqrt(2), 8), '; digits per value', mp.nstr(-mp.log10(17 - 12 * mp.sqrt(2)), 4), 'against', mp.nstr(mp.log10(9), 4))
# the torus measure behind c: c(K) = int_0^1 tau^{K-1} nu'(dtau), nu' the image of the torus law under t -> 1/(9t)
print('density of the torus law at f* = (2pi)^{-2} g(0) =', sp.simplify(27 * sp.sqrt(3) * sp.pi / (4 * sp.pi ** 2)), '; at tau -> 1 the image density is that times 1/9:', sp.simplify(27 * sp.sqrt(3) * sp.pi / (4 * sp.pi ** 2) / 9))
