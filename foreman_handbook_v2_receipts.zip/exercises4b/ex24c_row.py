"""Exercise ex:cfour-row: the row of the four-mark centre at every step (exact arithmetic).
256^n <1>_{n+1} = sum_l w_l T3(1/2+Z, cut l) - 16^n sum_l c_l J[F[.,p_l]].
Checks the formula against the rows given by the law for n <= 40, and sum_l w_l = 4^n C_n."""
import sys; sys.path.insert(0, '.')
from common import *
from fractions import Fraction as Fr
from flint import fmpq, fmpq_poly

def binom(a, b):
    return comb(a, b) if 0 <= b <= a else 0

def harmonic(m):
    return sum((Fr(1, i) for i in range(1, m+1)), Fr(0))

def lam(i):
    """J[binom(sigma,i)] = (-1)^i (H_{i-1}-1)/(i(i+1)) for i >= 1, lam_0 = 0"""
    if i == 0: return Fr(0)
    return Fr((-1)**i) * (harmonic(i-1) - 1) / (i*(i+1))

# moments of the critical-line law: E[X^m] = m! [t^m] t e^t/(e^t-1), X = 1/2 + iY (thm:sharelaw(iii))
MMAX = 100
def bernoulli_plus(M):
    # t e^t/(e^t-1) = sum B^+_m t^m/m!, B^+_m = sum_{j} binom(m,j) B_j with B_1=-1/2 ... use recurrence
    # t/(e^t - 1) = sum B_m t^m/m! (B_1 = -1/2); t e^t/(e^t-1) = t + t/(e^t-1)
    B = [Fr(1)]
    for mm in range(1, M+1):
        B.append(-sum(comb(mm+1, j)*B[j] for j in range(mm))/Fr(mm+1))
    Bp = B[:]
    Bp[1] = B[1] + 1
    return Bp
EX = bernoulli_plus(MMAX)
print('E[X^m], m = 0..8:', [str(x) for x in EX[:9]])

def J(g):
    """J[g] = (1/2) E[g'(X)] for g an fmpq_poly in sigma"""
    gp = g.derivative()
    return Fr(1, 2)*sum((Fr(int(gp[e].p), int(gp[e].q))*EX[e] for e in range(gp.degree()+1)), Fr(0))

# lambda_i from the moments, i <= 8
sig = fmpq_poly([0, 1])
def binom_poly(i):
    P = fmpq_poly([1])
    for a in range(i): P *= (sig - a)
    return P/fmpq(factorial(i))
print('lambda_i (formula / from the moments):', [(str(lam(i)), str(J(binom_poly(i)))) for i in range(9)])
assert all(lam(i) == J(binom_poly(i)) for i in range(40))

def F_of(n):
    P = fmpq_poly([1])
    for i in range(1, n+1): P *= (sig - i)
    P = P/fmpq(factorial(n))
    return P*P          # binom(sigma-1, n)^2

def row_formula(n):
    F = F_of(n)
    A = Fr(0); B = Fr(0); Jsum = Fr(0)
    for l in range(n+1):
        j = n - l
        cl = binom(2*l, l)*binom(2*j, j)
        Sl = Fr(factorial(2*l)*factorial(2*j), factorial(l)*factorial(j)*factorial(n))
        wl = Sl**2*cl
        head = sum((Fr(8, (2*i-1)**3) for i in range(1, l+1)), Fr(0))   # T3 on 1/2+Z over (0,l]
        p = fmpq(2*l+1, 2)
        Fdd = (F - fmpq_poly([F(p)]))
        q, r = divmod(Fdd, fmpq_poly([-p, 1]))
        assert r == 0
        Jl = J(q)
        A += wl
        B += wl*head + 16**n*cl*Jl
        Jsum += cl*Jl
    return A, B, Jsum

_, cl4 = ri_law(4)
p = [sp.expand(cl4[i].subs(s, k)) for i in range(3)]
N = 40
aa = run_law(p, [1, Fr(1, 16)], N+1)
bb = run_law(p, [0, Fr(3, 8)], N+1)
C = multinomial_closings(4, N)
allok = True
for nn in range(0, N+1):
    A, B, Js = row_formula(nn)
    ok = (A == 256**nn*aa[nn+1]) and (B == 256**nn*bb[nn+1]) and (A == 4**nn*C[nn])
    allok &= ok
    if nn <= 3:
        print('  n=%d: sum_l w_l = %s, 256^n b_{n+1} = %s, sum_l c_l J[F[.,p_l]] = %s: %s' % (nn, A, B, Js, ok))
print('row formula equals the rows of the law, and sum_l w_l = 4^n C_n, for n <= %d:' % N, allok)
for nn in (1, 2):
    print('n=%d data:' % nn)
    F = F_of(nn)
    for l in range(nn+1):
        j = nn-l
        cl = binom(2*l, l)*binom(2*j, j); Sl = Fr(factorial(2*l)*factorial(2*j), factorial(l)*factorial(j)*factorial(nn))
        pp = fmpq(2*l+1, 2)
        q, r = divmod(F - fmpq_poly([F(pp)]), fmpq_poly([-pp, 1]))
        print('   l=%d: c_l=%s S_l=%s w_l=%s F[sigma,p_l]=%s J=%s' % (l, cl, Sl, Sl**2*cl, q, J(q)))
# the partial fractions of rho/Omega^2 and the residues r_l, n = 3 (sympy)
sgm = sp.Symbol('sigma')
for nn in (1, 2, 3):
    Om = sp.prod([sgm - i for i in range(1, nn+1)])
    rho = sp.prod([(1-sgm+i) for i in range(nn)])**3/sp.prod([(sp.Rational(1, 2)-sgm+i) for i in range(nn+1)])
    pf = sp.apart(sp.cancel(rho/Om**2), sgm)
    target = -sum(sp.Rational(binom(2*l, l)*binom(2*(nn-l), nn-l), 4**nn)/(sgm - sp.Rational(2*l+1, 2)) for l in range(nn+1))
    print('n=%d: rho/Omega^2 = -(1/4^n) sum c_l/(sigma-p_l):' % nn, sp.simplify(pf - target) == 0)
    for l in range(nn+1):
        j = nn-l
        Omp = Om.subs(sgm, sp.Rational(2*l+1, 2))
        cl = binom(2*l, l)*binom(2*j, j)
        Sl = sp.Rational(factorial(2*l)*factorial(2*j), factorial(l)*factorial(j)*factorial(nn))
        assert Omp == sp.Rational((-1)**(nn-l)*sp.factorial2(2*l-1)*sp.factorial2(2*j-1), 2**nn)
        assert -cl*Omp**2/4**nn == -sp.factorial(nn)**2*Sl**2*cl/64**nn
print('Omega(p_l) and r_l = -n!^2 w_l/64^n checked for n <= 3')
