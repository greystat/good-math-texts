"""Exercise ex:cfour-halflattice: the centre of binom([4],1) at strength one, closed on the half-lattice.
Prints the Laurent data used in the solution and checks the value (checks only in floating point)."""
import sympy as sp
import mpmath as mp
c, eps, m = sp.symbols('c epsilon m')
# integrand at k=1: Gamma(c)^4 Gamma(1-c)^4 / (Gamma(2c) Gamma(2-2c)) = 2 pi^3 cos(pi c)/((1-2c) sin^3(pi c))
w = 2*sp.pi**3*sp.cos(sp.pi*c)/((1-2*c)*sp.sin(sp.pi*c)**3)
# Laurent data of 2 pi^3 cos/sin^3 at an integer: cos(pi eps)/sin^3(pi eps)
ser = sp.series(2*sp.pi**3*sp.cos(sp.pi*eps)/sp.sin(sp.pi*eps)**3, eps, 0, 4).removeO()
print('2 pi^3 cos(pi e)/sin^3(pi e) =', sp.expand(ser))
# residue at c = m: 2 [eps^2] (1-2m-2eps)^(-1)
res = sp.simplify(2*sp.series(1/(1-2*m-2*eps), eps, 0, 3).removeO().coeff(eps, 2))
print('residue at c=m:', sp.factor(res))
# check the rewriting with Gammas at a sample point
mp.mp.dps = 40
cc = mp.mpf('0.3') + mp.mpf('0.7')*1j
lhs = mp.gamma(cc)**4*mp.gamma(1-cc)**4/(mp.gamma(2*cc)*mp.gamma(2-2*cc))
rhs = 2*mp.pi**3*mp.cos(mp.pi*cc)/((1-2*cc)*mp.sin(mp.pi*cc)**3)
print('rewriting check |lhs-rhs| =', mp.nstr(abs(lhs-rhs), 3))
# value: sum 8/(2m-1)^3 = 7 zeta(3), against the contour integral (check)
mp.mp.dps = 30
val = 7*mp.zeta(3)
f = lambda t: (mp.gamma(mp.mpf(1)/2+1j*t)**4*mp.gamma(mp.mpf(1)/2-1j*t)**4/(mp.gamma(1+2j*t)*mp.gamma(1-2j*t))).real
integral = mp.quad(f, [-mp.inf, 0, mp.inf])/(2*mp.pi)
print('7 zeta(3) =', mp.nstr(val, 25), ' contour integral (check) =', mp.nstr(integral, 25))
print('half-lattice sum 8 sum 1/(2m-1)^3 =', mp.nstr(8*mp.nsum(lambda j: 1/(2*j-1)**3, [1, mp.inf]), 25))
