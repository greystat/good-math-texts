"""Exercise ex:wthree-box: W_3 at (1;0,2) read from its list by the box of the walls.
Walls, V_1, the box B_2 with one unit of Psi modulo the 24 automorphisms, its reduction, the matrix B(k),
the proof over Q(k) of the two congruences (rank at 220 strengths), the law from the rows, the native gauges,
the spectrum and the change of masters. Exact arithmetic (python-flint, sympy)."""
import sys, time, random; sys.path.insert(0, '.')
from w3common import *
from flint import nmod_mat, fmpz_mat, fmpq
import sympy as sp
kk = sp.Symbol('k')
t0 = time.time()
print('marks:', MARKS)
print('bases (spanning trees):', [''.join(sorted(MARKS[i] for i in T)) for T in BASES])
print('walls kappa_{1,S} = 2 r(S) - |S| > 0 for every nonempty proper S:', all(v > 0 for v in KAPPA1.values()),
      ' values taken:', sorted(set(KAPPA1.values())))
print('V_1 =', V1())
lev0, lev1, orb, rels, cnt = build_box(2)
o_lev0 = [o for o in orb if o[0] == '0']; o_lev1 = [o for o in orb if o[0] == '1']
print('box B_2(0,1): stems (Laurent symbols of wall degree <= 2):', len(lev0), ' symbols at level (0,1):', len(lev1))
print('orbits under the automorphisms: %d Laurent + %d at level (0,1) = %d' % (len(o_lev0), len(o_lev1), len(orb)))
print('relations: %d letter identities, %d mark relations; %d distinct after averaging' % (cnt[0], cnt[1], len(rels)))
TRI = (1, 1, 0, 1, 0, 0); STAR = tuple(1-x for x in TRI)          # triangle s1 s2 r1, star s3 r2 r3
cts = canon(tuple(a-b for a, b in zip(TRI, STAR)))
print('b_1: orbit of', cts, '= alpha^{r1 r2 r3}/alpha^{s1 s2 s3}; orbit size', len(orb[('0', cts)]))
k1 = sorted(o_lev1, key=lambda o: (-wall_degree(o[1], 1), o[1]))
k0 = sorted(o_lev0, key=lambda o: (-wall_degree(o[1], 0), 1 if o[1] == cts else 0, o[1]))
cols = k1 + k0; idx = {c: i for i, c in enumerate(cols)}; NC = len(cols)
print('Laurent orbits by wall degree:', {str(d): sum(1 for o in o_lev0 if wall_degree(o[1], 0) == d) for d in sorted(set(wall_degree(o[1], 0) for o in o_lev0))})
# elimination at a random strength modulo p
P = (1 << 61) - 1
random.seed(2026)
kv = random.randrange(10**6, P)
M = nmod_mat(len(rels), NC, [0]*(len(rels)*NC), P)
for i, r in enumerate(rels):
    for c, (a, b) in r.items(): M[i, idx[c]] = (a + b*kv) % P
R, rk = M.rref()
piv = set()
for i in range(rk):
    for j in range(NC):
        if int(R[i, j]): piv.add(j); break
free = [cols[j] for j in range(NC) if j not in piv]
print('rank of the relations:', rk, '; free orbits:', len(free), '(level (0,1):', sum(1 for c in free if c[0] == '1'), ')')
print('free Laurent orbits:', [(c[1], str(wall_degree(c[1], 0))) for c in free if c[0] == '0'])

# exact reduction of the targets at integer strengths, and reconstruction of B(k)
def target_rows():
    out = []
    for bcan in [(0,)*6, cts]:
        tv = target_vector(orb, bcan)
        out.append({c: fmpq(v.numerator, v.denominator) for c, v in tv.items()})
    return out
TGT = target_rows()
print('target f^{-1}: orbits in its support:', len(TGT[0]), ', of f^{-1} b_1:', len(TGT[1]))
def B_at(kv):
    Mz = fmpz_mat(len(rels), NC)
    for i, r in enumerate(rels):
        for c, (a, b) in r.items(): Mz[i, idx[c]] = a + b*kv
    Rz, den, rkz = Mz.rref()
    pv = {}
    for i in range(rkz):
        for j in range(NC):
            if Rz[i, j] != 0: pv[j] = i; break
    out = []
    for tv in TGT:
        v = [fmpq(0)]*NC
        for c, val in tv.items(): v[idx[c]] = val
        for j in sorted(pv):
            if v[j] != 0:
                i = pv[j]; cf = v[j]/fmpq(Rz[i, j])
                for jj in range(j, NC):
                    if Rz[i, jj] != 0: v[jj] -= cf*fmpq(Rz[i, jj])
        supp = {cols[j]: v[j] for j in range(NC) if v[j] != 0}
        if not set(supp) <= {('0', (0,)*6), ('0', cts)}: return None
        out.append([supp.get(('0', (0,)*6), fmpq(0)), supp.get(('0', cts), fmpq(0))])
    return out
B = sp.Matrix([[-2*(2*kk - 1)*(kk**2 - 4*kk + 2)*(7*kk**2 - 8*kk + 3)/((kk - 1)**2*(kk**2 - kk + 1)), 14*kk**2*(2*kk - 1)/(kk**2 - kk + 1)],
               [-2*kk*(kk - 3)*(kk - 1)*(kk + 1)*(2*kk - 1)*(7*kk**2 - 14*kk + 8)/((kk - 2)**4*(kk**2 - kk + 1)),
                2*kk**2*(kk - 1)*(2*kk - 1)*(kk**2 - 2)*(7*kk**2 - 20*kk + 15)/((kk - 2)**5*(kk**2 - kk + 1))]])
agree = True; nchk = 0
for kv in list(range(11, 41)) + [101, 257, 1009]:
    Bv = B_at(kv)
    if Bv is None: continue
    nchk += 1
    for i in range(2):
        for j in range(2):
            ex = B[i, j].subs(kk, kv)
            agree &= (sp.Rational(int(Bv[i][j].p), int(Bv[i][j].q)) == ex)
print('the reconstructed B(k) agrees with the exact reduction at %d strengths:' % nchk, agree)
print('B(k) =', [[sp.factor(B[i, j]) for j in range(2)] for i in range(2)])
# proof over Q(k): v_i'(k) = Q_c(k) (target_i - B_i0 [1] - B_i1 [b_1]) lies in the row space of R(k)
Qc = (kk-1)**2*(kk-2)**5*(kk**2-kk+1)
Bpoly = [[sp.Poly(sp.cancel(Qc*B[i, j]), kk) for j in range(2)] for i in range(2)]
print('degrees of Q_c B_ij:', [[Bpoly[i][j].degree() for j in range(2)] for i in range(2)], ' deg Q_c =', sp.degree(Qc, kk))
from math import lcm
def integer_rows_at(kv):
    Mz = fmpz_mat(len(rels)+2, NC)
    for i, r in enumerate(rels):
        for c, (a, b) in r.items(): Mz[i, idx[c]] = a + b*kv
    qc = int(Qc.subs(kk, kv))
    for t, tv in enumerate(TGT):
        row = {}
        for c, val in tv.items(): row[idx[c]] = sp.Rational(int(val.p), int(val.q))*qc
        row[idx[('0', (0,)*6)]] = row.get(idx[('0', (0,)*6)], 0) - int(Bpoly[t][0].eval(kv))
        row[idx[('0', cts)]] = row.get(idx[('0', cts)], 0) - int(Bpoly[t][1].eval(kv))
        L = lcm(*[int(sp.Rational(x).q) for x in row.values()])
        for j, x in row.items(): Mz[len(rels)+t, j] = int(sp.Rational(x)*L)
    return Mz
ranks = set(); npts = 0
for kv in range(3, 3+230):
    Mz = integer_rows_at(kv)
    ranks.add(Mz.rank()); npts += 1
print('rank of [R(k); v_0(k); v_1(k)] at %d integer strengths: %s (minors of size 201 have degree <= 219)' % (npts, sorted(ranks)))
# the law from the rows (prop:rays-lawrows)
w0 = sp.Matrix([[1, 0]]); w1 = (w0*B).applyfunc(sp.cancel); w2 = (w1.subs(kk, kk-1)*B).applyfunc(sp.cancel)
q1 = sp.cancel(-w2[1]/w1[1]); q0 = sp.cancel(-(w2[0] + q1*w1[0]))
dn = sp.lcm(sp.fraction(q0)[1], sp.fraction(q1)[1])
q = [sp.factor(sp.cancel(q0*dn)), sp.factor(sp.cancel(q1*dn)), sp.factor(dn)]
print('dependence of the rows: q_0, q_1, q_2 =', q)
p = [sp.factor(sp.expand(q[2-j].subs(kk, kk+2))) for j in range(3)]
print('law p_j(k), coefficient of <1>_{k+j}:', p)
chi = sum(sp.Poly(sp.expand(p[j]), kk).coeff_monomial(kk**5)*sp.Symbol('lam')**j for j in range(3))
print('symbol:', sp.factor(chi))
# native gauges (exact): the table's gauge and alpha_c = (1, w, w^2, w^2, 1, w)
w = sp.Rational(-1, 2) + sp.sqrt(3)*sp.I/2
for name, a in (('table gauge 1', [sp.Integer(1)]*6), ('alpha_c', [1, w, w**2, w**2, 1, w])):
    Ps = sp.expand(sum(sp.prod([a[e] for e in C]) for C in COBASES))
    Rst = [sp.simplify(sp.expand(sum(sp.prod([a[x] for x in C]) for C in COBASES if e in C))/Ps) for e in range(6)]
    terms = [sp.expand(sp.prod([a[x] for x in C])) for C in COBASES]
    m1 = [sum(t for C, t in zip(COBASES, terms) if e in C)/Ps for e in range(6)]
    H = sp.Matrix(5, 5, lambda i, j: 2*(sum(t for C, t in zip(COBASES, terms) if (i+1) in C and (j+1) in C)/Ps - m1[i+1]*m1[j+1]))
    tri = [T for T in itertools.combinations(range(6), 3) if (not is_tree([EDGES[i] for i in T])) and len(set(v for i in T for v in EDGES[i])) == 3]
    b1 = sp.simplify(sum(sp.prod([a[e] for e in T])/sp.prod([a[e] for e in range(6) if e not in T]) for T in tri)/4)
    print('%s: Psi = %s, dual occupations %s, native value f = %s, det of the Hessian of -log f on the chart = %s, b_1 = %s' % (
        name, sp.simplify(Ps), Rst, sp.simplify(sp.prod(a)/Ps**2), sp.nsimplify(sp.simplify(sp.expand(H.det()))), b1))
# spectrum: B is not regular at infinity; the change of masters T(k)
print('leading behaviour B(k)/k ->', B.applyfunc(lambda x: sp.limit(x/kk, kk, sp.oo)))
T = lambda x: sp.Matrix([[1, 0], [-x, x]])
Bt = (T(kk-1)*B*T(kk).inv()).applyfunc(sp.cancel)
Binf = Bt.applyfunc(lambda x: sp.limit(x, kk, sp.oo))
print('tilde B(k) =', [[sp.factor(Bt[i, j]) for j in range(2)] for i in range(2)])
print('tilde B(infinity) =', Binf.tolist(), ' characteristic polynomial', sp.factor(Binf.charpoly().as_expr()), ' eigenvalues', Binf.eigenvals())
print('eigenvectors:', [(ev, [list(v) for v in vecs]) for ev, mult, vecs in Binf.eigenvects()])
print('T(k-1) T(k)^{-1} =', (T(kk-1)*T(kk).inv()).applyfunc(sp.simplify).tolist())
print('tr B(k) =', sp.factor(sp.cancel(B.trace())), ' -> ', sp.limit(B.trace(), kk, sp.oo))
print('det B(k) =', sp.factor(sp.cancel(B.det())), ' -> ', sp.limit(sp.cancel(B.det()), kk, sp.oo))
print('time %.1fs' % (time.time()-t0))
