"""Exercise ex:cfive-gauge: the centre ray of binom([5],1) read from its gauge end (Theorem gaugeend):
the density operator, its exponents at f* = 1/25, the line of germs that extend by zero, the Taylor
coefficients of the germ (exact, over Q times g(0)), Beta sums at a large strength and the law run back.
Exact arithmetic for the operator and the germ; mpmath at 150 digits for the Beta sums and the run back."""
import sys; sys.path.insert(0, '.')
from common import *
import mpmath as mp

n = 5
Q, c = ri_law(n)
h = 3
D = 4
t, x = sp.symbols('t x')
lam_ = sp.Symbol('lambda')
pk = [sp.expand(c[i].subs(s, k)) for i in range(h + 1)]
chi = sp.expand(sum(sp.Poly(pk[i], k).coeff_monomial(k ** D) * lam_ ** i for i in range(h + 1)))
chi1 = sp.expand(sum(sp.Poly(pk[i], k).coeff_monomial(k ** (D - 1)) * lam_ ** i for i in range(h + 1)))
print('symbol chi =', sp.factor(chi), '  second symbol chi_1 =', chi1)

# density operator sum_i t^i p_i(-1-i-theta), theta = t d/dt, written sum_j a_j(t) d_t^j
def theta_poly_to_d(poly_theta):
    """polynomial in theta -> {j: coefficient of t^j d^j} via Stirling numbers of the second kind"""
    P = sp.Poly(poly_theta, th)
    out = {}
    for (m,), cf in P.terms():
        for jj in range(m + 1):
            out[jj] = out.get(jj, 0) + cf * sp.functions.combinatorial.numbers.stirling(m, jj)
    return out
a = {}
for i in range(h + 1):
    pt = sp.expand(pk[i].subs(k, -1 - i - th))
    for jj, cf in theta_poly_to_d(pt).items():
        a[jj] = sp.expand(a.get(jj, 0) + t ** i * cf * t ** jj)
print('density operator: a_j(t) =', {jj: sp.factor(v) for jj, v in sorted(a.items())})
print('a_D = (-1)^D t^D chi(t):', sp.expand(a[D] - (-1) ** D * t ** D * chi.subs(lam_, t)) == 0)

fs = sp.Rational(1, 25)
sv = sp.Symbol('s_')
b = {jj: sp.expand((-1) ** jj * a[jj].subs(t, fs - sv)) for jj in a}       # d_t = -d_s
bjl = lambda jj, l: (sp.Poly(b[jj], sv).coeff_monomial(sv ** l) if (jj in b and l >= 0) else 0)
print('b_{D,0} =', bjl(D, 0), ' b_{D,1} =', bjl(D, 1), " = -(f*)^D chi'(f*):", bjl(D, 1) == -fs ** D * sp.diff(chi, lam_).subs(lam_, fs))
gamma = D - 1 - bjl(D - 1, 0) / bjl(D, 1)
print('gamma = D-1-b_{D-1,0}/b_{D,1} =', gamma, '  = -1 + chi_1(f*)/(f* chi\'(f*)) =', -1 + chi1.subs(lam_, fs) / (fs * sp.diff(chi, lam_).subs(lam_, fs)))
def ff(xx, jj):
    return sp.prod([xx - i for i in range(jj)])
def Rm(m):
    return sp.expand(sum(bjl(jj, m - D + 1 + jj) * ff(x, jj) for jj in range(D + 1)))
R0 = Rm(0)
print('R_0(x) =', sp.factor(R0), '  indicial roots', sp.solve(R0, x), '  25^5 R_0 =', sp.factor(R0 * 25 ** 5))
for m in range(1, 8):
    print('R_%d(x) =' % m, sp.factor(Rm(m)))
Mmax = max(m for m in range(0, 30) if Rm(m) != 0)
print('R_m = 0 for m >', Mmax)

# the conditions p_r(u) = 0, r <= D-2, of Theorem gaugeend(iv)
u = sp.symbols('u0:%d' % (D - 1))
def p_r(r):
    tot = 0
    for i in range(r + 1):
        for jj in range(i + 1, D + 1):
            l = jj + r + 1 - D - i
            if l < 0: continue
            tot += (-1) ** l * sp.binomial(jj - 1 - i, l) * sp.factorial(i) * sp.factorial(l) * bjl(jj, l) * u[i]
    return sp.expand(tot)
for r in range(D - 1):
    print('p_%d(u) =' % r, p_r(r), '  coefficient of u_%d =' % r, sp.expand(p_r(r)).coeff(u[r]), ' = r! b_{D,1}(r-gamma):', sp.expand(p_r(r)).coeff(u[r]) == sp.factorial(r) * bjl(D, 1) * (r - gamma))
# cross-check: point masses of D(u H) at s = 0 for u = sum u_r s^r, from the distributional derivatives
deltas = {}
for jj in range(1, D + 1):
    for m in range(jj):                       # u^{(m)}(0) delta^{(jj-1-m)}
        qd = jj - 1 - m
        for l in range(qd + 1):               # b_j(s) delta^{(q)} = sum_l (-1)^l binom(q,l) b_j^{(l)}(0) delta^{(q-l)}
            coef = (-1) ** l * sp.binomial(qd, l) * sp.factorial(l) * bjl(jj, l) * sp.factorial(m) * (u[m] if m < len(u) else 0)
            deltas[qd - l] = sp.expand(deltas.get(qd - l, 0) + coef)
print('point-mass coefficients of D(u H) (delta^(q)):', {q: v for q, v in sorted(deltas.items())})
sol = sp.solve([deltas[q] for q in deltas], list(u), dict=True)
print('germs that extend by zero (u_0, u_1, u_2):', sol)

# the germ: u_0 = 0, u_1 = g(0), u_2 from p_2, u_N (N >= 3) from R_0(N) u_N = -sum_m R_m(N-m) u_{N-m}
NMAX = 400
Rpolys = [sp.Poly(Rm(m), x) for m in range(Mmax + 1)]
def Reval(m, xx):
    return Fraction(Rpolys[m].eval(xx)) if m <= Mmax else Fraction(0)
U = [Fraction(0), Fraction(1)]
u2 = sp.solve(p_r(2).subs({u[0]: 0, u[1]: 1}), u[2])[0]
U.append(Fraction(int(u2.p), int(u2.q)))
for N in range(D - 1, NMAX + 1):
    acc = sum((Reval(m, N - m) * U[N - m] for m in range(1, min(N, Mmax) + 1)), Fraction(0))
    U.append(-acc / Reval(0, N))
print('u_r/u_1, r = 0..4:', [str(v) for v in U[:5]])
# check: the germ satisfies the density equation to order NMAX - 10
ser = sum(sp.Rational(U[r].numerator, U[r].denominator) * sv ** r for r in range(40))
resid = sp.expand(sum(b[jj] * sp.diff(ser, sv, jj) for jj in b))
print('D_p applied to the truncated germ: lowest surviving power of s =', min(sp.Poly(resid, sv).monoms())[0])

# g(0) from the Hessian: w* = 1, f* = 1/25, det H = 16/3125
detH = sp.Rational(16, 3125)
g0 = (2 * sp.pi / fs) ** sp.Rational(n - 1, 2) / (sp.gamma(sp.Rational(n - 1, 2)) * sp.sqrt(detH))
print('g(0) = (2 pi/f*)^2/(Gamma(2) sqrt(det H)) =', sp.simplify(g0))

# Beta sums and the run back
mp.mp.dps = 150
G0 = mp.mpf(15625) * mp.sqrt(5) * mp.pi ** 2
fsm = mp.mpf(1) / 25
def beta_sum(K):
    tot = mp.mpf(0)
    for r in range(1, NMAX + 1):
        term = mp.mpf(U[r].numerator) / U[r].denominator * fsm ** (K + r + 1) * mp.beta(K + 1, r + 1)
        tot += term
    return G0 * tot, term
cf = [sp.lambdify(k, pk[i], 'mpmath') for i in range(h + 1)]
def read(K):
    vals = {}
    last = []
    for KK in (K, K + 1, K + 2):
        vals[KK], lt = beta_sum(KK)
        last.append(lt)
    for kk in range(K - 1, 0, -1):
        vals[kk] = -(cf[1](kk) * vals[kk + 1] + cf[2](kk) * vals[kk + 2] + cf[3](kk) * vals[kk + 3]) / cf[0](kk)
    return vals, last
V150, last150 = read(150)
V250, last250 = read(250)
print('last Beta-sum term relative to the sum at K=150: %s' % mp.nstr(abs(last150[0] * G0 / V150[150]), 5))
for kk in (1, 2, 3):
    print('P(%d) =' % kk, mp.nstr(V150[kk], 60))
print('depths 150 and 250 agree to:', mp.nstr(abs(V150[1] - V250[1]), 5), mp.nstr(abs(V150[2] - V250[2]), 5))
print('low-end relation read on the output: 5P(1) - 285P(2) + 900P(3) =', mp.nstr(5 * V150[1] - 285 * V150[2] + 900 * V150[3], 60))
print('Cor read on the output: -(c_{5,1}(0)P(1)+c_{5,2}(0)P(2)+c_{5,3}(0)P(3))/[s^4]c_{5,0} =', mp.nstr(-(-5 * V150[1] + 285 * V150[2] - 900 * V150[3]), 40))
