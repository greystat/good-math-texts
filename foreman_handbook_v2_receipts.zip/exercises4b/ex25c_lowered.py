"""Exercise ex:cfive-lowered: the lowered settings of five marks, their low-end coefficients, their rates,
and the frame of the law with its constant Phi(1). Exact derivation of Phi(1) (sympy); the quadratures
are checks (mpmath)."""
import sys; sys.path.insert(0, '.')
from common import *
import mpmath as mp

n = 5
Q, c = ri_law(n)
# M-normalization: x(s) = Gamma(s)^2 xi(s); law sum_m q_{5,m}(-s-m) x(s+m) = 0
ML = {m: sp.expand(q.subs(th, -s - m)) for m, q in Q.items()}
print('law in x(s) = Gamma(s)^2 xi(s): coefficients', {m: sp.factor(v) for m, v in sorted(ML.items())})
print('frame: Phi(s+1) = (-1)^3 q0/q3 Phi(s) =', sp.factor(-ML[0] / ML[3]), '* Phi(s)')

# low-end: s^4 xi_{5,j}(s) -> ? as s -> 0; g^{5-j} h^j ~ (-log y)^{5-j} near 0
for jj in range(3):
    print('  j=%d: int_0^1 y^(s-1) (-log y)^(%d) dy = Gamma(%d)/s^%d, so s^4 xi(s) ~ s^4 s^2 Gamma(%d)/s^%d -> %s'
          % (jj, 5 - jj, 6 - jj, 6 - jj, 6 - jj, 6 - jj, factorial(5) if jj == 0 else 0))

# amplitudes and Phi(1)
pi = sp.pi
rho = {jj: 2 * (5 - 2 * jj) for jj in range(3)}
Aj = {jj: 2 * pi ** sp.Rational(5 - 2 * jj, 2) * sp.Rational(1, 2 ** jj) * sp.Integer(rho[jj]) ** sp.Rational(5, 2) for jj in range(3)}
print('rho_j =', rho, ' A_j =', {jj: sp.nsimplify(Aj[jj]) for jj in range(3)})
u = [sp.Rational(1, rho[jj] ** 2) for jj in range(3)]
V = (u[1] - u[0]) * (u[2] - u[0]) * (u[2] - u[1])
print('u_j = rho_j^-2 =', u, ' Vandermonde =', V)
# Phi(s) ~ prod A_j Gamma(2s-5/2)^3 (2s)^6 V prod rho_j^(-2s); Gamma(2s-5/2) ~ Gamma(2s) (2s)^(-5/2); Gamma(2s) ~ 2^(2s-1) Gamma(s)^2 s^(1/2)/sqrt(pi)
# => Phi(s) ~ prod A_j V 2^(-9/2) pi^(-3/2) Gamma(s)^6 (64/prod rho_j^2)^s ; Phi(s) = Phi(1) Gamma(s)^6 225^(1-s)
const = sp.prod(list(Aj.values())) * V * 2 ** sp.Rational(-9, 2) * pi ** sp.Rational(-3, 2)
base = sp.Rational(64, sp.prod([r ** 2 for r in rho.values()]))
print('64/prod rho_j^2 =', base)
Phi1 = sp.nsimplify(sp.simplify(const / 225))
print('Phi(1) =', Phi1, ' block = (225/120) Phi(1) =', sp.simplify(Phi1 * sp.Rational(225, 120)))

# checks by quadrature
mp.mp.dps = 30
g = lambda yy: 2 * mp.besselk(0, 2 * mp.sqrt(yy))
h = lambda yy: mp.besseli(0, 2 * mp.sqrt(yy))
def x(jj, ss):
    return mp.quad(lambda yy: yy ** (ss - 1) * g(yy) ** (5 - jj) * h(yy) ** jj, [0, 1, 10, 100, 1000, mp.inf])
X = {(jj, ss): x(jj, ss) for jj in range(3) for ss in range(1, 6)}
for jj in range(3):
    print('  x^(%d)(s), s=1..3:' % jj, [mp.nstr(X[(jj, ss)], 15) for ss in (1, 2, 3)])
cM = [sp.lambdify(s, ML[m]) for m in range(4)]
for jj in range(3):
    res = [cM[0](ss) * X[(jj, ss)] + cM[1](ss) * X[(jj, ss + 1)] + cM[2](ss) * X[(jj, ss + 2)] + cM[3](ss) * X[(jj, ss + 3)] for ss in (1, 2)]
    low = -5 * X[(jj, 1)] + 285 * X[(jj, 2)] - 225 * X[(jj, 3)]
    print('  j=%d: law residuals at s=1,2: %s;  -5x(1)+285x(2)-225x(3) = %s' % (jj, [mp.nstr(r_, 3) for r_ in res], mp.nstr(low, 20)))
Phi_num = mp.matrix([[X[(i, 1 + l)] for l in range(3)] for i in range(3)])
print('  Phi(1) by quadrature =', mp.nstr(mp.det(Phi_num), 25), ' exact value rendered =', mp.nstr(mp.mpf(128) * mp.sqrt(15) / 16875 * mp.pi ** 3, 25))
blk = X[(1, 1)] * X[(2, 2)] - X[(1, 2)] * X[(2, 1)]
print('  block by quadrature =', mp.nstr(blk, 25), ' exact =', mp.nstr(16 * mp.sqrt(15) / 1125 * mp.pi ** 3, 25))
# rates and amplitudes at moderate s (checks)
for jj in range(3):
    ss = 30
    xs = mp.quad(lambda yy: yy ** (ss - 1) * g(yy) ** (5 - jj) * h(yy) ** jj, [0, 100, 1000, 10 ** 4, 10 ** 5, mp.inf])
    xs1 = mp.quad(lambda yy: yy ** ss * g(yy) ** (5 - jj) * h(yy) ** jj, [0, 100, 1000, 10 ** 4, 10 ** 5, mp.inf])
    amp = 2 * mp.pi ** (mp.mpf(5 - 2 * jj) / 2) * mp.mpf(2) ** (-jj) * mp.mpf(rho[jj]) ** 2.5 * mp.gamma(2 * ss - 2.5) * mp.mpf(rho[jj]) ** (-2 * ss)
    print('  j=%d, s=%d: x/(A_j Gamma(2s-5/2) rho^-2s) = %s;  x(s+1)/(s^2 x(s)) = %s against (5-2j)^-2 = %s'
          % (jj, ss, mp.nstr(xs / amp, 8), mp.nstr(xs1 / (ss ** 2 * xs), 8), mp.nstr(mp.mpf(1) / (5 - 2 * jj) ** 2, 8)))
# the one-mark asymptotics from Theorem configgauge(iii): xi=(1,1), t=(1,-1), nu=0
print('configgauge data: Phi_xi(y) = e^y + e^-y, y* = 0, Phi(y*) = 2, sum w* t t^T = 2: g(y) ~ sqrt(pi) y^(-1/4) e^(-2 sqrt y)')
for yy in (100, 10000):
    print('  y=%d: g(y)/(sqrt(pi) y^-1/4 e^-2sqrt(y)) = %s,  h(y)/(e^(2 sqrt y)/(2 sqrt(pi) y^(1/4))) = %s'
          % (yy, mp.nstr(g(yy) / (mp.sqrt(mp.pi) * mp.mpf(yy) ** (-0.25) * mp.exp(-2 * mp.sqrt(yy))), 8),
             mp.nstr(h(yy) / (mp.exp(2 * mp.sqrt(yy)) / (2 * mp.sqrt(mp.pi) * mp.mpf(yy) ** 0.25)), 8)))
