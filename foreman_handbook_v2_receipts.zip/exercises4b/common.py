"""Shared exact tools for the exercises of chapter XI.4, second half (python-flint, sympy).
Operators in y are written sum_m y^m Q_m(theta), theta = y d/dy."""
import sympy as sp
from fractions import Fraction
from math import comb, factorial, gcd

y, th, s, k = sp.symbols('y theta s k')

def sym_power_operator(n):
    """Operator annihilating every product of n solutions of theta^2 u = y u.
    Returns {m: Q_m(theta)} with sum_m y^m Q_m(theta) u_1...u_n = 0, normalized so Q_0 has leading coefficient 1."""
    A = sp.zeros(n + 1, n + 1)
    for i in range(n + 1):
        if i + 1 <= n:
            A[i, i + 1] = n - i
        if i - 1 >= 0:
            A[i, i - 1] = i * y
    rows = [sp.Matrix([[1] + [0] * n])]
    for j in range(n + 1):
        r = rows[-1]
        rows.append(sp.Matrix([[sp.expand(y * sp.diff(r[c], y)) for c in range(n + 1)]]) + r * A)
    M = sp.Matrix.vstack(*rows)          # (n+2) x (n+1) over Q[y]
    ns = M.T.nullspace()
    assert len(ns) == 1
    q = ns[0]
    den = sp.lcm([sp.fraction(sp.together(x))[1] for x in q])
    q = [sp.expand(sp.cancel(x * den)) for x in q]
    g = sp.gcd_list(q)
    q = [sp.expand(sp.cancel(x / g)) for x in q]
    Q = {}
    for j, qj in enumerate(q):
        P = sp.Poly(qj, y)
        for (mm,), c in P.terms():
            Q[mm] = Q.get(mm, 0) + c * th**j
    lead = sp.Poly(Q[0], th).LC()
    Q = {mm: sp.expand(v / lead) for mm, v in Q.items()}
    return Q

def apply_operator_to_series(Q, coeffs, J):
    """[y^J] of sum_m y^m Q_m(theta) sum_j a_j y^j for a power series with coefficients coeffs."""
    tot = 0
    for mm, Qm in Q.items():
        j = J - mm
        if 0 <= j < len(coeffs):
            tot += Qm.subs(th, j) * coeffs[j]
    return tot

def mellin_law(Q):
    """sum_m Q_m(-s-m) M(s+m) = 0 : returns {m: polynomial in s}"""
    return {mm: sp.expand(Qm.subs(th, -s - mm)) for mm, Qm in Q.items()}

def multinomial_closings(n, J):
    """C_j = CT[(K(a)K(1/a))^j] for K = a_1+...+a_n: sum over compositions of (j!/prod a!)^2."""
    h = [Fraction(1, factorial(m) ** 2) for m in range(J + 1)]
    p = [Fraction(1)] + [Fraction(0)] * J
    for _ in range(n):
        q = [Fraction(0)] * (J + 1)
        for i, a in enumerate(p):
            if a == 0: continue
            for jj in range(J + 1 - i):
                q[i + jj] += a * h[jj]
        p = q
    return [int(p[j] * factorial(j) ** 2) for j in range(J + 1)]

def run_law(p, init, K, start=1):
    """sum_i p_i(k) x_{k+i} = 0 ; p list of sympy polys in k ; init x_start.. ; returns dict k->Fraction"""
    h = len(p) - 1
    x = {start + i: Fraction(init[i]) for i in range(h)}
    pf = [sp.lambdify(k, pi, 'sympy') for pi in p]
    for kk in range(start, K - h + 1):
        acc = Fraction(0)
        for i in range(h):
            v = sp.Rational(p[i].subs(k, kk))
            acc += Fraction(int(v.p), int(v.q)) * x[kk + i]
        ph = sp.Rational(p[h].subs(k, kk))
        x[kk + h] = -acc / Fraction(int(ph.p), int(ph.q))
    return x

def d_lcm(n):
    L = 1
    for i in range(1, n + 1):
        L = L * i // gcd(L, i)
    return L

# ---- the law of the values of binom(E,1) as in Theorem ri-law: R_0 = 1, R_1 = theta,
# R_{i+1} = theta R_i - i(n+1-i) y R_{i-1}; Q_n = R_{n+1} = sum_k y^k q_{n,k}(theta).
def R_operators(n):
    """Returns the list [R_0, ..., R_{n+1}], each a dict {power of y: polynomial in theta}."""
    def theta_left(Rd):          # theta o (y^m q(theta)) = y^m (theta + m) q(theta)
        return {m: sp.expand((th + m) * q) for m, q in Rd.items()}
    def y_left(Rd, c):           # c * y o (y^m q) = y^{m+1} c q
        return {m + 1: sp.expand(c * q) for m, q in Rd.items()}
    R = [{0: sp.Integer(1)}, {0: th}]
    for i in range(1, n + 1):
        a = theta_left(R[i])
        b = y_left(R[i - 1], -i * (n + 1 - i))
        new = dict(a)
        for m, q in b.items():
            new[m] = sp.expand(new.get(m, 0) + q)
        R.append({m: q for m, q in new.items() if q != 0})
    return R

def ri_law(n):
    """c_{n,k}(s) of Theorem ri-law(ii): c_{n,0} = (-1)^{n+1} s^{n-1}, c_{n,k} = q_{n,k}(-s-k) ((s+1)...(s+k-1))^2."""
    Q = R_operators(n)[n + 1]
    c = {}
    for kk, q in Q.items():
        if kk == 0:
            c[0] = sp.expand((-1) ** (n + 1) * s ** (n - 1))
            assert sp.expand(q.subs(th, -s) - (-1) ** (n + 1) * s ** (n + 1)) == 0
        else:
            c[kk] = sp.expand(q.subs(th, -s - kk) * sp.prod([(s + i) ** 2 for i in range(1, kk)]))
    return Q, c
