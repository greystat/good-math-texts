"""Shared tools for the receipts of Chapter ch:exlists (exercises on rays: other lists).

Exact arithmetic: Python integers and fractions, python-flint (fmpz, fmpq, fmpz_mat, fmpq_mat, nmod_mat,
fmpq_poly) and sympy for symbolic identities.  Ball arithmetic (flint arb/acb) only for decimal renderings
and for checks, never as evidence for an exact statement.
"""
import math, itertools
from fractions import Fraction
from math import comb, gcd, factorial
from flint import (fmpz, fmpq, fmpz_mat, fmpq_mat, nmod_mat, fmpq_poly, fmpz_poly,
                   arb, acb, arb_mat, ctx)
import sympy as sp

# ----------------------------------------------------------------------------------------------- lists
def rank_fn(bases):
    return lambda S: max(len(set(T) & set(S)) for T in bases)

def proper_subsets(n):
    for r in range(1, n):
        for S in itertools.combinations(range(n), r):
            yield S

def walls(bases, n, m, s, t):
    """walls kappa_{1,S} = m_S - s d(S) - t (|S| - r(S)) of the direction (m; s, t) of one table"""
    r = rank_fn(bases)
    d = lambda S: min(len(set(T) & set(S)) for T in bases)
    return {S: sum(m[i] for i in S) - s * d(S) - t * (len(S) - r(S)) for S in proper_subsets(n)}

def widths(bases, n):
    r = rank_fn(bases); rk = r(tuple(range(n)))
    return {S: r(S) + r(tuple(set(range(n)) - set(S))) - rk for S in proper_subsets(n)}

def V1(kap, n):
    """V_1 = sum over the orders of prod_{l>=2} kappa_{1,U_l}^{-1}, U_l the tails"""
    tot = Fraction(0)
    for pi in itertools.permutations(range(n)):
        pr = Fraction(1)
        for l in range(1, n):
            pr /= kap[tuple(sorted(pi[l:]))]
        tot += pr
    return tot

# ------------------------------------------------------------------------------ Laurent polynomials
def lmul(a, b):
    c = {}
    for e1, v1 in a.items():
        for e2, v2 in b.items():
            e = tuple(x + y for x, y in zip(e1, e2))
            c[e] = c.get(e, 0) + v1 * v2
    return {e: v for e, v in c.items() if v != 0}

def lpow(a, k, n):
    r = {tuple([0] * n): 1}
    for _ in range(k):
        r = lmul(r, a)
    return r

def letter(bases, n):
    return {tuple(1 if i in T else 0 for i in range(n)): 1 for T in bases}

def coletter(bases, n):
    return {tuple(0 if i in T else 1 for i in range(n)): 1 for T in bases}

def recip_stride(bases, n, m, s, t):
    """f^{-1} = alpha^{-m} K^s Psi^t as a Laurent polynomial"""
    K, P = letter(bases, n), coletter(bases, n)
    out = lmul(lpow(K, s, n), lpow(P, t, n))
    return {tuple(e[i] - m[i] for i in range(n)): v for e, v in out.items()}

def constant_terms(finv, n, J):
    """CT((f^{-1})^j), j < J, by repeated multiplication (a check on closed forms)"""
    out, cur = [], {tuple([0] * n): 1}
    for j in range(J):
        out.append(cur.get(tuple([0] * n), 0))
        cur = lmul(cur, finv)
    return out

# ------------------------------------------------------------------------------------ recurrences
J_ = sp.Symbol('j'); K_ = sp.Symbol('k'); U_ = sp.Symbol('u')

def find_rec(x, h, D, J=None):
    """the recurrence sum_{i<=h} p_i(j) x_{j+i} = 0 with deg p_i <= D, by an exact nullspace over Z.
    Returns the list of sympy polynomials p_i(j) (primitive), or None if the nullspace is not a line."""
    J = J or len(x)
    neq = J - h
    rows = [[x[jj + i] * jj ** e for i in range(h + 1) for e in range(D + 1)] for jj in range(neq)]
    N, nul = fmpz_mat(rows).nullspace()
    if nul != 1:
        return None
    v = [int(N[c, 0]) for c in range((h + 1) * (D + 1))]
    g = 0
    for c in v:
        g = gcd(g, c)
    v = [c // g for c in v]
    if next(c for c in reversed(v) if c) < 0:
        v = [-c for c in v]
    return [sp.expand(sum(v[i * (D + 1) + e] * J_ ** e for e in range(D + 1))) for i in range(h + 1)]

def no_recurrence_mod(x, h, D, p=2 ** 61 - 1):
    """True if x satisfies no recurrence of order h and degree D on its terms (rank test modulo p;
    a full rank modulo p implies a full rank over Q)"""
    nunk = (h + 1) * (D + 1); neq = len(x) - h
    if neq < nunk:
        return None
    M = nmod_mat(neq, nunk, p)
    for jj in range(neq):
        for i in range(h + 1):
            xi = x[jj + i] % p; pw = 1
            for e in range(D + 1):
                M[jj, i * (D + 1) + e] = xi * pw % p; pw = pw * jj % p
    return M.rank() == nunk

def check_rec(p, x):
    f = [sp.lambdify(J_, q, 'math') for q in p]
    pol = [sp.Poly(q, J_) for q in p]
    h = len(p) - 1
    return all(sum(int(pol[i].eval(jj)) * x[jj + i] for i in range(h + 1)) == 0 for jj in range(len(x) - h))

def reflect(p):
    """c_i(k) = p_{h-i}(-k-h): sum_i p_i(j) x_{j+i} = 0 read at j = -k-h (Corollary cor:reflected),
    normalized so that c_0 has a positive leading coefficient"""
    h = len(p) - 1
    c = [sp.expand(p[h - i].subs(J_, -K_ - h)) for i in range(h + 1)]
    if sp.Poly(c[0], K_).LC() < 0:
        c = [-ci for ci in c]
    return c

def symbol(c):
    D = max(sp.Poly(ci, K_).degree() for ci in c)
    lam = sp.Symbol('lambda')
    return sp.factor(sum(sp.Poly(ci, K_).coeff_monomial(K_ ** D) * lam ** i for i, ci in enumerate(c))), D

# ------------------------------------------------------------------- telescoping (closings are sums)
def telescoper_A(Fj, Fu, p, Dd_shift_factor, degA):
    """Solve  Fu(u) * A(u+1)/Dd(u+1) - A(u)/Dd(u) = N/Dn  for a polynomial A in u of degree degA, where
    N/Dn = sum_i p_i(j) Fj(i) (Fj(i) = F(j+i,u)/F(j,u)), Dd = Dn.  Returns (A, Dd) or None."""
    r = len(p) - 1
    S = sp.together(sum(p[i] * Fj(i) for i in range(r + 1)))
    N, Dn = sp.fraction(S)
    a = sp.symbols('a0:%d' % (degA + 1))
    A = sum(a[q] * U_ ** q for q in range(degA + 1))
    expr = Fu * A.subs(U_, U_ + 1) / Dn.subs(U_, U_ + 1) - A / Dn - N / Dn
    num = sp.Poly(sp.expand(sp.numer(sp.together(expr))), U_)
    sol = sp.solve(num.coeffs(), a, dict=True)
    if not sol:
        return None
    return sp.factor(A.subs(sol[0]).subs({ai: 0 for ai in a})), sp.factor(Dn)

# ---------------------------------------------------------------- Laurent expansions of Gamma, psi
# Truncated Laurent series in x: (v, [c_v, c_{v+1}, ...]) with sympy coefficients in the symbols
# g1 = -(log Gamma)'(1) and z_n = (T_{n;(1)}[x] I_Z)((0,oo)), n >= 2 (Proposition prop:resonance).
X_ = sp.Symbol('x')
EG = sp.Symbol('g1')
ZV = {n: sp.Symbol('z%d' % n) for n in range(2, 30)}
NPREC = 8

class LS:
    def __init__(self, v, c):
        self.v, self.c = v, [sp.expand(a) for a in c[:NPREC]] + [sp.Integer(0)] * max(0, NPREC - len(c))
    @staticmethod
    def const(a):
        return LS(0, [sp.sympify(a)])
    def __mul__(self, o):
        if not isinstance(o, LS):
            return LS(self.v, [a * o for a in self.c])
        c = [sp.expand(sum(self.c[i] * o.c[k - i] for i in range(k + 1))) for k in range(NPREC)]
        return LS(self.v + o.v, c)
    __rmul__ = __mul__
    def __add__(self, o):
        if not isinstance(o, LS):
            o = LS.const(o)
        v = min(self.v, o.v)
        c = [sp.Integer(0)] * NPREC
        for i in range(NPREC):
            e = v + i
            if 0 <= e - self.v < NPREC: c[i] += self.c[e - self.v]
            if 0 <= e - o.v < NPREC: c[i] += o.c[e - o.v]
        return LS(v, c)
    __radd__ = __add__
    def __neg__(self):
        return self * (-1)
    def __sub__(self, o):
        return self + (-o)
    def __rsub__(self, o):
        return (-self) + o
    def inv(self):
        k = 0
        while sp.simplify(self.c[k]) == 0:
            k += 1
        c = self.c[k:] + [sp.Integer(0)] * k
        b = [1 / c[0]]
        for m in range(1, NPREC):
            b.append(sp.expand(-sum(c[i] * b[m - i] for i in range(1, m + 1)) / c[0]))
        return LS(-(self.v + k), b)
    def __truediv__(self, o):
        if not isinstance(o, LS):
            return self * (sp.Integer(1) / o)
        return self * o.inv()
    def __pow__(self, n):
        r = LS.const(1)
        for _ in range(n):
            r = r * self
        return r
    def coeff(self, e):
        return sp.simplify(self.c[e - self.v]) if 0 <= e - self.v < NPREC else None

def _exp_series(L):
    """exp of a power series L with L(0) = 0, coefficients list (index = power)"""
    e = [sp.Integer(1)] + [sp.Integer(0)] * (NPREC - 1)
    for m in range(1, NPREC):
        e[m] = sp.expand(sum(k * L[k] * e[m - k] for k in range(1, m + 1)) / m)
    return e

def gam(a, sc=1):
    """Gamma(a + sc*x) as a truncated Laurent series, a an integer"""
    L = [sp.Integer(0), -EG * sc] + [(-1) ** m * ZV[m] * sc ** m / m for m in range(2, NPREC)]
    base = LS(0, _exp_series(L))
    if a >= 1:
        for i in range(1, a):
            base = base * LS(0, [i, sc])
        return base
    den = LS(1, [sc])
    for i in range(1, -a + 1):
        den = den * LS(0, [-i, sc])
    return base / den

def psi(a, sc=1):
    """(log Gamma)'(a + sc*x) as a truncated Laurent series, a an integer"""
    base = LS(0, [-EG] + [(-1) ** m * ZV[m] * sc ** (m - 1) for m in range(2, NPREC + 1)])
    if a >= 1:
        for i in range(1, a):
            base = base + LS(0, [i, sc]).inv()
        return base
    base = base - LS(1, [sc]).inv()
    for i in range(1, -a + 1):
        base = base - LS(0, [-i, sc]).inv()
    return base

def poly_at(pol, a):
    """a sympy polynomial in K_ read at k = a + x, as a truncated series"""
    q = sp.Poly(sp.expand(pol.subs(K_, a + X_)), X_)
    cs = [q.coeff_monomial(X_ ** i) for i in range(NPREC)]
    return LS(0, cs)

# --------------------------------------------------------------------------------- the gauge end
def density_operator(cp):
    """L = sum_i t^i c_i(-1-i-theta) = sum_j a_j(t) d^j/dt^j; cp: coefficient lists (fmpq) of the c_i in k"""
    D = max(len(c) - 1 for c in cp)
    S = [[0] * (D + 1) for _ in range(D + 1)]; S[0][0] = 1
    for a_ in range(1, D + 1):
        for b_ in range(1, a_ + 1):
            S[a_][b_] = b_ * S[a_ - 1][b_] + S[a_ - 1][b_ - 1]
    a = [fmpq_poly([]) for _ in range(D + 1)]
    for i, c in enumerate(cp):
        q = fmpq_poly([fmpq(-1 - i), fmpq(-1)])
        poly = fmpq_poly([]); pw = fmpq_poly([1])
        for gm in c:
            if gm != 0:
                poly += fmpq(gm) * pw
            pw *= q
        for r in range(poly.degree() + 1):
            beta = poly[r]
            if beta == 0:
                continue
            for jj in range(r + 1):
                if S[r][jj]:
                    a[jj] += fmpq_poly([0] * (i + jj) + [beta * S[r][jj]])
    return D, a

def shifted_ops(a, t0):
    """b_j(s) = (-1)^j a_j(t0 - s), coefficient lists in s; t0 an fmpq or an arb"""
    b = []
    for jj, aj in enumerate(a):
        deg = aj.degree()
        out = []
        for l in range(deg + 1):
            c = 0
            for r in range(l, deg + 1):
                if aj[r] != 0:
                    c += (aj[r] if isinstance(t0, fmpq) else arb(aj[r].p) / arb(aj[r].q)) * comb(r, l) * t0 ** (r - l)
            out.append(c * (-1) ** l)
        sgn = -1 if jj % 2 else 1
        b.append([sgn * c for c in out])
    return b

def falling(xv, jj):
    r = 1
    for i in range(jj):
        r *= (xv - i)
    return r

def coef(lst, l):
    return lst[l] if 0 <= l < len(lst) else 0

def indicial_extra(b, D):
    """the exponent beyond 0, ..., D-2 at a simple root: D - 1 - b_{D-1,0}/b_{D,1}"""
    return D - 1 - coef(b[D - 1], 0) / coef(b[D], 1)

def germ_series_halfint(b, D, mu, M):
    """the solution s^mu (1 + sum e_m s^m) at a simple root, mu not an integer (arb, midpoints)"""
    terms = {}
    for m in range(0, 400):
        lst = []
        for jj in range(D + 1):
            l = m - D + 1 + jj
            if 0 <= l < len(b[jj]) and b[jj][l] != 0:
                bj = b[jj][l]
                lst.append((jj, bj.mid() if isinstance(bj, arb) else arb(bj.p) / arb(bj.q)))
        if lst:
            terms[m] = lst
    maxm = max(terms)
    def Rm(m, xv):
        tot = arb(0)
        for jj, bj in terms.get(m, []):
            tot += bj * falling(xv, jj)
        return tot
    mu_a = arb(mu.p) / arb(mu.q) if isinstance(mu, fmpq) else arb(mu)
    e = [arb(1)]
    for Nn in range(1, M + 1):
        s = arb(0)
        for jj in range(1, min(Nn, maxm) + 1):
            if jj in terms:
                s += Rm(jj, mu_a + Nn - jj) * e[Nn - jj]
        e.append((-s / Rm(0, mu_a + Nn)).mid())
    return e

def beta_sums(e, mu, fstar, K):
    """P(K) = sum_m e_m fstar^{K+mu+m+1} B(K+1, mu+m+1)"""
    mu_a = arb(mu.p) / arb(mu.q) if isinstance(mu, fmpq) else arb(mu)
    B = arb(K + 1).gamma() * (mu_a + 1).gamma() / (arb(K + 1) + mu_a + 1).gamma()
    fp = fstar ** (arb(K + 1) + mu_a)
    tot = arb(0)
    for m, em in enumerate(e):
        tot += em * fp * B
        B *= (mu_a + m + 1) / (arb(K + 1) + mu_a + m + 1)
        fp *= fstar
    return tot

def run_back(cpoly, vals, K):
    """cpoly: sympy polynomials c_i(k); vals: dict k -> arb for k = K..K+h-1; returns dict down to k = 1"""
    h = len(cpoly) - 1
    P = [sp.Poly(c, K_) for c in cpoly]
    xv = dict(vals)
    for k in range(K - 1, 0, -1):
        s = arb(0)
        for i in range(1, h + 1):
            s += arb(int(P[i].eval(k))) * xv[k + i]
        xv[k] = -s / arb(int(P[0].eval(k)))
    return xv

def law_coeff_lists(cpoly):
    return [[fmpq(int(cf)) for cf in reversed(sp.Poly(c, K_).all_coeffs())] for c in cpoly]

# ----------------------------------------------------------------------------- integer relations
def lll_relation(vals, digits):
    """an integer relation among the arb values by LLL at the given number of digits; returns
    (coefficients, residual).  A search: the relation it returns is then checked at higher precision."""
    sc = arb(10) ** digits
    n = len(vals)
    rows = []
    for i, v in enumerate(vals):
        row = [0] * n; row[i] = 1
        row.append(int((v * sc).mid().floor().unique_fmpz()))
        rows.append(row)
    M = fmpz_mat(rows).lll()
    best = min(([int(M[i, jj]) for jj in range(n)] for i in range(n)), key=lambda r_: max(abs(x) for x in r_))
    return best, sum((arb(a) * v for a, v in zip(best, vals)), arb(0))

def ell_value():
    """l = P_{binom([3],1)}(1;1,1) = 3 sum_n chi_{-3}(n)/n^2 in ball arithmetic (Hurwitz zeta values)"""
    return (arb(2).zeta(arb(1) / 3) - arb(2).zeta(arb(2) / 3)) / 3


def trunc(x, digits):
    """The first `digits` significant digits of the real ball x, truncated (not rounded),
    followed by '...'; checks that the whole ball gives the same digits."""
    from decimal import Decimal, getcontext, ROUND_DOWN
    getcontext().prec = digits + 40
    lo = Decimal((x - x.rad()).str(digits + 30, radius=False))
    hi = Decimal((x + x.rad()).str(digits + 30, radius=False))
    def cut(d):
        q = Decimal(1).scaleb(d.adjusted() - digits + 1)
        return d.quantize(q, rounding=ROUND_DOWN)
    a, b = cut(lo), cut(hi)
    if a != b:
        return 'radius too large for %d digits' % digits
    return str(a) + '...'
