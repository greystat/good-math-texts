"""Receipt for Exercise ex:lista-trees: the five-mark lists along their hinge trees.
Run: python3 ex30_trees.py   (a few minutes; the checks by the box procedure use the supplied reader
/home/claude/v2/receipts_src/rayreader, run in a temporary folder)
Prints every number the solution displays; exact unless marked as a rendering (ball arithmetic)."""
import sys, time, os, json, tempfile, contextlib, io
sys.path.insert(0, __file__.rsplit('/', 1)[0])
from common import *

T0 = time.time()
say = lambda *a: print(*a, flush=True)

LISTS = {
    'binom([5],1)': [(i,) for i in range(5)],
    'P_5 (pairs other than {1,2})': [T for T in itertools.combinations(range(5), 2) if T != (0, 1)],
    'binom([5],2)': list(itertools.combinations(range(5), 2)),
    'R_5 (classes {1,2},{3,4},{5})': [(0, 2), (0, 3), (1, 2), (1, 3), (0, 4), (1, 4), (2, 4), (3, 4)],
    'T_5 (classes {1,2,3},{4},{5})': [(0, 3), (1, 3), (2, 3), (0, 4), (1, 4), (2, 4), (3, 4)],
}

say('1. Widths and bunches of width one with at least two marks on each side')
for name, B in LISTS.items():
    w = widths(B, 5)
    ones = sorted({min(S, tuple(sorted(set(range(5)) - set(S)))) for S, c in w.items() if c == 1 and 2 <= len(S) <= 3},
                  key=lambda S: (len(S), S))
    two = all(c >= 2 for S, c in w.items() if 2 <= len(S) <= 3)
    say('   %-32s rank %d, %d bases; width-one splits (one side shown, marks 1..5): %s%s' % (
        name, rank_fn(B)(tuple(range(5))), len(B), [tuple(i + 1 for i in S) for S in ones] or '-',
        '  (every such set has width 2: prime)' if two else ''))
B4 = list(itertools.combinations(range(4), 2))
w4 = widths(B4, 4)
say('   binom([4],2): widths of the pairs', sorted({c for S, c in w4.items() if len(S) == 2}), '(prime)')

say('2. The three-mark centre: closings, the law, its proof')
B3 = [(0,), (1,), (2,)]
xs = [sum(comb(j, u) ** 2 * comb(2 * u, u) for u in range(j + 1)) for j in range(120)]
say('   closings = constant terms of the powers of (a1+a2+a3)(1/a1+1/a2+1/a3) for j < 8:',
    xs[:8] == constant_terms(recip_stride(B3, 3, [1, 1, 1], 1, 1), 3, 8), ';', xs[:7])
say('   no recurrence of order 1 and degree <= 40 on 120 closings:', all(no_recurrence_mod(xs, 1, D) for D in range(41)))
p3 = find_rec(xs[:60], 2, 2)
say('   recurrence:', [sp.factor(q) for q in p3], '; holds on 120:', check_rec(p3, xs))
Fj = lambda i: sp.prod([((J_ + l) / (J_ + l - U_)) ** 2 for l in range(1, i + 1)]) if i else sp.Integer(1)
Fu = ((J_ - U_) / (U_ + 1)) ** 2 * (2 * (2 * U_ + 1) / (U_ + 1))
A3, Dd3 = telescoper_A(Fj, Fu, p3, None, 4)
say('   telescoping: A(j,u) =', sp.factor(A3))
plhs = (U_ + 1) ** 3 * sum(p3[i] * sp.prod([(J_ + l) ** 2 for l in range(1, i + 1)]) * sp.prod([(J_ + l - U_) ** 2 for l in range(i + 1, 3)]) for i in range(3))
prhs = 2 * (2 * U_ + 1) * (J_ + 2 - U_) ** 2 * A3.subs(U_, U_ + 1) - (U_ + 1) ** 3 * A3
say('   (u+1)^3 sum_i p_i prod_{l<=i}(j+l)^2 prod_{l>i}(j+l-u)^2 = 2(2u+1)(j+2-u)^2 A(j,u+1) - (u+1)^3 A(j,u) in Q[j,u]:',
    sp.expand(plhs - prhs) == 0, '; A(j,0) = 0:', sp.expand(A3.subs(U_, 0)) == 0)
c3 = reflect(p3)
say('   the law sum_i c_i(k) p(k+i) = 0:', [sp.factor(q) for q in c3])
kap3 = walls(B3, 3, [1, 1, 1], 1, 1)
V13 = V1(kap3, 3)
say('   V_1 =', V13)
ell = sp.Symbol('ell')
pv = {1: ell}
pv[2] = sp.expand(-(sp.Poly(c3[0], K_).coeff_monomial(K_ ** 2) * V13 + sp.Poly(c3[1], K_).eval(0) * pv[1]) / sp.Poly(c3[2], K_).eval(0))
for kk in range(1, 8):
    pv[kk + 2] = sp.expand(-(sp.Poly(c3[0], K_).eval(kk) * pv[kk] + sp.Poly(c3[1], K_).eval(kk) * pv[kk + 1]) / sp.Poly(c3[2], K_).eval(kk))
say('   low-end relation gives p(2) =', pv[2], '; p(3) =', pv[3], '; p(4) =', pv[4])

say('3. P_5: the doubled mark of binom([4],2)')
BP = LISTS['P_5 (pairs other than {1,2})']
kapP = walls(BP, 5, [1] * 5, 1, 1)
say('   walls: singles', kapP[(0,)], kapP[(2,)], '; {1,2}:', kapP[(0, 1)], '; {1,3}:', kapP[(0, 2)], '; {3,4}:', kapP[(2, 3)], '; {3,4,5}:', kapP[(2, 3, 4)],
    '; V_1 =', V1(kapP, 5))
# the symmetric square of the three-mark law
a_ = -c3[0] / c3[2]; b_ = -c3[1] / c3[2]
A_ = b_.subs(K_, K_ + 1) * a_; Bb = a_.subs(K_, K_ + 1) + b_.subs(K_, K_ + 1) * b_
d3 = sp.Integer(1); d2 = -A_ * Bb / (a_ * b_); d0 = -d2 * a_ ** 2 - A_ ** 2; d1 = -d2 * b_ ** 2 - Bb ** 2
dd = [sp.together(x) for x in (d0, d1, d2, d3)]
den = sp.lcm([sp.fraction(x)[1] for x in dd])
dd = [sp.factor(sp.cancel(x * den)) for x in dd]
g_ = dd[0]
for x in dd[1:]:
    g_ = sp.gcd(g_, x)
dd = [sp.factor(sp.cancel(x / g_)) for x in dd]
cont = 0
for x in dd:
    for c in sp.Poly(x, K_).coeffs():
        cont = sp.gcd(cont, c)
dd = [sp.factor(sp.cancel(x / cont)) for x in dd]
if sp.Poly(dd[0], K_).LC() < 0:
    dd = [-x for x in dd]
say('   the law of p(k)^2 (order 3):')
for i, x in enumerate(dd):
    say('     d_%d(k) =' % i, x)
xsq = {kk: sp.expand(pv[kk] ** 2) for kk in pv}
say('   it holds on p(k)^2, k = 1..5, identically in ell:',
    all(sp.expand(sum(sp.Poly(dd[i], K_).eval(kk) * xsq[kk + i] for i in range(4))) == 0 for kk in range(1, 6)))
symP, DgP = symbol(dd)
say('   symbol:', symP)
d0p = sp.Poly(dd[0], K_)
say('   d_0 at 0: orders 0..3:', [d0p.coeff_monomial(K_ ** q) for q in range(4)], '; [k^4] d_0 =', d0p.coeff_monomial(K_ ** 4))
lowP = sp.expand(d0p.coeff_monomial(K_ ** 4) * 36 + sum(sp.Poly(dd[i], K_).eval(0) * xsq[i] for i in range(1, 4)))
say('   low-end relation with V_1 = 36 at p(i)^2:', lowP)

say('4. binom([4],2) at its centre: q = P_2 P_3 and its law')
sg = sp.Symbol('sigma')
P2r = lambda x: sp.gamma(x) ** 2 / sp.gamma(2 * x)
# ratios P_2(s+1)/P_2(s) = s/(2(2s+1))
r1 = sp.simplify(sp.gammasimp(P2r(sg + 1) / P2r(sg))); r2 = sp.simplify(sp.gammasimp(P2r(sg + 2) / P2r(sg)))
say('   P_2(s+1)/P_2(s) =', sp.factor(r1), '; P_2(s+2)/P_2(s) =', sp.factor(r2))
cq = [sp.factor(sp.cancel(c3[0].subs(K_, sg) * sg)), sp.factor(sp.cancel(c3[1].subs(K_, sg) / r1 * sg)), sp.factor(sp.cancel(c3[2].subs(K_, sg) / r2 * sg))]
say('   the law of q:', cq)
say('   V_1 of binom([4],2):', V1(walls(B4, 4, [1] * 4, 1, 1), 4), '; symbol of the law of q:', sp.factor(sum(sp.Poly(cq[i], sg).coeff_monomial(sg ** 3) * sp.Symbol('lambda') ** i for i in range(3))))

say('5. Numbers (renderings): l, l\', the closings of T_5, and checks by the box procedure')
ctx.prec = 400
import mpmath
mpmath.mp.dps = 60
# G_0(y) = 2 K_0(2 sqrt y); with y = w^2/4: int_0^oo F(y) dy = int_0^oo F(w^2/4) (w/2) dw
I0 = mpmath.quad(lambda w: 4 * w * mpmath.besselk(0, w) ** 3, [0, 1, 4, 16, 64, 160])
I1 = mpmath.quad(lambda w: 4 * w * mpmath.log(w * w / 4) * mpmath.besselk(0, w) ** 3, [0, 1, 4, 16, 64, 160])
lv = arb(mpmath.nstr(I0, 55))
EGa = arb.const_euler()
lpv = arb(mpmath.nstr(I1, 55)) + 2 * EGa * lv
say('   l  = int G_0^3 dy  =', lv.mid().str(45, radius=False), '(quadrature, 60 digits); minus the closed rendering:', (lv - ell_value()).mid().str(3, radius=False))
say('   l\' = int log(y) G_0^3 dy + 2 gamma l =', lpv.mid().str(45, radius=False), '(quadrature)')
# three-mark values and slopes at the integers, exact in Q(l, l'):
# the law differentiated, sum_i c_i(k) p'(k+i) + sum_i c_i'(k) p(k+i) = 0, from p'(1) = l' and p'(2)
lp_ = sp.Symbol('lp')
c3p = [sp.Poly(c, K_) for c in c3]; c3d = [sp.Poly(sp.diff(c, K_), K_) for c in c3]
for kk in range(1, 70):
    if kk + 2 not in pv:
        pv[kk + 2] = sp.expand(-(c3p[0].eval(kk) * pv[kk] + c3p[1].eval(kk) * pv[kk + 1]) / c3p[2].eval(kk))
# p'(2) from the derivative of the law at k = 0: c_0 p = 6 + L_1 k + O(k^2) with L_1 = 0
pp = {1: lp_, 2: sp.expand(-(c3d[1].eval(0) * pv[1] + c3p[1].eval(0) * lp_ + c3d[2].eval(0) * pv[2]) / c3p[2].eval(0))}
for kk in range(1, 68):
    pp[kk + 2] = sp.expand(-(c3p[0].eval(kk) * pp[kk] + c3p[1].eval(kk) * pp[kk + 1]
                             + c3d[0].eval(kk) * pv[kk] + c3d[1].eval(kk) * pv[kk + 1] + c3d[2].eval(kk) * pv[kk + 2]) / c3p[2].eval(kk))
say("   p'(2) =", pp[2], "; p'(3) =", pp[3])
def hnum(n):
    return sp.Rational(sum(Fraction(1, i) for i in range(1, n + 1)))
def P2(x):
    return sp.Rational(factorial(x - 1) ** 2, factorial(2 * x - 1))
coords = [sp.Integer(0)] * 3
for x in range(1, 66):
    e = sp.expand(-P2(x) * (pp[x] + 2 * (hnum(x - 1) - hnum(2 * x - 1)) * pv[x]))   # -q'(x)
    coords[0] += e.subs({ell: 0, lp_: 0}); coords[1] += e.coeff(ell); coords[2] += e.coeff(lp_)
toarb = lambda q: arb(int(sp.numer(q))) / arb(int(sp.denom(q)))
PT1 = toarb(coords[0]) + toarb(coords[1]) * lv + toarb(coords[2]) * lpv
say("   coordinates of P_{T_5}(1) = -sum_{x>=1} q'(x) on 1, l, l' (65 terms):", [trunc(toarb(c), 25) for c in coords])
say("   P_{T_5}(1) =", PT1.mid().str(45, radius=False))
# checks by the box procedure (the supplied reader), in a temporary folder
RR = '/home/claude/v2/receipts_src/rayreader/rayreader'
sys.path.insert(0, RR)
import rayreader as RRmod
tmp = tempfile.mkdtemp()
def read(name, bases, digits=50):
    jf = os.path.join(tmp, name + '.json')
    json.dump({'n': 5, 'bases': [list(T) for T in bases], 'name': name}, open(jf, 'w'))
    with contextlib.redirect_stdout(io.StringIO()):
        res = RRmod.read_ray(jf, '1 1 1 1 1 ; 1 1', digits=digits, workers=1, run=os.path.join(tmp, name))
    law = open(os.path.join(tmp, name, 'law.txt')).read().strip().splitlines()
    return res, law
for name, key in (('P5', 'P_5 (pairs other than {1,2})'), ('T5', 'T_5 (classes {1,2,3},{4},{5})'), ('R5', 'R_5 (classes {1,2},{3,4},{5})')):
    res, law = read(name, LISTS[key])
    say('   box reading of %s: P(1) = %s; law: %s' % (name, trunc(res['value'], 40), law[1:]))
    if name == 'P5':
        say('     minus l^2:', (res['value'] - ell_value() ** 2).mid().str(3, radius=False))
    if name == 'T5':
        say('     minus the closing:', (res['value'] - PT1).mid().str(3, radius=False))
say(f'total {time.time() - T0:.0f} s')
