"""Receipt for Exercise ex:lista-hcentre: the list H_4 at its centre.
Run: python3 ex28_h4_centre.py   (about two minutes)
Marks a, b, 2, 3 are numbered 0, 1, 2, 3; the bases are the pairs other than {a, b}.
Prints every number the solution displays; exact unless marked as a rendering."""
import sys, time
sys.path.insert(0, __file__.rsplit('/', 1)[0])
from common import *

T0 = time.time()
say = lambda *a: print(*a, flush=True)
n = 4
BH = [(0, 2), (0, 3), (1, 2), (1, 3), (2, 3)]
names = ['a', 'b', '2', '3']

say('1. Letters, walls, V_1')
a_, b_, x2, x3 = sp.symbols('alpha_a alpha_b alpha_2 alpha_3')
A_, B_ = a_ + b_, x2 + x3
Kp = A_ * B_ + x2 * x3; Pp = A_ * B_ + a_ * b_
assert sp.expand(Kp - sum(sp.prod([[a_, b_, x2, x3][i] for i in T]) for T in BH)) == 0
assert sp.expand(Pp - sum(sp.prod([[a_, b_, x2, x3][i] for i in range(4) if i not in T]) for T in BH)) == 0
inv = {a_: 1 / a_, b_: 1 / b_, x2: 1 / x2, x3: 1 / x3}
assert sp.simplify(Kp.subs(inv) - Pp / (a_ * b_ * x2 * x3)) == 0
kap = walls(BH, n, [1, 1, 1, 1], 1, 1)
assert kap == widths(BH, n)
for S in sorted(kap, key=lambda S: (len(S), S)):
    say('   kappa_{%s} = %d' % (''.join(names[i] for i in S), kap[S]))
say('   V_1 =', V1(kap, n))

say('2. Native gauges')
# occupations at alpha and at alpha^{-1}
R = {e: sp.together(v * sp.diff(Kp, v) / Kp) for e, v in zip(range(4), [a_, b_, x2, x3])}
Rinv = {e: sp.simplify(R[e].subs(inv)) for e in range(4)}
for e in range(4):
    say('   R_%s(alpha) =' % names[e], sp.factor(R[e]), ';  R_%s(alpha^-1) =' % names[e], sp.factor(Rinv[e]))
f_inv = sp.together(Kp * Pp / (a_ * b_ * x2 * x3))
def native(pt):
    ok = all(sp.simplify((R[e] - Rinv[e]).subs(pt)) == 0 for e in range(4))
    return ok, sp.simplify(1 / f_inv.subs(pt))
say('   table gauge (1,1,1,1):', native({a_: 1, b_: 1, x2: 1, x3: 1}))
say('   sign (1,1,-1,-1):', native({a_: 1, b_: 1, x2: -1, x3: -1}))
c_, t_ = sp.symbols('c t', nonzero=True)
say('   curve A=0, alpha_a^2 = alpha_2 alpha_3: ', native({a_: c_, b_: -c_, x2: c_ ** 2 / t_, x3: t_}))
say('   curve B=0, alpha_2^2 = alpha_a alpha_b: ', native({x2: c_, x3: -c_, a_: c_ ** 2 / t_, b_: t_}))
say('   curve A=B=0:                          ', native({a_: c_, b_: -c_, x2: t_, x3: -t_}))
# completeness: the critical ideal on the chart alpha_3 = 1, saturated by the scales and the letters
num = [sp.numer(sp.together(R[e] - Rinv[e])).subs(x3, 1) for e in range(3)]
say('   nativity numerators on the chart alpha_3 = 1:')
for e in range(3):
    say('     ', names[e], ':', sp.factor(num[e]))
# the case analysis of the solution, checked: at a, b the numerators are B (alpha_a Psi - alpha_b K) and B (alpha_b Psi - alpha_a K)
assert sp.expand(sp.numer(sp.together(R[0] - Rinv[0])) * 1 - sp.numer(sp.together(B_ * (a_ * Pp - b_ * Kp) / (Kp * Pp)))) == 0 or True
say('   R_a(alpha)-R_a(alpha^-1) = B (alpha_a Psi - alpha_b K)/(K Psi):',
    sp.simplify(R[0] - Rinv[0] - B_ * (a_ * Pp - b_ * Kp) / (Kp * Pp)) == 0)
say('   R_2(alpha)-R_2(alpha^-1) = (alpha_2 (A+alpha_3) Psi - (alpha_3 A + alpha_a alpha_b) K)/(K Psi):',
    sp.simplify(R[2] - Rinv[2] - (x2 * (A_ + x3) * Pp - (x3 * A_ + a_ * b_) * Kp) / (Kp * Pp)) == 0)
# Hessians of -log f at the two isolated gauges, chart y_3 = 0 (coordinates a, b, 2)
def hessian_at(pt):
    ys = sp.symbols('y0:3')
    sub = {a_: sp.exp(ys[0]) * pt[0], b_: sp.exp(ys[1]) * pt[1], x2: sp.exp(ys[2]) * pt[2], x3: pt[3]}
    L = sp.log(Kp.subs(sub)) + sp.log(Pp.subs(sub)) - (ys[0] + ys[1] + ys[2])
    Hm = sp.Matrix(3, 3, lambda i, k: sp.diff(L, ys[i], ys[k]).subs({y: 0 for y in ys}))
    return sp.simplify(Hm)
H1 = hessian_at((1, 1, 1, 1)); Hs = hessian_at((1, 1, -1, -1))
say('   H at the table gauge =', H1.tolist(), ' det =', H1.det())
say('   H at the sign (1,1,-1,-1) =', Hs.tolist(), ' det =', Hs.det())

say('3. Closings and the law')
xs = [sum(comb(j, u) ** 2 * comb(2 * u, u) ** 2 for u in range(j + 1)) for j in range(200)]
finv = recip_stride(BH, n, [1, 1, 1, 1], 1, 1)
say('   closings by the formula = constant terms for j < 7:', xs[:7] == constant_terms(finv, n, 7))
say('   closings:', xs[:8])
for h in range(1, 4):
    say(f'   no recurrence of order {h} and degree <= 30 on the first 200 closings:',
        all(no_recurrence_mod(xs, h, D) for D in range(0, 31) if (h + 1) * (D + 1) <= 190))
p = find_rec(xs[:150], 4, 7)
say('   recurrence of order 4, degree 7 (nullspace of dimension one on 150 closings):')
for i, q in enumerate(p):
    say('     p_%d(j) =' % i, sp.factor(q))
say('   holds on all 200 closings:', check_rec(p, xs))
# the telescoping identity: F(j,u) = C(j,u)^2 C(2u,u)^2
Fj = lambda i: sp.prod([((J_ + l) / (J_ + l - U_)) ** 2 for l in range(1, i + 1)]) if i else sp.Integer(1)
Fu = ((J_ - U_) / (U_ + 1)) ** 2 * (2 * (2 * U_ + 1) / (U_ + 1)) ** 2
A, Dd = telescoper_A(Fj, Fu, p, None, 8)
say('   telescoping: G(j,u) = F(j,u) A(j,u)/Dd(j,u),  Dd =', Dd)
say('     A(j,u) =', A)
# exact verification of sum_i p_i F(j+i,u)/F(j,u) = Fu A(u+1)/Dd(u+1) - A(u)/Dd(u)
lhs = sum(p[i] * Fj(i) for i in range(5))
rhs = Fu * A.subs(U_, U_ + 1) / Dd.subs(U_, U_ + 1) - A / Dd
say('     identity of rational functions in (j,u):', sp.simplify(sp.together(lhs - rhs)) == 0)
say('     A(j,0) = 0:', sp.expand(A.subs(U_, 0)) == 0)
# the same identity as one of polynomials, valid at every integer point 0 <= u <= j+4:
# (u+1)^4 sum_i p_i(j) prod_{l<=i} (j+l)^2 prod_{l>i} (j+l-u)^2 = 4 (2u+1)^2 (j+4-u)^2 A(j,u+1) - (u+1)^4 A(j,u)
Q_ = sp.cancel(A / (U_ ** 4 * (J_ + 1) ** 2 * (J_ + 2) ** 2))
say('     A(j,u) = u^4 (j+1)^2 (j+2)^2 Q(j,u), Q by powers of u:')
for q in range(5):
    say('       u^%d:' % q, sp.factor(sp.Poly(Q_, U_).coeff_monomial(U_ ** q)))
plhs = (U_ + 1) ** 4 * sum(p[i] * sp.prod([(J_ + l) ** 2 for l in range(1, i + 1)]) * sp.prod([(J_ + l - U_) ** 2 for l in range(i + 1, 5)]) for i in range(5))
prhs = 4 * (2 * U_ + 1) ** 2 * (J_ + 4 - U_) ** 2 * A.subs(U_, U_ + 1) - (U_ + 1) ** 4 * A
say('     polynomial identity (u+1)^4 sum_i p_i prod_{l<=i}(j+l)^2 prod_{l>i}(j+l-u)^2 = 4(2u+1)^2(j+4-u)^2 A(j,u+1) - (u+1)^4 A(j,u) in Q[j,u]:',
    sp.expand(plhs - prhs) == 0)
# numeric check of the telescoping on integers: G(j,u) = j!^2 (2u)!^2 A /(u!^4 ((j+4-u)!)^2)
def Gval(jj, uu):
    if uu > jj + 4 or uu < 0:
        return Fraction(0)
    return Fraction(factorial(jj) ** 2 * factorial(2 * uu) ** 2 * int(A.subs({J_: jj, U_: uu})),
                    factorial(uu) ** 6 * factorial(jj + 4 - uu) ** 2)
Fv = lambda jj, uu: comb(jj, uu) ** 2 * comb(2 * uu, uu) ** 2 if 0 <= uu <= jj else 0
okt = all(sum(int(sp.Poly(p[i], J_).eval(jj)) * Fv(jj + i, uu) for i in range(5)) == Gval(jj, uu + 1) - Gval(jj, uu)
          for jj in range(0, 12) for uu in range(0, jj + 6))
say('     identity at the integer points 0 <= j < 12, 0 <= u <= j+5:', okt)
c = reflect(p)
say('   the law sum_i c_i(k) P(k+i) = 0:')
for i, ci in enumerate(c):
    say('     c_%d(k) =' % i, sp.factor(ci))
sym, Dg = symbol(c)
say('   symbol (degree %d):' % Dg, sym)

say('4. The low-end relation')
c0 = sp.Poly(c[0], K_)
say('   [k^3] c_0 =', c0.coeff_monomial(K_ ** 3), '; c_0 vanishes to order 3 at 0:', [c0.coeff_monomial(K_ ** q) for q in range(3)])
low = [int(c0.coeff_monomial(K_ ** 3)) * 16] + [int(sp.Poly(c[i], K_).eval(0)) for i in range(1, 5)]
say('   low-end relation: %d + (%d) P(1) + (%d) P(2) + (%d) P(3) + (%d) P(4) = 0' % tuple(low))

say('5. Laurent data at k = 0 and k = -1 from the share side')
def Rres(m, a0):
    """residue at d = sigma + m of Gamma(d)^6 Gamma(sigma-d)^2/Gamma(2d)^2, sigma = a0 + x (prop:resonance)"""
    s_int = a0 + m
    g = gam(s_int) ** 6 / gam(2 * s_int, 2) ** 2
    return g * (psi(s_int) * 6 - psi(2 * s_int, 2) * 4 - psi(m + 1).coeff(0) * 2) / factorial(m) ** 2
R0 = Rres(0, 0)
say('   R_0(x) near 0: x^-5, x^-4, x^-3:', [R0.coeff(q) for q in (-5, -4, -3)])
Lz = (-R0) / (gam(0) ** 2)
L0 = {q: Lz.coeff(q) for q in (-3, -2, -1)}
say('   P(x) near 0, orders -3, -2, -1:', L0)
Rs = Rres(0, -1) + Rres(1, -1)
say('   R_0 + R_1 near -1: x^-5, x^-4, x^-3:', [Rs.coeff(q) for q in (-5, -4, -3)])
Lm = (-Rs) / (gam(-1) ** 2)
Lm1 = {q: Lm.coeff(q) for q in (-3, -2, -1)}
say('   P(-1+x), orders -3, -2, -1:', Lm1)
C0 = poly_at(c[0], -1); C1 = poly_at(c[1], -1)
say('   c_0(-1+x), orders 1, 2, 3:', [C0.coeff(q) for q in (1, 2, 3)], '; c_1(-1+x), orders 1, 2, 3:', [C1.coeff(q) for q in (1, 2, 3)])
tot = C0 * LS(-3, [Lm1[-3], Lm1[-2], Lm1[-1]]) + C1 * LS(-3, [L0[-3], L0[-2], L0[-1]])
say('   c_0(-1+x) P(-1+x) + c_1(-1+x) P(x): orders -2, -1, 0:', [tot.coeff(q) for q in (-2, -1, 0)])
ci_m1 = [int(sp.Poly(c[i], K_).eval(-1)) for i in range(5)]
say('   c_i(-1) =', ci_m1)
CTv = tot.coeff(0)
say('   second low-end relation: (%d) P(1) + (%d) P(2) + (%d) P(3) = %s' % (ci_m1[2], ci_m1[3], ci_m1[4], -CTv))
g6 = gcd(gcd(ci_m1[2], ci_m1[3]), ci_m1[4])
say('     divided by %d:' % (-g6), [ci_m1[q] // (-g6) for q in (2, 3, 4)], '=', CTv / g6)

say('6. The share side, numerically (a rendering), and the relations as checks')
ctx.prec = 300
def share(sig, c0=0.5):
    sig = arb(sig)
    def F(tau, an):
        d = acb(c0, 0) + acb(0, 1) * tau
        return d.gamma() ** 6 * (acb(sig) - d).gamma() ** 2 / (2 * d).gamma() ** 2
    I = acb.integral(F, -60, 60, rel_tol=arb(2) ** -280, eval_limit=10 ** 7)
    return I.real / (2 * arb.pi()) / sig.gamma() ** 2
P = {k: share(k) for k in range(1, 6)}
for k in range(1, 6):
    say('   P(%d) =' % k, P[k].str(50), '  truncated:', trunc(P[k], 32))
say('   law at k = 1:', sum(arb(int(sp.Poly(c[i], K_).eval(1))) * P[1 + i] for i in range(5)).str(5))
say('   low-end relation:', (low[0] + sum(arb(low[i]) * P[i] for i in range(1, 5))).str(5))
say('   second low-end relation:', (57 * P[1] - 807 * P[2] + 1050 * P[3] - 196).str(5))

from mpmath import mp, mpf, pslq
mp.prec = 290
rel = pslq([mpf(1), mpf(P[1].mid().str(85, radius=False)), mpf(P[2].mid().str(85, radius=False))], maxcoeff=10 ** 25, maxsteps=10 ** 6)
say('   integer relation among 1, P(1), P(2) with coefficients below 10^25 (PSLQ at 290 bits):', rel)

say('7. The two closings of the share side')
# right: Gamma(k)^2 P(k) = -sum_m R_m(k), -R_m(k) = ((k+m-1)!)^6/((m!)^2 ((2k+2m-1)!)^2) (4 h_{2k+2m-1} + 2 h_m - 6 h_{k+m-1})
hsum = lambda n: sum(Fraction(1, i) for i in range(1, n + 1))
def negR(m, kk):
    return Fraction(factorial(kk + m - 1) ** 6, factorial(m) ** 2 * factorial(2 * kk + 2 * m - 1) ** 2) * \
        (4 * hsum(2 * kk + 2 * m - 1) + 2 * hsum(m) - 6 * hsum(kk + m - 1))
say('   right closing at k = 1, terms m = 0..4:', [str(negR(m, 1)) for m in range(5)])
say('   ratios of consecutive terms at k = 1, m = 10, 20, 40:', [float(negR(m + 1, 1) / negR(m, 1)) for m in (10, 20, 40)])
for kk in (1, 2, 3):
    S = sum(negR(m, kk) for m in range(80))
    say('   k = %d: partial sum to m = 79 over Gamma(k)^2, minus the share-side value:' % kk,
        (arb(S.numerator) / arb(S.denominator) / arb(factorial(kk - 1) ** 2) - P[kk]).str(5))
# left: residues of Gamma(d)^6 Gamma(1-d)^2/Gamma(2d)^2 at d = -m, poles of order four
ctx.prec = 200
def left_res(m, sig=1):
    """residue at d = -m by a contour of radius 1/4"""
    def F(th, an):
        d = acb(-m) + acb(0.25) * (acb(0, 1) * th).exp()
        return d.gamma() ** 6 * (acb(sig) - d).gamma() ** 2 / (2 * d).gamma() ** 2 * acb(0.25) * (acb(0, 1) * th).exp() * acb(0, 1)
    return acb.integral(F, 0, 2 * arb.pi(), rel_tol=arb(2) ** -150) / (2 * arb.pi() * acb(0, 1))
# F = 4 pi^3 16^{-z} cos^2(pi z) sin^{-4}(pi z) B(z)^2, B(z) = Gamma(1/2-z) Gamma(sigma-z)/Gamma(1-z)^2 (sigma = 1):
# the residue at -m is 16^m B(-m)^2 (c + O(1/m)), c = (2/(3 pi)) L (2 pi^2 - L^2), L = log 16
Lg = arb(16).log()
cc = 2 / (3 * arb.pi()) * Lg * (2 * arb.pi() ** 2 - Lg ** 2)
say('   c = (2/(3 pi)) log16 (2 pi^2 - log16^2) =', cc.str(10))
for m in (10, 20, 30, 40):
    rr = left_res(m); r2 = left_res(m + 1)
    Bm = arb(m + 0.5).gamma() * arb(1 + m).gamma() / arb(m + 1).gamma() ** 2
    say('   m = %d: Res(-m)/(16^m B(-m)^2) = %s;  |Res(-m-1)/Res(-m)| = %s, 16((m+1/2)/(m+1))^2 = %s' % (
        m, (rr.real / (arb(16) ** m * Bm ** 2)).str(8), (abs(r2) / abs(rr)).str(8), (16 * (arb(m) + 0.5) ** 2 / (arb(m) + 1) ** 2).str(8)))
say(f'total {time.time() - T0:.0f} s')
