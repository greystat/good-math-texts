"""Receipt for Exercise ex:lista-hslit: the list H_4 on the ray (1,1,3,3;3,1).
Run: python3 ex29_h4_lean.py   (a few minutes)
Marks a, b, 2, 3 are numbered 0, 1, 2, 3; the bases are the pairs other than {a, b}; the direction has the
masses (1,1,3,3), the exponent 3 on K and 1 on Psi, and the origin is 0.
Prints every number the solution displays; exact unless marked as a rendering (ball arithmetic)."""
import sys, time, pickle
sys.path.insert(0, __file__.rsplit('/', 1)[0])
from common import *
from flint import fmpq_mpoly_ctx

T0 = time.time()
say = lambda *a: print(*a, flush=True)
n = 4
BH = [(0, 2), (0, 3), (1, 2), (1, 3), (2, 3)]
names = ['a', 'b', '2', '3']
M1, S1, T1 = [1, 1, 3, 3], 3, 1

say('1. Walls and V_1')
kap = walls(BH, n, M1, S1, T1)
for S in sorted(kap, key=lambda S: (len(S), S)):
    say('   kappa_{%s} = %d' % (''.join(names[i] for i in S), kap[S]))
say('   all positive:', all(v > 0 for v in kap.values()), '  V_1 =', V1(kap, n))

say('2. The native gauge of the direction and its conjugate')
a_, b_, x2, x3, xx = sp.symbols('alpha_a alpha_b alpha_2 alpha_3 x')
Kp = (a_ + b_) * (x2 + x3) + x2 * x3; Pp = (a_ + b_) * (x2 + x3) + a_ * b_
f = a_ * b_ * x2 ** 3 * x3 ** 3 / (Kp ** 3 * Pp)
fs_slice = sp.factor(f.subs({a_: xx, b_: xx, x2: 1, x3: 1}))
say('   f(x,x,1,1) =', fs_slice)
dlog = sp.factor(sp.together(sp.diff(sp.log(fs_slice), xx)))
say('   d/dx log f(x,x,1,1) =', dlog)
r19 = sp.sqrt(19)
roots = [(-4 + r19) / 3, (-4 - r19) / 3]
for x0 in roots:
    pt = {a_: x0, b_: x0, x2: 1, x3: 1}
    grad = [sp.simplify(sp.radsimp((v * sp.diff(sp.log(f), v)).subs(pt))) for v in (a_, b_, x2, x3)]
    val = sp.radsimp(sp.simplify(f.subs(pt)))
    Kv, Pv = sp.radsimp(Kp.subs(pt)), sp.radsimp(Pp.subs(pt))
    ys = sp.symbols('y0:3')
    sub = {a_: sp.exp(ys[0]) * x0, b_: sp.exp(ys[1]) * x0, x2: sp.exp(ys[2]), x3: 1}
    L = 3 * sp.log(Kp.subs(sub)) + sp.log(Pp.subs(sub)) - (ys[0] + ys[1] + 3 * ys[2])
    Hm = sp.Matrix(3, 3, lambda i, k: sp.diff(L, ys[i], ys[k]).subs({y: 0 for y in ys}))
    dH = sp.radsimp(sp.simplify(Hm.det()))
    say('   x0 =', x0, ': gradient of log f', grad, '; K =', Kv, ', Psi =', Pv)
    say('      f =', val, '=', sp.nsimplify(val), ' ~', sp.N(val, 20), ';  det H =', dH, '~', sp.N(dH, 18))
say('   minimal polynomial of f*:', sp.factor(sp.minimal_polynomial(sp.radsimp((roots[0]) / ((4 * roots[0] + 1) ** 3 * (roots[0] + 4))), sp.Symbol('lambda'))))

say('3. Closings, the law and its proof')
xs = [sum(comb(3 * j, u) * comb(j, u) * comb(2 * u, u) ** 2 for u in range(j + 1)) for j in range(300)]
finv = recip_stride(BH, n, M1, S1, T1)
say('   closings = constant terms of the powers of f^-1 for j < 6:', xs[:6] == constant_terms(finv, n, 6))
say('   closings:', xs[:6])
for h in range(1, 4):
    Dmax = (280 // (h + 1)) - 2
    say(f'   no recurrence of order {h} and degree <= {Dmax} on the first 300 closings:',
        all(no_recurrence_mod(xs, h, D) for D in range(0, Dmax + 1)))
say('   no recurrence of order 4 and degree <= 24:', all(no_recurrence_mod(xs, 4, D) for D in range(0, 25)))
p = find_rec(xs[:170], 4, 25)
say('   recurrence of order 4 and degree 25 (one-dimensional nullspace on 170 closings), holds on all 300:', check_rec(p, xs))
say('   largest coefficient:', max(len(str(abs(int(cf)))) for q in p for cf in sp.Poly(q, J_).coeffs()), 'digits')
# the telescoping identity: F(j,u) = C(3j,u) C(j,u) C(2u,u)^2,
# 4(2u+1)^2 (3j+12-u)(j+4-u) A(j,u+1) - (u+1)^4 A(j,u) = (u+1)^4 N(j,u)
P_ = [sp.Poly(q, J_) for q in p]
def N_at(jv):
    tot = fmpq_poly([])
    for i in range(5):
        cc = int(P_[i].eval(jv))
        for l in range(1, 3 * i + 1): cc *= (3 * jv + l)
        for l in range(1, i + 1): cc *= (jv + l)
        poly = fmpq_poly([cc])
        for l in range(3 * i + 1, 13): poly *= fmpq_poly([3 * jv + l, -1])
        for l in range(i + 1, 5): poly *= fmpq_poly([jv + l, -1])
        tot += poly
    return tot
degA = 16; U1 = fmpq_poly([1, 1])
def solve_at(jv):
    fac = fmpq_poly([1, 2]) ** 2 * 4 * fmpq_poly([3 * jv + 12, -1]) * fmpq_poly([jv + 4, -1])
    cols = [fac * U1 ** q - U1 ** 4 * fmpq_poly([0] * q + [1]) for q in range(degA + 1)]
    rhs = U1 ** 4 * N_at(jv)
    deg = max([cc.degree() for cc in cols] + [rhs.degree()])
    M = fmpq_mat(deg + 1, degA + 1, [cols[q][r] for r in range(deg + 1) for q in range(degA + 1)])
    bb = fmpq_mat(deg + 1, 1, [rhs[r] for r in range(deg + 1)])
    Mt = M.transpose(); xsol = (Mt * M).solve(Mt * bb)
    assert M * xsol == bb
    return [xsol[q, 0] for q in range(degA + 1)]
jpts = list(range(40, 40 + 41))
sols = {jv: solve_at(jv) for jv in jpts}
def interp(xsj, ys):
    res = fmpq_poly([])
    for i in range(len(xsj)):
        num = fmpq_poly([1]); den = fmpq(1)
        for k2 in range(len(xsj)):
            if k2 != i:
                num *= fmpq_poly([-xsj[k2], 1]); den *= (xsj[i] - xsj[k2])
        res += num * (ys[i] / den)
    return res
Acoef = [interp(jpts, [sols[jv][q] for jv in jpts]) for q in range(degA + 1)]
say('   A(j,u): degree in u', max(q for q in range(degA + 1) if Acoef[q] != 0), '; lowest power of u',
    min(q for q in range(degA + 1) if Acoef[q] != 0), '; degrees in j of the coefficients:', [Acoef[q].degree() for q in range(degA + 1)])
# exact verification in Q[j,u]
R2 = fmpq_mpoly_ctx.get(('j', 'u'), 'lex')
jj, uu = R2.gens()
def to_mp(poly1, var):
    out = R2.from_dict({}) if hasattr(R2, 'from_dict') else 0 * jj
    for i in range(poly1.degree() + 1):
        out += poly1[i] * var ** i
    return out
Amp = 0 * jj
for q in range(degA + 1):
    Amp += to_mp(Acoef[q], jj) * uu ** q
def subs_u(poly, shift):
    return poly.compose(jj, uu + shift)
Nmp = 0 * jj
for i in range(5):
    term = 0 * jj
    for (e,), cf in sp.Poly(p[i], J_).terms():
        term += int(cf) * jj ** e
    for l in range(1, 3 * i + 1): term *= (3 * jj + l)
    for l in range(1, i + 1): term *= (jj + l)
    for l in range(3 * i + 1, 13): term *= (3 * jj + l - uu)
    for l in range(i + 1, 5): term *= (jj + l - uu)
    Nmp += term
lhs = 4 * (2 * uu + 1) ** 2 * (3 * jj + 12 - uu) * (jj + 4 - uu) * subs_u(Amp, 1) - (uu + 1) ** 4 * Amp
say('   the identity 4(2u+1)^2(3j+12-u)(j+4-u)A(j,u+1) - (u+1)^4 A(j,u) = (u+1)^4 N(j,u) holds in Q[j,u]:', lhs == (uu + 1) ** 4 * Nmp)
say('   number of terms of A:', len(list(Amp.terms())))
open(__file__.rsplit('/', 1)[0] + '/ex29_telescoper_A.txt', 'w').write('A(j,u) =\n' + str(Amp) + '\n')
c = reflect(p)
eps = sp.simplify(c[0] / p[4].subs(J_, -K_ - 4))
say('   c_i(k) = eps p_{4-i}(-k-4) with eps =', eps)
for i in range(5):
    fl = sp.factor_list(c[i])
    say('   c_%d(k) = %s x' % (i, fl[0]), ' x '.join('(%s)^%d' % (fac, mm) if sp.Poly(fac, K_).degree() <= 1 else '(degree %d)' % sp.Poly(fac, K_).degree() for fac, mm in fl[1]))
sym, Dg = symbol(c)
say('   symbol (degree %d):' % Dg, sym)
c0 = sp.Poly(c[0], K_)
say('   c_0 vanishes to order 3 at 0:', [c0.coeff_monomial(K_ ** q) for q in range(3)], '; [k^3] c_0 =', c0.coeff_monomial(K_ ** 3))
cz = [int(sp.Poly(c[i], K_).eval(0)) for i in range(5)]
say('   c_i(0) =', cz)
v1 = Fraction(160, 27)
low = [Fraction(int(c0.coeff_monomial(K_ ** 3))) * v1] + cz[1:]
g = 0
for x_ in [low[0].numerator] + cz[1:]: g = gcd(g, int(x_))
say('   low-end relation: %s + %d P(1) + %d P(2) + %d P(3) + %d P(4) = 0' % tuple([low[0]] + cz[1:]))
open(__file__.rsplit('/', 1)[0] + '/ex29_law.txt', 'w').write(''.join('c_%d(k) = %s\n' % (i, sp.expand(ci)) for i, ci in enumerate(c)))

say('   c_0(k) has no zero at the integers 1 <= k <= 200:', all(sp.Poly(c[0], K_).eval(kk) != 0 for kk in range(1, 201)))
say('   c_4(k) > 0 at the integers 1 <= k <= 200:', all(sp.Poly(c[4], K_).eval(kk) > 0 for kk in range(1, 201)), '; real roots of c_4:', [str(sp.N(r, 6)) for r in sp.Poly(c[4], K_).real_roots()][:20])
say('4. The gauge end (renderings in ball arithmetic)')
ctx.prec = 2600
cp = law_coeff_lists(c)
D, aops = density_operator(cp)
s19 = arb(19).sqrt(); x0a = (s19 - 4) / 3
fstar = (7643 + 1064 * s19) / 1366875; fconj = (7643 - 1064 * s19) / 1366875
b = shifted_ops(aops, fstar)
say('   order of the density operator D =', D)
say('   b_{D,0} ~', b[D][0].mid().str(5), ' (zero: f* is a root of the symbol)')
mu = indicial_extra(b, D)
say('   gamma = D-1-b_{D-1,0}/b_{D,1} =', mu.mid().str(30), ' (Theorem thm:gaugeend(iii) asks (n-3)/2 = 1/2)')
detH = (376096 * s19 - 1614848) / 151875
g0 = (2 * arb.pi() / fstar) ** (arb(3) / 2) / ((arb(3) / 2).gamma() * detH.sqrt())
say('   g(0) =', g0.str(25))
e = germ_series_halfint(b, D, fmpq(1, 2), 1800)
ea = [g0 * x for x in e]
for m in (50, 400, 1600):
    say('   m = %d: e_m f*^m = %s,  e_m (f*-f*\')^m = %s' % (m, (ea[m] * fstar ** m).str(5), (ea[m] * (fstar - fconj) ** m).str(5)))
vals = {}
for K0 in (80, 120):
    vv = {kk: beta_sums(ea, fmpq(1, 2), fstar, kk) for kk in range(K0, K0 + 4)}
    xv = run_back(c, vv, K0)
    vals[K0] = xv
    say('   from K = %d: P(1) = %s' % (K0, xv[1].mid().str(60, radius=False)))
    say('                P(2) = %s' % xv[2].mid().str(60, radius=False))
say('   difference of the two readings of P(1):', (vals[80][1] - vals[120][1]).mid().str(3, radius=False))
P = vals[120]
V1read = -sum(arb(cz[i]) * P[i] for i in range(1, 5)) / arb(int(c0.coeff_monomial(K_ ** 3)))
say('   V_1 from the low-end relation at these values:', V1read.mid().str(40, radius=False), '; minus 160/27:', (V1read - arb(160) / 27).mid().str(3, radius=False))
say('   g_m f*^m for m <= 1800 at most:', max(abs(ea[m] * fstar ** m) for m in range(1801)).mid().str(4, radius=False))

say('5. The second low-end relation, exactly, from the share side')
def Rk(m, k0):   # residue at v = k+m, k = k0 + x
    return gam(k0 + m) ** 6 * gam(2 * k0 - m, 2) / gam(2 * k0 + 2 * m, 2) ** 2 * ((-1) ** (m + 1) * sp.Rational(1, factorial(m)))
def R3k(m, k0):  # residue at v = 3k+m
    return gam(3 * k0 + m, 3) ** 6 * gam(-2 * k0 - m, -2) / gam(6 * k0 + 2 * m, 6) ** 2 * ((-1) ** (m + 1) * sp.Rational(1, factorial(m)))
pref0 = (gam(0, 3) * gam(0, 1)).inv()
Pz = (-(Rk(0, 0) + R3k(0, 0))) * pref0
L0 = {q: Pz.coeff(q) for q in (-3, -2, -1)}
say('   P(x) near 0:', L0)
prefm = (gam(-3, 3) * gam(-1, 1)).inv()
Pm = (-(Rk(0, -1) + Rk(1, -1) + R3k(0, -1) + R3k(1, -1) + R3k(2, -1) + R3k(3, -1))) * prefm
Lm1 = {q: Pm.coeff(q) for q in (-3, -2, -1)}
say('   P(-1+x):', Lm1)
say('   top coefficients against V_1 C_j(1): at 0', L0[-3], '=', v1 * xs[0], '; at -1', Lm1[-3], '=', v1 * xs[1])
C0 = poly_at(c[0], -1); C1 = poly_at(c[1], -1)
tot = C0 * LS(-3, [Lm1[-3], Lm1[-2], Lm1[-1]]) + C1 * LS(-3, [L0[-3], L0[-2], L0[-1]])
say('   orders -2, -1, 0:', [tot.coeff(q) for q in (-2, -1, 0)])
cm = [int(sp.Poly(c[i], K_).eval(-1)) for i in range(5)]
CTv = tot.coeff(0)
g3 = gcd(gcd(cm[2], cm[3]), cm[4])
say('   c_i(-1) for i = 2, 3, 4:', cm[2:], '; gcd', g3)
say('   second low-end relation: %d P(1) + %d P(2) + %d P(3) = %s' % (cm[2] // g3, cm[3] // g3, cm[4] // g3, -CTv / g3))
say('   at the gauge-end values:', (sum(arb(cm[i] // g3) * P[i - 1] for i in (2, 3, 4)) + arb(int(CTv)) / g3).mid().str(3, radius=False))

say('6. The share side, numerically (a check)')
ctx.prec = 240
def share(k):
    def F(tau, an):
        v = acb(0.5, 0) + acb(0, 1) * tau
        return v.gamma() ** 6 * (acb(3 * k) - v).gamma() * (acb(k) - v).gamma() / (2 * v).gamma() ** 2
    I = acb.integral(F, -40, 40, rel_tol=arb(2) ** -220)
    return I.real / (2 * arb.pi()) / (arb(3 * k).gamma() * arb(k).gamma())
say('   P(1) =', share(1).str(60))

say('7. Positive selection at the slit')
ctx.prec = 2000
# rational solutions: P(1), P(2), P(3) free, P(4) from the low-end relation, then the law forward
def forward(init, K):
    xv = dict(init)
    for kk in range(1, K):
        xv[kk + 4] = -sum(arb(int(sp.Poly(c[i], K_).eval(kk))) * xv[kk + i] for i in range(4)) / arb(int(sp.Poly(c[4], K_).eval(kk)))
    return xv
def sol(v):   # v = (P1, P2, P3) as arb, P4 from the low-end relation
    P4 = -(arb(low[0].numerator) / low[0].denominator + sum(arb(cz[i]) * v[i - 1] for i in (1, 2, 3))) / arb(cz[4])
    return {1: v[0], 2: v[1], 3: v[2], 4: P4}
for K in (40, 80):
    base = forward(sol([arb(0)] * 3), K + 4)
    basis = [forward(sol([arb(1) if q == r else arb(0) for q in range(3)]), K + 4) for r in range(3)]
    # homogeneous parts
    Mm = arb_mat([[basis[r][K + l] - base[K + l] for r in range(3)] for l in range(3)])
    rhs = arb_mat([[-base[K + l]] for l in range(3)])
    s_ = Mm.solve(rhs)
    say('   K = %d: selected P(1) = %s' % (K, s_[0, 0].mid().str(5, radius=False)))
say(f'total {time.time() - T0:.0f} s')
