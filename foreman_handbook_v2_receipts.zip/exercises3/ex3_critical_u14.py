"""Receipt for Exercise ex:mot-critical: binom([4],1) at its full leans and at its centre.

Run: cd scripts; python3 ex3_critical_u14.py
"""
from itertools import combinations
from fractions import Fraction
import sympy as sp
import mpmath as mp
from listkit import List, uniform

L = uniform(4, 1)
al = {e: sp.Symbol('a%d' % e, positive=True) for e in L.E}
a1, a2, a3, a4 = (al[i] for i in L.E)
K, Psi = L.K(al), L.Psi(al)
print('K =', K, '  Psi =', Psi)
for k in (1, 2, 3):
    print('|S| =', k, ' d', {L.d(S) for S in combinations(L.E, k)}, ' d*', {L.dstar(S) for S in combinations(L.E, k)},
          ' width', {L.width(S) for S in combinations(L.E, k)})

# full lean (s,0): walls m_S - s d(S) = m_S; period = Gamma[m; m_E] (thm:dirichlet); sample values
for m in ((1, 1, 1, 1), (2, 1, 1, 1), (1, 2, 3, 1)):
    s = sum(m)
    val = sp.prod([sp.gamma(x) for x in m]) / sp.gamma(s)
    print('full lean (s,0), s =', s, ' masses', m, ' period', val)
# Cremona masses for (0,t): balance m_E = 3t, and t*1 - m has total t
t = sp.Symbol('t', positive=True)
print('Cremona: total of t*1-m on the balance wall of (0,t):', sp.simplify(4 * t - 3 * t))
# the split at {3,4}: both cells on three marks
S, Sp = frozenset({3, 4}), frozenset({1, 2})
cellB = sorted(L.restriction(S).B, key=sorted) + [X | {'g'} for X in L.contraction(Sp).B]
cellR = sorted(L.restriction(Sp).B, key=sorted) + [X | {'g'} for X in L.contraction(S).B]
print('cell of the bunch {3,4}:', [sorted(map(str, T)) for T in cellB], '  cell of the room:', [sorted(map(str, T)) for T in cellR])

# the centre: walls, the set S = {3,4}
print('walls at the centre:', {k: {k - L.d(X) - L.dstar(X) for X in combinations(L.E, k)} for k in (1, 2, 3)})
res, con = L.restriction(S), L.contraction(Sp)
print('B|S:', [sorted(T) for T in res.B], ' B/S\':', [sorted(T) for T in con.B])
gK = sp.simplify(res.K(al) / con.K(al)); gP = sp.simplify(con.Psi(al) / res.Psi(al))
print('gamma^K_S =', gK, '  gamma^Psi_S =', gP, '  varrho_S =', sp.simplify(gP / gK))
print('E_{B|S} =', sp.factor(res.K(al) * res.Psi(al)), '  E_{B/S\'} =', con.K(al) * con.Psi(al))
# the law (def:seamlaw): kappa_S, top wall, scale, scale form, seam vector
kS = 2 - L.d(S) - L.dstar(S); ktop = 2 * 1 - kS
print('kappa_S =', kS, '  top wall =', ktop)
V0, V1 = con.K(al), res.K(al)          # K-seam letters at the excesses 0 and 1
W0, W1 = con.Psi(al), res.Psi(al)      # Psi-seam letters at the excesses 0 and 1
scale = sp.sqrt(sp.simplify((V1 / V0) * (W0 / W1)))
print('scale gamma^rho =', sp.simplify(scale))
u = sp.Symbol('u', positive=True)
on = {a3: u, a4: 1 - u}
form = sp.simplify((V0 ** -1 * W1 ** -1 * scale ** -kS).subs(on))
seam = [sp.simplify(x.subs(on)) for x in (V0 / V0, V1 / (V0 * scale), W0 / (W1 * scale), W1 / W1)]
print('scale form density on (u,1-u):', form, '  seam vector:', seam)
x = sp.Symbol('x', positive=True)
dens = 4 / (x * sp.sqrt(x ** 2 - 4))
print('law: density', dens, 'on x>2, total mass', sp.simplify(sp.integrate(dens, (x, 2, sp.oo))),
      ' = int (u(1-u))^(-1/2) du =', sp.integrate((u * (1 - u)) ** sp.Rational(-1, 2), (u, 0, 1)))
# the density from the change of variables x = (u(1-u))^(-1/2), two branches
ub = (1 - sp.sqrt(1 - 4 / x ** 2)) / 2
assert sp.simplify((ub * (1 - ub)) - x ** -2) == 0
d_branch = -x * sp.diff(ub, x)          # du/dx < 0 on this branch; the other branch is u -> 1-u
for xv in (sp.Rational(5, 2), 3, 7, sp.Rational(101, 10)):
    assert sp.simplify((2 * d_branch - dens).subs(x, xv)) == 0
# node form at the root bunch S: alpha_S = rho (u,1-u), alpha_{S'} = (w, 1-w)
rho, w = sp.symbols('rho w', positive=True)
sub = {a3: rho * u, a4: rho * (1 - u), a1: w, a2: 1 - w}
Kr, Pr = sp.factor(K.subs(sub)), sp.factor(Psi.subs(sub))
rS, rSp = u * (1 - u), w * (1 - w)
assert sp.simplify(Kr - (rho + 1)) == 0 and sp.simplify(Pr - rho * (rS * rho + rSp)) == 0
print('K(rho u,w) = rho+1,  Psi(rho u,w) = rho*(varrho_S rho + varrho_S\')')
# the stacked Gamma identity behind the critical-line word
a = sp.Symbol('a')
G = sp.pi ** 2 / sp.sin(sp.pi * a) ** 2
prod = sp.gamma(a) ** 2 / sp.gamma(2 * a) * sp.gamma(1 - a) ** 2 / sp.gamma(2 - 2 * a)
target = 2 * sp.pi * sp.cot(sp.pi * a) / (1 - 2 * a)
mp.mp.dps = 40
for pt in (sp.Rational(1, 3), sp.Rational(2, 7), sp.Rational(1, 2) + sp.I / 3, sp.Rational(3, 5) - 2 * sp.I):
    assert abs(sp.N((prod - target).subs(a, pt), 35)) < 1e-30
assert sp.simplify(sp.diff(G, a) + 2 * sp.pi * sp.cot(sp.pi * a) * G) == 0
print('Gamma[a,a;2a] Gamma[1-a,1-a;2-2a] = 2 pi cot(pi a)/(1-2a) (four points, 35 digits); G\' = -2 pi cot(pi a) G (exact)')
# residues of -G'(a)/(1-2a) at a = m and of the integrated form G(a) * 2/(1-2a)^2
eps = sp.Symbol('eps')
for m in range(1, 7):
    ser = sp.series((-sp.diff(G, a) / (1 - 2 * a)).subs(a, m + eps), eps, 0, 1).removeO()
    r = sp.nsimplify(sp.simplify(ser.coeff(eps, -1)))
    assert r == sp.Rational(8, (1 - 2 * m) ** 3), (m, r)
g = 2 / (1 - 2 * a) ** 2
print("g'(a) =", sp.factor(sp.diff(g, a)), ';  residues 8(1-2m)^-3 at m = 1..6 (exact)')
# lattice relation at the step 2 on exact heads: sum_{m<=N}(m-1/2)^-3 + sum_{m<=N} m^-3 = 8 sum_{k<=2N} k^-3
for N in (1, 2, 10, 60):
    lhs = sum(Fraction(8, (2 * m - 1) ** 3) for m in range(1, N + 1)) + sum(Fraction(1, m ** 3) for m in range(1, N + 1))
    rhs = 8 * sum(Fraction(1, k ** 3) for k in range(1, 2 * N + 1))
    assert lhs == rhs
print('heads of the lattice relation at the step 2: exact for N = 1, 2, 10, 60')
# rendering: the share integral on Re a = 1/2 against 7 T_3(I_Z)
f = lambda y: (lambda aa: (mp.gamma(aa) ** 2 * mp.gamma(1 - aa) ** 2) * (mp.gamma(1 - aa) ** 2 / mp.gamma(2 - 2 * aa))
               * (mp.gamma(aa) ** 2 / mp.gamma(2 * aa)))(mp.mpf(1) / 2 + 1j * y)
share = mp.quad(lambda y: f(y), [-mp.inf, 0, mp.inf]) / (2 * mp.pi)
print('rendering: share integral =', mp.nstr(share.real, 25), ' imaginary part', mp.nstr(abs(share.imag), 3),
      '  7*T_3(I_Z) =', mp.nstr(7 * mp.zeta(3), 25))
assert abs(share - 7 * mp.zeta(3)) < mp.mpf(10) ** -25
