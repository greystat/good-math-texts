"""Receipt for Exercise ex:mot-fulllean: lists at (s,t) = (0,2) with unit masses; the list D_10.

Run: cd scripts; python3 ex5_fulllean.py
"""
from itertools import combinations
from collections import Counter
import sympy as sp
from listkit import List
from subst import substitute, is_matroid


def walls02(L):
    """walls at (0,2) with unit masses: kappa_S = |S| - 2 d*(S) = 2 r(S) - |S| (def:family, def:skeleton)"""
    out = {}
    for k in range(1, L.n):
        for S in combinations(L.E, k):
            kap = len(S) - 2 * L.dstar(S)
            assert kap == 2 * L.rank(S) - len(S)
            out[frozenset(S)] = kap
    return out


T6 = List(range(1, 7), [frozenset(c) for c in combinations(range(1, 7), 3) if set(c) != {1, 2, 3}])
print('T_6: marks', T6.n, ' rank', T6.r, ' balance at (0,2) with unit masses: n = 2r ->', T6.n == 2 * T6.r)
w = walls02(T6)
table = Counter()
for S, k in w.items():
    tag = ('{1,2,3}' if S == frozenset({1, 2, 3}) else '{4,5,6}' if S == frozenset({4, 5, 6}) else '|S|=%d' % len(S))
    table[(tag, T6.rank(S), k)] += 1
for key in sorted(table, key=str):
    print('  ', key, 'x', table[key])
print('T_6 at (0,2): least wall', min(w.values()))
prime_widths = {T6.width(S) for k in (2, 3, 4) for S in combinations(T6.E, k)}
print('T_6: widths of the sets with two marks on each side:', prime_widths)

# D_10: two copies of T_6 glued along the hinge, the mark 6 of each (lem:twosumpieces)
Tc = List([1, 2, 3, 4, 5, 'g'], [frozenset('g' if x == 6 else x for x in T) for T in T6.B])
Tp = List(["1'", "2'", "3'", "4'", "5'", 'g2'],
          [frozenset({1: "1'", 2: "2'", 3: "3'", 4: "4'", 5: "5'", 6: 'g2'}[x] for x in T) for T in T6.B])
core = List(['h1', 'h2'], [frozenset({'h1'}), frozenset({'h2'})])
D10 = substitute(core, {'h1': (Tc, 'g'), 'h2': (Tp, 'g2')})
print('D_10: marks', D10.n, ' rank', D10.r, ' bases', len(D10.B), ' exchange property', is_matroid(D10))
dele = [T for T in Tc.B if 'g' not in T]; cont = [T - {'g'} for T in Tc.B if 'g' in T]
print('  hinge minors of a cell: deletion', len(dele), 'bases (rank 3), contraction', len(cont), 'bases (rank 2)')
S = frozenset(["1'", "2'", "3'", "4'", "5'"]); Sc = frozenset([1, 2, 3, 4, 5])
print('  width of S:', D10.width(S), '  r(S) =', D10.rank(S), '  r(S\') =', D10.rank(Sc))
wd = walls02(D10)
print('  walls at (0,2), unit masses: least', min(wd.values()), ' over', len(wd), 'proper sets;  kappa_S =', wd[S],
      ' kappa_S\' =', wd[Sc])
print('  Beta corner Gamma(1)Gamma(1)/Gamma(2) =', sp.gamma(1) ** 2 / sp.gamma(2))
# the cell families: copies of T_6 at (0,2), unit masses at the marks and at the hinge (2 sigma - kappa = 1)
# the centre: the hinge minors of the cell of S, D_10|S and D_10/S', at the gauge 1: E = (number of bases)^2
res, con = D10.restriction(S), D10.contraction(Sc)
print('  centre: D|S has', len(res.B), 'bases, D/S\' has', len(con.B), 'bases; E(1) =', len(res.B) ** 2, 'and',
      len(con.B) ** 2)
assert {frozenset(x.replace("'", '') for x in map(str, T)) for T in res.B} == {frozenset(map(str, T)) for T in dele}
assert {frozenset(x.replace("'", '') for x in map(str, T)) for T in con.B} == {frozenset(map(str, T)) for T in cont}
# parity: a list at (0,2) on its balance wall with unit masses has n = 2r
for n in range(2, 9):
    print('  n =', n, ': balanced at (0,2) with unit masses needs r =', sp.Rational(n, 2))
