"""Receipt for Exercise ex:mot-dualpair: binom([4],2) at its centre, its dual-pair cells, and its pairs.

Run: cd scripts; python3 ex2_dualpair_u24.py
"""
from itertools import combinations
import sympy as sp
from listkit import List, uniform

L = uniform(4, 2)
al = {e: sp.Symbol('a%d' % e, positive=True) for e in L.E}
K, Psi = L.K(al), L.Psi(al)
assert sp.expand(K - Psi) == 0
print('K = Psi =', K)

# widths and walls at the centre (masses 1, s=t=1)
for k in (1, 2, 3):
    ws = {L.width(S) for S in combinations(L.E, k)}
    kap = {k - L.d(S) - L.dstar(S) for S in combinations(L.E, k)}
    print('|S| =', k, ' widths', ws, ' walls', kap)

# the complement of a mark: cell of the bunch R, a dual pair
gsym = sp.Symbol('ag', positive=True)
for e in L.E:
    R = frozenset(L.E) - {e}
    res, con = L.restriction(R), L.contraction({e})
    assert {frozenset(R) - X for X in res.B} == set(con.B)          # B/e is the dual of B|R
    cell = List(sorted(R) + ['g'], list(res.B) + [X | {'g'} for X in con.B])
    assert set(cell.B) == {frozenset(c) for c in combinations(sorted(R) + ['g'], 2)}
    E1 = sp.expand(res.K(al) * res.Psi(al)); E2 = sp.expand(con.K(al) * con.Psi(al))
    assert E1 - E2 == 0                                                # one even letter
    kappa = 3 - L.d(R) - L.dstar(R)
    assert kappa == 1 == 3 - 2 * (L.rank(R) - 1)
print('every complement of a mark: width 1, cell binom(R+g,2), B/e = (B|R)^*, E equal, wall 1')

# e = 4, R = {1,2,3}: letters of the substitution binom({4,h},1)<4, A_R>  (prop:mot-dualletters(iii))
a1, a2, a3, a4 = (al[i] for i in (1, 2, 3, 4))
e1R, e2R = a1 + a2 + a3, a1 * a2 + a1 * a3 + a2 * a3
pi = e1R                                     # psi of the mark left in place is 1, psi_A = e1(R)
KH = lambda x, y: x + y                      # K and Psi of binom({4,h},1)
assert sp.expand(KH(pi * a4, e2R) - K) == 0
assert sp.expand(KH(pi * a4, e2R) - Psi) == 0
gam = e2R / e1R
print('hinge value gamma =', gam, '; K = e1(R)*(a4 + gamma):', sp.simplify(e1R * (a4 + gam) - K) == 0)
# coefficient of the form: alpha^1/(K Psi) = core(alpha_4, x_h=gamma) * pinned(alpha_R)
core = lambda x4, xh: x4 * xh / (x4 + xh) ** 2              # (binom({4,h},1);1,1) at masses (1,1)
pinned = gam ** -1 * a1 * a2 * a3 * e1R ** -1 * e1R ** -1   # gamma^{-1} alpha^{1_R} K_{A/g}^{-1} Psi_{A\g}^{-1}
lhs = a1 * a2 * a3 * a4 / (K * Psi)
assert sp.simplify(lhs - core(a4, gam) * pinned) == 0
assert sp.simplify(pinned - a1 * a2 * a3 / (e1R * e2R)) == 0
print('alpha^1/(K Psi) = [a4*gamma/(a4+gamma)^2] * [alpha^{1_R}/(e1(R) e2(R))]  (exact)')
# the core family on two marks: walls 1 and 1, Beta corner Gamma(1)Gamma(1)/Gamma(2)
u = sp.Symbol('u', positive=True)
print('core period on the simplex:', sp.integrate(sp.simplify(core(u, 1 - u) / (u * (1 - u))), (u, 0, 1)),
      ' Beta corner:', sp.gamma(1) * sp.gamma(1) / sp.gamma(2))
# the logarithmic Jacobian of the shear (alpha_4, alpha_R) -> (alpha_4, x_h = |alpha_R| gamma(v), v = alpha_R/|alpha_R|)
lam = sp.Symbol('lam', positive=True); v1, v2 = sp.symbols('v1 v2', positive=True)
xh = lam * gam.subs({a1: v1, a2: v2, a3: 1 - v1 - v2})
print('d log x_h / d log lam =', sp.simplify(sp.diff(sp.log(xh), lam) * lam))
