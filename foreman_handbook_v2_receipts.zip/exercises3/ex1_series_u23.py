"""Receipt for Exercise ex:mot-series: binom([3],2) at its centre, read at the root bunch {1,2}.

Prints every quantity the solution displays; all identities are exact (sympy), and the one decimal
value is a labelled rendering (mpmath).  Run: cd scripts; python3 ex1_series_u23.py
"""
from itertools import combinations
import sympy as sp
import mpmath as mp
from listkit import uniform

L = uniform(3, 2)
a1, a2, a3 = sp.symbols('a1 a2 a3', positive=True)
al = {1: a1, 2: a2, 3: a3}
K, Psi = L.K(al), L.Psi(al)
print('K =', K, '  Psi =', Psi)

# walls at the centre (s,t)=(1,1), masses 1 (def:family)
walls = {}
for k in (1, 2):
    for S in combinations(L.E, k):
        walls[S] = len(S) - L.d(S) - L.dstar(S)
print('walls:', walls, ' imbalance:', 3 - (L.r + (L.n - L.r)))
assert all(v == 1 for v in walls.values())

# the pair S={1,2}
S, R = frozenset({1, 2}), frozenset({3})
print('d, d*, r, width of S:', L.d(S), L.dstar(S), L.rank(S), L.width(S))
assert L.width(S) == 1
# series bunch: every basis contains all but at most one mark of S
assert all(len(S - T) <= 1 for T in L.B)
res, con = L.restriction(S), L.contraction(R)
print('B|S bases:', [sorted(T) for T in res.B], '  B/R bases:', [sorted(T) for T in con.B])
gK = sp.simplify(res.K(al) / con.K(al))
gP = sp.simplify(con.Psi(al) / res.Psi(al))
rho_S = sp.simplify(gP / gK)
print('gamma^K_S =', gK, '  gamma^Psi_S =', gP, '  varrho_S =', rho_S)
u = sp.Symbol('u', positive=True)
print('varrho_S on (u,1-u):', sp.factor(rho_S.subs({a1: u, a2: 1 - u})))
# even letters of the hinge minors; deletion and contraction of 3 (cor:mot-whatsplits(iv))
E_res = sp.expand(res.K(al) * res.Psi(al))
E_con = sp.expand(con.K(al) * con.Psi(al))
E_del = sp.expand(L.delete(3).K(al) * L.delete(3).Psi(al))
E_ctr = sp.expand(L.contract(3).K(al) * L.contract(3).Psi(al))
print('E_{B|S} =', E_res, '  E_{B/R} =', sp.factor(E_con))
print('E_{B\\3} =', E_del, '  E_{B/3} =', sp.factor(E_ctr))
assert sp.simplify(E_res - E_con) != 0 and E_res == E_del and E_con == E_ctr

# node form at the root: alpha_S = rho*(u,1-u), alpha_3 = 1
rho, Q = sp.symbols('rho Q', positive=True)
sub = {a1: rho * u, a2: rho * (1 - u), a3: 1}
Kr, Pr = sp.factor(K.subs(sub)), sp.factor(Psi.subs(sub))
print('K(rho u,1) =', Kr, '  Psi(rho u,1) =', Pr)
Qu = u * (1 - u)
assert sp.simplify(Kr - rho * Qu * (rho + 1 / Qu)) == 0 and sp.simplify(Pr - (rho + 1)) == 0
# letters of the step: K is the basis polynomial of binom([3],2), Psi that of binom([3],1)
dual = L.dual()
for name, N, g in (('K', L, K), ('Psi', dual, Psi)):
    rest, cont = N.restriction(S), N.contraction(R)
    gB = sp.simplify(rest.K(al) / cont.K(al))       # gamma^g_B = K_{N|Z_B}/K_{N/Z_R}
    gR = sp.simplify(N.restriction(R).K(al) / N.contraction(S).K(al))  # gamma^g_R
    print(name, ': floor d =', N.d(S), ' gamma_B =', gB, ' gamma_R =', gR,
          ' Skeleton value on the simplices =', sp.simplify((gR / gB).subs({a1: u, a2: 1 - u, a3: 1})))
# the integrand of the period on the section alpha_3 = 1 (thm:projective, lem:scaleshape)
integrand = sp.simplify(rho / (Kr * Pr))
print('rho/(K Psi) =', integrand)
assert sp.simplify(integrand - 1 / ((1 + rho) * (1 + Qu * rho))) == 0
# the node form: A_t = Q^{-1}, Skeleton values (1, 1/Q), letter exponents (1,1), nu_t = 1
v = sp.Symbol('v', positive=True)
breta = sp.integrate(1 / (1 * v + (1 / Q) * (1 - v)), (v, 0, 1))
print('Breta B_{(1,1),1}(1,1/Q) =', sp.simplify(breta))
prim = sp.log((1 + rho) / (1 + Q * rho)) / (1 - Q)        # a primitive of the scale integrand
assert sp.simplify(sp.diff(prim, rho) - 1 / ((1 + rho) * (1 + Q * rho))) == 0
scale = sp.limit(prim, rho, sp.oo) - prim.subs(rho, 0)
print('scale integral =', sp.simplify(scale))
target = sp.log(Q) / (Q - 1)
assert sp.simplify(sp.expand_log(Q ** -1 * breta - target, force=True)) == 0
assert sp.simplify(sp.expand_log(scale - target, force=True)) == 0
# the share side and its left closing (lem:resonantpair(ii)): residue at a=-j is -Q^j log Q
a = sp.Symbol('a')
G = sp.gamma(a) ** 2 * sp.gamma(1 - a) ** 2
for j in range(4):
    eps = sp.Symbol('eps')
    ser = sp.series((G * Q ** (-a)).subs(a, -j + eps), eps, 0, 1).removeO()
    resid = sp.simplify(ser.coeff(eps, -1))
    print('residue at a=-%d:' % j, resid)
    assert sp.simplify(resid + Q ** j * sp.log(Q)) == 0
# reflection u -> 1-u and the coordinate y = log(1/u)
assert sp.expand((1 - u) ** 2 - (1 - u) + 1 - (u ** 2 - u + 1)) == 0
assert sp.expand(Qu - 1 + (1 - u + u ** 2)) == 0
z = sp.Symbol('z', positive=True)   # z = e^{-y}
assert sp.expand((1 - z + z ** 2) * (1 + z) - (1 + z ** 3)) == 0
lap = (z + z ** 2 - z ** 4 - z ** 5) / (1 - z ** 6)
assert sp.simplify(lap - (z + z ** 2) / (1 + z ** 3)) == 0
print('Laplace transform of the input on (0,oo):', sp.factor(lap), '=', (z + z**2) / (1 + z**3))
# the lattice input: phi = 1_{1+6Z}+1_{2+6Z}-1_{4+6Z}-1_{5+6Z} = chi + 2(1_{2+6Z}-1_{4+6Z})
def phi(m):
    return {1: 1, 2: 1, 4: -1, 5: -1}.get(m % 6, 0)
def chi(m):
    return {1: 1, 2: -1}.get(m % 3, 0)
for m in range(1, 601):
    assert phi(m) == chi(m) + 2 * ((m % 6 == 2) - (m % 6 == 4))
    if m % 6 == 2:
        assert (m // 2) % 3 == 1
    if m % 6 == 4:
        assert (m // 2) % 3 == 2
coef = 2 * (1 + 2 * sp.Rational(1, 2) ** 2)
print('coefficient 2(1 + 2*2^-2) =', coef)
assert coef == 3
# exact heads: sum_{m<=6N} phi(m)/m^2 = 3 * sum_{m<=3N} chi(m)/m^2 - ... check the finite form of the dilation
from fractions import Fraction
for N in (1, 5, 40):
    lhs = sum(Fraction(phi(m), m * m) for m in range(1, 6 * N + 1))
    rhs = sum(Fraction(chi(m), m * m) for m in range(1, 6 * N + 1)) + \
        Fraction(2, 4) * sum(Fraction(chi(k), k * k) for k in range(1, 3 * N + 1))
    assert lhs == rhs
print('heads: sum_{m<=6N} phi/m^2 = sum_{m<=6N} chi/m^2 + (1/2) sum_{k<=3N} chi/k^2 (exact, N=1,5,40)')
# rendering
mp.mp.dps = 30
val_int = mp.quad(lambda t: mp.log(t * (1 - t)) / (t * (1 - t) - 1), [0, 0.5, 1])
val_lat = 3 * (mp.psi(1, mp.mpf(1) / 3) - mp.psi(1, mp.mpf(2) / 3)) / 9
print('rendering: integral =', val_int, '  3*T_2(chi) =', val_lat)
assert abs(val_int - val_lat) < mp.mpf(10) ** -25
