"""Receipt for Exercise ex:mot-substitution: the lists P_5 and M_8 at their centres.

Run: cd scripts; python3 ex4_substitution.py
"""
from itertools import combinations
import sympy as sp
from listkit import List, uniform
from subst import substitute, is_matroid


def walls_centre(L):
    return {S: len(S) - L.d(S) - L.dstar(S) for k in range(1, L.n) for S in combinations(L.E, k)}


# ---- P_5: all pairs of [5] but {1,2}
P5 = List(range(1, 6), [frozenset(c) for c in combinations(range(1, 6), 2) if set(c) != {1, 2}])
A = uniform(4, 2, marks=(3, 4, 5, 'g'))
core = uniform(3, 1, marks=(1, 2, 'h'))
assert set(substitute(core, {'h': (A, 'g')}).B) == set(P5.B)
dele = [T for T in A.B if 'g' not in T]; cont = [T - {'g'} for T in A.B if 'g' in T]
assert {frozenset({3, 4, 5}) - X for X in dele} == set(cont)            # dual pair
R = frozenset({3, 4, 5})
print('P_5: rank', P5.r, ' r(R) =', P5.rank(R), ' width(R) =', P5.width(R), ' kappa_R =', 3 - P5.d(R) - P5.dstar(R),
      ' = 3 - 2(r(R)-1) =', 3 - 2 * (P5.rank(R) - 1))
w = walls_centre(P5)
print('P_5 walls at the centre: min', min(w.values()), ' max', max(w.values()))
al = {e: sp.Symbol('a%s' % e, positive=True) for e in (1, 2, 3, 4, 5, 'h')}
a1, a2, a3, a4, a5, ah = (al[e] for e in (1, 2, 3, 4, 5, 'h'))
e1R, e2R = a3 + a4 + a5, a3 * a4 + a3 * a5 + a4 * a5
gam = e2R / e1R
K, Psi = P5.K(al), P5.Psi(al)
assert sp.simplify(K - e1R * (a1 + a2 + gam)) == 0                        # thm:substletters
assert sp.simplify(Psi - e1R * (a1 * a2 + a1 * gam + a2 * gam)) == 0
coreK = lambda x1, x2, xh: x1 + x2 + xh
corePsi = lambda x1, x2, xh: x1 * x2 + x1 * xh + x2 * xh
lhs = a1 * a2 * a3 * a4 * a5 / (K * Psi)
rhs = (a1 * a2 * gam / (coreK(a1, a2, gam) * corePsi(a1, a2, gam))) * (gam ** -1 * a3 * a4 * a5 / (e1R * e1R))
assert sp.simplify(lhs - rhs) == 0
print('P_5: alpha^1/(K Psi) = [core (binom({1,2,h},1);1,1) at x_h = gamma] * [alpha^{1_R}/(e1(R) e2(R))] (exact)')
# the core (binom({1,2,h},1);1,1) has the letters e1, e2: the form of (binom([3],2);1,1)
print('core letters:', sp.expand(coreK(a1, a2, ah)), '|', sp.expand(corePsi(a1, a2, ah)))

# ---- M_8
A1 = uniform(4, 2, marks=('x1', 'y1', 'z1', 'g1'))
A2 = uniform(4, 2, marks=('x2', 'y2', 'z2', 'g2'))
H = uniform(4, 2, marks=('b1', 'b2', 'h1', 'h2'))
M8 = substitute(H, {'h1': (A1, 'g1'), 'h2': (A2, 'g2')})
print('M_8: marks', M8.n, ' rank', M8.r, ' bases', len(M8.B), ' exchange property', is_matroid(M8))
cob = {frozenset(M8.E) - T for T in M8.B}
print('M_8 identically self-dual (cobases = bases):', cob == set(M8.B))
R1, R2 = frozenset({'x1', 'y1', 'z1'}), frozenset({'x2', 'y2', 'z2'})
B = frozenset({'b1', 'b2'})
for Ri in (R1, R2):
    print('  R =', sorted(Ri), ' width', M8.width(Ri), ' r(R)', M8.rank(Ri), ' kappa_R', 3 - M8.d(Ri) - M8.dstar(Ri))
print('  B: width', M8.width(B))
w8 = walls_centre(M8)
print('M_8 walls at the centre: min', min(w8.values()), ' (', len(w8), 'proper sets)')
bl = {e: sp.Symbol('a_%s' % e, positive=True) for e in M8.E}
K8 = M8.K(bl)
assert sp.expand(K8 - M8.Psi(bl)) == 0
e1 = lambda Ri: sum(bl[x] for x in Ri)
e2 = lambda Ri: sum(bl[x] * bl[y] for x, y in combinations(sorted(Ri), 2))
g1, g2 = e2(R1) / e1(R1), e2(R2) / e1(R2)
pi = e1(R1) * e1(R2)
b1, b2 = bl['b1'], bl['b2']
e2core = lambda x: sum(x[i] * x[j] for i, j in combinations(range(4), 2))
assert sp.simplify(K8 - pi * e2core([b1, b2, g1, g2])) == 0               # prop:mot-dualletters(iii)
mono = sp.prod([bl[e] for e in M8.E])
lhs = mono / K8 ** 2
coef_core = b1 * b2 * g1 * g2 / e2core([b1, b2, g1, g2]) ** 2
pin = lambda Ri, g: g ** -1 * sp.prod([bl[x] for x in Ri]) / (e1(Ri) * e1(Ri))
assert sp.simplify(lhs - coef_core * pin(R1, g1) * pin(R2, g2)) == 0
assert sp.simplify(pin(R1, g1) - sp.prod([bl[x] for x in R1]) / (e1(R1) * e2(R1))) == 0
print('M_8: K = Psi = e1(R1) e1(R2) e2(b1,b2,gamma1,gamma2); alpha^1/(K Psi) = core * pinned * pinned (exact)')
# discriminant along B on the line alpha_B = (1,1), alpha_R1 = (1,1,1), alpha_R2 = lam*(1,1,1)
lam = sp.Symbol('lam', positive=True)
line = {b1: 1, b2: 1, **{bl[x]: 1 for x in R1}, **{bl[x]: lam for x in R2}}
disc = sp.factor(((b1 + b2) ** 2 * (g1 + g2) ** 2 - 4 * b1 * b2 * g1 * g2).subs(line))
print('gamma1, gamma2 on the line:', sp.simplify(g1.subs(line)), sp.simplify(g2.subs(line)), '  discriminant:', disc)
