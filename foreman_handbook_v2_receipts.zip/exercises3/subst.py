"""Substitution of cells into a core (Definition def:substitution), exact, for the receipts of ch:exmotive."""
from itertools import product, combinations
from listkit import List


def hinge_minors(cell, g):
    dele = [T for T in cell.B if g not in T]
    cont = [T - {g} for T in cell.B if g in T]
    return dele, cont


def substitute(core, cells):
    """core: a List; cells: {h: (cell List, hinge name)} for the marks h that receive a cell;
    the other marks of the core are left in place.  Returns the substituted List."""
    parts = {}
    for h in core.E:
        if h in cells:
            cell, g = cells[h]
            dele, cont = hinge_minors(cell, g)
            parts[h] = (dele, cont)
        else:
            parts[h] = ([frozenset({h})], [frozenset()])
    marks = []
    for h in core.E:
        if h in cells:
            cell, g = cells[h]
            marks += [x for x in cell.E if x != g]
        else:
            marks.append(h)
    bases = set()
    for T in core.B:
        choices = [parts[h][0] if h in T else parts[h][1] for h in core.E]
        for pick in product(*choices):
            bases.add(frozenset().union(*pick))
    return List(marks, bases)


def is_matroid(L):
    """basis exchange: for T1, T2 and x in T1 - T2 there is y in T2 - T1 with T1 - x + y a basis"""
    Bs = set(L.B)
    for T1 in L.B:
        for T2 in L.B:
            for x in T1 - T2:
                if not any((T1 - {x}) | {y} in Bs for y in T2 - T1):
                    return False
    return True
