"""Receipt for Exercise ex:cls-share (the list binom([2],1) on its share side).

Prints every quantity the solution displays, in exact arithmetic.
"""
import sympy as sp
from listkit import uniform, name

a, s, t, m1, m2, k, y = sp.symbols('a s t m1 m2 k y')

L = uniform(2, 1)
print('bases', [name(T) for T in L.B])
print('K =', L.K(), '  Psi =', L.Psi())

# (1) the pins of the atom formula (Corollary cor:atomwall), g = 2, one share per basis and letter:
# a1, a2 for K (a_i the share of alpha^{T_i}), b1, b2 for Psi (b_i the share of alpha^{E minus T_i}).
a1, a2, b1, b2 = sp.symbols('a1 a2 b1 b2')
sigma = (s + t) / 2
pins = [sp.Eq(a1 + a2, s), sp.Eq(b1 + b2, t),
        sp.Eq(((a1 - b1) - (a2 - b2)) / 2, m1 - sigma)]
sol = sp.solve(pins, [a2, b1, b2], dict=True)[0]
print('pins solved with a1 = a:', {str(kk): sp.simplify(v.subs(a1, a)) for kk, v in sol.items()})
# the load at mark 1 is a1 + b2 = m1
print('load at 1:', sp.simplify((a1 + sol[b2]).subs(a1, a)))

# normalization of the fibre integral (Definition def:fibre)
P = sp.Matrix([[1, 1, 0, 0], [0, 0, 1, 1], [sp.Rational(1, 2), -sp.Rational(1, 2), -sp.Rational(1, 2), sp.Rational(1, 2)]])
print('P P^T =', (P * P.T).tolist(), ' sqrt det =', sp.sqrt((P * P.T).det()))
direction = sp.Matrix([1, -1, 1, -1])
print('P * direction =', (P * direction).T.tolist(), ' |direction| =', direction.norm())
factor = (2 * sp.pi) ** (3 - 4) / sp.sqrt((P * P.T).det()) * direction.norm()
print('fibre measure per dy:', sp.simplify(factor), ' (so the fibre integral is (1/2 pi i) int da)')

# (2) four Gammas on a line (Corollary cor:fourgammas): a+z, b+z, c-z, d-z with (a,b,c,d) = (0, t-m1, s, m1)
A, Bq, C, D = 0, t - m1, s, m1
print('Gamma entries:', [A + C, Bq + D, A + D, Bq + C], ' total', sp.simplify(A + Bq + C + D))
result = sp.gamma(s) * sp.gamma(t) * sp.gamma(m1) * sp.gamma(s + t - m1) / sp.gamma(s + t) / (sp.gamma(s) * sp.gamma(t))
print('P_F(m; s, t) =', sp.simplify(result.subs(s + t - m1, m2)))

# (3) at (1;1,1): the integrand on Re a = 1/2
integrand = sp.gamma(a) ** 2 * sp.gamma(1 - a) ** 2
on_line = sp.simplify(sp.expand_func((sp.pi / sp.sin(sp.pi * a)) ** 2).subs(a, sp.Rational(1, 2) + sp.I * y))
print('integrand at a = 1/2 + iy:', sp.simplify(on_line.rewrite(sp.cosh)))
pcrit = on_line / (2 * sp.pi)
target = 2 * sp.pi / (sp.exp(sp.pi * y) + sp.exp(-sp.pi * y)) ** 2
print('p_crit check (difference simplifies to 0):', sp.simplify((pcrit - target).rewrite(sp.exp)))
prim = sp.tanh(sp.pi * y) / 2
print('d/dy (tanh(pi y)/2) - p_crit:', sp.simplify((sp.diff(prim, y) - pcrit).rewrite(sp.exp)))
print('total mass:', sp.limit(prim, y, sp.oo) - sp.limit(prim, y, -sp.oo))

# (4) the centre ray at strength 1: stride, values, ratios, law
x = sp.Symbol('x', positive=True)  # alpha_1 on the chart alpha_2 = 1
f = x / (1 + x) ** 2
print('stride on the chart:', f, '  f(1) =', f.subs(x, 1))
vals = [sp.gamma(kk) ** 2 / sp.gamma(2 * kk) for kk in range(1, 7)]
print('values <1>_k, k=1..6:', vals)
print('ratios <1>_{k+1}/<1>_k:', [sp.nsimplify(vals[i + 1] / vals[i]) for i in range(5)],
      ' formula k/(2(2k+1)):', [sp.Rational(kk, 2 * (2 * kk + 1)) for kk in range(1, 6)])
print('law 2(2k+1)x_{k+1} - k x_k:', [2 * (2 * kk + 1) * vals[kk] - kk * vals[kk - 1] for kk in range(1, 6)])
step = sp.gamma(k - a) ** 2 / sp.gamma(k) ** 2 / (sp.gamma(1 - a) ** 2)
for kk in range(1, 5):
    print('  step factor at k =', kk, ':', sp.factor(sp.simplify(sp.gammasimp(step.subs(k, kk)))))

# (5) closings, V_1, principal parts
clos = [sp.expand((x + 2 + 1 / x) ** j).as_coefficients_dict().get(sp.Integer(1), 0) if j > 0 else 1 for j in range(0, 8)]
print('closings C_j(1), j=0..7:', clos, ' binomials:', [sp.binomial(2 * j, j) for j in range(8)])
V1 = 1 + 1
print('V_1 =', V1)
for j in range(0, 6):
    lim = sp.limit((k + j) * sp.gamma(k) ** 2 / sp.gamma(2 * k), k, -j)
    print('  lim_{k->-%d} (k+%d)<1>_k =' % (j, j), lim, '  V_1 C_j =', V1 * clos[j])
print('reflected law j C_j + 2(1-2j) C_{j-1}:', [j * clos[j] + 2 * (1 - 2 * j) * clos[j - 1] for j in range(1, 8)])

# (6) H, the product, the leading constants
yy = sp.Symbol('yy')
mlogf = 2 * sp.log(1 + sp.exp(yy)) - yy
H = sp.simplify(sp.diff(mlogf, yy, 2).subs(yy, 0))
print('H =', H, ' (variance of X_1 under the weight law is 1/4, times s_1 + t_1 = 2)')
prod = [kk * vals[kk - 1] * sp.binomial(2 * kk, kk) for kk in range(1, 7)]
print('k <1>_k C_k(1), k=1..6:', prod, '  (det H)^{-1} =', 1 / H)
print('symbolic:', sp.simplify(sp.gammasimp(k * sp.gamma(k) ** 2 / sp.gamma(2 * k) * sp.gamma(2 * k + 1) / sp.gamma(k + 1) ** 2)))
a0 = sp.sqrt(2 * sp.pi) * H ** sp.Rational(-1, 2)
print('a_0(1) = (2 pi)^{1/2} (det H)^{-1/2} =', sp.simplify(a0))
print('duplication: Gamma(k)^2/Gamma(2k) * 2^(2k-1)/sqrt(pi) - Gamma(k)/Gamma(k+1/2) =',
      sp.simplify(sp.gammasimp(sp.gamma(k) ** 2 / sp.gamma(2 * k) * 2 ** (2 * k - 1) / sp.sqrt(sp.pi) - sp.gamma(k) / sp.gamma(k + sp.Rational(1, 2)))))
print('limit sqrt(k) Gamma(k)/Gamma(k+1/2):', sp.limit(sp.sqrt(k) * sp.gamma(k) / sp.gamma(k + sp.Rational(1, 2)), k, sp.oo))
print('so 4^k sqrt(k) <1>_k -> 2 sqrt(pi) = a_0(1); and 4^{-j} sqrt(j) C_j -> a_0(1)/(2 pi) =', sp.simplify(a0 / (2 * sp.pi)))
