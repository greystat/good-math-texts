"""Receipt for Exercise ex:con-fusion (fusing binom([5],2)).

Prints: the circuits and cocircuits of binom([5],2) and the tell (Theorem thm:fusiontell (b) and (c)); the
quotient test (a) through the rank functions; the fusion width; the bases of the Foreman fusion of
Theorem thm:fusion(v) and their equality with binom([6],3); the letter identity K# = Psi + a_g K; every major
(Definition def:fusion(i)) found by a search over the families of 3-sets of [5]+g; the cousins
(Proposition prop:cousins) and their isomorphism with binom([5],2); the automorphisms; the scale integral of
Corollary cor:fusionone at the masses (m_E, m_g); the period identity at the centre.
"""
from itertools import combinations, permutations
import sympy as sp
from listkit import List, uniform, name

E = (1, 2, 3, 4, 5)
F = uniform(5, 2)
print('rank', F.r, ' corank', F.n - F.r, ' fusion width c =', F.n - 2 * F.r)
circ, cocirc = F.circuits(), F.cocircuits()
print('circuits:', [name(C) for C in circ])
print('cocircuits:', [name(D) for D in cocirc])
print('every cocircuit is a union of circuits:', all(frozenset().union(*[C for C in circ if C <= D]) == D for D in cocirc))
Fd = F.dual()
quot = all(F.rank(Y) - F.rank(X) <= Fd.rank(Y) - Fd.rank(X)
           for k in range(0, 6) for Y in combinations(E, k) for j in range(0, k + 1) for X in combinations(Y, j))
print('(a) quotient through the rank functions, r*(Y)-r*(X) >= r(Y)-r(X) for all X in Y:', quot)
okc = True
for e in E:
    rest = [x for x in E if x != e]
    for k in range(0, len(rest) + 1):
        for A in combinations(rest, k):
            A = set(A); A2 = set(rest) - A
            if F.rank(A | {e}) > F.rank(A) and F.rank(A2 | {e}) > F.rank(A2):
                okc = False
print('(c) for every mark and every split of the others one half spans the mark:', okc)
# the fusion at width one (Theorem thm:fusion(v)): bases T+g and E minus T
G = 'g'
fus = List(E + (G,), [T | {G} for T in F.B] + [frozenset(E) - T for T in F.B])
print('fusion bases:', len(fus.B), ' equal to binom([5]+g, 3):', set(fus.B) == set(uniform(6, 3, E + (G,)).B))
al = fus.symbols()
Kf = F.K({e: al[e] for e in E}); Pf = F.Psi({e: al[e] for e in E})
print('K# - (Psi + a_g K) =', sp.expand(fus.K() - (Pf + al[G] * Kf)), ';  K# - Psi# =', sp.expand(fus.K() - fus.Psi()))
print('identically self-dual: complements of bases are bases:', all(frozenset(fus.E) - T in set(fus.B) for T in fus.B))
# majors: tables on E+g whose contraction of g is F and whose deletion of g is F*
cand = [frozenset(c) for c in combinations(E + (G,), 3)]
need_through = {T | {G} for T in F.B}
need_avoid = set(Fd.B)
majors = []
# a family of 3-sets whose contraction at g is F and deletion is F* must contain exactly these sets
fam = need_through | need_avoid
L = List(E + (G,), fam)
print('majors: the conditions fix the family of bases:', len(fam), ' sets; it is a table:',
      all(any((T - {a}) | {b} in fam for b in T2 - T) for T in fam for T2 in fam for a in T - T2))
# cousins
for x in E + (G,):
    cous = fus.contract(x)
    print('  cousin at', x, ':', len(cous.B), 'bases, equal to binom(others,2):', set(cous.B) == set(uniform(5, 2, tuple(e for e in E + (G,) if e != x)).B),
          ' deletion is its dual:', set(fus.delete(x).B) == set(cous.dual().B))
autF = len(F.carrying())
autFus = len(fus.carrying())
print('automorphisms: binom([5],2):', autF, ' binom([6],3):', autFus)
print('index', autFus, '/', autF, '=', sp.Rational(autFus, autF), ' = binom(6,1) =', sp.binomial(6, 1))
# Corollary cor:fusionone: the scale of g integrated (Theorem thm:dirichlet in one variable)
v, mg, sig2 = sp.symbols('v m_g two_sigma', positive=True)
e2, e3 = sp.symbols('e2 e3', positive=True)
integral = sp.integrate(v ** (mg - 1) * (e3 + v * e2) ** (-sig2), (v, 0, sp.oo), conds='none')
print('int_0^oo v^(m_g-1) (e3 + v e2)^(-2 sigma) dv =', sp.simplify(integral))
expected = sp.gamma(mg) * sp.gamma(sig2 - mg) / sp.gamma(sig2) * e3 ** (mg - sig2) * e2 ** (-mg)
print('  minus Gamma(m_g, 2sigma-m_g; 2sigma) e3^(m_g - 2sigma) e2^(-m_g):', sp.simplify(sp.gammasimp(integral - expected)))
print('balance of the fusion: m_E + m_g = 2 sigma r* =', 2 * 3, 'sigma; of binom([5],2) at (m_g, 2sigma - m_g): m_E = 2 m_g + 3(2 sigma - m_g) = 6 sigma - m_g')
