"""Receipt for Exercise ex:con-transverse (one share per station at a set of width two).

The list Q_5 on {1,...,5} whose bases are the sets of three marks other than {1,2,5} and {3,4,5}, at its centre
(1;1,1), and S = {1,2,3} with the room R = {4,5}.
Prints: the bases, the counts of S and R, the patterns and room sides by excess with their children and room
children, the stations, the seam letters and the room station letters, the room-station factorization, the
walls, the pins of the seam, the room word and its period on the chart, the Newton sums, the lattice of
Theorem thm:transversepins and its pins, the scale pin as a consequence, the native split at the stations and
the strict interior check of the masses in the Newton sum of the seam word there.
"""
from itertools import combinations
from fractions import Fraction
import sympy as sp
from listkit import List, name

E = (1, 2, 3, 4, 5)
Q5 = List(E, [frozenset(c) for c in combinations(E, 3) if set(c) not in ({1, 2, 5}, {3, 4, 5})])
print('bases:', [name(T) for T in Q5.B], len(Q5.B))
print('circuits:', [name(C) for C in Q5.circuits()], ' cocircuits:', [name(C) for C in Q5.cocircuits()])
S, R = frozenset({1, 2, 3}), frozenset({4, 5})
for X, nm in ((S, 'S'), (R, 'R')):
    print(nm, ': r =', Q5.rank(X), ' d =', Q5.d(X), ' d* =', Q5.dstar(X), ' width =', Q5.width(X), ' window', Q5.window(X))
al = Q5.symbols()
dS = Q5.d(S)
stations = []  # (excess, room side X, room child list on S)
for i in range(Q5.width(S) + 1):
    k = dS + i
    pats = sorted({T & S for T in Q5.B if len(T & S) == k}, key=name)
    sides = sorted({T & R for T in Q5.B if len(T & S) == k}, key=name)
    print('excess', i)
    for p in pats:
        print('   pattern', name(p), ' child', [name(T - p) for T in Q5.B if T & S == p])
    for X in sides:
        rc = List(sorted(S), [T - X for T in Q5.B if T & R == X])
        print('   room side', name(X), ' room child', [name(Y) for Y in rc.B], ' K =', rc.K(), ' Psi =', sp.factor(rc.Psi()))
        stations.append((i, X, rc))
# stations: room sides with proportional room children; here all distinct
print('stations of room sides (one room side each):', [(i, name(X)) for i, X, rc in stations])
y = {}
for i, X, rc in stations:
    yD = sp.Mul(*[al[e] for e in X])
    ysD = sp.Mul(*[al[e] for e in R if e not in X])
    y[(i, name(X))] = (rc.K(), rc.Psi(), yD, ysD)
    print('  D =', (i, name(X)), ' V_D =', rc.K(), ' V*_D =', sp.factor(rc.Psi()), ' y_D =', yD, ' y*_D =', ysD)
K = sp.expand(sum(v[0] * v[2] for v in y.values()))
P = sp.expand(sum(v[1] * v[3] for v in y.values()))
print('room-station factorization reproduces K and Psi:', sp.expand(K - Q5.K()) == 0, sp.expand(P - Q5.Psi()) == 0)
s = t = 1
m = {e: 1 for e in E}
kS = sum(m[e] for e in S) - s * Q5.d(S) - t * Q5.dstar(S)
kR = sum(m[e] for e in R) - s * Q5.d(R) - t * Q5.dstar(R)
cS = Q5.width(S)
print('walls: kappa_S =', kS, ' kappa_R =', kR, ' top wall of S =', (s + t) * cS - kS)
# shares
keys = list(y.keys())
a = {kk: sp.Symbol('a_%d%s' % kk) for kk in keys}
b = {kk: sp.Symbol('b_%d%s' % kk) for kk in keys}
tot_a, tot_b = sum(a.values()), sum(b.values())
scale_pin = sum(kk[0] * a[kk] + (cS - kk[0]) * b[kk] for kk in keys)
print('pins of the seam: sum a =', tot_a, '= 1; sum b =', tot_b, '= 1; scale pin:', scale_pin, '=', kS)
# room word: product of y_D^{-a_D} y*_D^{-b_D}: exponents at the marks 4, 5
p = {e: sum(a[kk] * sp.degree(y[kk][2], al[e]) + b[kk] * sp.degree(y[kk][3], al[e]) for kk in keys) for e in R}
print('room word = a4^(-p4) a5^(-p5) with p4 =', p[4], ' p5 =', p[5])
print('p4 + p5 =', sp.expand(p[4] + p[5]), '= 2(sum a + sum b) - (scale pin form), so on the pins of the seam p4 + p5 = 4 -', kS, '=', 4 - kS, '= m_4 + m_5')
print('period of the room word on the chart a5 = 1: integral over (0,oo) of a4^(m4 - p4 - 1): diverges for every p4')
# Newton polytopes of the seam letters (support exponents on S)
def support(poly):
    return [tuple(sp.degree(mono, al[e]) for e in sorted(S)) for mono in sp.Add.make_args(sp.expand(poly))]
print('supports of the seam letters:', {kk: (support(v[0]), support(v[1])) for kk, v in y.items()})
# native split at the stations (Lemma lem:nativestations) at the table's gauge: s P(T cap R in D)
nat_a = {kk: Fraction(sum(1 for T in Q5.B if name(T & R) == kk[1]), len(Q5.B)) * s for kk in keys}
nat_b = {kk: Fraction(sum(1 for T in Q5.B if name(T & R) == kk[1]), len(Q5.B)) * t for kk in keys}
print('native split: a* =', nat_a, ' b* =', nat_b)
sub = {a[kk]: sp.Rational(nat_a[kk].numerator, nat_a[kk].denominator) for kk in keys}
sub.update({b[kk]: sp.Rational(nat_b[kk].numerator, nat_b[kk].denominator) for kk in keys})
print('at the native split: totals', tot_a.subs(sub), tot_b.subs(sub), ' scale pin', scale_pin.subs(sub), ' p4 =', p[4].subs(sub), ' p5 =', p[5].subs(sub))
# the transverse pins: p4 = m4, p5 = m5; the scale pin follows
lhs = sp.expand(2 * (tot_a + tot_b) - (p[4] + p[5]))
print('2(sum a + sum b) - (p4 + p5) =', lhs, ' equals the scale pin form:', sp.expand(lhs - scale_pin) == 0, ' value 4 - 2 =', 4 - 2)
# interior check of m_S in the Newton sum of the seam word at the native split (exact, in the plane x1+x2+x3 = 3)
pts = []
summands = []
for kk in keys:
    summands.append((nat_a[kk], support(y[kk][0])))
    summands.append((nat_b[kk], support(y[kk][1])))
def h(u):
    return sum(w * max(sum(ui * vi for ui, vi in zip(u, v)) for v in sup) for w, sup in summands if w != 0)
normals = set()
for w, sup in summands:
    for v1 in sup:
        for v2 in sup:
            if v1 != v2:
                d = tuple(Fraction(q2 - q1) for q1, q2 in zip(v1, v2))
                # normal in the plane sum = 0: n = d x (1,1,1)
                n = (d[1] - d[2], d[2] - d[0], d[0] - d[1])
                normals.add(n); normals.add(tuple(-c for c in n))
if not normals:
    pass
mS = (1, 1, 1)
gaps = [(n, h(n) - sum(ni * mi for ni, mi in zip(n, mS))) for n in normals]
print('support function minus <n, m_S> over the edge normals:', sorted(set(g for n, g in gaps)))
print('m_S strictly inside the Newton sum (all gaps positive):', all(g > 0 for n, g in gaps))
print('dimension of the Newton sum of the seam word: 2 (the letter e1 on S has a triangle as Newton polytope)')
print('fibre dimensions: one share per station n_D = 2|D| - 2N - 1 =', 2 * len(keys) - 2 - 1, '; with transverse pins 8 - 4 =', 8 - 4)
