"""Receipt for Exercise ex:cls-u14tree (the Foreman trees of binom([4],1)).

Prints the widths of the proper sets, the occupations, the masses of the realizations at the table's gauge,
the writings K_{e,g} and Psi_{e,g} of Proposition prop:viewform from every mark in every order of its room,
and the bijections that carry or exchange the list (Corollary cor:certifyone).
"""
from itertools import permutations, combinations
from fractions import Fraction
import sympy as sp
from listkit import uniform, name

L = uniform(4, 1)
E = L.E
print('bases', [name(T) for T in L.B], ' K =', L.K(), ' Psi =', L.Psi())
print('widths of the proper nonempty sets:', sorted({L.width(S) for k in range(1, 4) for S in combinations(E, k)}))
print('occupations R_e(1):', [L.occupation(e) for e in E])
sig, dl = sp.symbols('sigma delta')
print('masses at the realization (sigma, delta) at the table gauge: tau_e =', sp.simplify(sig + dl * (2 * sp.Rational(1, 4) - 1)),
      ' total', sp.simplify(4 * (sig - dl / 2)), ' = s r + t r* =', sp.expand((sig + dl) * 1 + (sig - dl) * 3))

x = sp.symbols('x0:4')
writings = set()
for e in E:
    room = [h for h in E if h != e]
    for order in permutations(room):
        pos = (e,) + order
        Kw = sum(sp.Mul(*[x[i] for i, h in enumerate(pos) if h in T]) for T in L.B)
        Pw = sum(sp.Mul(*[x[i] for i, h in enumerate(pos) if h not in T]) for T in L.B)
        writings.add((sp.expand(Kw), sp.expand(Pw)))
print('number of distinct writings (K_{e,g}, Psi_{e,g}) over 4 marks x 6 orders:', len(writings))
print('the writing:', writings.pop())
car, exc = L.carrying(), L.exchanging()
print('carrying bijections:', len(car), ' exchanging bijections:', len(exc))
print('orbits of the carrying bijections:', L.orbits(car))
# views with no partner (Definition def:view, k = 0): the potential on the scale of e alone
v = sp.Symbol('v')
for e in E:
    al = {h: (sp.exp(v) if h == e else 1) for h in E}
    print('  view of mark', e, 'with no partner: K =', sp.simplify(L.K(al)), ' Psi =', sp.simplify(L.Psi(al)))
