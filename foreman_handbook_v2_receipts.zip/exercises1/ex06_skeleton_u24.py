"""Receipt for Exercise ex:cls-u24skel (Skeleton values of binom([4],2) along {1,2}).

Prints the levels of K along the scale of B = {1,2}, the Skeleton polynomial, its discriminant, the discriminant
at the table's gauge and the Skeleton values there, the discriminant on the line (1,1,1,lam), its roots, and the
same for Psi (the Cremona of Proposition prop:sklaws(iii)).
"""
import sympy as sp
from listkit import uniform

L = uniform(4, 2)
al = L.symbols()
a1, a2, a3, a4 = [al[e] for e in (1, 2, 3, 4)]
rho, x, lam = sp.symbols('rho x lam')
K = L.K()
Ks = sp.expand(K.subs({a1: rho * a1, a2: rho * a2}, simultaneous=True))
print('K(rho a1, rho a2, a3, a4) =', sp.collect(Ks, rho))
B = frozenset({1, 2})
print('d(B) =', L.d(B), ' r(B) =', L.rank(B), ' c(B) =', L.width(B))
Q = sp.expand(Ks.subs(rho, x))  # x^{-d(B)} K(x alpha_B, alpha_R), d(B) = 0
c2, c1, c0 = [Q.coeff(x, i) for i in (2, 1, 0)]
disc = sp.factor(c1 ** 2 - 4 * c2 * c0)
print('levels: x^0:', c0, ' x^1:', sp.factor(c1), ' x^2:', c2)
print('discriminant:', disc, ' expanded:', sp.expand(disc))
at1 = {a1: 1, a2: 1, a3: 1, a4: 1}
print('at the table gauge: Q(x)*K(1) =', Q.subs(at1), ' K(1) =', K.subs(at1), ' discriminant =', disc.subs(at1))
xi = sp.solve(sp.Eq(Q.subs(at1), 0), x)
print('roots -xi:', xi, ' Skeleton values:', [sp.simplify(-r) for r in xi])
dl = sp.factor(disc.subs({a1: 1, a2: 1, a3: 1, a4: lam}))
print('discriminant on (1,1,1,lam):', dl, ' its discriminant in lam:', sp.discriminant(sp.expand(dl / 4), lam), ' roots:', sp.solve(dl, lam))
print('sum and product of the Skeleton values: ', sp.simplify(c1 / c2), sp.simplify(c0 / c2))
# Psi: the same discriminant, by Cremona
P = L.Psi()
Ps = sp.expand(P.subs({a1: x * a1, a2: x * a2}, simultaneous=True))
d_star = L.dstar(B)
Ps = sp.expand(Ps / x ** d_star)
p2, p1, p0 = [Ps.coeff(x, i) for i in (2, 1, 0)]
print('Psi levels: x^0:', p0, ' x^1:', sp.factor(p1), ' x^2:', p2, ' discriminant:', sp.factor(p1 ** 2 - 4 * p2 * p0))
