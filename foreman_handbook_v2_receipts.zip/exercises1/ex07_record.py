"""Receipt for Exercise ex:cls-record (peeling with and without the record).

The family ((binom([5],2);1,0),(binom([5],3);-1,0),(binom([5],4);4,0)) at the masses 3*1, peeled at {1}.
Prints the balance, the usage at the table's gauge, the walls, the indexed children of the record with their
exponents, the merged peel, and the checks of the native split on the room.
"""
from itertools import combinations
from fractions import Fraction
import sympy as sp
from listkit import uniform, name

E = (1, 2, 3, 4, 5)
tables = [(uniform(5, 2), Fraction(1)), (uniform(5, 3), Fraction(-1)), (uniform(5, 4), Fraction(4))]
m = Fraction(3)
print('balance: sum_j s_j r_j =', sum(s * T.r for T, s in tables), ' m_E =', 5 * m)
print('usage at the gauge 1 at every mark:', [sum(s * T.occupation(e) for T, s in tables) for e in E])
for k in range(1, 6):
    S = frozenset(range(1, k + 1))
    kap = k * m - sum(s * T.d(S) for T, s in tables)
    print('  wall at a set of', k, 'marks:', kap, ' (d_j =', [T.d(S) for T, s in tables], ')')
B = frozenset({1})
R = (2, 3, 4, 5)
record = []
for j, (T, s) in enumerate(tables, start=1):
    for p in T.patterns(B):
        ch = T.child(B, p)
        pr = T.pattern_probability(B, p)
        record.append((j, name(p), ch, pr, pr * s))
        print('  record: table', j, ' pattern', name(p), ' child: binom(R,%d)' % ch.r, ' probability', pr, ' exponents (%s, 0)' % (pr * s))
merged = {}
for j, p, ch, pr, ex in record:
    merged[ch.r] = merged.get(ch.r, 0) + ex
print('merged peel: rank of the child on R -> exponent:', dict(sorted(merged.items())))
print('the child binom(R,2) carries', [ex for j, p, ch, pr, ex in record if ch.r == 2], ' summing to', merged[2])
print('balance of the record on R: sum exponent * rank =', sum(ex * ch.r for j, p, ch, pr, ex in record), ' m_R =', 4 * m)
print('usage of the record at the gauge 1 on R:', [sum(ex * ch.occupation(e) for j, p, ch, pr, ex in record) for e in R])
# the record determines the family (Proposition prop:record): exponents of the children of table j add up
for j in (1, 2, 3):
    print('  table', j, ' sum of the exponents of its children:', sum(ex for jj, p, ch, pr, ex in record if jj == j))
# with nonnegative exponents merging adds terms of one sign
al = {e: sp.Symbol('a%d' % e, positive=True) for e in R}
ek = {k: sp.Add(*[sp.Mul(*[al[i] for i in c]) for c in combinations(R, k)]) for k in range(1, 5)}
word_record = sp.Mul(*[ek[ch.r] ** (-sp.Rational(ex.numerator, ex.denominator)) for j, p, ch, pr, ex in record if ch.r >= 1])
word_peel = sp.Mul(*[ek[k] ** (-sp.Rational(v.numerator, v.denominator)) for k, v in merged.items() if k >= 1 and v != 0])
print('word of the record:', word_record)
print('word of the peel:', word_peel)
print('equal:', sp.simplify(word_record - word_peel) == 0)
