"""Receipt for Exercises ex:cls-sixtree and ex:cls-sixsplit (the list T_6 of rank three on six marks without
the basis {1,2,3}).

Prints: the bases, the widths of all sets (connectedness and primality), the bijections that carry or exchange
the list and their orbits, the occupations, the law of the level of {1,2,3} and its cumulants of orders two and
three under the weight law, the coefficient of the rise of stage zero, the Skeleton polynomial along {1,2,3}
at the table's gauge, its discriminant and Skeleton values, the discriminant as a polynomial and on a line,
the patterns, children and pattern probabilities of both triples (the peels at a lean), and the even letters
of the deletion and the contraction at every mark.
"""
from itertools import combinations
from fractions import Fraction
from collections import Counter
import sympy as sp
from listkit import List, name, kappa_cumulant

E = (1, 2, 3, 4, 5, 6)
T6 = List(E, [frozenset(c) for c in combinations(E, 3) if set(c) != {1, 2, 3}])
print('bases:', len(T6.B), ' rank', T6.r)
widths = {}
for k in range(1, 6):
    for S in combinations(E, k):
        widths[frozenset(S)] = T6.width(S)
print('widths of singletons:', sorted({widths[frozenset([e])] for e in E}))
two_each = Counter(widths[S] for S in widths if 2 <= len(S) <= 4)
print('widths of the sets with at least two marks on each side (counts):', dict(two_each))
print('  c({1,2,3}) =', widths[frozenset({1, 2, 3})], ' c({4,5,6}) =', widths[frozenset({4, 5, 6})])
car, exc = T6.carrying(), T6.exchanging()
print('carrying bijections:', len(car), ' orbits:', T6.orbits(car))
print('exchanging bijections:', len(exc), ' orbits of carrying and exchanging together:', T6.orbits(car + exc))
shift = {i: (i + 2) % 6 + 1 for i in E}
print('i -> i+3 mod 6:', shift, ' exchanges:', shift in exc)
print('occupations:', {e: T6.occupation(e) for e in E})
C = frozenset({1, 2, 3})
law = Counter(len(T & C) for T in T6.B)
print('law of N_C under the weight law (value: count of bases):', dict(sorted(law.items())))
vp = [(v, Fraction(c, len(T6.B))) for v, c in law.items()]
k2, k3 = kappa_cumulant(vp, 2), kappa_cumulant(vp, 3)
print('cumulants of N_C: kappa_2 =', k2, ' kappa_3 =', k3)
D = frozenset({4, 5, 6})
lawD = Counter(len(T & D) for T in T6.B)
vpD = [(v, Fraction(c, len(T6.B))) for v, c in lawD.items()]
print('law of N_D:', dict(sorted(lawD.items())), ' kappa_2 =', kappa_cumulant(vpD, 2), ' kappa_3 =', kappa_cumulant(vpD, 3))
dl = sp.Symbol('delta')
print('[v0^3] of the odd rise of stage 0 for C: (2/3!) delta kappa_3 =', sp.Rational(2, 6) * dl * k3)
# Skeleton polynomial along C at the table's gauge (Definition def:skelpoly), d(C) = 0
al = T6.symbols()
x, rho, lam = sp.symbols('x rho lam')
K = T6.K()
Kx = sp.expand(K.subs({al[1]: x * al[1], al[2]: x * al[2], al[3]: x * al[3]}, simultaneous=True))
print('d(C) =', T6.d(C), ' r(C) =', T6.rank(C))
levels = [sp.factor(Kx.coeff(x, i)) for i in range(4)]
print('levels of K along C:', levels)
at1 = {al[e]: 1 for e in E}
Q1 = sp.expand(Kx.subs(at1))
print('K(x 1_C, 1_R) =', Q1, ' K(1) =', K.subs(at1), ' discriminant =', sp.discriminant(Q1, x))
roots = sp.solve(Q1, x)
print('roots:', roots, ' Skeleton values:', [sp.nsimplify(-r) for r in roots])
c2, c1, c0 = [Kx.coeff(x, i) for i in (2, 1, 0)]
Dsc = sp.expand(c1 ** 2 - 4 * c2 * c0)
line = {al[1]: 1, al[2]: 1, al[3]: 1, al[4]: 1, al[5]: 1, al[6]: lam}
DL = sp.factor(Dsc.subs(line))
print('discriminant on (1,1,1,1,1,lam):', DL, '; discriminant of its quadratic factor:', sp.discriminant(sp.expand(DL / 3), lam))
# patterns and children of both triples (peel at a lean)
for Bset in (C, D):
    print('bunch', name(Bset), ' d =', T6.d(Bset), ' r =', T6.rank(Bset), ' width', T6.width(Bset))
    for p in T6.patterns(Bset):
        ch = T6.child(Bset, p)
        print('   pattern', name(p), ' probability', T6.pattern_probability(Bset, p), ' child: rank', ch.r, ' bases', [name(T) for T in ch.B])
# the complements of single marks: even letters of the deletion and the contraction
for e in E:
    dele, con = T6.delete(e), T6.contract(e)
    Ed = sp.expand(dele.K() * dele.Psi())
    Ec = sp.expand(con.K() * con.Psi())
    print('mark', e, ': deletion has', len(dele.B), 'bases, contraction', len(con.B), '; E at the gauge:',
          Ed.subs(at1), Ec.subs(at1), ' equal as polynomials:', sp.expand(Ed - Ec) == 0)
