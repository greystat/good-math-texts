"""Exact toolkit for the exercise receipts of ch:exclass and ch:exconstruct.

A list is given by its marks (a tuple of names) and its bases (a list of frozensets).
Everything here is exact: integers, Fractions, sympy rationals and polynomials.
"""
from fractions import Fraction
from itertools import combinations, permutations
import sympy as sp


class List:
    def __init__(self, marks, bases):
        self.E = tuple(marks)
        self.B = sorted({frozenset(T) for T in bases}, key=lambda T: sorted(map(str, T)))
        assert self.B, 'a list has at least one basis'
        r = {len(T) for T in self.B}
        assert len(r) == 1, 'bases of one size'
        self.r = r.pop()
        self.n = len(self.E)

    # counts of Definition def:skeleton and Theorem thm:window
    def rank(self, S):
        S = frozenset(S)
        return max(len(T & S) for T in self.B)

    def d(self, S):
        S = frozenset(S)
        return min(len(T & S) for T in self.B)

    def dstar(self, S):
        S = frozenset(S)
        return min(len(S - T) for T in self.B)

    def width(self, S):
        S = frozenset(S)
        return len(S) - self.d(S) - self.dstar(S)

    def window(self, S):
        S = frozenset(S)
        return sorted({len(T & S) for T in self.B})

    # letters
    def symbols(self):
        return {e: sp.Symbol('a%s' % e, positive=True) for e in self.E}

    def K(self, al=None):
        al = al or self.symbols()
        return sp.expand(sum(sp.Mul(*[al[e] for e in T]) for T in self.B))

    def Psi(self, al=None):
        al = al or self.symbols()
        return sp.expand(sum(sp.Mul(*[al[e] for e in self.E if e not in T]) for T in self.B))

    def dual(self):
        return List(self.E, [frozenset(self.E) - T for T in self.B])

    # minors (Definition def:minors, def:delcon)
    def restriction(self, X):
        X = frozenset(X)
        rX = self.rank(X)
        return List(sorted(X, key=str), {T & X for T in self.B if len(T & X) == rX})

    def contraction(self, X):
        X = frozenset(X)
        rX = self.rank(X)
        rest = [e for e in self.E if e not in X]
        return List(rest, {T - X for T in self.B if len(T & X) == rX})

    def delete(self, e):
        return List([x for x in self.E if x != e], [T for T in self.B if e not in T])

    def contract(self, e):
        return List([x for x in self.E if x != e], [T - {e} for T in self.B if e in T])

    # patterns and children (Definition def:patterns)
    def patterns(self, Bset):
        Bset = frozenset(Bset)
        return sorted({T & Bset for T in self.B}, key=lambda p: (len(p), sorted(map(str, p))))

    def child(self, Bset, p):
        Bset = frozenset(Bset)
        room = [e for e in self.E if e not in Bset]
        return List(room, [T - p for T in self.B if T & Bset == p])

    def pattern_probability(self, Bset, p):
        Bset = frozenset(Bset)
        return Fraction(sum(1 for T in self.B if T & Bset == p), len(self.B))

    def occupation(self, e):
        return Fraction(sum(1 for T in self.B if e in T), len(self.B))

    # circuits and cocircuits (Definition def:molecule)
    def independent(self, S):
        S = frozenset(S)
        return any(S <= T for T in self.B)

    def circuits(self):
        out = []
        for k in range(1, self.n + 1):
            for S in combinations(self.E, k):
                S = frozenset(S)
                if not self.independent(S) and all(self.independent(S - {x}) for x in S):
                    out.append(S)
        return out

    def cocircuits(self):
        out = []
        for k in range(1, self.n + 1):
            for S in combinations(self.E, k):
                S = frozenset(S)
                meets_all = all(T & S for T in self.B)
                if meets_all and all(not all(T & (S - {x}) for T in self.B) for x in S):
                    out.append(S)
        return out

    # bijections that carry or exchange the list (Definition def:carry)
    def carrying(self):
        Bs = set(self.B)
        out = []
        for perm in permutations(self.E):
            g = dict(zip(self.E, perm))
            if all(frozenset(g[x] for x in T) in Bs for T in self.B):
                out.append(g)
        return out

    def exchanging(self):
        Cs = {frozenset(self.E) - T for T in self.B}
        out = []
        for perm in permutations(self.E):
            g = dict(zip(self.E, perm))
            if all(frozenset(g[x] for x in T) in Cs for T in self.B):
                out.append(g)
        return out

    def orbits(self, maps):
        seen, orbs = set(), []
        for e in self.E:
            if e in seen:
                continue
            orb = {g[e] for g in maps}
            seen |= orb
            orbs.append(sorted(orb, key=str))
        return orbs


def uniform(n, r, marks=None):
    E = marks or tuple(range(1, n + 1))
    return List(E, [frozenset(c) for c in combinations(E, r)])


def name(S):
    S = sorted(S, key=str)
    return ''.join(map(str, S)) if S else '0'


def kappa_cumulant(values_probs, k):
    """k-th cumulant of a finite law given as [(value, probability)] (exact)."""
    t = sp.Symbol('t')
    m = sum(sp.Rational(p.numerator, p.denominator) * sp.exp(t * v) for v, p in values_probs)
    cgf = sp.log(m)
    return sp.simplify(sp.diff(cgf, t, k).subs(t, 0))
