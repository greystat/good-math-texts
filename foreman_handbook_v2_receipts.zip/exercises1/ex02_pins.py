"""Receipt for Exercise ex:cls-pins (the pins of the atom formula of six lists).

For each list binom([n],r) the pins of Corollary cor:atomwall are written with integer coefficients:
the two letter totals and the loads at the marks e != g, g = n (Definition def:shares).
Printed: the Smith normal form, a maximal minor equal to +-1 (the certificate), the absolute values of all
maximal minors with their counts, and for the lists with a minor of absolute value at least 2 a point of
the fibre at integer data where the shares outside such a minor are integers and some share is not.
"""
from itertools import combinations
from collections import Counter
import sympy as sp
from sympy.matrices.normalforms import smith_normal_form
from listkit import uniform, name


def pin_matrix(L, g):
    cols, labels = [], []
    for T in L.B:
        cols.append([1, 0] + [1 if e in T else 0 for e in L.E if e != g])
        labels.append('a' + name(T))
    for T in L.B:
        cols.append([0, 1] + [0 if e in T else 1 for e in L.E if e != g])
        labels.append('b' + name(T))
    return sp.Matrix(cols).T, labels


def show(M, cols, labels):
    sub = M[:, list(cols)]
    print('    columns', [labels[c] for c in cols])
    for row in sub.tolist():
        print('     ', row)
    print('    det =', sub.det())


lists = [(2, 1), (3, 1), (3, 2), (4, 2), (4, 3), (5, 2)]
for (n, r) in lists:
    L = uniform(n, r)
    g = n
    M, labels = pin_matrix(L, g)
    q = M.shape[0]
    print('=== binom([%d],%d): %d bases, pin matrix %dx%d, g = %d' % (n, r, len(L.B), q, M.shape[1], g))
    print('  Smith normal form diagonal:', [smith_normal_form(M, domain=sp.ZZ)[i, i] for i in range(q)])
    # certificate: the first maximal minor equal to +-1 in the order that takes the a-columns first
    cert = None
    for cols in combinations(range(M.shape[1]), q):
        if abs(M[:, list(cols)].det()) == 1:
            cert = cols
            break
    show(M, cert, labels)
    cnt = Counter(abs(M[:, list(cols)].det()) for cols in combinations(range(M.shape[1]), q))
    print('  |maximal minors| with counts:', dict(sorted(cnt.items())))

# points with non-integer shares
sh = {}
for (n, r, cols_names, data) in [
        (4, 2, ['a12', 'a34', 'b13', 'b14', 'b24'], dict(m=[1, 1, 1, 1], s=1, t=1)),
        (5, 2, None, dict(m=[1, 1, 1, 1, 1], s=1, t=1))]:
    L = uniform(n, r)
    M, labels = pin_matrix(L, n)
    q = M.shape[0]
    target = 2 if n == 4 else 3
    if cols_names is None:
        for cols in combinations(range(M.shape[1]), q):
            if abs(M[:, list(cols)].det()) == target:
                cols_names = [labels[c] for c in cols]
                break
    cols = [labels.index(c) for c in cols_names]
    print('=== binom([%d],%d): the minor on' % (n, r), cols_names)
    show(M, cols, labels)
    rhs = sp.Matrix([data['s'], data['t']] + data['m'][:-1])
    sol = M[:, cols].LUsolve(rhs)
    print('  data (m; s, t) =', data, ' the other shares 0; the shares on the minor:',
          dict(zip(cols_names, list(sol))))
    # every share is then fixed; check the pins and the loads
    full = [0] * M.shape[1]
    for c, v in zip(cols, sol):
        full[c] = v
    print('  pins hold:', list(M * sp.Matrix(full)) == list(rhs))
