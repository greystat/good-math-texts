"""Receipt for Exercise ex:con-widthbound (the width of the marks left in place).

Builds substitutions (Definition def:substitution) by their bases and prints:
- the eight-mark list binom({b1,b2,h1,h2},2)<b1,b2,A1,A2>, A_i = binom({x_i,y_i,z_i,g_i},2): its rank, number of
  bases, the windows and widths of the subsets of L = {b1,b2} against the core and against the bound
  |L minus S| + |H'| of Corollary cor:mot-widthbound, the sets D(S), D*(S) of Theorem thm:substwalls, and the
  letter K along B = {b1,b2};
- the five-mark list of Exercise ex:cls-five as binom({1,2,h},1)<1,2,binom({3,4,5,g},2)>;
- the cores binom(B + {h_1..h_c}, c), |B| = c, with dual-pair cells at the h_i, for c = 1, 2, 3: the width of B.
"""
from itertools import combinations, product
import sympy as sp
from listkit import List, uniform, name


def substitute(core, left, cells):
    """core: List on left + list(cells); left: marks left in place; cells: {h: (cell List, hinge g)}."""
    bases = set()
    for T in core.B:
        choices = [[frozenset([l])] if l in T else [frozenset()] for l in left]
        for h, (A, g) in cells.items():
            if h in T:
                choices.append([X for X in A.B if g not in X])
            else:
                choices.append([X - {g} for X in A.B if g in X])
        for pick in product(*choices):
            bases.add(frozenset().union(*pick))
    marks = list(left) + [e for h, (A, g) in cells.items() for e in A.E if e != g]
    return List(marks, bases)


def cell(i):
    return uniform(4, 2, ('x%d' % i, 'y%d' % i, 'z%d' % i, 'g%d' % i)), 'g%d' % i


core8 = uniform(4, 2, ('b1', 'b2', 'h1', 'h2'))
M8 = substitute(core8, ['b1', 'b2'], {'h1': cell(1), 'h2': cell(2)})
print('eight-mark list: marks', M8.n, ' rank', M8.r, ' bases', len(M8.B))
L = ['b1', 'b2']
for k in (1, 2):
    for S in combinations(L, k):
        print('  S =', S, ' window in M:', M8.window(S), ' width', M8.width(S), ' width in the core', core8.width(S),
              ' bound', len(set(L) - set(S)) + 2, ' d, d* in M:', M8.d(S), M8.dstar(S), ' in the core:', core8.d(S), core8.dstar(S))
# the cells are dual pairs (Proposition prop:mot-dualletters): deletion binom(R,2), contraction binom(R,1)
A, g = cell(1)
print('cell A1: deletion', [name(T) for T in A.delete(g).B], ' contraction', [name(T) for T in A.contract(g).B],
      ' dual pair:', set(A.contract(g).B) == set(A.delete(g).dual().B))
# the letter along B: K(tau a_b1, tau a_b2, rest)
al = M8.symbols()
tau = sp.Symbol('tau')
Ks = sp.expand(M8.K().subs({al['b1']: tau * al['b1'], al['b2']: tau * al['b2']}, simultaneous=True))
R1 = [al[v] for v in ('x1', 'y1', 'z1')]
R2 = [al[v] for v in ('x2', 'y2', 'z2')]
e1 = lambda R: sum(R)
e2 = lambda R: R[0] * R[1] + R[0] * R[2] + R[1] * R[2]
g1, g2 = e2(R1) / e1(R1), e2(R2) / e1(R2)
pred = e1(R1) * e1(R2) * (g1 * g2 + tau * (al['b1'] + al['b2']) * (g1 + g2) + tau ** 2 * al['b1'] * al['b2'])
print('K along B equals e1(R1) e1(R2) (g1 g2 + tau (a_b1 + a_b2)(g1 + g2) + tau^2 a_b1 a_b2):', sp.simplify(Ks - pred) == 0)
# the five-mark list
core5 = uniform(3, 1, (1, 2, 'h'))
A5 = uniform(4, 2, (3, 4, 5, 'g'))
P5 = substitute(core5, [1, 2], {'h': (A5, 'g')})
print('five-mark list: bases', sorted(name(T) for T in P5.B), ' c({1,2}) =', P5.width({1, 2}), ' core width', core5.width({1, 2}), ' bound', 0 + 1)
# every width occurs
for c in (1, 2, 3):
    Bm = ['b%d' % i for i in range(1, c + 1)]
    H = ['h%d' % i for i in range(1, c + 1)]
    core = uniform(2 * c, c, tuple(Bm + H))
    M = substitute(core, Bm, {H[i]: cell(i + 1) for i in range(c)})
    print('c =', c, ': marks', M.n, ' rank', M.r, ' bases', len(M.B), ' window of B:', M.window(Bm), ' width', M.width(Bm),
          ' core width', core.width(Bm), ' bound', c)
