"""Receipt for Exercise ex:cls-five (the list P_5 of rank two on five marks without the basis {1,2}).

Prints the bases and letters, the occupations, the bijections that carry or exchange the list and their orbits,
the widths of the two classes, the patterns of the bunch {1,2} with their probabilities and children, the peel
and the record at the centre and at a lean, the minors and the two cells of Theorem thm:widthone, the hinge
values and their ratio, and the substitution binom({1,2,h},1)<1,2,binom({3,4,5,g},2)>.
"""
from itertools import combinations
import sympy as sp
from listkit import List, uniform, name

E = (1, 2, 3, 4, 5)
P5 = List(E, [frozenset(c) for c in combinations(E, 2) if set(c) != {1, 2}])
al = P5.symbols()
print('bases:', [name(T) for T in P5.B], len(P5.B))
e1, e2, e3 = [sp.Add(*[sp.Mul(*[al[i] for i in c]) for c in combinations(E, k)]) for k in (1, 2, 3)]
print('K - (e2 - a1 a2) =', sp.expand(P5.K() - (e2 - al[1] * al[2])), '; Psi - (e3 - a3 a4 a5) =', sp.expand(P5.Psi() - (e3 - al[3] * al[4] * al[5])))
print('occupations R_e(1):', {e: P5.occupation(e) for e in E})
car, exc = P5.carrying(), P5.exchanging()
print('carrying bijections:', len(car), ' orbits:', P5.orbits(car), ' exchanging bijections:', len(exc))
B, R = frozenset({1, 2}), frozenset({3, 4, 5})
print('widths: c(B) =', P5.width(B), ' c(R) =', P5.width(R), ' window of B:', P5.window(B), ' d(B) =', P5.d(B), ' d*(B) =', P5.dstar(B))
print('ranks: r(B) =', P5.rank(B), ' r(R) =', P5.rank(R), ' r =', P5.r)
s, t, sig, dl = sp.symbols('s t sigma delta')
peel = {}
for p in P5.patterns(B):
    ch = P5.child(B, p)
    pr = P5.pattern_probability(B, p)
    key = tuple(name(T) for T in ch.B)
    print('  pattern', name(p), ' probability', pr, ' child bases on R:', key, ' K =', ch.K(), ' Psi =', ch.Psi())
    peel.setdefault(key, [0, 0])
    peel[key][0] += sp.Rational(pr.numerator, pr.denominator) * s
    peel[key][1] += sp.Rational(pr.numerator, pr.denominator) * t
print('peel (merged children):', {k: v for k, v in peel.items()})
xs = {e: al[e] for e in (3, 4, 5)}
f1 = al[3] + al[4] + al[5]
f2 = al[3] * al[4] + al[3] * al[5] + al[4] * al[5]
word_centre = sp.simplify((f2 ** (-s / 3) * f1 ** (-s / 3) * (f1 * f2) ** (-2 * s / 3)))
print('peel word at the centre s = t:', sp.powsimp(word_centre, force=True))
word_lean = sp.powsimp(f2 ** (-s / 3) * f1 ** (-t / 3) * f1 ** (-2 * s / 3) * f2 ** (-2 * t / 3), force=True)
print('peel word at (s, t):', word_lean)
print('balance of the peel at the centre: sum of exponent times degree =', sp.simplify(s / 3 * (2 + 1) + 2 * s / 3 * (1 + 2)), ' = m_R = 3 sigma')
# minors (Definition def:minors) and cells (Theorem thm:widthone)
MB, MR = P5.restriction(B), P5.restriction(R)
cB, cR = P5.contraction(B), P5.contraction(R)
print('M|B:', [name(T) for T in MB.B], ' M/R:', [name(T) for T in cR.B], ' M|R:', [name(T) for T in MR.B], ' M/B:', [name(T) for T in cB.B])
gK = sp.simplify(MB.K() / cR.K())
gP = sp.simplify(cR.Psi() / MB.Psi())
print('gamma^K_B =', gK, ' gamma^Psi_B =', sp.factor(gP), ' rho_B =', sp.factor(sp.simplify(gP / gK)))
u = sp.Symbol('u', positive=True)
print('rho_B on the shape (u, 1-u):', sp.factor(sp.simplify((gP / gK).subs({al[1]: u, al[2]: 1 - u}))))
cellB = List((1, 2, 'g'), [T for T in MB.B] + [frozenset(X) | {'g'} for X in cR.B])
cellR = List((3, 4, 5, 'g'), [T for T in MR.B] + [frozenset(Y) | {'g'} for Y in cB.B])
print('cell of the bunch:', [name(T) for T in cellB.B], ' = binom({1,2,g},1):', set(cellB.B) == set(uniform(3, 1, (1, 2, 'g')).B))
print('cell of the room:', [name(T) for T in cellR.B], ' = binom({3,4,5,g},2):', set(cellR.B) == set(uniform(4, 2, (3, 4, 5, 'g')).B))
A = uniform(4, 2, (3, 4, 5, 'g'))
Adel, Acon = A.delete('g'), A.contract('g')
print('A minus g:', [name(T) for T in Adel.B], ' A/g:', [name(T) for T in Acon.B], ' dual pair:', set(Acon.B) == set(Adel.dual().B))
# the substitution binom({1,2,h},1) <1, 2, A at h> (Definition def:substitution)
core = uniform(3, 1, (1, 2, 'h'))
subst = set()
for T in core.B:
    parts = [frozenset([x]) for x in (1, 2) if x in T]
    if 'h' in T:
        for X in Adel.B:
            subst.add(frozenset().union(*parts, X))
    else:
        for X in Acon.B:
            subst.add(frozenset().union(*parts, X))
print('substitution bases:', sorted(name(T) for T in subst), ' equal to the bases of P5:', subst == set(P5.B))
