"""Receipt for Exercise ex:smallc-box: the centre of binom([3],1) by the box.

Run: python3 ex19_centre_box.py     (sympy; exact arithmetic over Q(k) and Q)
Prints: the box B_2(1,1) modulo S_3 and the Cremona (symbols, orbits, relations, rank), the pivots and the free
orbits, the spanning set at s = 1, the two targets and their reductions, the matrix B(k), a certificate supported on
the stems and its verification, the rows and the law (Proposition prop:rays-lawrows), B(infinity) and its eigenvectors
at the native gauges; then the closing relations alone at the point (1, w, w^2): their free orbits for R = 3..7 and the
residuals of the law at k = 7, 10, 23/3.
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from boxkit import *
from fractions import Fraction as Fr

say = print
tb = Table(3, [{0}, {1}, {2}])
ray = Ray(tb, (1, 1, 1), 1, 1)
G = [perm_map((1, 0, 2), 3), perm_map((0, 2, 1), 3), cremona_map(3)]
box = Box(ray, 2, 1, 1, G)
n = 3
say('=' * 100)
say('1. The box B_2(1,1) of the centre ray, modulo S_3 and the Cremona')
say('   walls of the direction:', {tuple(sorted(e + 1 for e in S)): v for S, v in ray.kappa1.items()})
by_level = {}
for s in box.syms:
    by_level.setdefault((s[3], s[4]), []).append(s)
for lev in sorted(by_level):
    reps = sorted({box.orbit_of[s] for s in by_level[lev]})
    say(f'   level {lev}: {len(by_level[lev])} symbols in {len(reps)} orbits:',
        ', '.join(f'{r[:3]} (deg {box.deg[r]}, {box.orbit_size[r]})' for r in sorted(reps, key=lambda r: (box.deg[r], r))))
say('   symbols:', len(box.syms), ' orbits:', len(box.orbits), ' stems (Laurent, wall degree <= 2):', len(box.stems))
nK = sum(1 for d, _ in box.relations if d[0] == 'K'); nP = sum(1 for d, _ in box.relations if d[0] == 'Psi'); nM = sum(1 for d, _ in box.relations if d[0] == 'MR')
say(f'   relations: {nK} letter identities for K, {nP} for Psi, {nM} mark relations of stems; total {len(box.relations)}')
# relations modulo G: distinct orbit-averaged rows
rows = {}
for d, rel in box.relations:
    r = box.to_orbits(rel)
    key = tuple(sorted((x, str(c)) for x, c in r.items()))
    rows[key] = r
say('   distinct orbit-averaged relations:', len(rows))
piv = box.eliminate()
say('   rank of the relations modulo G:', len(piv), ';  free orbits:', [(r[:3], r[3:], box.deg[r]) for r in box.free])
say('=' * 100)
say('2. The spanning set at s = 1 and the targets')
lau_free = [r for r in box.free if r[3:] == (0, 0)]
span = sorted([r for r in lau_free if box.deg[r] <= 1], key=lambda r: (box.deg[r], r))
say('   free Laurent orbits:', [(r[:3], box.deg[r]) for r in lau_free], '; spanning set at s = 1:', [r[:3] for r in span])
b1rep = (-1, 0, 1, 0, 0) if (-1, 0, 1, 0, 0) in box.orbit_of else None
b = [box.average((0, 0, 0, 0, 0)), box.average(box.orbit_of[(1, -1, 0, 0, 0)])]
names = ['1', 'b1']
Bmat = []
for i, bi in enumerate(b):
    tgt = box.times_finv(bi)
    nf = box.normal_form(tgt)
    say(f'   target f^-1 {names[i]}: monomials {len(tgt)}; normal form:', {r[:3]: fk_str(c) for r, c in nf.items()})
    assert set(nf) <= set(span), 'not accepted'
    Bmat.append([nf.get(r, ZERO) for r in span])
say('   the box is accepted at s = 1.  B(k) =', [[fk_str(x) for x in row] for row in Bmat])
say('   (coordinates on the orbit averages: the average of an orbit has coordinate 1)')

say('=' * 100)
say('3. A certificate supported on the stems (Theorem thm:raybox(ii)) for the second row')
a1, a2, a3 = sp.symbols('a1 a2 a3')
A = (a1, a2, a3)
e1 = a1 + a2 + a3; e2 = a1 * a2 + a1 * a3 + a2 * a3; e3 = a1 * a2 * a3
c = [1 - A[e] / e1 - A[e] * (e1 - A[e]) / e2 for e in range(3)]
finv = e1 * e2 / e3
bb1 = sum(A[i] / A[j] for i in range(3) for j in range(3) if i != j) / 6
B21, B22 = [FK.to_sympy(x) for x in Bmat[1]]
target_fn = sp.together(finv * bb1 - B21 - B22 * bb1)
# ansatz: G_1 a Laurent polynomial on the stems, symmetric in a2,a3; G_e its image under the transposition (1 e)
stems = [s[:3] for s in box.stems]
orbs23 = []
seen = set()
for v in stems:
    if v in seen: continue
    o = sorted({v, (v[0], v[2], v[1])}); seen |= set(o); orbs23.append(o)
cs = sp.symbols('x0:%d' % len(orbs23))
G1 = sum(cs[i] * sum(a1 ** v[0] * a2 ** v[1] * a3 ** v[2] for v in o) for i, o in enumerate(orbs23))
def swap(P, e):
    if e == 0: return P
    return P.subs({A[0]: A[e], A[e]: A[0]}, simultaneous=True)
Gs = [swap(G1, e) for e in range(3)]
D = lambda P, e: A[e] * sp.diff(P, A[e])
expr = sum(k * c[e] * Gs[e] + D(Gs[e], e) for e in range(3)) - target_fn
num = sp.numer(sp.together(expr))
eqs = sp.Poly(sp.expand(num), a1, a2, a3).coeffs()
sol = sp.solve(eqs, cs, dict=True)
say('   stems modulo the transposition of marks 2 and 3:', len(orbs23), ' unknowns; linear equations', len(eqs), '; solution families:', len(sol))
s0 = sol[0]
freevars = [x for x in cs if x not in s0]
say('   free parameters of the solution:', len(freevars))
# the source's certificate (notebook s23, Example 23.15)
G1src = ((a2 ** 2 + a3 ** 2) / (6 * (k - 2) * a1 ** 2) + (5 * k ** 2 - 6 * k - 4) * a2 * a3 / (6 * (k + 1) * (k - 2) ** 2 * a1 ** 2)
         + (3 * k - 4) / (6 * (k + 1) * (k - 2) ** 2) * (a3 ** 2 / (a1 * a2) + a2 ** 2 / (a1 * a3))
         + (5 * k - 9) / (6 * (k - 2) ** 2) * (a2 + a3) / a1 + (3 * k - 4) / (6 * (k + 1) * (k - 2)) * (a3 ** 2 / a2 ** 2 + a2 ** 2 / a3 ** 2))
Gsrc = [swap(G1src, e) for e in range(3)]
chk = sp.simplify(sp.together(sum(k * c[e] * Gsrc[e] + D(Gsrc[e], e) for e in range(3)) - target_fn))
say('   the certificate G_1 of the display, with G_2, G_3 its images under (1 2), (1 3), satisfies the identity:', chk == 0)
numG = sp.numer(sp.together(G1src * a1 ** 2 * a2 ** 2 * a3 ** 2))
denG = sp.denom(sp.together(G1src * a1 ** 2 * a2 ** 2 * a3 ** 2))
assert not denG.has(a1) and not denG.has(a2) and not denG.has(a3)
supp = sorted({tuple(m) for m in sp.Poly(sp.expand(numG), a1, a2, a3).monoms()})
say('   support of G_1 (exponents) and wall degrees:', [((v[0] - 2, v[1] - 2, v[2] - 2), str(ray.wdeg((v[0] - 2, v[1] - 2, v[2] - 2, 0, 0)))) for v in supp])
say('   it lies in five orbits of stems under S_3 and the Cremona:', len({box.orbit_of[(v[0] - 2, v[1] - 2, v[2] - 2, 0, 0)] for v in supp}))
# the homogeneous solutions of the ansatz: the space of G_1 with zero right side
hom = sp.solve([sp.Poly(sp.expand(sp.numer(sp.together(sum(k * c[e] * Gs[e] + D(Gs[e], e) for e in range(3))))), a1, a2, a3).coeffs()][0], cs, dict=True)
say('   homogeneous solutions of the ansatz (zero right side): dimension', len([x for x in cs if x not in hom[0]]))
pt = {a1: 1, a2: 2, a3: 4, k: sp.Rational(1, 3)}
say('   at alpha=(1,2,4), k=1/3: f^-1 b1 =', sp.nsimplify((finv * bb1).subs(pt)), ', B21 + B22 b1 =', sp.nsimplify((B21 + B22 * bb1).subs(pt)),
    ', both sides of the certificate =', sp.nsimplify(target_fn.subs(pt)), sp.nsimplify(sum(k * c[e] * Gsrc[e] + D(Gsrc[e], e) for e in range(3)).subs(pt)))
say('   first row: f^-1 = 3 + 6 b1 identically:', sp.simplify(finv - 3 - 6 * bb1) == 0)

say('=' * 100)
say('4. The rows and the law (Proposition prop:rays-lawrows)')
Bk = sp.Matrix([[FK.to_sympy(x) for x in row] for row in Bmat])
w0 = sp.Matrix([[1, 0]])
w1 = sp.simplify(w0 * Bk)
w2 = sp.simplify(w1.subs(k, k - 1) * Bk)
say('   w0 =', list(w0), ' w1 =', [sp.factor(x) for x in w1], ' w2 =', [sp.factor(x) for x in w2])
q0, q1, q2 = sp.symbols('q0 q1 q2')
solq = sp.solve(list(q0 * w0 + q1 * w1 + q2 * w2), [q0, q1], dict=True)[0]
qs = [sp.factor(solq[q0].subs(q2, 1)), sp.factor(solq[q1].subs(q2, 1)), 1]
den = sp.lcm([sp.denom(sp.together(x)) for x in qs])
qs = [sp.factor(sp.cancel(x * den)) for x in qs]
say('   (q0, q1, q2) =', qs)
p = [sp.expand(qs[2 - j].subs(k, k + 2)) for j in range(3)]
say('   p_j(k) = q_(2-j)(k+2):', p)
say('   det B(k) =', sp.factor(Bk.det()), ';  q0 det W(k) = q2 det W(k-1) det B(k):',
    sp.simplify(qs[0] * sp.Matrix([list(w0), list(w1)]).det() - qs[2] * sp.Matrix([list(w0), list(w1.subs(k, k - 1))]).det() * Bk.det()) == 0)
Binf = Bk.applyfunc(lambda x: sp.limit(x, k, sp.oo))
say('   B(infinity) =', Binf.tolist(), '; eigen:', Binf.eigenvects())
for eta in [(1, 1, 1), (-1, 1, 1)]:
    bv = sp.Rational(sum(sp.Rational(eta[i], eta[j]) for i in range(3) for j in range(3) if i != j), 6)
    fv = sp.Rational(eta[0] * eta[1] * eta[2], sum(eta) * (eta[0] * eta[1] + eta[0] * eta[2] + eta[1] * eta[2]))
    say(f'   at {eta}: (b_1, b_2) values = (1, {bv}); f = {fv}; B(inf) beta = {list(Binf * sp.Matrix([1, bv]))}')

# closings of the spanning set (Theorem thm:closings): C_j(1) = x_j, C_j(b1) = (x_(j+1) - 3 x_j)/6 by the first row
from math import factorial as _fa
def _cl(j):
    return sum((_fa(j) // (_fa(a) * _fa(b) * _fa(j - a - b))) ** 2 for a in range(j + 1) for b in range(j + 1 - a))
_x = [_cl(j) for j in range(15)]
_cb = [Fr(_x[j + 1] - 3 * _x[j], 6) for j in range(14)]
_ok = True
for j in range(12):
    Bm = [[Fr(str(Bk[i, l].subs(k, -j))) for l in range(2)] for i in range(2)]
    _ok = _ok and [Bm[0][0] * _x[j] + Bm[0][1] * _cb[j], Bm[1][0] * _x[j] + Bm[1][1] * _cb[j]] == [Fr(_x[j + 1]), _cb[j + 1]]
say('   closings: C_j(b1) = (x_(j+1) - 3 x_j)/6 =', [str(z) for z in _cb[:7]], '; C_(j+1)(b) = B(-j) C_j(b) for 0 <= j < 12:', _ok)

say('=' * 100)
say('5. The closing relations alone (Proposition prop:box-closing)')
finv_poly = ray.finv()
say('   f^-1 =', finv_poly)
wpt = sp.Rational(-1, 2) + sp.sqrt(3) * sp.I / 2
zpt = (1, wpt, wpt ** 2)
def ev(v): return sp.nsimplify(sp.expand_complex(zpt[0] ** v[0] * zpt[1] ** v[1] * zpt[2] ** v[2]))
say('   K(z), Psi(z) at z = (1,w,w^2):', sp.expand(sum(zpt)), sp.expand(zpt[0] * zpt[1] + zpt[0] * zpt[2] + zpt[1] * zpt[2]))
Lperm = [perm_map(bt, 3) for bt in [(1, 0, 2), (0, 2, 1)]] + [cremona_map(3)]
def laurent_orbit(v):
    orb = {v + (0, 0)}; fr = [v + (0, 0)]
    while fr:
        x = fr.pop()
        for phi in Lperm:
            y = phi(x)
            if y not in orb: orb.add(y); fr.append(y)
    return min(orb), orb
def closing_reduce(R, kval):
    """eliminate the closing relations of the Laurent monomials alpha^w of wall degree <= R-1 at the strength kval,
    on the invariant Laurent combinations of wall degree <= R; return (pivot dict, free orbits, deg, orbit sizes)"""
    lau = [(x, y, -x - y) for x in range(-R, R + 1) for y in range(-R, R + 1) if ray.wdeg((x, y, -x - y, 0, 0)) <= R]
    reps, orb_of, size = {}, {}, {}
    for v in lau:
        rep, orb = laurent_orbit(v)
        for x in orb: orb_of[x[:3]] = rep
        size[rep] = len(orb)
    degs = {rep: ray.wdeg(rep) for rep in set(orb_of.values())}
    order = sorted(set(orb_of.values()), key=lambda r: (degs[r], r), reverse=True)
    pos = {r: i for i, r in enumerate(order)}
    piv = {}
    def red(row):
        row = dict(row)
        while True:
            cand = [r for r in row if r in piv]
            if not cand: return row
            q = min(cand, key=lambda r: pos[r]); cq = row.pop(q)
            for r2, c2 in piv[q].items():
                if r2 == q: continue
                row[r2] = row.get(r2, 0) - cq * c2
                if row[r2] == 0: del row[r2]
    for w in lau:
        if ray.wdeg(w + (0, 0)) > R - 1: continue
        for e in range(3):
            row = {}
            for v, lv in finv_poly.items():
                x = tuple(w[i] + v[i] for i in range(3))
                rep = orb_of[x]
                row[rep] = row.get(rep, 0) + lv * (w[e] + (1 - kval) * v[e])
            row = {r: cc for r, cc in row.items() if cc != 0}
            row = red(row)
            if row:
                lead = min(row, key=lambda r: pos[r]); inv = Fr(1) / row[lead]
                piv[lead] = {r: cc * inv for r, cc in row.items()}
    free = [r for r in order if r not in piv]
    return piv, free, degs, size, orb_of, red
for R in range(3, 8):
    piv_, free_, degs_, size_, orb_of_, red_ = closing_reduce(R, Fr(9))
    say(f'   R = {R}: free orbits of wall degree <= {R - 1}:', [r[:3] for r in free_ if degs_[r] <= R - 1], ' (of degree R:', len([r for r in free_ if degs_[r] == R]), ')')
def law_element(kk):
    """k^2 f^-2 - (10k^2+10k+3) f^-1 + 9(k+1)^2, read at the strength k+2, as a Laurent combination"""
    f1 = finv_poly
    f2 = {}
    for v, lv in f1.items():
        for w_, lw in f1.items():
            x = tuple(v[i] + w_[i] for i in range(3)); f2[x] = f2.get(x, 0) + lv * lw
    out = {}
    for x, cx in f2.items(): out[x] = out.get(x, 0) + kk * kk * cx
    for x, cx in f1.items(): out[x] = out.get(x, 0) - (10 * kk * kk + 10 * kk + 3) * cx
    out[(0, 0, 0)] = out.get((0, 0, 0), 0) + 9 * (kk + 1) ** 2
    return out
for kk in (Fr(7), Fr(10), Fr(23, 3)):
    piv_, free_, degs_, size_, orb_of_, red_ = closing_reduce(5, kk + 2)
    el = law_element(kk)
    row = {}
    for x, cx in el.items():
        rep = orb_of_[x]; row[rep] = row.get(rep, 0) + cx
    nf = red_(row)
    # coordinates on the orbit averages; b1 = average of {a_i/a_j}, b2 = average of {a_i^2/a_j^2}
    say(f'   law at k = {kk} read at the strength {kk + 2}: residual', {r[:3]: str(cc) for r, cc in nf.items()})
    val = 0
    for r, cc in nf.items():
        vz = sp.nsimplify(sp.expand_complex(sum(ev(x[:3]) for x in laurent_orbit(r[:3])[1]) / len(laurent_orbit(r[:3])[1])))
        val += sp.Rational(cc.numerator, cc.denominator) * vz
    say(f'      at z = (1,w,w^2): {sp.nsimplify(val)};  9(k+1)^2 = {9 * (kk + 1) ** 2}')
for Rr in range(3, 8):
    piv_, free_, degs_, size_, orb_of_, red_ = closing_reduce(Rr, Fr(9))
    el = law_element(Fr(7)); row = {}
    for x_, cx in el.items():
        rep = orb_of_[x_]; row[rep] = row.get(rep, 0) + cx
    say(f'   R = {Rr}: the law at k = 7 read at the strength 9 reduces to', {r[:3]: str(cc) for r, cc in red_(row).items()})
say('   b1(z), b2(z):', [sp.nsimplify(sp.expand_complex(sum(ev(x[:3]) for x in laurent_orbit(v)[1]) / 6)) for v in [(1, -1, 0), (2, -2, 0)]])
