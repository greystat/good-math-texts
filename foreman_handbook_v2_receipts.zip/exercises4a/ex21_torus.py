"""Receipt for Exercise ex:smallc-torus: the torus at three marks.

Run: python3 ex21_torus.py      (sympy and fractions for the exact parts; mpmath for the labelled checks)
Prints: the torus stride and its critical points with their Hessians; the zeros of K on the torus and the quadratic
form there; the residue R of the torus value at k = 1; T(-j) = closings; the reflected solution U and its values
c(K); the frame W(P, U) at the integers; the constants of the connection, alpha = 3R^2/2 and b_0 = T_0 + R log 9;
the Morse constants at the maximum and at the saddles; then the checks: T by its one-mark form, (L) on T at
non-integral k, the connection at k = 0.1, ..., 0.9, T_0, the torus mean of log|K| and the arc integral S_2.
"""
import sympy as sp
import mpmath as mp
from fractions import Fraction as Fr
from math import factorial

say = print
th1, th2, k = sp.symbols('theta1 theta2 k', real=True)
say('=' * 100)
say('1. The stride on the torus (chart alpha_3 = 1, alpha_1 = e^{i theta1}, alpha_2 = e^{i theta2})')
F = sp.expand(3 + 2 * sp.cos(th1) + 2 * sp.cos(th2) + 2 * sp.cos(th1 - th2))     # |K|^2
Kc = 1 + sp.exp(sp.I * th1) + sp.exp(sp.I * th2)
say('   |K|^2 - F =', sp.simplify(sp.expand_complex(Kc * sp.conjugate(Kc)) - F))
say('   f = e3/(e1 e2) equals |K|^-2 on the torus: Psi = e3 * conj(K) there:',
    sp.simplify(sp.expand_complex((sp.exp(sp.I * th1) * sp.exp(sp.I * th2) + sp.exp(sp.I * th1) + sp.exp(sp.I * th2))
                                   - sp.exp(sp.I * (th1 + th2)) * sp.conjugate(Kc))) == 0)
crit = [(0, 0), (sp.pi, 0), (0, sp.pi), (sp.pi, sp.pi), (2 * sp.pi / 3, 4 * sp.pi / 3), (4 * sp.pi / 3, 2 * sp.pi / 3)]
grad = [sp.diff(F, v) for v in (th1, th2)]
Hes = sp.Matrix(2, 2, lambda i, j: sp.diff(F, [th1, th2][i], [th1, th2][j]))
for c in crit:
    sub = {th1: c[0], th2: c[1]}
    say(f'   point {c}: F = {sp.nsimplify(F.subs(sub))}, grad = {[sp.nsimplify(g.subs(sub)) for g in grad]}, '
        f'Hessian of F = {[[sp.nsimplify(Hes[i, j].subs(sub)) for j in range(2)] for i in range(2)]}, det = {sp.nsimplify(Hes.det().subs(sub))}')
# all critical points: sin th1 + sin(th1 - th2) = 0, sin th2 - sin(th1 - th2) = 0
say('   critical points of F on the torus: the six above (solving grad F = 0 by cases, see the solution)')
# Hessian of u = log t = -log F at the saddles and at the maximum
for c in [(0, 0), (sp.pi, 0)]:
    sub = {th1: c[0], th2: c[1]}
    Hu = sp.Matrix(2, 2, lambda i, j: sp.diff(-sp.log(F), [th1, th2][i], [th1, th2][j]).subs(sub))
    say(f'   Hessian of u = -log F at {c}: {[[sp.nsimplify(Hu[i, j]) for j in range(2)] for i in range(2)]}, det = {sp.nsimplify(Hu.det())}')
say('   at a zero of K, |K|^2 = d1^2 - d1 d2 + d2^2 + O(|d|^3), the form of determinant',
    sp.Matrix([[1, -sp.Rational(1, 2)], [-sp.Rational(1, 2), 1]]).det())
z = (2 * sp.pi / 3, 4 * sp.pi / 3)
d1, d2 = sp.symbols('d1 d2')
quad2 = sp.expand(sp.series(F.subs({th1: z[0] + d1, th2: z[1] + d2}).subs({d1: d1 * sp.Symbol('e'), d2: d2 * sp.Symbol('e')}), sp.Symbol('e'), 0, 3).removeO()).subs(sp.Symbol('e'), 1)
say('   check: the quadratic part of F at (2pi/3, 4pi/3) is', sp.nsimplify(sp.simplify(quad2)))

say('=' * 100)
say('2. The residue at k = 1, the closings, U and the frame')
R = -1 / (sp.sqrt(3) * sp.pi)
say('   R = (two zeros) (2 pi / sqrt(3/4)) (1/2) / (4 pi^2) with the sign of 1/(1-k):', sp.simplify(-2 * 2 * sp.pi / sp.sqrt(sp.Rational(3, 4)) / 2 / (4 * sp.pi ** 2)), '=', R)
def closing(j):
    return sum((factorial(j) // (factorial(a) * factorial(b) * factorial(j - a - b))) ** 2 for a in range(j + 1) for b in range(j + 1 - a))
x = [closing(j) for j in range(12)]
say('   T(-j) = CT(|K|^{2j}) = x_j:', x)
c = {K: Fr(x[K - 1], 9 ** (K - 1)) for K in range(1, 12)}
say('   U(K) = 9^(1-K) T(1-K) = 9^(1-K) x_(K-1) = c(K):', [str(c[K]) for K in range(1, 8)])
# the law (L) and its rational solutions c, r
def run(x1, x2, KM):
    v = {1: Fr(x1), 2: Fr(x2)}
    for kk in range(1, KM - 1):
        v[kk + 2] = ((10 * kk * kk + 10 * kk + 3) * v[kk + 1] - kk * kk * v[kk]) / (9 * (kk + 1) ** 2)
    return v
cc = run(1, Fr(1, 3), 12); rr = run(0, Fr(-2, 3), 12)
say('   the solution of (L) with c(1) = 1, c(2) = 1/3 agrees with U at K <= 11:', all(cc[K] == c[K] for K in range(1, 12)))
say('   W(P, U)(K) = W(r, c)(K) = r(K)c(K+1) - r(K+1)c(K) = (2/3) 9^(1-K)/K^2 for K <= 10:',
    all(rr[K] * cc[K + 1] - rr[K + 1] * cc[K] == Fr(2, 3) / 9 ** (K - 1) / K ** 2 for K in range(1, 11)))
alpha = sp.Rational(3, 2) * R ** 2
say('   alpha = (3/2) R^2 =', sp.simplify(alpha))
say('   the residue of T at k = 1 + j from the connection: R U(1+j) = R c(1+j):', [sp.simplify(R * sp.Rational(c[1 + j].numerator, c[1 + j].denominator)) for j in range(3)])

say('=' * 100)
say('3. The Morse constants on the torus (for the Fourier argument)')
# density of u = log t = -log F on the torus near its least value u_0 = -log 9: pi * J(0), J = 1/sqrt(det Hess u / 4) ... computed directly:
Hmax = sp.Matrix(2, 2, lambda i, j: sp.diff(-sp.log(F), [th1, th2][i], [th1, th2][j]).subs({th1: 0, th2: 0}))
n_u0 = sp.simplify(2 * sp.pi / sp.sqrt(Hmax.det()) / (4 * sp.pi ** 2))
say('   n(u_0+) = (area of {u - u_0 <= s}/ds) / (4 pi^2) = 2 pi / sqrt(det Hess u) / (4 pi^2) =', n_u0, '; t rho_T(t) at 1/9+, so rho_T(1/9+) =', sp.simplify(9 * n_u0))
say('   (2 pi)^-2 rho_f(1/9) = (2 pi)^-2 27 sqrt3 pi =', sp.simplify(27 * sp.sqrt(3) * sp.pi / (4 * sp.pi ** 2)))
Hsad = sp.Matrix(2, 2, lambda i, j: sp.diff(-sp.log(F), [th1, th2][i], [th1, th2][j]).subs({th1: sp.pi, th2: 0}))
a_log = sp.simplify(3 * 2 / sp.sqrt(-Hsad.det()) / (4 * sp.pi ** 2))
say('   log coefficient at u = 0: three saddles, each -(2/sqrt|det Hess u|) log|u| / (4 pi^2): a =', a_log)
say('   Fourier matching at frequency 0: pi a = Q/sqrt3 - i b_0 Q with Q = n(u_0+):  pi a =', sp.simplify(sp.pi * a_log), '; Q/sqrt3 =', sp.simplify(n_u0 / sp.sqrt(3)))

say('=' * 100)
say('Checks (floating point, not part of the solution)')
mp.mp.dps = 40
def I1(kk, a):
    """mean over theta of |a + e^{i theta}|^{-2k}, a >= 0"""
    if a < 1:
        return mp.hyp2f1(kk, kk, 1, a * a)
    return a ** (-2 * kk) * mp.hyp2f1(kk, kk, 1, 1 / (a * a))
def Tval(kk):
    """T(k) = (2/pi) int_0^2 I1(k, a) da / sqrt(4 - a^2), Re k < 1"""
    f = lambda a: I1(kk, a) / mp.sqrt(4 - a * a)
    return 2 / mp.pi * mp.quad(f, [0, 1, 2])
for j in range(4):
    say(f'   T(-{j}) by the one-mark form =', mp.nstr(Tval(mp.mpf(-j)), 20), ' x_j =', x[j])
for kk in (mp.mpf('-1.3'), mp.mpf('-2.7') + mp.mpf('0.4') * 1j):
    lhs = kk ** 2 * Tval(kk) - (10 * kk ** 2 + 10 * kk + 3) * Tval(kk + 1) + 9 * (kk + 1) ** 2 * Tval(kk + 2)
    say(f'   (L) on T at k = {mp.nstr(kk, 5)}:', mp.nstr(abs(lhs), 3))
# P at non-integral k from the gauge end: Beta sums at k + N, run back
mp.mp.dps = 60
g0 = 27 * mp.sqrt(3) * mp.pi
# recompute the germ coefficients directly from the operator in s (as in ex20)
s = sp.symbols('s')
b2 = s * (9 * s - 1) ** 2 * (9 * s + 8) / 81; b1 = (9 * s - 1) * (405 * s ** 2 + 270 * s - 8) / 81; b0 = (324 * s ** 2 + 135 * s - 10) / 9
bc = {(j, l): Fr(str(sp.Poly(sp.expand([b0, b1, b2][j]), s).coeff_monomial(s ** l))) for j in range(3) for l in range(5)}
def Rm_(m, X):
    return bc.get((0, m - 1), Fr(0)) + bc.get((1, m), Fr(0)) * X + bc.get((2, m + 1), Fr(0)) * X * (X - 1)
ee = [Fr(1)]
for N in range(1, 700):
    ee.append(-sum(Rm_(m, N - m) * ee[N - m] for m in range(1, min(N, 3) + 1)) / Rm_(0, N))
eg = [mp.mpf(z.numerator) / z.denominator / mp.mpf(9) ** m for m, z in enumerate(ee)]
def Pval(kk, N=120, M=220):
    """P(k) for real k > 0: Beta sums at k + N and k + N + 1, then (L) backwards"""
    def bs(K):
        return g0 * sum(eg[m] * mp.beta(K + 1, m + 1) for m in range(M)) / mp.mpf(9) ** (K + 1)
    hi = {N: bs(kk + N), N + 1: bs(kk + N + 1)}
    for i in range(N - 1, -1, -1):
        q = kk + i
        hi[i] = ((10 * q * q + 10 * q + 3) * hi[i + 1] - 9 * (q + 1) ** 2 * hi[i + 2]) / (q * q)
    return hi[0]
mp.mp.dps = 40
ell = Pval(mp.mpf(1))
say('   P(1) from the gauge end =', mp.nstr(ell, 30))
for kk in [mp.mpf(i) / 10 for i in range(2, 9)]:
    T_ = Tval(kk); U_ = 9 ** (1 - kk) * Tval(1 - kk); P_ = Pval(kk)
    resid = T_ - (P_ / (2 * mp.pi ** 2) - mp.cot(mp.pi * kk) / mp.sqrt(3) * U_)
    W = P_ * 9 ** (-kk) * Tval(-kk) - Pval(kk + 1) * U_
    say(f'   k = {mp.nstr(kk, 2)}: connection residual {mp.nstr(resid, 3)};  frame W(P,U) k^2 9^(k-1) = {mp.nstr(W * kk ** 2 * 9 ** (kk - 1), 20)}')

# b_0 = beta(1/2) = (3k^2/2) 9^(k-1) [P(k) T(k+1) - P(k+1) T(k)] at k = 1/2, with T(3/2) from (L) at k = -1/2
Rm = -1 / (mp.sqrt(3) * mp.pi)
kh = mp.mpf(1) / 2
Th, Tmh = Tval(kh), Tval(-kh)
T32 = (kh * Th - Tmh / 4) / (9 * kh * kh)
beta_h = 3 * kh * kh / 2 * 9 ** (kh - 1) * (Pval(kh) * T32 - Pval(kh + 1) * Th)
say('   b_0 = beta(1/2) =', mp.nstr(beta_h, 3), ';  so T_0 = b_0 - R log 9 = ', mp.nstr(beta_h - Rm * mp.log(9), 25), ' and 2 log 3/(sqrt3 pi) =', mp.nstr(2 * mp.log(3) / (mp.sqrt(3) * mp.pi), 25))
# the torus mean of log|K| by Jensen, and the arc integral
m1 = 1 / mp.pi * mp.quad(lambda v: mp.log(2 * mp.cos(v / 2)), [0, 2 * mp.pi / 3])
say('   m_1 = (1/pi) int_0^{2pi/3} log(2 cos(v/2)) dv =', mp.nstr(m1, 30), ';  sqrt3 l/(4 pi) =', mp.nstr(mp.sqrt(3) * ell / (4 * mp.pi), 30))
S2 = -mp.quad(lambda v: mp.log(2 * mp.sin(v / 2)), [0, 2 * mp.pi / 3])
Cl13 = -mp.quad(lambda v: mp.log(2 * mp.sin(v / 2)), [0, mp.pi / 3])
say('   S_2 =', mp.nstr(S2, 30), '; Cl(pi/3) =', mp.nstr(Cl13, 30), '; Cl(pi/3) - (3/2) S_2 =', mp.nstr(Cl13 - 1.5 * S2, 3), '; 2 sqrt3 S_2 - l =', mp.nstr(2 * mp.sqrt(3) * S2 - ell, 3))
# direct check of the torus mean of log|K| by a two-dimensional quadrature
mp.mp.dps = 15
m1d = mp.quad(lambda a, b: mp.log(abs(1 + mp.expj(a) + mp.expj(b))), [0, 2 * mp.pi / 3, 4 * mp.pi / 3, 2 * mp.pi], [0, 2 * mp.pi / 3, 4 * mp.pi / 3, 2 * mp.pi]) / (4 * mp.pi ** 2)
say('   two-dimensional quadrature of the torus mean of log|K| =', mp.nstr(m1d, 12))
