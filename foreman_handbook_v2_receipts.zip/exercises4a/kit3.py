"""Shared exact tools for the exercises on the list binom([3],1) (marks 1, 2, 3, bases the singletons, unit weights).

Everything here is exact (sympy rationals and polynomials, python Fractions).  The receipts ex18_*.py ... ex23_*.py
import it; each receipt prints what its solution displays.
"""
from fractions import Fraction as Fr
from itertools import permutations, combinations
from math import factorial, comb
import sympy as sp

a1, a2, a3, k = sp.symbols('a1 a2 a3 k')
A = (a1, a2, a3)
e1 = a1 + a2 + a3
e2 = a1 * a2 + a1 * a3 + a2 * a3
e3 = a1 * a2 * a3
K = e1                      # the basis letter of binom([3],1)
Psi = e2                    # the cobasis letter
MARKS = (0, 1, 2)
BASES = [frozenset({e}) for e in MARKS]


# ---------------------------------------------------------------- skeleton counts (Definition def:skeleton)
def rank(S, bases=BASES):
    return max(len(T & S) for T in bases)


def skeleton(S, bases=BASES, n=3):
    S = frozenset(S)
    E = frozenset(range(n))
    r = rank(E, bases)
    rs = len(S) + rank(E - S, bases) - r          # dual rank r*(S)
    d = len(S) - rs
    ds = len(S) - rank(S, bases)
    c = len(S) - d - ds
    return dict(r=rank(S, bases), rstar=rs, d=d, dstar=ds, c=c)


def proper_subsets(n=3):
    for s in range(1, n):
        for S in combinations(range(n), s):
            yield frozenset(S)


def walls(m, s, t, bases=BASES, n=3):
    """walls kappa_S = m_S - s d(S) - t d*(S) of the data (m; s, t) (Definition def:family)"""
    out = {}
    for S in proper_subsets(n):
        sk = skeleton(S, bases, n)
        out[tuple(sorted(S))] = sum(m[e] for e in S) - s * sk['d'] - t * sk['dstar']
    return out


def V1(wall, n=3):
    """V_1 = sum over the orders pi of prod_{l>=2} kappa_{U_l}^{-1}, U_l the tails (Proposition prop:principal)"""
    tot = Fr(0)
    for pi in permutations(range(n)):
        pr = Fr(1)
        for l in range(1, n):
            U = tuple(sorted(pi[l:]))
            pr /= wall[U]
        tot += pr
    return tot


# ---------------------------------------------------------------- symmetric polynomials in the basis e1^i e2^j e3^l
def to_e_basis(P, deg):
    """write a symmetric homogeneous polynomial P of degree deg in a1,a2,a3 in the basis e1^i e2^j e3^l"""
    basis = [(deg - 2 * j - 3 * l, j, l) for l in range(deg // 3 + 1) for j in range((deg - 3 * l) // 2 + 1)]
    cs = sp.symbols('c0:%d' % len(basis))
    expr = sum(c * e1 ** i * e2 ** j * e3 ** l for c, (i, j, l) in zip(cs, basis))
    eqs = sp.Poly(sp.expand(expr - P), a1, a2, a3).coeffs()
    sol = sp.solve(eqs, cs, dict=True)
    assert len(sol) == 1
    out = {b: sol[0].get(c, 0) for c, b in zip(cs, basis)}
    assert sp.expand(sum(v * e1 ** i * e2 ** j * e3 ** l for (i, j, l), v in out.items()) - P) == 0
    return {b: v for b, v in out.items() if v != 0}


def fmt_e(d):
    return ' + '.join(f'({v}) e1^{i} e2^{j} e3^{l}' for (i, j, l), v in d.items())


# ---------------------------------------------------------------- closings of the centre ray
def closing_centre(j):
    """C_j(1) = CT((e1 e2/e3)^j) = sum over a1+a2+a3=j of (j!/(a1!a2!a3!))^2"""
    return sum((factorial(j) // (factorial(p) * factorial(q) * factorial(j - p - q))) ** 2
               for p in range(j + 1) for q in range(j + 1 - p))


def least_recurrence(x, order, degree, start=0):
    """the solutions (p_0,...,p_order) with deg p_i <= degree of sum_i p_i(j) x_{j+i} = 0 for start <= j <= len(x)-1-order"""
    J = len(x)
    rows = []
    for j in range(start, J - order):
        rows.append([x[j + i] * j ** d for i in range(order + 1) for d in range(degree + 1)])
    M = sp.Matrix(rows)
    ns = M.nullspace()
    return M.shape, ns


# ---------------------------------------------------------------- the law (L) of the centre ray and its solutions
def law_L(kk):
    """coefficients of (L): k^2 x(k) - (10k^2+10k+3) x(k+1) + 9(k+1)^2 x(k+2) = 0"""
    return (kk * kk, -(10 * kk * kk + 10 * kk + 3), 9 * (kk + 1) ** 2)


def run_law(x1, x2, KMAX):
    x = {1: Fr(x1), 2: Fr(x2)}
    for kk in range(1, KMAX - 1):
        c0, c1, c2 = law_L(kk)
        x[kk + 2] = (-c0 * x[kk] - c1 * x[kk + 1]) / c2
    return x
