"""The box of a ray (Definition def:raybox) and its reduction (Definition def:box-reduction), exact over Q(k).

For one table with unit weights, given by its bases on the marks 0..n-1, a ray with origin 0 and an integral direction
(m1; s1, t1).  Symbols are tuples (u_0,...,u_{n-1}, a, b): the insertion alpha^u K^-a Psi^-b with u_E = a r + b r*.
A finite group G of symmetries is given by maps on symbols; the box is reduced modulo G (orbit averages).
Arithmetic is in the field Q(k) of sympy (QQ.frac_field(k)), so every pivot and every normal form is exact.
"""
from fractions import Fraction as Fr
from itertools import product, combinations
import sympy as sp

k = sp.symbols('k')
FK = sp.QQ.frac_field(k)
ONE, ZERO = FK.one, FK.zero


def fk(x):
    return FK.convert(sp.sympify(x))


class Table:
    def __init__(self, n, bases):
        self.n = n
        self.E = frozenset(range(n))
        self.bases = [frozenset(T) for T in bases]
        self.r = max(len(T) for T in self.bases)
        self.rstar = n - self.r
        self.proper = [frozenset(S) for s in range(1, n) for S in combinations(range(n), s)]
        self._d = {S: min(len(T & S) for T in self.bases) for S in self.proper}
        self._ds = {S: min(len(S - T) for T in self.bases) for S in self.proper}

    def d(self, S): return self._d[S]

    def dstar(self, S): return self._ds[S]


class Ray:
    def __init__(self, table, m1, s1, t1):
        self.tb = table
        self.m1, self.s1, self.t1 = tuple(m1), s1, t1
        n = table.n
        assert sum(m1) == s1 * table.r + t1 * table.rstar, 'direction off the balance wall'
        self.kappa1 = {S: sum(m1[e] for e in S) - s1 * table.d(S) - t1 * table.dstar(S) for S in table.proper}
        assert all(v > 0 for v in self.kappa1.values()), 'a wall of the direction is not positive'

    def walls(self, sym):
        n = self.tb.n
        u, a, b = sym[:n], sym[n], sym[n + 1]
        return {S: sum(u[e] for e in S) - a * self.tb.d(S) - b * self.tb.dstar(S) for S in self.tb.proper}

    def wdeg(self, sym):
        w = self.walls(sym)
        return max(Fr(-w[S], self.kappa1[S]) for S in self.tb.proper)

    def finv(self):
        """the Laurent polynomial f^-1 = alpha^-m1 K^s1 Psi^t1, as a dict exponent -> integer coefficient"""
        n = self.tb.n
        poly = {tuple(-x for x in self.m1): 1}
        for _ in range(self.s1):
            new = {}
            for u, c in poly.items():
                for T in self.tb.bases:
                    v = tuple(u[e] + (1 if e in T else 0) for e in range(n))
                    new[v] = new.get(v, 0) + c
            poly = new
        for _ in range(self.t1):
            new = {}
            for u, c in poly.items():
                for T in self.tb.bases:
                    v = tuple(u[e] + (0 if e in T else 1) for e in range(n))
                    new[v] = new.get(v, 0) + c
            poly = new
        return poly


class Box:
    """B_t(abar, bbar) of a ray with origin 0, modulo a group G of maps on symbols."""

    def __init__(self, ray, t, abar, bbar, group, rank_key=None):
        self.ray, self.t, self.abar, self.bbar = ray, t, abar, bbar
        self.G = group
        tb = ray.tb
        n = tb.n
        self.n = n
        # enumerate symbols: at each level, u with u_E fixed and wall degree <= t
        syms = []
        for a in range(abar + 1):
            for b in range(bbar + 1):
                tot = a * tb.r + b * tb.rstar
                # bound: kappa_{e}(g) = u_e - a d({e}) - b d*({e}) >= -t kappa1({e})
                lo = [a * tb.d(frozenset({e})) + b * tb.dstar(frozenset({e})) - t * ray.kappa1[frozenset({e})] for e in range(n)]
                # u_e <= tot - sum of the other lower bounds
                hi = [tot - sum(lo[x] for x in range(n) if x != e) for e in range(n)]
                for u in product(*[range(lo[e], hi[e] + 1) for e in range(n - 1)]):
                    ul = list(u) + [tot - sum(u)]
                    if not (lo[n - 1] <= ul[-1] <= hi[n - 1]):
                        continue
                    sym = tuple(ul) + (a, b)
                    if ray.wdeg(sym) <= t:
                        syms.append(sym)
        self.syms = syms
        self.symset = set(syms)
        # orbits
        self.orbit_of = {}
        self.orbits = []
        for s in syms:
            if s in self.orbit_of:
                continue
            orb = {s}
            frontier = [s]
            while frontier:
                x = frontier.pop()
                for phi in self.G:
                    y = phi(x)
                    if y not in orb:
                        orb.add(y); frontier.append(y)
            rep = min(orb)
            for x in orb:
                assert x in self.symset, ('the group does not keep the box', x)
                self.orbit_of[x] = rep
            self.orbits.append((rep, sorted(orb)))
        self.orbit_size = {rep: len(o) for rep, o in self.orbits}
        self.level = {rep: (rep[n], rep[n + 1]) for rep, _ in self.orbits}
        self.deg = {rep: ray.wdeg(rep) for rep, _ in self.orbits}
        # ranking: positive levels above Laurent; then total level, wall degree, representative
        if rank_key is None:
            def rank_key(rep):
                a, b = self.level[rep]
                return (0 if (a, b) == (0, 0) else 1, a + b, self.deg[rep], rep)
        self.rank = {rep: rank_key(rep) for rep, _ in self.orbits}
        self.order = sorted(self.rank, key=lambda r: self.rank[r], reverse=True)     # highest first
        self.pos = {rep: i for i, rep in enumerate(self.order)}
        self.stems = [s for s in syms if (s[n], s[n + 1]) == (max(abar - 1, 0), max(bbar - 1, 0))]
        self.relations = []          # (description, dict symbol -> FK coefficient)
        self._build_relations()

    # ---- relations of the box (Definition def:raybox(iv))
    def _build_relations(self):
        n, tb, ray = self.n, self.ray.tb, self.ray
        for s in self.syms:
            u, a, b = s[:n], s[n], s[n + 1]
            if a < self.abar:
                rel = {s: ONE}
                for T in tb.bases:
                    v = tuple(u[e] + (1 if e in T else 0) for e in range(n)) + (a + 1, b)
                    rel[v] = rel.get(v, ZERO) - ONE
                self.relations.append((('K', s), rel))
            if b < self.bbar:
                rel = {s: ONE}
                for T in tb.bases:
                    v = tuple(u[e] + (0 if e in T else 1) for e in range(n)) + (a, b + 1)
                    rel[v] = rel.get(v, ZERO) - ONE
                self.relations.append((('Psi', s), rel))
        for s in self.stems:
            for e in range(n):
                self.relations.append((('MR', s, e), self.mark_relation(s, e)))
        for desc, rel in self.relations:
            for x in rel:
                assert x in self.symset, ('a term outside the box', desc, x)

    def mark_relation(self, s, e):
        n, tb, ray = self.n, self.ray.tb, self.ray
        u, a, b = s[:n], s[n], s[n + 1]
        kk = fk(k)
        rel = {s: kk * ray.m1[e] + u[e]}
        ca = kk * ray.s1 + a
        cb = kk * ray.t1 + b
        if ca != ZERO:
            for T in tb.bases:
                if e in T:
                    v = tuple(u[x] + (1 if x in T else 0) for x in range(n)) + (a + 1, b)
                    rel[v] = rel.get(v, ZERO) - ca
        if cb != ZERO:
            for T in tb.bases:
                if e not in T:
                    v = tuple(u[x] + (0 if x in T else 1) for x in range(n)) + (a, b + 1)
                    rel[v] = rel.get(v, ZERO) - cb
        return {x: c for x, c in rel.items() if c != ZERO}

    # ---- orbit coordinates: e_G of a combination of symbols has the coordinate sum_{s in O} r_s on the average of O
    def to_orbits(self, comb):
        out = {}
        for x, c in comb.items():
            rep = self.orbit_of[x]
            out[rep] = out.get(rep, ZERO) + c
        return {r: c for r, c in out.items() if c != ZERO}

    def eliminate(self, verbose=False):
        self.pivots = {}            # pivot orbit -> row (dict), leading coefficient 1, only lower orbits otherwise
        for desc, rel in self.relations:
            row = self.to_orbits(rel)
            row = self._reduce(row)
            if row:
                lead = min(row, key=lambda r: self.pos[r])
                inv = ONE / row[lead]
                row = {r: c * inv for r, c in row.items()}
                self.pivots[lead] = row
        # back-substitute so that pivot rows involve no other pivot
        for p in sorted(self.pivots, key=lambda r: self.pos[r], reverse=True):
            row = self.pivots[p]
            changed = True
            while changed:
                changed = False
                for q in list(row):
                    if q != p and q in self.pivots:
                        c = row.pop(q)
                        for r2, c2 in self.pivots[q].items():
                            if r2 == q: continue
                            row[r2] = row.get(r2, ZERO) - c * c2
                            if row[r2] == ZERO: del row[r2]
                        changed = True
        self.free = [r for r in self.order if r not in self.pivots]
        return self.pivots

    def _reduce(self, row):
        row = dict(row)
        while True:
            cand = [r for r in row if r in getattr(self, 'pivots', {})]
            if not cand:
                return row
            q = min(cand, key=lambda r: self.pos[r])
            c = row.pop(q)
            for r2, c2 in self.pivots[q].items():
                if r2 == q: continue
                row[r2] = row.get(r2, ZERO) - c * c2
                if row[r2] == ZERO: del row[r2]

    def normal_form(self, comb_syms):
        return self._reduce(self.to_orbits(comb_syms))

    def average(self, rep):
        """the orbit average as a dict symbol -> coefficient"""
        orb = [x for x in self.syms if self.orbit_of[x] == rep]
        return {x: ONE / len(orb) for x in orb}

    def times_finv(self, comb_laurent):
        """f^-1 times a Laurent combination (symbols at level (0,0)), as a combination of symbols"""
        n = self.n
        out = {}
        for x, c in comb_laurent.items():
            assert x[n:] == (0, 0)
            for v, lv in self.ray.finv().items():
                y = tuple(x[e] + v[e] for e in range(n)) + (0, 0)
                out[y] = out.get(y, ZERO) + c * lv
        return {x: c for x, c in out.items() if c != ZERO}


# ---------------------------------------------------------------- symmetries on symbols (Proposition prop:raysym(iii))
def perm_map(beta, n):
    """phi_beta for a permutation beta of the marks (carrying the bases): (u;a,b) -> (u o beta^-1; a, b)"""
    inv = [0] * n
    for i, bi in enumerate(beta):
        inv[bi] = i
    def phi(sym):
        u = sym[:n]
        return tuple(u[inv[e]] for e in range(n)) + sym[n:]
    return phi


def cremona_map(n):
    """cr: (u; a, b) -> (-u + (a+b) 1; b, a)"""
    def phi(sym):
        u, a, b = sym[:n], sym[n], sym[n + 1]
        return tuple(-x + a + b for x in u) + (b, a)
    return phi


def fk_str(x):
    return str(sp.factor(FK.to_sympy(x)))
