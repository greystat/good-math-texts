"""Receipt for Exercise ex:smallc-directions: the balanced directions of binom([3],1).

Run: python3 ex23_directions.py    (sympy, python-flint; exact except the labelled check)
Prints: the balanced directions (m; s, t) with 1 <= s, t <= 5, positive walls and m in decreasing order; their offsets
c_e = m_e - t, the sums S = s + t and the shapes of {|c_e|}; the families; the values P(1) of the directions with |c_e|
constant, read on the centre ray (insertions reduced in the boxes of the centre ray) and moved along the families by
the ratios of Beta corners; the native values f*; and, as a check, the least recurrences of the closings.
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from boxkit import *
from fractions import Fraction as Fr
from math import factorial, comb
import flint

say = print
tb = Table(3, [{0}, {1}, {2}])
dirs = []
for s in range(1, 6):
    for t in range(1, 6):
        tot = s + 2 * t
        for m1 in range(tot, -1, -1):
            for m2 in range(min(m1, tot - m1), -1, -1):
                m3 = tot - m1 - m2
                if m3 > m2 or m3 < 0: continue
                m = (m1, m2, m3)
                walls = [m[e] for e in range(3)] + [m[a] + m[b] - t for a, b in ((0, 1), (0, 2), (1, 2))]
                if min(walls) > 0:
                    dirs.append((m, s, t))
say('=' * 100)
say('1. Balanced directions with 1 <= s,t <= 5, positive walls, m decreasing:', len(dirs))
shape = {}
for d in dirs:
    m, s, t = d
    c = tuple(m[e] - t for e in range(3))
    ac = tuple(sorted(abs(x) for x in c))
    nv = len(set(ac))
    shape[d] = (s + t, ac, nv)
cnt = {}
for d in dirs: cnt[shape[d][2]] = cnt.get(shape[d][2], 0) + 1
say('   number of distinct values of |c_e|: ', dict(sorted(cnt.items())))
fam = {}
for d in dirs:
    fam.setdefault((shape[d][0], shape[d][1]), []).append(d)
const = {key: v for key, v in fam.items() if len(set(key[1])) == 1}
say('   directions with |c_e| constant:', sum(len(v) for v in const.values()), 'in', len(const), 'families:')
for key in sorted(const, key=lambda x: (x[1], x[0])):
    say('     S =', key[0], ' |c| =', key[1][0], ':', const[key])
two = {key: v for key, v in fam.items() if len(set(key[1])) == 2}
say('   families with two values of |c_e|:', len(two), '; with three:', len([1 for key in fam if len(set(key[1])) == 3]))
say('   families of size > 1 among all:', sum(1 for v in fam.values() if len(v) > 1), '; total families', len(fam))

say('=' * 100)
say('2. The centre ray: c(K), r(K) of the law (L), P_c(K) = c(K) l + r(K)')
cc = {1: Fr(1), 2: Fr(1, 3)}; rr = {1: Fr(0), 2: Fr(-2, 3)}
for kk in range(1, 10):
    cc[kk + 2] = ((10 * kk * kk + 10 * kk + 3) * cc[kk + 1] - kk * kk * cc[kk]) / (9 * (kk + 1) ** 2)
    rr[kk + 2] = ((10 * kk * kk + 10 * kk + 3) * rr[kk + 1] - kk * kk * rr[kk]) / (9 * (kk + 1) ** 2)
ell = sp.symbols('ell')
Pc = {K: sp.Rational(cc[K].numerator, cc[K].denominator) * ell + sp.Rational(rr[K].numerator, rr[K].denominator) for K in cc}
for K in range(1, 6): say(f'   P_c({K}) =', sp.factor(Pc[K]))
b1c = {K: sp.expand((Pc[K - 1] - 3 * Pc[K]) / 6) for K in range(2, 8)}     # <b1>_K = (P(K-1) - 3 P(K))/6

say('=' * 100)
say('3. Insertions of the centre ray reduced in its boxes (modulo S_3 and the Cremona)')
centre = Ray(tb, (1, 1, 1), 1, 1)
Gc = [perm_map((1, 0, 2), 3), perm_map((0, 2, 1), 3), cremona_map(3)]
box11 = Box(centre, 2, 1, 1, Gc); box11.eliminate()
box22 = Box(centre, 2, 2, 2, Gc); box22.eliminate()
b1rep = box11.orbit_of[(1, -1, 0, 0, 0)]
def reduce_ins(box, ins):
    nf = box.normal_form(ins)
    rep1 = box.orbit_of[(1, -1, 0, 0, 0)]
    assert set(nf) <= {(0, 0, 0, 0, 0), rep1}, nf
    return FK.to_sympy(nf.get((0, 0, 0, 0, 0), ZERO)), FK.to_sympy(nf.get(rep1, ZERO))
A1, B1 = reduce_ins(box11, {(2, 0, 0, 0, 1): ONE})
say('   alpha_1^2/Psi = A(k) 1 + B(k) b1 modulo the relations of B_2(1,1): A =', sp.factor(A1), ', B =', sp.factor(B1))
A2, B2 = reduce_ins(box22, {(4, 0, 0, 0, 2): ONE})
say('   alpha_1^4/Psi^2 in B_2(2,2): A =', sp.factor(A2), ', B =', sp.factor(B2))
A3, B3 = reduce_ins(box22, {tuple(0 if x == e else 1 for x in range(3)) + (2, 0): ONE for e in range(3)})
say('   Psi/K^2 in B_2(2,2): A =', sp.factor(A3), ', B =', sp.factor(B3))
def val(Ak, Bk, K):
    return sp.factor(sp.expand(Ak.subs(k, K) * Pc[K] + Bk.subs(k, K) * b1c[K]))
vals = {}
for K in (2, 3, 4):
    say(f'   <alpha_1^2/Psi>_{K} = P({tuple(x + K for x in (2, 0, 0))}; {K}, {K + 1}) =', val(A1, B1, K))
    vals[((K + 2, K, K), K, K + 1)] = val(A1, B1, K)
vals[((7, 3, 3), 3, 5)] = val(A2, B2, 3)
say('   <alpha_1^4/Psi^2>_3 = P((7,3,3); 3, 5) =', vals[((7, 3, 3), 3, 5)])
vals[((2, 2, 2), 4, 1)] = val(A3, B3, 2)
say('   <Psi/K^2>_2 = P((2,2,2); 4, 1) =', vals[((2, 2, 2), 4, 1)])
for cp in range(1, 6):
    vals[((cp, cp, cp), cp, cp)] = sp.factor(Pc[cp])

say('=' * 100)
say('4. The family ratio: Gamma(sk)Gamma(tk) P(k) depends on S and {|c_e|} only, so P_d\'/P_d = B(sk,tk)/B(s\'k,t\'k)')
def beta(a, b): return sp.gamma(a) * sp.gamma(b) / sp.gamma(a + b)
allvals = {}
for key, members in sorted(const.items(), key=lambda x: (x[0][1], x[0][0])):
    known = [d for d in members if d in vals]
    assert known, members
    d0 = known[0]
    for d in members:
        m, s, t = d
        r_ = sp.simplify(beta(d0[1], d0[2]) / beta(s, t))
        allvals[d] = sp.factor(r_ * vals[d0])
        say(f'   {d}: ratio to {d0} at k = 1: {r_};  P(1) =', allvals[d], ('  (read directly: ' + str(vals[d]) + ')') if d in vals and d != d0 else '')
say('   ratios at k = 1..4 for (4,2,2;2,3) against (3,3,3;1,4): Gamma(4k)Gamma(k)/(Gamma(3k)Gamma(2k)) =', [sp.gamma(4 * K) * sp.gamma(K) / (sp.gamma(3 * K) * sp.gamma(2 * K)) for K in range(1, 5)])
say('   ratios at k = 1..3 for (5,3,3;3,4) against (4,4,4;2,5): Gamma(5k)Gamma(2k)/(Gamma(4k)Gamma(3k)) =', [sp.gamma(5 * K) * sp.gamma(2 * K) / (sp.gamma(4 * K) * sp.gamma(3 * K)) for K in range(1, 4)])

say('=' * 100)
say('5. Native values f* on the orthant (alpha_2 = alpha_3 = 1 by the symmetry of m_2 = m_3 where it holds)')
x = sp.symbols('x', positive=True)
for key, members in sorted(const.items(), key=lambda x_: (x_[0][1], x_[0][0])):
    for d in members:
        m, s, t = d
        if m[1] == m[2]:
            al = (x, 1, 1)
        elif m[0] == m[1]:
            al = (1, 1, x)
        else:
            al = None
        E1 = sum(al); E2 = al[0] * al[1] + al[0] * al[2] + al[1] * al[2]
        e = 0 if m[1] == m[2] else 2
        eq = sp.Eq(m[e], s * al[e] / E1 + t * al[e] * (E1 - al[e]) / E2)
        sol = [z for z in sp.solve(eq, x) if z.is_positive]
        assert len(sol) == 1
        xv = sol[0]
        alv = [sp.sympify(a).subs(x, xv) for a in al]
        E1v = sum(alv); E2v = alv[0] * alv[1] + alv[0] * alv[2] + alv[1] * alv[2]
        fs = sp.nsimplify(sp.simplify(alv[0] ** m[0] * alv[1] ** m[1] * alv[2] ** m[2] / (E1v ** s * E2v ** t)))
        say(f'   {d}: alpha* = {tuple(alv)}, f* = {fs}')
say('   rates: 4^4/(3^3 2^2) =', sp.Rational(4 ** 4, 3 ** 3 * 2 ** 2), '; 5^5 2^2/(4^4 3^3) =', sp.Rational(5 ** 5 * 2 ** 2, 4 ** 4 * 3 ** 3))

say('=' * 100)
say('Check: least recurrences of the closings (modular nullspaces; not part of the solution)')
def closings(d, J):
    m, s, t = d
    c = [m[e] - t for e in range(3)]
    out = []
    for j in range(J):
        tot = 0
        for d1 in range(t * j + 1):
            for d2 in range(t * j - d1 + 1):
                d3 = t * j - d1 - d2
                b = (d1 + j * c[0], d2 + j * c[1], d3 + j * c[2])
                if min(b) < 0: continue
                tot += (factorial(t * j) // (factorial(d1) * factorial(d2) * factorial(d3))) * (factorial(s * j) // (factorial(b[0]) * factorial(b[1]) * factorial(b[2])))
        out.append(tot)
    return out
P = (1 << 61) - 1
def least_order(xs, hmax=4, Dmax=24):
    for h in range(1, hmax + 1):
        for Dg in range(0, Dmax + 1):
            nunk = (h + 1) * (Dg + 1)
            neq = len(xs) - h
            if neq < nunk + 5: break
            M = flint.nmod_mat(neq, nunk, P)
            for j in range(neq):
                for i in range(h + 1):
                    xi = xs[j + i] % P; pw = 1
                    for e_ in range(Dg + 1):
                        M[j, i * (Dg + 1) + e_] = xi * pw % P; pw = pw * j % P
            if M.rank() < nunk:
                return h, Dg
    return None
res = {}
for d in dirs:
    xs = closings(d, 60)
    res[d] = least_order(xs)
orders = {}
for d in dirs:
    orders.setdefault(res[d][0] if res[d] else None, []).append(d)
for h in sorted(orders, key=lambda z: (z is None, z)):
    say(f'   order {h}: {len(orders[h])} directions; shapes of |c|:', sorted({shape[d][2] for d in orders[h]}))
xs5 = closings(((5, 5, 5), 5, 5), 70)
say('   (5,5,5;5,5) with 70 closings: least recurrence (order, degree) =', least_order(xs5, 2, 24))
say('   order 2 directions:', [(d, res[d]) for d in orders.get(2, [])])
say('   order 3 directions:', [(d, res[d]) for d in orders.get(3, [])])
