"""Receipt for Exercise ex:smallc-gauge: the centre of binom([3],1) read from its gauge end.

Run: python3 ex20_gauge_end.py      (sympy for the exact parts, mpmath for the labelled renderings and checks)
Prints, in the order of the solution: the density operator of the law (L) and its coefficients at t = 1/9; the
exponents there; the delta terms left by the two local solutions; the Taylor coefficients of the germ; the Hessian and
rho_f(1/9); the low-end coefficients L_0, L_1, L_2 from the faces of the sectors; the values and their slopes from the
Beta sums at two depths and the run back; the low-end relation and its derivatives read on the output; the arc
integrals S_1, S_2.
"""
import sympy as sp
import mpmath as mp
from fractions import Fraction as Fr

say = print
t, s, th, k, x = sp.symbols('t s theta k x')
p = [k ** 2, -(10 * k ** 2 + 10 * k + 3), 9 * (k + 1) ** 2]          # the law (L): sum_i p_i(k) P(k+i) = 0

say('=' * 100)
say('1. The density operator  D = sum_i t^i p_i(-1-i-theta),  theta = t d/dt')
thpoly = [sp.expand(t ** i * p[i].subs(k, -1 - i - th)) for i in range(3)]
for i in range(3):
    say(f'   t^{i} p_{i}(-1-{i}-theta) =', sp.factor(sp.expand(p[i].subs(k, -1 - i - th))), '* t^%d' % i)
u = sp.Function('u')(t)
def theta_pow(f, m):
    for _ in range(m):
        f = t * sp.diff(f, t)
    return f
Du = 0
for i in range(3):
    P_i = sp.Poly(sp.expand(p[i].subs(k, -1 - i - th)), th)
    for (m,), c in P_i.terms():
        Du += c * t ** i * theta_pow(u, m)
Du = sp.expand(Du)
a2 = sp.factor(Du.coeff(sp.diff(u, t, 2))); a1 = sp.factor(Du.coeff(sp.diff(u, t)))
a0 = sp.factor(sp.expand(Du - a2 * sp.diff(u, t, 2) - a1 * sp.diff(u, t)).subs(u, 1))
say('   D = a2 d^2/dt^2 + a1 d/dt + a0:  a2 =', a2, ';  a1 =', a1, ';  a0 =', a0)
lam = sp.symbols('lambda')
chi = sum(sp.Poly(p[i], k).coeff_monomial(k ** 2) * lam ** i for i in range(3))
chi1 = sum(sp.Poly(p[i], k).coeff_monomial(k) * lam ** i for i in range(3))
say('   symbol chi =', sp.factor(chi), ';  second symbol chi_1 =', sp.factor(chi1), ';  t^2 chi(t) =', sp.factor(t ** 2 * chi.subs(lam, t)))

say('=' * 100)
say('2. At f* = 1/9, in s = 1/9 - t:  D = b2 d^2/ds^2 + b1 d/ds + b0')
fs = sp.Rational(1, 9)
b2 = sp.expand(a2.subs(t, fs - s)); b1 = sp.expand(-a1.subs(t, fs - s)); b0 = sp.expand(a0.subs(t, fs - s))
say('   b2 =', sp.factor(b2), ' =', sp.Poly(b2, s).all_coeffs()[::-1])
say('   b1 =', sp.factor(b1), ' =', sp.Poly(b1, s).all_coeffs()[::-1])
say('   b0 =', sp.factor(b0), ' =', sp.Poly(b0, s).all_coeffs()[::-1])
b = {(j, l): sp.Poly([b0, b1, b2][j], s).coeff_monomial(s ** l) for j in range(3) for l in range(5)}
say('   b_{2,0} =', b[(2, 0)], '; b_{2,1} =', b[(2, 1)], ' = -(f*)^2 chi\'(f*) =', -fs ** 2 * sp.diff(chi, lam).subs(lam, fs), '; b_{1,0} =', b[(1, 0)])
gam = 2 - 1 - b[(1, 0)] / b[(2, 1)]
say('   gamma = D - 1 - b_{1,0}/b_{2,1} =', gam, ';  -1 + chi_1(f*)/(f* chi\'(f*)) =', -1 + chi1.subs(lam, fs) / (fs * sp.diff(chi, lam).subs(lam, fs)))
def ff(xx, j):
    out = 1
    for i in range(j): out *= (xx - i)
    return out
R = {m: sp.expand(sum(b.get((j, m - 2 + 1 + j), 0) * ff(x, j) for j in range(3))) for m in range(0, 5)}
for m in range(5):
    say(f'   R_{m}(x) =', sp.factor(R[m]))

say('=' * 100)
say('3. Extension by zero: the delta terms of D(u 1_{s>0}) for the two local solutions')
# holomorphic solution phi = 1 + e1 s + ...; log solution psi = phi log s + chi(s) with chi = c1 s + ...
M = 14
es = sp.symbols('e0:%d' % (M + 1))
U = sum(es[m] * s ** m for m in range(M + 1))
expr = sp.expand(b2 * sp.diff(U, s, 2) + b1 * sp.diff(U, s) + b0 * U)
sol = {es[0]: 1}
for m in range(M):
    eqm = sp.expand(expr.coeff(s, m).subs(sol))
    sol[es[m + 1]] = sp.solve(eqm, es[m + 1])[0]
e = [sp.Rational(sol[es[m]]) for m in range(M + 1)]
say('   germ: e_m (Taylor coefficients of the holomorphic solution, e_0 = 1), m = 0..8:', e[:9])
# check against the recurrence R_0(N) u_N = - sum_{m>=1} R_m(N-m) u_{N-m}
ok = all(sp.simplify(R[0].subs(x, N) * e[N] + sum(R[m].subs(x, N - m) * e[N - m] for m in range(1, min(N, 4) + 1))) == 0 for N in range(1, M + 1))
say('   the e_m satisfy R_0(N) e_N = - sum_{m>=1} R_m(N-m) e_{N-m}:', ok)
say('   delta coefficient for a function smooth at s = 0: (b_{1,0} - b_{2,1}) u(0) =', b[(1, 0)] - b[(2, 1)], '* u(0)')
# for v = phi log s + chi: the boundary terms at s = eps of int_eps (v D*w - w D v) ds, D v = 0
eps = sp.symbols('epsilon', positive=True)
cs = sp.symbols('c1:6')
phi = sum(e[m] * s ** m for m in range(6))
chis = sum(cs[i] * s ** (i + 1) for i in range(5))
v = phi * sp.log(s) + chis
Dv = sp.expand(b2 * sp.diff(v, s, 2) + b1 * sp.diff(v, s) + b0 * v)
solc = sp.solve([sp.expand(Dv).coeff(sp.log(s), 0).coeff(s, m) for m in range(0, 4)], cs[:4], dict=True)
say('   log solution: chi =', sp.expand(chis.subs(solc[0]).subs(cs[4], 0)), '+ ...')
# the distribution D(v 1_{s>0}) pairs with a test function w as lim_eps [b2 (v' w - v w') + (b1 - b2') v w]_{s=eps}
w0, w1 = sp.symbols('w0 w1')
Lg = sp.symbols('Lg')                          # stands for log(eps)
w = w0 + w1 * s
def boundary(vv, dvv):
    """the boundary form at s = eps, as a polynomial in eps, 1/eps and Lg; returns its limit (coefficient of eps^0 Lg^0)
    after checking that no negative power of eps and no power of Lg survives with a nonzero coefficient"""
    bd = sp.expand(b2 * (dvv * w - vv * sp.diff(w, s)) + (b1 - sp.diff(b2, s)) * vv * w)
    bd = sp.expand(bd)
    P_ = sp.Poly(bd, s, Lg)          # in s = eps; vv and dvv are polynomials in s, Lg and 1/s cleared below
    out, bad = 0, []
    for (ds, dl), c in P_.terms():
        if ds == 0 and dl == 0: out += c
        elif ds == 0 and dl > 0: bad.append((ds, dl, c))
    return sp.simplify(out), bad
vlog = (phi * Lg + chis).subs(solc[0]).subs(cs[4], 0)
dvlog = sp.expand((sp.diff(phi, s) * Lg + phi / s + sp.diff(chis, s)).subs(solc[0]).subs(cs[4], 0))
# multiply through: b2 * phi/s is a polynomial since b2(0) = 0
lim_log, bad_log = boundary(sp.expand(vlog), sp.expand(sp.cancel(dvlog * s) / s))
say('   log solution: the pairing of D(v 1_{s>0}) with a test function w reduces to', lim_log, '(no log or negative power survives:', bad_log == [], '): a point mass', lim_log, 'at f*')
lim_hol, bad_hol = boundary(sp.expand(phi), sp.expand(sp.diff(phi, s)))
say('   holomorphic solution: the same pairing is', lim_hol, '(', bad_hol == [], ')')

say('=' * 100)
say('4. The constant: H, det H, rho_f(1/9)')
H = sp.Matrix([[sp.Rational(4, 9), -sp.Rational(2, 9)], [-sp.Rational(2, 9), sp.Rational(4, 9)]])
say('   H = 2 (covariances of the indicators under the uniform law on three marks) =', H.tolist(), '; det H =', H.det())
g0 = sp.simplify(2 * sp.pi / (fs * sp.sqrt(H.det())))
say('   rho_f(1/9) = 2 pi / (f* sqrt(det H)) =', g0)

say('=' * 100)
say('5. The low-end coefficients from the faces of the sectors')
q = sp.symbols('q', positive=True)
phi_face = -sp.log(1 + q)
I_face = sp.integrate(phi_face / q, (q, 0, 1))
say('   per order and per face: int_0^1 log phi|_face dq/q = int_0^1 -log(1+q) dq/q =', sp.simplify(I_face))
L = {0: sp.Integer(6), 1: sp.Integer(0), 2: sp.simplify(6 * 2 * I_face)}
say('   L_0 = V_1 = 6;  L_1 = 0 (unit weights);  L_2 = 6 orders x 2 faces x (-pi^2/12) =', L[2])

say('=' * 100)
say('6. The values and the slopes from the gauge end (renderings)')
mp.mp.dps = 140
g0m = 27 * mp.sqrt(3) * mp.pi
def germ_coeffs(N):
    """e_m / 9^m as mpf, from the recurrence R_0(N) e_N = -sum R_m(N-m) e_{N-m} (exact rationals)"""
    Rl = {m: sp.lambdify(x, R[m]) for m in range(5)}
    ee = [Fr(1)]
    Rc = {m: sp.Poly(R[m], x).all_coeffs() for m in range(5)}
    def ev(m, X):
        out = Fr(0)
        for c in Rc[m]:
            out = out * X + Fr(int(sp.fraction(c)[0]), int(sp.fraction(c)[1]))
        return out
    for n_ in range(1, N + 1):
        rhs = -sum(ev(m, n_ - m) * ee[n_ - m] for m in range(1, min(n_, 4) + 1))
        ee.append(rhs / ev(0, n_))
    return [mp.mpf(z.numerator) / z.denominator / mp.mpf(9) ** m for m, z in enumerate(ee)]
def beta_sums(K, Nterms, eg, J=4):
    """the j-th K-derivatives of g0 sum_m e_m int_0^{1/9} t^K (1/9-t)^m dt, j = 0..J"""
    out = [mp.mpf(0)] * (J + 1)
    lg9 = mp.log(9)
    for m in range(Nterms):
        base = eg[m] * mp.beta(K + 1, m + 1) / mp.mpf(9) ** (K + 1)
        h1 = -lg9 + mp.digamma(K + 1) - mp.digamma(K + m + 2)
        h2 = mp.psi(1, K + 1) - mp.psi(1, K + m + 2)
        h3 = mp.psi(2, K + 1) - mp.psi(2, K + m + 2)
        h4 = mp.psi(3, K + 1) - mp.psi(3, K + m + 2)
        d = [1, h1, h1 ** 2 + h2, h1 ** 3 + 3 * h1 * h2 + h3, h1 ** 4 + 6 * h1 ** 2 * h2 + 4 * h1 * h3 + 3 * h2 ** 2 + h4]
        for j in range(J + 1):
            out[j] += base * d[j]
    return [g0m * z for z in out]
pl = [sp.lambdify(k, sp.diff(p[i], k, d), 'mpmath') for i in range(3) for d in range(5)]
def pd(i, d, kk): return pl[5 * i + d](kk)
def run_back(K, vals):
    """vals[j][i] = j-th derivative at K + i (i = 0, 1); returns dict j -> {k: value} for 1 <= k <= K+1"""
    J = len(vals) - 1
    D = {j: {K: vals[j][0], K + 1: vals[j][1]} for j in range(J + 1)}
    for kk in range(K - 1, 0, -1):
        for j in range(J + 1):
            # sum_{l<=j} C(j,l) sum_i p_i^{(j-l)}(kk) D_l(kk+i) = 0, solved for D_j(kk)
            tot = mp.mpf(0)
            for l in range(j + 1):
                for i in range(3):
                    if l == j and i == 0: continue
                    tot += mp.binomial(j, l) * pd(i, j - l, kk) * D[l][kk + i]
            D[j][kk] = -tot / pd(0, 0, kk)
    return D
res = {}
for K, Nt in ((150, 520), (200, 380)):
    eg = germ_coeffs(Nt + 2)
    v0 = beta_sums(K, Nt, eg); v1 = beta_sums(K + 1, Nt, eg)
    tail = g0m * eg[Nt] * mp.beta(K + 1, Nt + 1) / mp.mpf(9) ** (K + 1) / (g0m * eg[0] * mp.beta(K + 1, 1) / mp.mpf(9) ** (K + 1))
    D = run_back(K, [[v0[j], v1[j]] for j in range(5)])
    res[K] = D
    say(f'   depth K = {K}, {Nt} terms (last term / first term = {mp.nstr(tail, 3)})')
D, D2 = res[150], res[200]
for j, name in enumerate(['P(1) = l', "P'(1) = l'", "P''(1) = l''", "P'''(1)", "P''''(1)"]):
    say(f'   {name:14s} =', mp.nstr(D[j][1], 110))
    say(f'   {"":14s}   two depths differ by', mp.nstr(abs(D[j][1] - D2[j][1]), 3))
say('   P(2) =', mp.nstr(D[0][2], 60), "; P'(2) =", mp.nstr(D[1][2], 60))
l, l1, l2, l3, l4 = (D[j][1] for j in range(5))
P2, P21, P22, P23, P24 = (D[j][2] for j in range(5))
say('   low-end relation, order 0: 6 - 3P(1) + 9P(2) =', mp.nstr(6 - 3 * l + 9 * P2, 5))
say("   order 1: L_1 - 10P(1) - 3P'(1) + 18P(2) + 9P'(2) with L_1 = 0:", mp.nstr(-10 * l - 3 * l1 + 18 * P2 + 9 * P21, 5))
say("   order 2: L_2 - 10P(1) - 10P'(1) - 3/2 P''(1) + 9P(2) + 18P'(2) + 9/2 P''(2) with L_2 = -pi^2:",
    mp.nstr(-mp.pi ** 2 - 10 * l - 10 * l1 - mp.mpf(3) / 2 * l2 + 9 * P2 + 18 * P21 + mp.mpf(9) / 2 * P22, 5))
L3 = l3 / 2 + 5 * l2 + 10 * l1 - 9 * (P23 / 6 + P22 + P21)
L4 = l4 / 8 + 10 * l3 / 6 + 5 * l2 - 9 * (P24 / 24 + P23 / 3 + P22 / 2)
say('   L_3 read from order 3 =', mp.nstr(L3, 60))
say('   L_4 read from order 4 =', mp.nstr(L4, 60))
say('      checks: 4 sum_m m^-3 =', mp.nstr(4 * mp.zeta(3), 60), ';  (7/60)pi^4 + (3/4) l^2 =', mp.nstr(mp.mpf(7) / 60 * mp.pi ** 4 + mp.mpf(3) / 4 * l ** 2, 60))
say('      differences:', mp.nstr(L3 - 4 * mp.zeta(3), 3), mp.nstr(L4 - mp.mpf(7) / 60 * mp.pi ** 4 - mp.mpf(3) / 4 * l ** 2, 3))
lq = mp.quad(lambda z: mp.log((1 + z) ** 2 / z) / (1 + z + z * z), [0, 1, mp.inf])
say('   check: l by quadrature of the one-dimensional form =', mp.nstr(lq, 60), '; difference', mp.nstr(lq - l, 3))

say('=' * 100)
say('7. The arc integrals S_j = -int_0^{2pi/3} log^{j-1}(2 sin(v/2)) dv')
S = {j: -mp.quad(lambda vv: mp.log(2 * mp.sin(vv / 2)) ** (j - 1), [0, 2 * mp.pi / 3]) for j in (1, 2, 3, 4)}
cl = mp.nsum(lambda m: mp.sin(2 * mp.pi * m / 3) / m ** 2, [1, mp.inf]) if False else None
cl2 = mp.sqrt(3) / 2 * (mp.zeta(2, mp.mpf(1) / 3) - mp.zeta(2, mp.mpf(2) / 3)) / 9
say('   S_1 =', mp.nstr(S[1], 30), ' = -2pi/3:', mp.nstr(S[1] + 2 * mp.pi / 3, 3))
say('   S_2 =', mp.nstr(S[2], 60), ';  sum_m sin(2 pi m/3)/m^2 = (sqrt3/2) sum_m chi(m)/m^2 =', mp.nstr(cl2, 60))
say('   2 sqrt3 S_2 - l =', mp.nstr(2 * mp.sqrt(3) * S[2] - l, 3), '  (Exercise ex:smallc-torus proves l = 2 sqrt3 S_2)')
say('   S_3 =', mp.nstr(S[3], 30), ';  S_4 =', mp.nstr(S[4], 30))
