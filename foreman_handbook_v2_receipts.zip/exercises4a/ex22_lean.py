"""Receipt for Exercise ex:smallc-lean: the lean (2 1; 4, 1) of binom([3],1).

Run: python3 ex22_lean.py      (sympy, mpmath; exact arithmetic except the labelled checks)
Prints: the walls and V_1; the closings; the box B_2(1,1) modulo S_3, its spanning set, the matrix B(k) and a
certificate on the stems for both rows; the rows and the law; the symbol and the native gauges; B(infinity) and its
eigenvectors; the low-end relation; the reduction of Psi/K^2 in the box B_2(2,2) of the centre ray, which gives
54 P(1) = 11 - 4 l; P(2); the share side (check); the denominators of the rational coordinates (check).
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from boxkit import *
from fractions import Fraction as Fr
from math import factorial, lcm, log
import mpmath as mp

say = print
tb = Table(3, [{0}, {1}, {2}])
lean = Ray(tb, (2, 2, 2), 4, 1)
say('=' * 100)
say('1. Walls and V_1')
say('   walls kappa_{1,S}:', {tuple(sorted(e + 1 for e in S)): v for S, v in lean.kappa1.items()})
from itertools import permutations
V1 = sum(Fr(1, lean.kappa1[frozenset(pi[1:])] * lean.kappa1[frozenset(pi[2:])]) for pi in permutations(range(3)))
say('   V_1 =', V1)

say('=' * 100)
say('2. Closings C_j(1) = CT(f^-j), f^-1 = K^4 Psi / alpha^(2,2,2)')
fi = lean.finv()
def ct_power(poly, j):
    cur = {(0, 0, 0): 1}
    for _ in range(j):
        new = {}
        for u, c in cur.items():
            for v, d in poly.items():
                w = (u[0] + v[0], u[1] + v[1], u[2] + v[2]); new[w] = new.get(w, 0) + c * d
        cur = new
    return cur.get((0, 0, 0), 0)
xs = [ct_power(fi, j) for j in range(6)]
def formula(j):
    tot = Fr(0)
    for b1 in range(j + 1):
        for b2 in range(j + 1 - b1):
            b3 = j - b1 - b2
            tot += Fr(1, factorial(b1) * factorial(b1 + j) * factorial(b2) * factorial(b2 + j) * factorial(b3) * factorial(b3 + j))
    return tot * factorial(4 * j) * factorial(j)
say('   closings j = 0..5:', xs, '; formula (4j)! j! sum prod (b!(b+j)!)^-1 agrees:', all(formula(j) == xs[j] for j in range(6)))

say('=' * 100)
say('3. The box B_2(1,1) of the lean modulo S_3')
G = [perm_map((1, 0, 2), 3), perm_map((0, 2, 1), 3)]
box = Box(lean, 2, 1, 1, G)
by_level = {}
for s in box.syms:
    by_level.setdefault((s[3], s[4]), set()).add(box.orbit_of[s])
say('   symbols', len(box.syms), '; orbits', len(box.orbits), '; per level:', {lv: len(v) for lv, v in sorted(by_level.items())}, '; stems', len(box.stems))
nK = sum(1 for d, _ in box.relations if d[0] == 'K'); nP = sum(1 for d, _ in box.relations if d[0] == 'Psi'); nM = sum(1 for d, _ in box.relations if d[0] == 'MR')
say(f'   relations: {nK} letter identities for K, {nP} for Psi, {nM} mark relations of stems')
distinct = {tuple(sorted((x, str(c)) for x, c in box.to_orbits(rel).items())) for d, rel in box.relations}
say('   distinct orbit-averaged relations:', len(distinct))
box.eliminate()
say('   rank', len(box.pivots), '; free orbits:', [(r[:3], r[3:], str(box.deg[r])) for r in box.free])
span = sorted([r for r in box.free if r[3:] == (0, 0) and box.deg[r] <= 1], key=lambda r: (box.deg[r], r))
say('   spanning set at s = 1:', [(r[:3], str(box.deg[r]), box.orbit_size[r]) for r in span])
Bmat = []
for r0 in span:
    nf = box.normal_form(box.times_finv(box.average(r0)))
    assert set(nf) <= set(span)
    Bmat.append([nf.get(r, ZERO) for r in span])
Bk = sp.Matrix([[FK.to_sympy(x) for x in row] for row in Bmat])
say('   B(k) =')
for i in range(2):
    say('     ', [str(sp.factor(Bk[i, j])) for j in range(2)])

# certificate on the stems for both rows
a1, a2, a3 = sp.symbols('a1 a2 a3'); Aa = (a1, a2, a3)
e1 = a1 + a2 + a3; e2 = a1 * a2 + a1 * a3 + a2 * a3; e3 = a1 * a2 * a3
cdef = [2 - 4 * Aa[e] / e1 - Aa[e] * (e1 - Aa[e]) / e2 for e in range(3)]
finv = e1 ** 4 * e2 / e3 ** 2
bb = sum(Aa[i] / Aa[j] for i in range(3) for j in range(3) if i != j) / 6
stems = [s[:3] for s in box.stems]
def swap(P, e):
    if e == 0: return P
    return P.subs({Aa[0]: Aa[e], Aa[e]: Aa[0]}, simultaneous=True)
orbs23, seen = [], set()
for v in stems:
    if v in seen: continue
    o = sorted({v, (v[0], v[2], v[1])}); seen |= set(o); orbs23.append(o)
D = lambda P, e: Aa[e] * sp.diff(P, Aa[e])
certs = []
for i, bi in enumerate([sp.Integer(1), bb]):
    target = sp.together(finv * bi - Bk[i, 0] - Bk[i, 1] * bb)
    cs = sp.symbols('y0:%d' % len(orbs23))
    G1 = sum(cs[j] * sum(a1 ** v[0] * a2 ** v[1] * a3 ** v[2] for v in o) for j, o in enumerate(orbs23))
    Gs = [swap(G1, e) for e in range(3)]
    expr = sp.numer(sp.together(sum(k * cdef[e] * Gs[e] + D(Gs[e], e) for e in range(3)) - target))
    eqs = sp.Poly(sp.expand(expr), a1, a2, a3).coeffs()
    sol = sp.solve(eqs, cs, dict=True)
    s0 = {x: sp.sympify(sol[0].get(x, 0)) for x in cs}          # free parameters set to 0
    s0 = {x: sp.factor(v.subs({y: 0 for y in cs})) for x, v in s0.items()}
    G1v = sum(s0[cs[j]] * sum(a1 ** v[0] * a2 ** v[1] * a3 ** v[2] for v in o) for j, o in enumerate(orbs23))
    Gv = [swap(G1v, e) for e in range(3)]
    ok = sp.simplify(sp.together(sum(k * cdef[e] * Gv[e] + D(Gv[e], e) for e in range(3)) - target)) == 0
    nz = [(orbs23[j][0], str(s0[cs[j]])) for j in range(len(orbs23)) if s0[cs[j]] != 0]
    say(f'   certificate of row {i + 1}: ansatz on {len(orbs23)} pairs of stems, {len(eqs)} equations, free parameters {len([x for x in cs if x not in sol[0]])};'
        f' a solution with {len(nz)} nonzero coefficients verifies: {ok}')
    certs.append(nz)
say('   the certificate of the second row, G_1 (G_2, G_3 its images under (1 2), (1 3)); stems as exponent vectors, symmetrized in marks 2,3:')
for v, cval in certs[1]:
    say('      ', v, cval)

say('=' * 100)
say('4. The rows and the law')
w0 = sp.Matrix([[1, 0]]); w1 = sp.simplify(w0 * Bk); w2 = sp.simplify(w1.subs(k, k - 1) * Bk)
q0, q1 = sp.symbols('q0 q1')
solq = sp.solve(list(q0 * w0 + q1 * w1 + w2), [q0, q1], dict=True)[0]
qs = [sp.together(solq[q0]), sp.together(solq[q1]), sp.Integer(1)]
den = sp.lcm([sp.denom(x) for x in qs])
qs = [sp.factor(sp.cancel(x * den)) for x in qs]
g = sp.gcd(sp.gcd(sp.Poly(qs[0], k), sp.Poly(qs[1], k)), sp.Poly(qs[2], k))
qs = [sp.factor(sp.cancel(x / g.as_expr())) for x in qs]
say('   (q0, q1, q2) =', qs)
p = [sp.expand(qs[2 - j].subs(k, k + 2)) for j in range(3)]
cont = sp.gcd_list([sp.Poly(x, k).content() for x in p])
p = [sp.expand(x / cont) for x in p]
if sp.Poly(p[0], k).LC() > 0: p = [-x for x in p]
say('   law p_0, p_1, p_2:')
for j in range(3): say('     ', sp.factor(p[j]))
src = [-3 * k ** 2 * (3 * k + 1) * (3 * k + 2) * (265 * k ** 2 + 636 * k + 383),
       1721705 * k ** 6 + 7575502 * k ** 5 + 13047276 * k ** 4 + 11068046 * k ** 3 + 4766659 * k ** 2 + 965100 * k + 75600,
       972 * (k + 1) ** 2 * (4 * k + 5) * (4 * k + 7) * (265 * k ** 2 + 106 * k + 12)]
ratio = [sp.simplify(p[j] / src[j]) for j in range(3)]
say('   equals the law displayed in the solution up to the factor', ratio)
deg = max(sp.Poly(x, k).degree() for x in src)
sym = [sp.Poly(src[j], k).coeff_monomial(k ** deg) for j in range(3)]
lam = sp.symbols('lambda')
say('   degree', deg, '; symbol', sp.factor(sum(sym[j] * lam ** j for j in range(3))))
say('   closings satisfy the reflected law sum_i p_i(-j) C_(j-i) = 0 for j <= 5:',
    all(sum(src[i].subs(k, -j) * xs[j - i] for i in range(3) if j - i >= 0) == 0 for j in range(6)))

say('=' * 100)
say('5. Native gauges')
mvec = (2, 2, 2); s1, t1 = 4, 1
def defects(al):
    E1 = sum(al); E2 = al[0] * al[1] + al[0] * al[2] + al[1] * al[2]
    return [sp.Rational(mvec[e]) - sp.Rational(s1 * al[e], E1) - sp.Rational(t1 * al[e] * (E1 - al[e]), E2) for e in range(3)]
def fval(al):
    E1 = sum(al); E2 = al[0] * al[1] + al[0] * al[2] + al[1] * al[2]; E3 = al[0] * al[1] * al[2]
    return sp.Rational(E3 ** 2, E1 ** 4 * E2)
y1, y2 = sp.symbols('y1 y2')
logf = sp.log((sp.exp(y1) * sp.exp(y2)) ** 2) - 4 * sp.log(sp.exp(y1) + sp.exp(y2) + 1) - sp.log(sp.exp(y1 + y2) + sp.exp(y1) + sp.exp(y2))
for al in [(1, 1, 1), (3, 3, -2), (3, -2, 3), (-2, 3, 3)]:
    say(f'   alpha = {al}: defects {defects(al)}, f = {fval(al)}')
# Hessian of log f in the chart alpha_3 = 1 at alpha = (3/(-2), 3/(-2), 1)·(-2) up to scale: take alpha = (-3/2, -3/2, 1)
def hessdet(al):
    # alpha_e = al_e e^{y_e}, y_3 = 0; f is real analytic there; derivatives of log f in y1, y2 at 0
    a = [al[0] * sp.exp(y1), al[1] * sp.exp(y2), al[2]]
    E1 = sum(a); E2 = a[0] * a[1] + a[0] * a[2] + a[1] * a[2]; E3 = a[0] * a[1] * a[2]
    lf = 2 * sp.log(E3) - 4 * sp.log(E1) - sp.log(E2)
    H = sp.Matrix(2, 2, lambda i, j: sp.diff(lf, [y1, y2][i], [y1, y2][j]).subs({y1: 0, y2: 0}))
    return sp.nsimplify(sp.simplify(H.det()))
say('   det Hessian of log f at (1,1,1):', hessdet((1, 1, 1)), '; at (-3/2,-3/2,1) (the point (3,3,-2) up to scale):', hessdet((sp.Rational(-3, 2), sp.Rational(-3, 2), 1)))
Binf = Bk.applyfunc(lambda x: sp.limit(x, k, sp.oo))
say('   B(infinity) =', Binf.tolist(), '; eigenvalues', Binf.eigenvals())
for al in [(1, 1, 1), (3, 3, -2)]:
    bv = sp.Rational(sum(sp.Rational(al[i], al[j]) for i in range(3) for j in range(3) if i != j), 6)
    say(f'   beta at {al} = (1, {bv}); B(inf) beta = {list(Binf * sp.Matrix([1, bv]))}; 1/f = {1 / fval(al)}')

say('=' * 100)
say('6. The low-end relation')
c0, c1, c2 = src
say('   [k^2]c_0 =', sp.Poly(c0, k).coeff_monomial(k ** 2), ' c_1(0) =', c1.subs(k, 0), ' c_2(0) =', c2.subs(k, 0), '; V_1 =', V1)
gg = sp.gcd_list([sp.Poly(c0, k).coeff_monomial(k ** 2), c1.subs(k, 0), c2.subs(k, 0)])
say('   divided by', gg, ':', sp.Poly(c0, k).coeff_monomial(k ** 2) / gg, '+', c1.subs(k, 0) / gg, 'P(1) +', c2.subs(k, 0) / gg, 'P(2) = 0')

say('=' * 100)
say('7. The lean value read on the centre ray: Psi/K^2 in the box B_2(2,2) of the centre ray modulo S_3 and the Cremona')
centre = Ray(tb, (1, 1, 1), 1, 1)
Gc = [perm_map((1, 0, 2), 3), perm_map((0, 2, 1), 3), cremona_map(3)]
cbox = Box(centre, 2, 2, 2, Gc)
cbox.eliminate()
say('   symbols', len(cbox.syms), '; orbits', len(cbox.orbits), '; relations', len(cbox.relations), '; rank', len(cbox.pivots), '; free', [(r[:3], r[3:]) for r in cbox.free])
ins = {tuple(0 if x == e else 1 for x in range(3)) + (2, 0): ONE for e in range(3)}
nf = cbox.normal_form(ins)
say('   Psi/K^2 = sum_e alpha^(E-e)/K^2 has the normal form', {r[:3]: fk_str(c) for r, c in nf.items()})
Acoef = FK.to_sympy(nf.get((0, 0, 0, 0, 0), ZERO)); Bcoef = FK.to_sympy(nf.get(cbox.orbit_of[(1, -1, 0, 0, 0)], ZERO))
ell = sp.symbols('ell')
P1c, P2c = ell, (ell - 2) / 3
b1at2 = (P1c - 3 * P2c) / 6
val = sp.simplify(Acoef.subs(k, 2) * P2c + Bcoef.subs(k, 2) * b1at2)
say('   at k = 2: A(2) =', Acoef.subs(k, 2), ', B(2) =', Bcoef.subs(k, 2), '; <b1>_2 = (l - 3P(2))/6; P_lean(1) =', sp.factor(val), '; 54 P_lean(1) =', sp.expand(54 * val))
P1l = val
P2l = sp.simplify((383 - 12600 * P1l) / 68040)
say('   P_lean(2) from the low-end relation =', sp.factor(P2l))
# the lean values at higher K from its law
def lean_vals(K):
    vals = {1: sp.expand(P1l), 2: sp.expand(P2l)}
    for kk in range(1, K - 1):
        vals[kk + 2] = sp.expand(-(c0.subs(k, kk) * vals[kk] + c1.subs(k, kk) * vals[kk + 1]) / c2.subs(k, kk))
    return vals
lv = lean_vals(8)
say('   P_lean(3) =', lv[3])

say('=' * 100)
say('Checks (floating point)')
mp.mp.dps = 40
l_num = mp.quad(lambda t: mp.log((1 + t) ** 2 / t) / (1 + t + t * t), [0, 1, mp.inf])
Pl1 = (11 - 4 * l_num) / 54
say('   (11 - 4 l)/54 =', mp.nstr(Pl1, 35))
G1f = lambda y: 2 * mp.sqrt(y) * mp.besselk(1, 2 * mp.sqrt(y))
share = mp.quad(lambda y: G1f(y) ** 3, [0, 1, 10, mp.inf]) / 6
say('   share side (1/6) int_0^oo G_1(1,y)^3 dy =', mp.nstr(share, 35))
say('   P_lean(2) =', mp.nstr(sp.lambdify(ell, P2l, 'mpmath')(l_num), 20), '; ratio P(2)/P(1) =', mp.nstr(sp.lambdify(ell, P2l, 'mpmath')(l_num) / Pl1, 10), ' vs f* = 1/243 =', mp.nstr(mp.mpf(1) / 243, 10))
# denominators of the rational coordinates
lvK = lean_vals(240)
def coords(e):
    pe = sp.Poly(e, ell)
    return [sp.Rational(pe.coeff_monomial(ell)), sp.Rational(pe.coeff_monomial(1))]
D = {}
d_lcm = 1
for K_ in range(1, 241):
    cK, rK = coords(lvK[K_])
    D[K_] = lcm(int(cK.q), int(rK.q))
for K_ in (40, 80, 120, 160, 200, 240):
    dK = 1
    for i in range(1, K_ + 1): dK = lcm(dK, i)
    say(f'   K={K_}: log D_K = {log(D[K_]):.1f};  log(D_K/lcm(1..K)^2)/K = {(log(D[K_]) - 2 * log(dK)) / K_:.3f};  log D_K/K = {log(D[K_]) / K_:.3f};  log 243 = {log(243):.3f}')
bad = [K_ for K_ in range(1, 241) if not D[K_] > 243 ** K_ * K_ * K_]
say('   exact: D_K > 243^K K^2 for every K with', min(K_ for K_ in range(1, 241) if all(D[j] > 243 ** j * j * j for j in range(K_, 241))), '<= K <= 240; it fails at K =', bad)
for (K1, K2) in ((120, 160), (160, 200), (200, 240)):
    say(f'   window {K1}..{K2}: (log D_K2 - log D_K1)/(K2-K1) = {(log(D[K2]) - log(D[K1])) / (K2 - K1):.3f}')
