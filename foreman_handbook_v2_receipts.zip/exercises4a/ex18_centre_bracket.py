"""Receipt for Exercise ex:smallc-bracket: the centre ray of binom([3],1), bracketed.

Run: python3 ex18_centre_bracket.py      (sympy, mpmath; exact arithmetic except the final check)
Prints, in the order of the solution: the walls and V_1; the sum of squares and the volume of the tropical stride;
the closings, their recurrence and the reflected candidate law; the certificate and its exact verification; the
walls of the certificate's insertions; the symbol, the signs and their Hessians; the low-end relation; the rational
solutions, their signs and the frame; the bracket, its width and the answer; the remarks; the decimal check.
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from kit3 import *
import mpmath as mp

say = print
say('=' * 100)
say('1. The ray: walls of the direction (1;1,1) and V_1')
w = walls((1, 1, 1), 1, 1)
for S in proper_subsets():
    say('   S =', sorted(e + 1 for e in S), skeleton(S), ' kappa_{1,S} =', w[tuple(sorted(S))])
say('   V_1 =', V1(w))

say('=' * 100)
say('2. The stride')
sos = a1 * (a2 - a3) ** 2 + a2 * (a3 - a1) ** 2 + a3 * (a1 - a2) ** 2
say('   e1 e2 - 9 e3 - sum a_i (a_j - a_k)^2 =', sp.expand(e1 * e2 - 9 * e3 - sos))
say('   e1 e2 = sum_{i != j} a_i^2 a_j + 3 e3:', sp.expand(e1 * e2 - (sum(A[i] ** 2 * A[j] for i in range(3) for j in range(3) if i != j) + 3 * e3)) == 0)
y1, y2, u = sp.symbols('y1 y2 u', real=True)
kp = sp.symbols('kp', positive=True)
# the six cones of the orders of (y1, y2, 0); on each, phi = largest entry less the smallest
I1 = sp.integrate(sp.integrate(sp.exp(-kp * y1), (y2, 0, y1)), (y1, 0, sp.oo))          # y1 >= y2 >= 0
I2 = sp.integrate(sp.exp(-kp * y1), (y1, 0, sp.oo)) * sp.integrate(sp.exp(kp * y2), (y2, -sp.oo, 0))   # y1 >= 0 >= y2
I3 = sp.integrate(sp.integrate(sp.exp(kp * y2), (y1, y2, 0)), (y2, -sp.oo, 0))          # 0 >= y1 >= y2
say('   cone integrals:', sp.simplify(I1), sp.simplify(I2), sp.simplify(I3), '  total over six cones:', sp.simplify(2 * (I1 + I2 + I3)))

say('=' * 100)
say('3. Closings and the candidate law')
x = [closing_centre(j) for j in range(16)]
say('   x_0..x_15 =', x)
shape, ns = least_recurrence(x, 2, 2)
say('   ansatz sum_i p_i(j) x_(j+i) = 0, deg p_i <= 2:', shape[0], 'equations,', shape[1], 'unknowns, nullity', len(ns))
v = ns[0]
v = v / sp.gcd(list(v))
if v[8] < 0: v = -v
jj = sp.symbols('j')
p = [sp.factor(sum(v[3 * i + d] * jj ** d for d in range(3))) for i in range(3)]
say('   p_0(j), p_1(j), p_2(j) =', p, '   [the recurrence: p_0(j) x_j + p_1(j) x_(j+1) + p_2(j) x_(j+2) = 0]')
cL = [sp.expand(p[2 - i].subs(jj, -k - 2)) for i in range(3)]
say('   reflected, c_i(k) = p_(2-i)(-k-2):', cL, ' = law_L(k):', [sp.expand(c) for c in law_L(k)] == cL)
say('   the recurrence holds at every computed shift and fails for no j < 14:', all(sum(p[i].subs(jj, j) * x[j + i] for i in range(3)) == 0 for j in range(14)))

say('=' * 100)
say('4. The certificate')
R = [A[e] / e1 for e in range(3)]
Rs = [A[e] * (e1 - A[e]) / e2 for e in range(3)]
c = [sp.simplify(1 - R[e] - Rs[e]) for e in range(3)]
f = e3 / (e1 * e2)
for e in range(3):
    say(f'   c_{e+1} = 1 - R_{e+1} - R*_{e+1}; equals D_{e+1} log f:', sp.simplify(c[e] - A[e] * sp.diff(sp.log(f), A[e])) == 0)
say('   sum_e c_e =', sp.simplify(sum(c)))
N1 = -a1 ** 2 * (k * a1 * (a2 + a3) + (2 + 3 * k) * (a2 ** 2 + a3 ** 2) - (1 - k) * a2 * a3)
def swap(P, e):
    if e == 0: return P
    return P.subs({A[0]: A[e], A[e]: A[0]}, simultaneous=True)
N = [sp.expand(swap(N1, e)) for e in range(3)]
g = [N[e] / (e1 ** 2 * e2) for e in range(3)]
say('   N_1 =', sp.expand(N1))
lhs = k ** 2 - (10 * k ** 2 + 10 * k + 3) * f + 9 * (k + 1) ** 2 * f ** 2
D = lambda P, e: A[e] * sp.diff(P, A[e])
rhs = sum(D(g[e], e) + k * c[e] * g[e] for e in range(3))
say('   (C) holds identically in alpha and k:', sp.simplify(sp.together(lhs - rhs)) == 0)
# powers of k, times e1^3 e2^2, in the e-basis
g0 = [sp.expand(g[e].subs(k, 0) * e1 ** 2 * e2) for e in range(3)]
g1 = [sp.expand(sp.diff(g[e], k) * e1 ** 2 * e2) for e in range(3)]
sc = e1 ** 3 * e2 ** 2
def prod_e_basis(expr):
    return to_e_basis(sp.expand(sp.cancel(expr * sc)), 7)
T_k2 = prod_e_basis(sum(c[e] * g1[e] / (e1 ** 2 * e2) for e in range(3)))
T_k1a = prod_e_basis(sum(D(g1[e] / (e1 ** 2 * e2), e) for e in range(3)))
T_k1b = prod_e_basis(sum(c[e] * g0[e] / (e1 ** 2 * e2) for e in range(3)))
T_k0 = prod_e_basis(sum(D(g0[e] / (e1 ** 2 * e2), e) for e in range(3)))
say('   g_e = g_e^(0) + k g_e^(1); N_1^(0) =', sp.factor(g0[0]), ';  N_1^(1) =', sp.factor(g1[0]))
say('   k^2: e1^3e2^2 sum_e c_e g_e^(1)            =', fmt_e(T_k2))
say('   k^1: e1^3e2^2 sum_e D_e g_e^(1)            =', fmt_e(T_k1a))
say('        e1^3e2^2 sum_e c_e g_e^(0)            =', fmt_e(T_k1b))
say('   k^0: e1^3e2^2 sum_e D_e g_e^(0)            =', fmt_e(T_k0))
say('   targets: e1^3e2^2 (1-10f+9f^2), (-10f+18f^2), (-3f+9f^2):', fmt_e(prod_e_basis(1 - 10 * f + 9 * f ** 2)), '|',
    fmt_e(prod_e_basis(-10 * f + 18 * f ** 2)), '|', fmt_e(prod_e_basis(-3 * f + 9 * f ** 2)))
# the ansatz: N_1 homogeneous of degree 4, symmetric in a2,a3, linear in k; N_e the exchange images
mons4 = [(i, j, 4 - i - j) for i in range(5) for j in range(5 - i)]
orbits, seen = [], set()
for m_ in mons4:
    if m_ not in seen:
        o = sorted({m_, (m_[0], m_[2], m_[1])}); seen |= set(o); orbits.append(o)
unk = []
cols = []
for o in orbits:
    for pk in range(2):
        mono = sum(a1 ** m_[0] * a2 ** m_[1] * a3 ** m_[2] for m_ in o) * k ** pk
        tot = 0
        for e in range(3):
            ge = swap(mono, e) / (e1 ** 2 * e2)
            tot += D(ge, e) + k * c[e] * ge
        cols.append(sp.Poly(sp.expand(sp.cancel(tot * sc)), a1, a2, a3, k))
target = sp.Poly(sp.expand(sp.cancel(lhs * sc)), a1, a2, a3, k)
keys = sorted(set().union(*[set(cl.as_dict()) for cl in cols]) | set(target.as_dict()))
M = sp.Matrix([[cl.as_dict().get(key, 0) for cl in cols] for key in keys])
say(f'   symmetric ansatz: {len(cols)} unknowns, {len(keys)} equations, rank {M.rank()}; homogeneous solutions of dimension {len(cols) - M.rank()}')
# which homogeneous solutions: one insertion h added at every mark with a symmetric numerator
say('   every monomial of every N_e divides into e1^2 e2 with positive coefficients (walls >= 0 below)')
pt = {a1: 1, a2: 2, a3: 4, k: sp.Rational(1, 3)}
say('   spot value at alpha=(1,2,4), k=1/3: f =', f.subs(pt), ', left side =', sp.nsimplify(lhs.subs(pt)), ', g =', [sp.nsimplify(g[e].subs(pt)) for e in range(3)])

say('=' * 100)
say('5. The walls of the insertions of the certificate: symbols (v; 2, 1), kappa_U = v_U - 2 d(U) - d*(U)')
mins = []
for e in range(3):
    for mon in sp.Poly(N[e], a1, a2, a3, k).monoms():
        vv = mon[:3]
        kap = [sum(vv[i] for i in S) - 2 * skeleton(S)['d'] - skeleton(S)['dstar'] for S in proper_subsets()]
        mins.append(min(kap))
say('   least wall over the symbols of g_1, g_2, g_3:', min(mins), ' (so wall degree 0: |g_e| bounded on the orthant)')

say('=' * 100)
say('6. Symbol, signs, Hessians')
sym = [sp.Poly(cL[i], k).coeff_monomial(k ** 2) for i in range(3)]
lam = sp.symbols('lambda')
say('   symbol chi(lambda) =', sp.factor(sum(sym[i] * lam ** i for i in range(3))))
for eta in [(1, 1, 1), (-1, 1, 1), (1, -1, 1), (-1, -1, 1)]:
    Kv = sum(eta)
    Pe = [Fr(t_, Kv) for t_ in eta]
    cov = [[(Pe[i] if i == j else 0) - Pe[i] * Pe[j] for j in range(2)] for i in range(2)]
    detH = 4 * (cov[0][0] * cov[1][1] - cov[0][1] * cov[1][0])
    say(f'   sign {eta}: K = {Kv}, native value K^-2 = {Fr(1, Kv * Kv)}, signed law {Pe}, det Hessian = {detH}')

say('=' * 100)
say('7. The low-end relation: [k^2]c_0 V_1 + c_1(0) P(1) + c_2(0) P(2) = 0')
say('   [k^2]c_0 =', sp.Poly(cL[0], k).coeff_monomial(k ** 2), ' c_0 vanishes to order 2:', sp.Poly(cL[0], k).coeff_monomial(1) == 0 and sp.Poly(cL[0], k).coeff_monomial(k) == 0,
    ' c_1(0) =', cL[1].subs(k, 0), ' c_2(0) =', cL[2].subs(k, 0))
say('   so 6 - 3 l + 9 P(2) = 0, P(2) = (l - 2)/3')

say('=' * 100)
say('8. The rational solutions')
KMAX = 16
cc = run_law(1, Fr(1, 3), KMAX)
rr = run_law(0, Fr(-2, 3), KMAX)
say('   K, c(K), r(K), a_K = -r/c:')
for K_ in range(1, 11):
    say(f'   {K_:3d}  {str(cc[K_]):>22s}  {str(rr[K_]):>30s}  {str(-rr[K_] / cc[K_]):>30s}  {float(-rr[K_] / cc[K_]):.10f}')
xs = [closing_centre(j) for j in range(KMAX)]
say(f'   9^(K-1) c(K) = x_(K-1) for K <= {KMAX}:', all(cc[K_] * 9 ** (K_ - 1) == xs[K_ - 1] for K_ in range(1, KMAX + 1)))
say(f'   c(K) >= 3^(1-K) and 9 c(K) >= 3 c(K-1) for K <= {KMAX}:', all(cc[K_] >= Fr(1, 3 ** (K_ - 1)) for K_ in range(1, KMAX + 1)),
    all(9 * cc[K_] >= 3 * cc[K_ - 1] for K_ in range(2, KMAX + 1)))
say('   7j^2+24j+20 - 3(j+2)^2 =', sp.factor(7 * jj ** 2 + 24 * jj + 20 - 3 * (jj + 2) ** 2), ';  10j^2+30j+23 - 3(j+1)^2 =', sp.expand(10 * jj ** 2 + 30 * jj + 23 - 3 * (jj + 1) ** 2))
xp = {0: Fr(1), 1: Fr(3)}
for j_ in range(0, KMAX - 2):
    xp[j_ + 2] = ((10 * j_ * j_ + 30 * j_ + 23) * xp[j_ + 1] - 9 * (j_ + 1) ** 2 * xp[j_]) / (j_ + 2) ** 2
say("   x'_j = 9^j c(j+1) satisfies 9(j+1)^2 x'_j - (10j^2+30j+23) x'_(j+1) + (j+2)^2 x'_(j+2) = 0 with x'_0 = 1, x'_1 = 3:",
    all(xp[j_] == cc[j_ + 1] * 9 ** j_ for j_ in range(KMAX - 1)))
frame_ok = all(cc[K_] * rr[K_ + 1] - cc[K_ + 1] * rr[K_] == Fr(-2, 3) / 9 ** (K_ - 1) / (K_ * K_) for K_ in range(1, KMAX))
say(f'   frame c(k) r(k+1) - c(k+1) r(k) = -(2/3) 9^(1-k)/k^2 for k < {KMAX}:', frame_ok)
say('   frame recursion C_(k+1) = (-1)^2 c_0(k)/c_2(k) C_k = k^2/(9(k+1)^2) C_k; C_1 =', cc[1] * rr[2] - cc[2] * rr[1])

say('=' * 100)
say('9. The bracket')
aK = {K_: -rr[K_] / cc[K_] for K_ in range(1, KMAX + 1)}
bK = {K_: (rr[K_ - 1] - 9 * rr[K_]) / (9 * cc[K_] - cc[K_ - 1]) for K_ in range(2, KMAX + 1)}
sK = {K_: -rr[K_] / (cc[K_] - Fr(1, 9 ** (K_ - 1))) for K_ in range(2, KMAX + 1)}
for K_ in range(2, 11):
    wdt = bK[K_] - aK[K_]
    say(f'   K={K_:2d}  b_K = {str(bK[K_]):>28s}  width = {str(wdt):>34s} = {float(wdt):.4e}   simple-bound width {float(sK[K_] - aK[K_]):.4e}')
ok = all(bK[K_] - aK[K_] == Fr(2, 3) * Fr(1, 9 ** (K_ - 2)) / ((K_ - 1) ** 2 * cc[K_] * (9 * cc[K_] - cc[K_ - 1]))
         == Fr(2, 3) * 9 ** (K_ - 1) / ((K_ - 1) ** 2 * xs[K_ - 1] * (xs[K_ - 1] - xs[K_ - 2])) for K_ in range(2, KMAX + 1))
say(f'   the two forms of the width agree for 2 <= K <= {KMAX}:', ok, '; width <= 1/(K-1)^2:', all(bK[K_] - aK[K_] <= Fr(1, (K_ - 1) ** 2) for K_ in range(2, KMAX + 1)))
say('   a_9 =', aK[9], '; b_9 =', bK[9], '; b_9 - a_9 =', bK[9] - aK[9], '; < 111/10^9:', bK[9] - aK[9] < Fr(111, 10 ** 9),
    '; width at K=8 > 10^-6:', bK[8] - aK[8] > Fr(1, 10 ** 6))
say('   K = 2: a_2 =', aK[2], ' b_2 =', bK[2])

say('=' * 100)
say('Remarks')
say('   the reading of (L) at k = 0 with 0*P(0) = 0 gives P(2) = l/3; the gauge bound then needs l/3 < l/9.')
pr = run_law(1, Fr(1, 3), 12)
say('   with P(2) = l/3 every P(K) is l times', [str(pr[K_]) for K_ in range(1, 8)], '...')
say('   a_8 =', aK[8], '; b_9 - a_8 =', float(bK[9] - aK[8]), '; a_9 - a_8 =', float(aK[9] - aK[8]))
say('   simple bound at K = 10: a_10 =', aK[10], ', width', float(sK[10] - aK[10]), '; c(K) - 9^(1-K) = 9^(1-K)(x_(K-1) - 1) > 0 for K>=2:',
    all(cc[K_] - Fr(1, 9 ** (K_ - 1)) == Fr(xs[K_ - 1] - 1, 9 ** (K_ - 1)) for K_ in range(2, KMAX + 1)))
say('   b_9 - a_8 =', bK[9] - aK[8], '< 10^-6:', bK[9] - aK[8] < Fr(1, 10 ** 6))
say('   2343907/10^6 < a_9:', Fr(2343907, 10 ** 6) < aK[9], '; b_9 - 2343907/10^6 =', float(bK[9] - Fr(2343907, 10 ** 6)))

say('=' * 100)
say('Check (floating point, not part of the solution)')
mp.mp.dps = 45
ell = mp.quad(lambda t: mp.log((1 + t) ** 2 / t) / (1 + t + t * t), [0, 1, mp.inf])
say('   l = int_0^oo log((1+x)^2/x)/(1+x+x^2) dx =', mp.nstr(ell, 40))
say('   l - a_8 =', mp.nstr(ell - mp.mpf(aK[8].numerator) / aK[8].denominator, 6), '; l - a_9 =', mp.nstr(ell - mp.mpf(aK[9].numerator) / aK[9].denominator, 6),
    '; b_9 - l =', mp.nstr(mp.mpf(bK[9].numerator) / bK[9].denominator - ell, 6))
P = lambda K_: mp.mpf(cc[K_].numerator) / cc[K_].denominator * ell + mp.mpf(rr[K_].numerator) / rr[K_].denominator
say('   P(2) =', mp.nstr(P(2), 15), '; l/3 =', mp.nstr(ell / 3, 15), '; P(9) =', mp.nstr(P(9), 20))
say('   9^K P(K)/l at K = 6, 7, 8, 9:', [mp.nstr(9 ** K_ * P(K_) / ell, 6) for K_ in (6, 7, 8, 9)])
# a direct two-dimensional check of l on the chart (alpha_3 = 1): inner integral over alpha_2 in closed form
inner = mp.quad(lambda a2: 1 / ((a2 + 3) * (3 * a2 + 2)), [0, mp.inf])
say('   inner integral at alpha_1 = 2 (A = 3, B = 2): int_0^oo da2/((a2+A)(A a2+B)) =', mp.nstr(inner, 30), '; log(A^2/B)/(A^2-B) =', mp.nstr(mp.log(mp.mpf(9) / 2) / 7, 30))
direct = mp.quad(lambda a1, a2: 1 / ((1 + a1 + a2) * (a1 + a2 + a1 * a2)), [0, 1, mp.inf], [0, 1, mp.inf]) if False else None
