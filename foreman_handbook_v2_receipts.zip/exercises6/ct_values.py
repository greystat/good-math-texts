"""The centre values of the lists of three and four marks read in the content: exact identities in Q(mu_3) and
Q(mu_2) with sympy, and labelled float renderings (mpmath, 40 digits) of the series and of the chains."""
import sympy as sp, mpmath as mp
mp.mp.dps = 40
w = sp.Rational(-1, 2) + sp.sqrt(3) * sp.I / 2   # e^{2 pi i/3}
# exact: (w - w^2)^2 = -3, the character of the cosets 1+3Z, 2+3Z as a combination of w^n, w^{-n}
assert sp.expand((w - w**2)**2 + 3) == 0 and sp.expand(w**3 - 1) == 0
for n in range(3):
    chi = {0: 0, 1: 1, 2: -1}[n]
    assert sp.simplify(sp.radsimp((w**n - w**(-n)) / (w - w**(-1))) - chi) == 0
assert sp.simplify(sp.radsimp(3 / (w - w**2)) - sp.expand(w**2 - w)) == 0      # 3/(w - w^2) = w^2 - w
print('exact: (w-w^2)^2 = -3; chi(n) = (w^n - w^-n)/(w - w^-1); 3/(w - w^2) = w^2 - w')
# renderings
W = mp.exp(2j * mp.pi / 3)
T21 = mp.polylog(2, W); T22 = mp.polylog(2, W**2)
S = mp.nsum(lambda k: 1 / (3 * k + 1)**2 - 1 / (3 * k + 2)**2, [0, mp.inf])
ell = 3 * S
print('rendering: ell = 3*(Tx2(1+3Z) - Tx2(2+3Z)) =', mp.nstr(ell, 30))
print('rendering: (w^2 - w)(T_{2,1/3} - T_{2,2/3}) =', mp.nstr((W**2 - W) * (T21 - T22), 30))
# the chain I(0; w^2, 0; 1) by its double integral, against -T_{2,1/3}
b = W**2
I2 = mp.quad(lambda t2: mp.quad(lambda t1: 1 / (t1 - b), [0, t2]) / t2, [0, 1])
print('rendering: I(0;w^2,0;1) =', mp.nstr(I2, 25), '  -T_{2,1/3} =', mp.nstr(-T21, 25))
I1 = mp.quad(lambda t: 1 / (t - b), [0, 1])
print('rendering: I(0;w^2;1) =', mp.nstr(I1, 25), '  (1/2)log 3 - i pi/6 =', mp.nstr(mp.log(3) / 2 - 1j * mp.pi / 6, 25), '  -T_{1,1/3} =', mp.nstr(mp.log(1 - W), 25))
g = lambda t: b + t * (1 - b)
I3 = mp.quad(lambda t: (1 - b) / g(t), [0, 1])
print('rendering: I(w^2;0;1) =', mp.nstr(I3, 25), '  2 pi i/3 =', mp.nstr(2j * mp.pi / 3, 25))
I4 = mp.quad(lambda t2: mp.quad(lambda t1: 1 / (t1 - 1), [0, t2]) / t2, [0, 1])
print('rendering: I(0;1,0;1) =', mp.nstr(I4, 25), '  -Tx2(IZ,0) =', mp.nstr(-mp.zeta(2), 25))
# four marks: v = Tx3(1/2+Z) = 4(T_{3,0} - T_{3,1/2}) = 7 Tx3(IZ,0); T_{3,1/2} = -(3/4) T_{3,0}
v = mp.nsum(lambda k: 1 / (k + mp.mpf(1) / 2)**3, [0, mp.inf])
T30 = mp.zeta(3); T31 = mp.polylog(3, -1)
print('rendering: v =', mp.nstr(v, 30), ' 4(T30 - T3h) =', mp.nstr(4 * (T30 - T31), 30), ' 7 Tx3 =', mp.nstr(7 * T30, 30))
print('rendering: T_{3,1/2} / T_{3,0} =', mp.nstr(T31 / T30, 30))
# the chain of Tx3: -I(0;1,0,0;1) by its triple integral
I5 = mp.quad(lambda t3: mp.quad(lambda t2: mp.log(1 - t2) / t2, [0, t3]) / t3, [0, 1])
print('rendering: I(0;1,0,0;1) =', mp.nstr(I5, 25), '  -Tx3(IZ,0) =', mp.nstr(-T30, 25))
