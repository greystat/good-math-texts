"""The cutting rule (Definition def:ct-cutting) on the symbols of the trails Tx3(IZ,0) and of index 2 at the
frequency 1/3; checks of Theorem thm:ct-coaction (i)-(iii) on them, in exact arithmetic.
Entries: 'Z' is 0, an integer r is the root of unity e^{2 pi i r/M}."""
from fractions import Fraction
from itertools import combinations
from collections import defaultdict
M = 3

def chain(*e):  # a formal chain I^s(a0; a1..aw; a_{w+1}) as a polynomial (dict monomial -> coeff)
    e = tuple(x if x == 'Z' else x % M for x in e)
    if len(e) == 2: return {(): Fraction(1)}                  # I^s(a;;b) = 1
    if e[0] == e[-1]: return {}                                # equal ends, weight >= 1: 0
    return {(e,): Fraction(1)}

def mul(p, q):
    r = defaultdict(Fraction)
    for a, x in p.items():
        for b, y in q.items():
            r[tuple(sorted(a + b, key=str))] += x * y
    return {k: v for k, v in r.items() if v}

def add(*ps, coeffs=None):
    r = defaultdict(Fraction)
    for i, p in enumerate(ps):
        c = 1 if coeffs is None else coeffs[i]
        for k, v in p.items(): r[k] += c * v
    return {k: v for k, v in r.items() if v}

def tmul(P, Q):  # product in S (x) S, tensors as dict (mono, mono) -> coeff
    r = defaultdict(Fraction)
    for (a1, a2), x in P.items():
        for (b1, b2), y in Q.items():
            r[(tuple(sorted(a1 + b1, key=str)), tuple(sorted(a2 + b2, key=str)))] += x * y
    return {k: v for k, v in r.items() if v}

def tensor(p, q):
    return {(a, b): x * y for a, x in p.items() for b, y in q.items() if x * y}

def delta_chain(e):
    a = list(e); w = len(a) - 2; out = defaultdict(Fraction)
    for k in range(w + 1):
        for S in combinations(range(1, w + 1), k):
            left = chain(a[0], *[a[s] for s in S], a[w + 1])
            s = [0] + list(S) + [w + 1]
            right = {(): Fraction(1)}
            for p in range(len(s) - 1):
                right = mul(right, chain(*a[s[p]:s[p + 1] + 1]))
            for kk, v in tensor(left, right).items(): out[kk] += v
    return {k: v for k, v in out.items() if v}

def delta(p):
    out = defaultdict(Fraction)
    for mono, c in p.items():
        t = {((), ()): Fraction(1)}
        for e in mono: t = tmul(t, delta_chain(e))
        for k, v in t.items(): out[k] += c * v
    return {k: v for k, v in out.items() if v}

def weight(mono): return sum(len(e) - 2 for e in mono)

def delta_left(T):   # (Delta (x) id) on S (x) S -> S^(x)3
    out = defaultdict(Fraction)
    for (a, b), c in T.items():
        for (a1, a2), d in delta({a: Fraction(1)}).items(): out[(a1, a2, b)] += c * d
    return {k: v for k, v in out.items() if v}

def delta_right(T):
    out = defaultdict(Fraction)
    for (a, b), c in T.items():
        for (b1, b2), d in delta({b: Fraction(1)}).items(): out[(a, b1, b2)] += c * d
    return {k: v for k, v in out.items() if v}

def counit_left(T):
    out = defaultdict(Fraction)
    for (a, b), c in T.items():
        if a == (): out[b] += c
    return {k: v for k, v in out.items() if v}

def counit_right(T):
    out = defaultdict(Fraction)
    for (a, b), c in T.items():
        if b == (): out[a] += c
    return {k: v for k, v in out.items() if v}

def rev_chain(e):
    w = len(e) - 2
    return {k: (-1) ** w * v for k, v in chain(*reversed(e)).items()}

def rot_chain(e, r):
    return chain(*[x if x == 'Z' else x + r for x in e])

def apply_auto(p, f):
    out = defaultdict(Fraction)
    for mono, c in p.items():
        t = {(): Fraction(1)}
        for e in mono: t = mul(t, f(e))
        for k, v in t.items(): out[k] += c * v
    return {k: v for k, v in out.items() if v}

def apply_auto2(T, f):
    out = defaultdict(Fraction)
    for (a, b), c in T.items():
        for ka, va in apply_auto({a: Fraction(1)}, f).items():
            for kb, vb in apply_auto({b: Fraction(1)}, f).items():
                out[(ka, kb)] += c * va * vb
    return {k: v for k, v in out.items() if v}

def show(T):
    def m(mono):
        if not mono: return '1'
        return '*'.join('I(' + str(e[0]) + ';' + ','.join(map(str, e[1:-1])) + ';' + str(e[-1]) + ')' for e in mono)
    return '  ' + '\n  '.join(f'{v:+} {m(a)} (x) {m(b)}' for (a, b), v in sorted(T.items(), key=str))

# the symbols: Tx3(IZ,0) has d=1, nu=3, a=0, so letter c^{-1} = 1 = e^{0}: (-1) I^s(0;1,0,0;1)
# T_{2,1/3}: d=1, nu=2, a=1/3, letter c^{-1} = e^{-2 pi i/3}, exponent -1 = 2 mod 3: (-1) I^s(0;w^2,0;1)
x = chain('Z', 0, 'Z', 'Z', 0)
y = chain('Z', 2, 'Z', 0)
for name, s in (('x = I^s(0;1,0,0;1)', x), ('y = I^s(0;w^2,0;1)', y)):
    D = delta(s)
    print('Delta', name); print(show(D))
    assert delta_left(D) == delta_right(D), 'coassociativity'
    assert counit_left(D) == s and counit_right(D) == s, 'counit'
    w = weight(next(iter(s)))
    assert all(weight(a) + weight(b) == w for (a, b) in D)
    rest = {k: v for k, v in D.items() if k not in (((), next(iter(s))), ((next(iter(s))), ()))}
    assert all(weight(a) > 0 and weight(b) > 0 for (a, b) in rest)
    # reversal
    assert delta(apply_auto(s, rev_chain)) == apply_auto2(D, rev_chain), 'reversal'
    print('Delta of the reversal:'); print(show(delta(apply_auto(s, rev_chain))))
    for r in range(M):
        f = lambda e, r=r: rot_chain(e, r)
        assert delta(apply_auto(s, f)) == apply_auto2(D, f), 'rotation'
    print('  coassociative, counital, graded, compatible with the reversal and the rotations: checked')

# the weight-two left factor of x is primitive, and so are the weight-one chains
for s in (chain('Z', 0, 'Z', 0), chain('Z', 'Z', 0), chain(0, 'Z', 'Z'), chain('Z', 2, 0), chain(2, 'Z', 0)):
    D = delta(s); e = next(iter(s))
    assert D == {((), e): 1, (e, ()): 1}, (e, D)
print('I^s(0;1,0;1), I^s(0;0;1), I^s(1;0;0), I^s(0;w^2;1), I^s(w^2;0;1) are primitive: checked')
