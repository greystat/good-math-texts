"""Signs as native gauges of a centre ray (Theorem thm:signgauges) and the independence of a box's spanning set
(Proposition prop:rays-spectrum (i)): for every sign eta with K(eta) != 0 (on the chart alpha_{n-1} = 1), its
native value K(eta)^-2, the determinant of the Hessian of -log f there (2 times the covariances of the indicators
under the signed measure P_eta(T) = eta^T / K(eta)), and the vector beta = (b_l(eta))_l of the spanning set.
Prints the rank of the beta's of the nondegenerate signs.  Exact (fractions).
usage: python3 signs_span.py NAME   (three banana4 banana5 H W3 W3x N Nx U25 U36)"""
import itertools, sys, os, pickle
from fractions import Fraction as Fr
import sympy as sp
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from boxes_all import CASES
from boxexact import OneTable

name = sys.argv[1]
n, bases, m, s, t, xch, T, ab, bb, sspan, rundir = CASES[name]
assert s == t == 1 and all(x == 1 for x in m), 'a centre'
L = OneTable(n, bases, m, s, t, exchanges=xch)
pk = os.path.join(os.path.dirname(os.path.abspath(__file__)), f'B_{name}.pkl')
if os.path.exists(pk):
    span = pickle.load(open(pk, 'rb'))['span']
else:
    sys.path.insert(0, '/home/claude/machine')
    from rrload import Run
    span = [x[0] for x in Run('/home/claude/rr_src/rayreader/runs/' + rundir).master_keys]
orbits = [L.orbit((u, 0, 0)) for u in span]
rows = []; info = []
for tail in itertools.product((1, -1), repeat=n - 1):
    eta = list(tail) + [1]
    K = sum(sp.prod([eta[e] for e in Tb]) for Tb in bases)
    if K == 0:
        continue
    P = [Fr(sp.prod([eta[e] for e in Tb]), K) for Tb in bases]
    mean = [sum(P[i] for i, Tb in enumerate(bases) if e in Tb) for e in range(n)]
    cov = sp.Matrix(n - 1, n - 1, lambda a, b: 2 * (sum(P[i] for i, Tb in enumerate(bases) if a in Tb and b in Tb) - mean[a] * mean[b]))
    det = cov.det()
    beta = [sum(Fr(1, len(O)) * sp.prod([eta[e] ** u[e] for e in range(n)]) for (u, _, _) in O) for O in orbits]
    info.append((tuple(eta), Fr(1, K * K), det, beta))
    if det != 0:
        rows.append(beta)
vals = sorted({x[1] for x in info})
print(f'{name}: {len(info)} signs with K != 0; native values {[str(v) for v in vals]}; '
      f'nondegenerate: {sum(1 for x in info if x[2] != 0)}')
for v in vals:
    grp = [x for x in info if x[1] == v]
    print(f'   native value {v}: {len(grp)} signs, det(-H) on the chart {sorted({str(x[2]) for x in grp})}, '
          f'distinct beta vectors {len({tuple(x[3]) for x in grp})}')
M = sp.Matrix(rows)
print(f'   spanning set of {len(span)} elements; rank of the beta vectors of the nondegenerate signs: {M.rank()}')
for x in info[:0]:
    print(x)
