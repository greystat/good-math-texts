#!/bin/bash
# blind2.py (receipts_src/twoends/closings_see_scripts) on every box of the exercise ex:closingssee:
# the closings on the spanning set, the annihilating polynomial rows up to degree E, and the closing equations
# for B at the degrees D0-1 .. D0+2.  Arguments: RUNDIR E J NSER (0: no formal solutions).
B2=/home/claude/v2/receipts_src/twoends/closings_see_scripts/blind2.py
R=/home/claude/rr_src/rayreader/runs
cd /home/claude/machine
for spec in "three_marks_eb3b44f0 24 120" "banana_on_four_marks_cd217f19 24 120" "banana_on_five_marks_96dd27c9 24 120" \
            "H_4c256682 24 150" "H_572b498a 24 150" "MK4_centre 40 260" "MK4_centre_x 40 260" "binom([5],2)_3f812547 24 150" \
            "U36_ea5c1c6a 40 200" "N_centre_x 32 480" "N_centre 8 400"; do
  set -- $spec
  echo "=== $1 (E=$2, J=$3)"
  timeout 7200 python3 $B2 "$R/$1" $2 $3 0 "" 2>&1 | grep -v Warning
done
