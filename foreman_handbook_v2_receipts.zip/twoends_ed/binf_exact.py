"""B(infinity) of the box at the centres of binom([5],2) and binom([6],3), exactly, with its eigenvalues and
eigenvectors (Proposition prop:rays-spectrum (ii)): the eigenvalues are the reciprocals of the native values, the
eigenvectors the values of the spanning set at the native gauges.  usage: python3 binf_exact.py"""
import sys
sys.path.insert(0, '/home/claude/machine')
from rrload import Run
import sympy as sp
k = sp.Symbol('k')
for d in ['binom([5],2)_3f812547', 'U36_ea5c1c6a']:
    r = Run('/home/claude/rr_src/rayreader/runs/' + d); B = r.Bsym()
    Binf = B.applyfunc(lambda x: sp.limit(x, k, sp.oo))
    print(d, 'spanning set', [x[0] for x in r.master_keys])
    print('   B(infinity) =', Binf.tolist())
    print('   characteristic polynomial', sp.factor(Binf.charpoly().as_expr()))
    for ev, mult, vecs in Binf.eigenvects():
        print('   eigenvalue', ev, 'multiplicity', mult, 'eigenvectors', [list(v) for v in vecs])
