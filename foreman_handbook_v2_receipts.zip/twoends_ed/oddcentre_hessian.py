"""Check of Proposition prop:onemarkhidden (ii) for r = 2..6, exactly: the covariances of the indicators at the sign
of binom([2r+2],r+1) with two scales -1, the eigenvalues of -H' modulo 1, det(-H') on a chart, and det(-H) at the
signs of binom([2r+1],r) with one and with two scales -1, against the closed forms.  usage: python3 oddcentre_hessian.py"""
import itertools
import sympy as sp
from fractions import Fraction as Fr
def cov(n, r, eta):
    Ts = list(itertools.combinations(range(n), r)); w = [sp.prod([eta[e] for e in T]) for T in Ts]; K = sum(w)
    P = [Fr(int(x), int(K)) for x in w]
    m = [sum(P[i] for i, T in enumerate(Ts) if e in T) for e in range(n)]
    return K, sp.Matrix(n, n, lambda a, b: sum(P[i] for i, T in enumerate(Ts) if a in T and b in T) - m[a] * m[b]), m
for r in range(2, 7):
    C = sp.binomial(2 * r, r) / (r + 1)
    n1 = 2 * r + 2; eta1 = [-1, -1] + [1] * (2 * r)
    K1, k1, m1 = cov(n1, r + 1, eta1)
    H1 = 2 * k1                                   # -H' (thm:signgauges (ii)), on C^{E'}
    v1 = sp.Matrix([1, -1] + [0] * (2 * r)); v2 = sp.Matrix([0, 0, 1, -1] + [0] * (2 * r - 2)); v3 = sp.Matrix([r, r] + [-1] * (2 * r))
    ev = [(H1 * v)[i] / v[i] for v, i in ((v1, 0), (v2, 2), (v3, 0))]
    det1 = H1[1:, 1:].det()
    # F = binom([2r+1], r) at the centre: -H = covariances of K and of Psi (two tables of the family word), on a chart
    out = []
    for i in (1, 2):
        eta = [-1] * i + [1] * (2 * r + 1 - i)
        K, kK, _ = cov(2 * r + 1, r, eta); Ps, kP, _ = cov(2 * r + 1, r + 1, eta)
        H = (kK + kP)[1:, 1:]                       # Hessian of -log f = cov under K + cov under Psi (s = t = 1)
        out.append((K, H.det()))
    print(f'r={r}: K\'(eta\') = {K1} (-2C_r = {-2*C}); occupations {set(m1)}; eigenvalues of -H\' {ev} '
          f'(expected {r+1}, {sp.Rational(r+1, 2*r-1)}, {-(r+1)}); det(-H\') chart {det1} = {-sp.Rational((r+1)**(2*r), 2*(2*r-1)**(2*r-1))}; '
          f'signs of F: K = {[o[0] for o in out]}, det(-H) = {[o[1] for o in out]} vs {-sp.Rational((r+1)**(2*r), (2*r-1)**(2*r-1))}')
