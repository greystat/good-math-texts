"""The element l = sum_{i!=j} a_i/a_j - (2k/(k-1)) (e1 e2/e3 + e3 e4/(e2 e5)) = 3 (1 - E) sum_{i!=j} a_i/a_j,
E the S6-symmetrizer on S5-invariants.  (a) its leading values at the five orbits of native gauges;
(b) its values over the orthant, which should vanish."""
import itertools, numpy as np, mpmath as mp
def es(a):
    n = len(a); e = [1]+[0]*n
    for x in a:
        for j in range(n, 0, -1): e[j] = e[j] + x*e[j-1]
    return e
def ell(a, k):
    e = es(a); S = e[1]*e[4]/e[5] - 5
    return S - (2*k/(k-1))*(e[1]*e[2]/e[3] + e[3]*e[4]/(e[2]*e[5]))
w = complex(mp.exp(2j*mp.pi/3)); s = 3**0.5-2
reps = {'table': [1, 1, 1, 1, 1], 'one -1': [1, 1, 1, 1, -1], 'two -1': [1, 1, 1, -1, -1],
        'three s': [1, s, s, s, 1], 'cube roots': [1, w, w, 1, w**2]}
print('leading values (k -> infinity) of l at the five orbits:')
for name, a in reps.items():
    print('  %-10s %s' % (name, np.round(ell([complex(x) for x in a], 1e12), 10)))
print('  orbit sum over the 15 signs: 5*l(one -1) + 10*l(two -1) =', np.round(5*ell([1, 1, 1, 1, -1], 1e12)+10*ell([1, 1, 1, -1, -1], 1e12), 10))
def orthant(k, h, R):
    g = np.arange(-R, R+h/2, h); Y1, Y2 = np.meshgrid(g, g, indexing='ij'); tot = np.zeros(3)
    for y3 in g:
        for y4 in g:
            a = [np.exp(Y1), np.exp(Y2), np.full_like(Y1, np.exp(y3)), np.full_like(Y1, np.exp(y4)), np.ones_like(Y1)]
            e = es(a); fk = (e[5]/(e[2]*e[3]))**k
            S = e[1]*e[4]/e[5] - 5; T = e[1]*e[2]/e[3] + e[3]*e[4]/(e[2]*e[5])
            tot += [np.sum(fk*S), np.sum(fk*T), np.sum(fk)]
    return tot*h**4
for k in (6.5, 8.0):
    S, T, one = orthant(k, 0.25, 9.0)
    print('k=%g: <S> = %.15e, (2k/(k-1))<T> = %.15e, <l>/<1> = %.2e' % (k, S, 2*k/(k-1)*T, (S-2*k/(k-1)*T)/one))
