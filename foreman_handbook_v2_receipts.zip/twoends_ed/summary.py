"""For each box of Exercise ex:closingssee: the monic common denominator Q0 of B and its roots, D0, the law of [1]
(order h, degree), from the rayreader's exact B (equal to the exact box's B where boxes_all.py has run)."""
import sys, os
sys.path.insert(0, '/home/claude/machine')
from rrload import Run
import sympy as sp
k = sp.Symbol('k')
R = '/home/claude/rr_src/rayreader/runs/'
for d in ['three_marks_eb3b44f0', 'banana_on_four_marks_cd217f19', 'banana_on_five_marks_96dd27c9', 'H_4c256682',
          'H_572b498a', 'MK4_centre', 'MK4_centre_x', 'N_centre_x', 'N_centre', 'binom([5],2)_3f812547', 'U36_ea5c1c6a']:
    r = Run(R + d); B = r.Bsym(); mu = r.mu
    Q0 = sp.Poly(sp.lcm([sp.fraction(sp.cancel(B[i, j]))[1] for i in range(mu) for j in range(mu)]), k).monic()
    P0 = (B * Q0.as_expr()).applyfunc(sp.cancel)
    D0 = max(Q0.degree(), max(sp.Poly(x, k).degree() for x in P0 if x != 0))
    roots = sp.roots(Q0, k)
    bad = [x for x in roots if x.is_integer and x <= 0]
    L = r.law(); c = L['c']
    reg = all(sp.Poly(sp.fraction(sp.cancel(B[i, j]))[0], k).degree() <= sp.Poly(sp.fraction(sp.cancel(B[i, j]))[1], k).degree() for i in range(mu) for j in range(mu) if B[i, j] != 0)
    print(f'{d}: m = {mu}, Q0 = {sp.factor(Q0.as_expr())}, D0 = {D0}, roots at nonpositive integers: {bad}; '
          f'B regular at infinity: {reg}; law of [1]: order {L["order"]}, degree {max(len(x) for x in c) - 1}')
