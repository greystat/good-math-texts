"""The centre of binom([3],1), exactly over Q (Exercise ex:closingssee, part (i), the worked list).
f^{-1} = e1 e2 / e3 = (a1+a2+a3)(1/a1+1/a2+1/a3); spanning set b_1 = 1, b_2 = (1/6) sum_{i != j} a_i/a_j.
Closings C_j(b) = CT(b f^{-j}) by direct expansion for j <= J; the recursion C_{j+1} = B(-j) C_j; the closing
equations of Proposition prop:blinddim at the degrees D = 1..4 (exact ranks over Q); the polynomial rows of degree
<= 24 annihilating the closings.  usage: python3 three_exact.py [J]"""
import sys, os, pickle, itertools
from fractions import Fraction as Fr
import flint, sympy as sp

J = int(sys.argv[1]) if len(sys.argv) > 1 else 80
k = sp.Symbol('k')
here = os.path.dirname(os.path.abspath(__file__))
Bd = pickle.load(open(os.path.join(here, 'B_three.pkl'), 'rb'))
B = sp.Matrix([[sp.sympify(x) for x in row] for row in Bd['B']])
print('spanning set', Bd['span'])
print('B(k) =', [[sp.factor(B[i, j]) for j in range(2)] for i in range(2)])
Q0 = sp.Poly(sp.lcm([sp.fraction(sp.cancel(B[i, j]))[1] for i in range(2) for j in range(2)]), k).monic().as_expr()
P0 = (B * Q0).applyfunc(lambda x: sp.expand(sp.cancel(x)))
print('Q0 =', sp.factor(Q0), '; P0 =', P0.tolist(), '; D0 =', max(sp.Poly(Q0, k).degree(), max(sp.Poly(x, k).degree() for x in P0)))

# closings by direct expansion: CT of a^u (e1 e2/e3)^j on the chart a3 = 1 is the coefficient of a1^j a2^j a3^j
# in a^u (e1 e2)^j, u of degree 0.  Use the bivariate polynomial (e1 e2)^j with a3 = 1.
R = flint.fmpz_mpoly_ctx.get(('x', 'y'), 'lex')
x, y = R.gens()
e1 = x + y + 1; e2 = x * y + x + y
cur = R.from_dict({(0, 0): 1})
C1, C2 = [], []
for j in range(J + 1):
    d = cur.to_dict()
    C1.append(int(d.get((j, j), 0)))
    # b_2 = (1/6) sum_{i != j} a_i/a_j: CT(a_i/a_j f^-j) = coefficient of a^{j1 - e_i + e_j} in (e1 e2)^j
    tot = 0
    for i, l in itertools.permutations(range(3), 2):
        ex = [j, j, j]; ex[i] -= 1; ex[l] += 1
        # on the chart a3 = 1 the coefficient of a1^ex0 a2^ex1 a3^ex2 in the homogeneous (e1 e2)^j (degree 3j)
        tot += int(d.get((ex[0], ex[1]), 0)) if ex[2] == 3 * j - ex[0] - ex[1] else 0
    C2.append(Fr(tot, 6))
    cur = cur * e1 * e2
print('C_j(1), j = 0..8:', C1[:9])
print('C_j(b_2), j = 0..8:', [str(c) for c in C2[:9]])
ok = []
for j in range(1, J):
    Bj = B.subs(k, -j)
    ok.append(all(sp.Rational(C1[j + 1] if i == 0 else C2[j + 1]) == Bj[i, 0] * C1[j] + Bj[i, 1] * C2[j] for i in range(2)))
print('C_{j+1} = B(-j) C_j for j = 1..%d:' % (J - 1), all(ok), '; at j = 0:',
      all(sp.Rational([C1, C2][i][1]) == B.subs(k, 0)[i, 0] * C1[0] + B.subs(k, 0)[i, 1] * C2[0] for i in range(2)))

X = [[Fr(C1[j]), C2[j]] for j in range(J + 1)]


def rank_Q(rows):
    M = flint.fmpq_mat(len(rows), len(rows[0]), [flint.fmpq(v.numerator, v.denominator) for r in rows for v in r])
    return M.rank()


def S_dim(D, j0=1):
    # unknowns: P (2x2, degree <= D) and Q (degree <= D); equations Q(-j) X_{j+1} = P(-j) X_j
    rows = []
    for j in range(j0, J):
        pw = [Fr(-j) ** e for e in range(D + 1)]
        for i in range(2):
            # unknowns: P_{i,l,e} (coefficient of k^e in P_{il}), then Q_e
            row = [Fr(0)] * (4 * (D + 1)) + [Fr(0)] * (D + 1)
            for l in range(2):
                for e in range(D + 1):
                    row[(i * 2 + l) * (D + 1) + e] = -pw[e] * X[j][l]
            for e in range(D + 1):
                row[4 * (D + 1) + e] = pw[e] * X[j + 1][i]
            rows.append(row)
    n = 5 * (D + 1)
    return n - rank_Q(rows), len(rows), n


for D in range(1, 5):
    d, ne, nu = S_dim(D)
    print('closing equations at degree D = %d: solution dimension %d (%d equations, %d unknowns, j = 1..%d)' % (D, d, ne, nu, J - 1))


def annih(e, j0=1):
    rows = [[Fr(-j) ** a * X[j][l] for l in range(2) for a in range(e + 1)] for j in range(j0, J + 1)]
    return 2 * (e + 1) - rank_Q(rows)


print('polynomial rows of degree <= e annihilating the closings (j = 1..%d):' % J, [(e, annih(e)) for e in (0, 4, 8, 12, 16, 20, 24)])
