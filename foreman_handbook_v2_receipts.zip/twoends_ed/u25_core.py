"""The centre of binom([5],2), exactly (Exercise ex:closingssee, part (iii)).

(1) the box B_3(1,1) modulo G = S_5 x <cr>: spanning set at s = 2, acceptance, the matrix B over Q(k);
(2) the native gauges: five representatives, criticality, native values, orbits, Hessian determinants on the
    chart alpha_5 = 1, the values of the spanning set there, and the independence of the spanning set;
(3) the element m, the line L: Sh^-1 m~ = 4 m~, the rank of [w_0; ...; w_3; m~], the law of [1];
(4) the reduction of T = (K/Psi) e_1 + (Psi/K) e_{-1} in the box and the identity
    l = [S] - 2k/(k-1) [T] = 20/(k-1)^2 m~,  S = sum_{i != j} alpha_i/alpha_j = 20 b_2;
(5) the leading terms of A_c(m)/A_c(1) at the two kinds of signs.
Everything is exact (sympy over Q(k), Q(sqrt 3), Q(omega); flint over Z[k]).  usage: python3 u25_core.py"""
import itertools, sys, os, time, math
from fractions import Fraction as Fr
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from boxexact import OneTable, Echelon, ZX
import sympy as sp

k = sp.Symbol('k')
n = 5; bases = list(itertools.combinations(range(5), 2))


def tosym(p):
    return sum(sp.Integer(int(c)) * k**i for i, c in enumerate(p.coeffs())) if p != 0 else sp.Integer(0)


def reduce_combination(L, E, comb):
    """comb: dict symbol -> Fraction or sympy-free rational; returns {column: rational function} (the reduction)"""
    den = 1
    for v in comb.values(): den = den * Fr(v).denominator // math.gcd(den, Fr(v).denominator)
    row = {}
    for y, v in comb.items():
        cz = L.canon(y); row[cz] = row.get(cz, 0) + int(Fr(v) * den)
    row = {cz: ZX([v]) for cz, v in row.items() if v}
    nf, d = E.reduce(row, ZX([den]))
    return {z: sp.factor(tosym(c) / tosym(d)) for z, c in nf.items()}


t0 = time.time()
L = OneTable(n, bases, (1,) * n, 1, 1)
syms, stems, rels = L.box(3, 1, 1)
avg = [L.average(R) for R in rels]
cols = sorted({z for R in avg for z in R})
key = lambda z: (z[1] + z[2], L.wdeg(*z), z)
E = Echelon(key)
rk = sum(1 for R in avg if E.add(R))
print(f'(1) box (3;1,1): {len(syms)} symbols, {len(rels)} relations at orbit representatives, {len(cols)} orbit '
      f'columns, rank {rk} ({time.time()-t0:.0f}s)')
free = [z for z in cols if z not in E.piv]
span = sorted([z for z in free if z[1] == z[2] == 0 and L.wdeg(*z) <= 2], key=key)
print('    spanning set at s = 2:', [z[0] for z in span], ' wall degrees', [str(L.wdeg(*z)) for z in span])
print('    free orbits at positive levels:', [z for z in free if z[1] + z[2] > 0])
finv = {}
for v in L.Kmon:
    for w in L.Pmon:
        x = tuple(p + q - 1 for p, q in zip(v, w)); finv[x] = finv.get(x, 0) + 1
print('    f^-1 =', {L.canon((x, 0, 0))[0]: 0 for x in finv} and 'K Psi / alpha^1 with', len(finv), 'monomials')
B = []
for z in span:
    orb = L.orbit(z); c = Fr(1, len(orb)); comb = {}
    for (u, a, b) in orb:
        for x, cx in finv.items():
            y = (tuple(p + q for p, q in zip(u, x)), 0, 0); comb[y] = comb.get(y, 0) + c * cx
    nf = reduce_combination(L, E, comb)
    assert set(nf) <= set(span), 'not accepted'
    B.append([nf.get(zz, sp.Integer(0)) for zz in span])
B = sp.Matrix(B)
Q0 = sp.lcm([sp.fraction(sp.cancel(B[i, j]))[1] for i in range(5) for j in range(5)])
Q0 = sp.Poly(Q0, k).monic().as_expr()
print('    accepted at s = 2; B over Q(k); monic common denominator Q0 =', sp.factor(Q0))
P0 = (B * Q0).applyfunc(sp.cancel)
print('    D0 = max(deg P0, deg Q0) =', max(sp.Poly(Q0, k).degree(), max(sp.Poly(P0[i, j], k).degree() for i in range(5) for j in range(5) if P0[i, j] != 0)))
for i in range(5):
    print('    B row', i, [sp.factor(B[i, j]) for j in range(5)])
sys.path.insert(0, '/home/claude/machine')
from rrload import Run
Brr = Run('/home/claude/rr_src/rayreader/runs/binom([5],2)_3f812547').Bsym()
print('    equal to the rayreader matrix (B_exact.pkl):', all(sp.cancel(B[i, j] - Brr[i, j]) == 0 for i in range(5) for j in range(5)))

# ---------------------------------------------------------------- (3) m, L, the law
mrow = sp.Matrix([[k*(k-5)*(k-2)*(k+2), -(3*k**4+11*k**3-71*k**2+227*k-210),
                   -sp.Rational(2, 3)*(3*k**4-11*k**3+119*k**2-125*k-90), -(k-5)*(k-2)**3,
                   (k-2)**2*(5*k**2-14*k+5)]])
cub = 3*k**3+4*k**2-61*k+130
wt = (mrow * (k - 1) / cub).applyfunc(sp.cancel)
lhs = (wt.subs(k, k - 1) * B).applyfunc(sp.cancel)
print('(3) w~(k-1) B(k) = 4 w~(k):', all(sp.cancel(lhs[i] - 4 * wt[i]) == 0 for i in range(5)))
rows = [sp.Matrix([[1, 0, 0, 0, 0]])]
for i in range(1, 6):
    rows.append((rows[-1].subs(k, k - 1) * B).applyfunc(sp.cancel))
for kv in (sp.Rational(37, 3), sp.Rational(-71, 5)):
    W4 = sp.Matrix.vstack(*rows[:4]).subs(k, kv)
    print('    at k =', kv, ': rank [w0..w3] =', W4.rank(), '; rank [w0..w3; w~] =', sp.Matrix.vstack(W4, wt.subs(k, kv)).rank(),
          '; rank [w0..w4] =', sp.Matrix.vstack(*rows[:5]).subs(k, kv).rank())
# the law: first dependence of w_0..w_4 (Proposition prop:rays-lawrows (ii))
W5 = sp.Matrix.vstack(*rows[:5])
ns = W5.T.nullspace()
assert len(ns) == 1
q = ns[0].T
q = (q * sp.lcm([sp.fraction(sp.cancel(x))[1] for x in q])).applyfunc(sp.cancel)
g = sp.gcd_list([sp.expand(x) for x in q])
q = [sp.cancel(x / g) for x in q]
p = [sp.expand(q[4 - j].subs(k, k + 4)) for j in range(5)]
law_rr = Run('/home/claude/rr_src/rayreader/runs/binom([5],2)_3f812547').law()['c']
plaw = [sum(sp.Integer(c) * k**i for i, c in enumerate(cs)) for cs in law_rr]
ratio = sp.cancel(p[0] / plaw[0])
print('    law of [1] from the rows: order 4, p_j proportional to the rayreader law:',
      all(sp.cancel(p[j] - ratio * plaw[j]) == 0 for j in range(5)), ' ratio', ratio)
for j in range(5):
    print('     p_%d =' % j, sp.factor(plaw[j]))

# ---------------------------------------------------------------- (4) T and l
T = {}
for i in range(5):
    for Tb in bases:
        u = [0] * 5; u[i] += 1
        for e in Tb: u[e] += 1
        y = (tuple(u), 0, 1); T[y] = T.get(y, 0) + 1                      # alpha_i alpha^T / Psi
        u = [-1 if e == i else 0 for e in range(5)]
        for e in range(5):
            if e not in Tb: u[e] += 1
        y = (tuple(u), 1, 0); T[y] = T.get(y, 0) + 1                      # alpha^{E-T} / (alpha_i K)
print('(4) T: symbols', len(T), '; wall degrees', sorted({str(L.wdeg(*y)) for y in T}), '; all in the box:', all(y in syms for y in T))
nfT = reduce_combination(L, E, T)
print('    reduction of T: only the spanning set:', set(nfT) <= set(span))
Tvec = sp.Matrix([[nfT.get(z, 0) for z in span]])
print('    [T] =', [sp.factor(x) for x in Tvec])
Svec = sp.Matrix([[0, 0, 20, 0, 0]])
ell = (Svec - 2 * k / (k - 1) * Tvec).applyfunc(sp.cancel)
target = (20 * wt / (k - 1)**2).applyfunc(sp.cancel)
print('    l = [S] - 2k/(k-1)[T] equals 20/(k-1)^2 m~:', all(sp.cancel(ell[i] - target[i]) == 0 for i in range(5)))
print('    l =', [sp.factor(x) for x in ell])
print('    (%.0fs)' % (time.time() - t0))

# ---------------------------------------------------------------- (2) native gauges
s3 = sp.sqrt(3); w3 = sp.Rational(-1, 2) + sp.sqrt(3) * sp.I / 2
reps = {'table': [1, 1, 1, 1, 1], 'one -1': [1, 1, 1, 1, -1], 'two -1': [1, 1, 1, -1, -1],
        'three s': [s3 - 2, s3 - 2, s3 - 2, 1, 1], 'cube roots': [1, 1, w3, w3, w3**2]}
a = sp.symbols('a0:5')
e2 = sum(a[i]*a[j] for i, j in itertools.combinations(range(5), 2))
e3 = sum(a[i]*a[j]*a[l] for i, j, l in itertools.combinations(range(5), 3))
logf = sum(sp.log(x) for x in a) - sp.log(e2) - sp.log(e3)
y = sp.symbols('y0:5')
subs_y = {a[i]: sp.exp(y[i]) for i in range(5)}
grad = [sp.simplify(a[i] * sp.diff(logf, a[i])) for i in range(5)]          # defects c^(1)_e
Hfun = [[a[j] * sp.diff(a[i] * sp.diff(logf, a[i]), a[j]) for j in range(4)] for i in range(4)]   # chart alpha_5 = 1


def orbit_size(pt):
    # points of the torus modulo scale, under S_5 and the Cremona; exact in the number field
    def norm(v):
        return tuple(sp.nsimplify(sp.simplify(x / v[4])) for x in v)
    seen = set()
    for p_ in itertools.permutations(range(5)):
        v = [pt[p_[i]] for i in range(5)]
        for vv in (v, [1 / x for x in v]):
            seen.add(tuple(sp.nsimplify(sp.expand(sp.radsimp(x / vv[4]))) for x in vv))
    return len(seen)


masters = []
for z in span:
    orb = L.orbit(z)
    masters.append([(u, Fr(1, len(orb))) for (u, aa, bb) in orb])
print('(2) native gauges (representatives on the chart alpha_5 = 1 after scaling):')
Mval = []
for name, pt in reps.items():
    pt = [sp.nsimplify(x) for x in pt]
    sub = {a[i]: pt[i] for i in range(5)}
    crit = all(sp.simplify(gq.subs(sub)) == 0 for gq in grad)
    fval = sp.nsimplify(sp.simplify((sp.prod(pt) / (e2 * e3)).subs(sub)))
    ptc = [x / pt[4] for x in pt]
    subc = {a[i]: ptc[i] for i in range(5)}
    H = sp.Matrix(4, 4, lambda i, j: sp.simplify(Hfun[i][j].subs(subc)))
    detH = sp.nsimplify(sp.simplify(H.det()))
    vals = [sp.nsimplify(sp.simplify(sum(c * sp.prod([ptc[e]**u[e] for e in range(5)]) for u, c in b))) for b in masters]
    Mval.append(vals)
    print('    %-10s critical %s, native value %s, orbit %d, det H %s, values of the spanning set %s'
          % (name, crit, fval, orbit_size(pt), detH, vals))
Mv = sp.Matrix(Mval)
print('    det [b_l(c)] (rows: the five orbits) =', sp.nsimplify(sp.simplify(Mv.det())))
print('    the 2x2 minor at the signs, columns 1, b_1:', sp.simplify(Mv[1, 0] * Mv[2, 1] - Mv[1, 1] * Mv[2, 0]))
# (5) leading terms at the signs
lead = [sp.Poly(sp.expand(x), k).coeff_monomial(k**4) for x in mrow]
for idx, name in ((1, 'one -1'), (2, 'two -1')):
    print('(5) leading coefficient of A_c(m)/A_c(1) at the sign', name, ':', sp.nsimplify(sum(lead[l] * Mv[idx, l] for l in range(5))), 'k^4')
print('    at the other orbits:', [sp.nsimplify(sp.simplify(sum(lead[l] * Mv[i, l] for l in range(5)))) for i in (0, 3, 4)])
print('total %.0fs' % (time.time() - t0))
