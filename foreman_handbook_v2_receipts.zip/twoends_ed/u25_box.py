"""The centre of binom([5],2): the box B_3(1,1) modulo G = S_5 x <cr>, eliminated exactly over Q(k).
Prints the spanning set at s = 2, the acceptance, the matrix B (compared with the rayreader's B_exact.pkl),
and the reduction of the insertions T = (K/Psi) e_1 + (Psi/K) e_{-1} and f^{-1} T.
usage: python3 u25_box.py"""
import itertools, sys, os, pickle, time
from fractions import Fraction as Fr
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from boxexact import OneTable, Echelon, ZX, P
import sympy as sp

k = sp.Symbol('k')


def tosym(p):
    return sum(sp.Integer(int(c)) * k**i for i, c in enumerate(p.coeffs())) if p != 0 else sp.Integer(0)


def run(n, bases, T, abar, bbar, s_span, extra_targets=None, tag=''):
    L = OneTable(n, bases, (1,) * n, 1, 1)
    t0 = time.time()
    syms, stems, rels = L.box(T, abar, bbar)
    avg = [L.average(R) for R in rels]
    cols = sorted({z for R in avg for z in R})
    def key(z):
        u, a, b = z
        return (a + b, L.wdeg(u, a, b), z)
    E = Echelon(key)
    rk = sum(1 for R in avg if E.add(R))
    print(f'{tag} box ({T};{abar},{bbar}): {len(syms)} symbols, {len(stems)} stems, {len(rels)} relations; '
          f'{len(cols)} orbit columns, rank {rk} ({time.time()-t0:.1f}s)')
    free = [z for z in cols if z not in E.piv]
    lau = [z for z in free if z[1] == 0 and z[2] == 0]
    span = sorted([z for z in lau if L.wdeg(*z) <= s_span], key=key)
    print('   free orbits:', len(free), '; free Laurent orbits by wall degree:',
          sorted((str(L.wdeg(*z)), z[0]) for z in lau))
    print('   spanning set at s =', s_span, ':', [z[0] for z in span])
    # targets f^{-1} b_i
    finv = {}
    for v in L.Kmon:
        for w in L.Pmon:
            x = tuple(p + q - 1 for p, q in zip(v, w)); finv[x] = finv.get(x, 0) + 1
    Bm = []
    ok = True
    for z in span:
        orb = L.orbit(z); c = Fr(1, len(orb))
        tgt = {}
        for (u, a, b) in orb:
            for x, cx in finv.items():
                y = (tuple(p + q for p, q in zip(u, x)), 0, 0)
                tgt[y] = tgt.get(y, 0) + c * cx
        # to integer coefficients: multiply by the lcm of denominators
        den = 1
        for v in tgt.values(): den = den * v.denominator // __import__('math').gcd(den, v.denominator)
        row = {}
        for y, v in tgt.items():
            cz = L.canon(y); row[cz] = row.get(cz, 0) + int(v * den)
        row = {cz: ZX([v]) for cz, v in row.items() if v}
        nf, d = E.reduce(row, ZX([den]))
        if not set(nf) <= set(span):
            ok = False
        Bm.append([sp.factor(tosym(nf.get(zz, ZX(0))) / tosym(d)) for zz in span])
    print('   accepted at s =', s_span, ':', ok)
    out = {'L': L, 'E': E, 'span': span, 'B': sp.Matrix(Bm), 'key': key}
    return out


if __name__ == '__main__':
    n = 5; bases = list(itertools.combinations(range(5), 2))
    R = run(n, bases, 3, 1, 1, 2, tag='binom([5],2) centre')
    B = R['B']
    # compare with the rayreader's matrix
    sys.path.insert(0, '/home/claude/machine')
    from rrload import Run
    run_ = Run('/home/claude/rr_src/rayreader/runs/binom([5],2)_3f812547')
    Brr = run_.Bsym()
    keys_rr = [x[0] for x in run_.master_keys]
    keys_me = [z[0] for z in R['span']]
    print('   masters (rayreader):', keys_rr, ' (here):', keys_me)
    perm = [keys_me.index(x) for x in keys_rr]
    same = all(sp.simplify(B[perm[i], perm[j]] - Brr[i, j]) == 0 for i in range(5) for j in range(5))
    print('   B equal to the rayreader B over Q(k):', same)
    pickle.dump({'span': keys_me, 'B': [[str(B[i, j]) for j in range(5)] for i in range(5)]},
                open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'u25_B.pkl'), 'wb'))
