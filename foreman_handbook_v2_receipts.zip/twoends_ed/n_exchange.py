"""The centre of N_6 (bases: the triples of {0..5} other than {0,1,2}) with G = automorphisms and Cremona: the action
of an exchange x on the spanning set of the box at s = 2 (15 orbit averages), and the values at the nondegenerate
signs that show b - x^* b != 0 in the module (Proposition prop:rays-spectrum (i) argument: the leading coefficient of
A_eta(b - x^* b) is C_eta (b(eta) - b(x eta))).  Exact.  usage: python3 n_exchange.py"""
import itertools, sys, os
from fractions import Fraction as Fr
import sympy as sp
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from boxes_all import CASES
from boxexact import OneTable
sys.path.insert(0, '/home/claude/machine')
from rrload import Run
n, bases, m, s, t, xch, T, ab, bb, sspan, rundir = CASES['N']
L = OneTable(n, bases, m, s, t)
Lx = OneTable(n, bases, m, s, t, exchanges=True)
span = [x[0] for x in Run('/home/claude/rr_src/rayreader/runs/N_centre').master_keys]
spanx = [x[0] for x in Run('/home/claude/rr_src/rayreader/runs/N_centre_x').master_keys]
print('automorphisms:', len(L.perms), '; exchanges:', len(Lx.xperms))
x = Lx.xperms[0]; print('exchange x:', x)
canon = {L.canon((u, 0, 0)): u for u in span}
for u in span:
    v = [0] * n
    for i in range(n): v[x[i]] = u[i]
    img = L.canon((tuple(v), 0, 0))[0]
    print(f'   b = avg{u}: x^* b = avg{img}', '(in the spanning set)' if img in span else '(not in the spanning set)',
          '; in the spanning set with exchanges:', u in spanx)
# signs
def val(u, eta):
    O = L.orbit((u, 0, 0))
    return sum(Fr(1, len(O)) * sp.prod([eta[e] ** w[e] for e in range(n)]) for (w, _, _) in O)
for tail in itertools.product((1, -1), repeat=n - 1):
    eta = list(tail) + [1]
    K = sum(sp.prod([eta[e] for e in Tb]) for Tb in bases)
    if K == 0 or abs(K) != 5:
        continue
    xe = [0] * n
    for i in range(n): xe[x[i]] = eta[i]
    diffs = {u: val(u, eta) - val(tuple(sorted(u)) if False else u, xe) for u in span}
    print('sign', eta, 'K =', K, '; b(eta) - b(x eta) for the 15:', [str(d) for d in diffs.values()])
