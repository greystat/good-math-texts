"""The native gauges of the centre of binom([5],2) lifted to the centre of binom([6],3) (Proposition prop:onemark (i)):
alpha_c -> (alpha_c, Psi(alpha_c)/K(alpha_c)), K = e_2, Psi = e_3.  For the five representatives: the lift, its
criticality for f' = alpha^1 alpha_6 / e_3(alpha, alpha_6)^2, its native value f(alpha_c)/4, and the orbit of the
lift under S_6 and the Cremona; then the law of [1] at the centre of binom([6],3) against the law of binom([5],2)
twisted by the stacked Gamma B(k,k) = Gamma(k)^2/Gamma(2k) (Proposition prop:onemark (ii)).  Exact.
usage: python3 u36_lift.py"""
import itertools, sys
import sympy as sp

s3 = sp.sqrt(3); w = sp.Rational(-1, 2) + sp.sqrt(3) * sp.I / 2
reps = {'table': [1, 1, 1, 1, 1], 'one -1': [1, 1, 1, 1, -1], 'two -1': [1, 1, 1, -1, -1],
        'three s': [s3 - 2, s3 - 2, s3 - 2, 1, 1], 'cube roots': [1, 1, w, w, w**2]}
a = sp.symbols('a0:6')
e3_6 = sum(a[i] * a[j] * a[l] for i, j, l in itertools.combinations(range(6), 3))
logf6 = sum(sp.log(x) for x in a) - 2 * sp.log(e3_6)
grad6 = [a[i] * sp.diff(logf6, a[i]) for i in range(6)]


def esym(r, v):
    return sum(sp.prod(c) for c in itertools.combinations(v, r))


def key(v):
    return tuple(sp.nsimplify(sp.expand(sp.radsimp(x / v[-1]))) for x in v)


def orbit6(v):
    seen = set()
    for p in itertools.permutations(range(6)):
        u = [v[p[i]] for i in range(6)]
        for uu in (u, [1 / x for x in u]):
            seen.add(key(uu))
    return seen


allpts = set(); sizes = {}
for name, pt in reps.items():
    pt = [sp.nsimplify(x) for x in pt]
    a6 = sp.nsimplify(sp.radsimp(esym(3, pt) / esym(2, pt)))
    lift = pt + [a6]
    crit = all(sp.simplify(g.subs({a[i]: lift[i] for i in range(6)})) == 0 for g in grad6)
    f5 = sp.nsimplify(sp.radsimp(sp.prod(pt) / (esym(2, pt) * esym(3, pt))))
    f6 = sp.nsimplify(sp.radsimp(sp.prod(lift) / esym(3, lift) ** 2))
    O = orbit6(lift); allpts |= O
    print(f'{name:10s} alpha_6 = {a6}; critical for binom([6],3): {crit}; f = {f5}, f\' = {f6} (= f/4: {sp.simplify(f6 - f5 / 4) == 0}); '
          f'orbit under S_6 x <cr>: {len(O)}')
print('distinct lifted points in these orbits:', len(allpts))

# the law of [1] at the centre of binom([6],3) and the twisted law of binom([5],2)
sys.path.insert(0, '/home/claude/machine')
from rrload import Run
k = sp.Symbol('k')
R = '/home/claude/rr_src/rayreader/runs/'
c = [sum(sp.Integer(x) * k**i for i, x in enumerate(cs)) for cs in Run(R + 'binom([5],2)_3f812547').law()['c']]
d = [sum(sp.Integer(x) * k**i for i, x in enumerate(cs)) for cs in Run(R + 'U36_ea5c1c6a').law()['c']]
# Sh'^i [1]' = (B(k+i,k+i)/B(k,k)) pi^-1 Sh^i [1]: the law sum_i p_i Sh^i [1] = 0 becomes
# sum_i p_i(k) B(k,k)/B(k+i,k+i) Sh'^i [1]' = 0; times B(k+4,k+4)/B(k,k): coefficients p_i(k) prod_{l=i}^{3} c(k+l), c(k) = k/(2(2k+1))
cc = lambda x: x / (2 * (2 * x + 1))
tw = [sp.cancel(c[i] * sp.prod([cc(k + l) for l in range(i, 4)])) for i in range(5)]
ratio = sp.cancel(d[0] / tw[0])
print('law at binom([6],3) proportional to the twisted law of binom([5],2):', all(sp.cancel(d[i] - ratio * tw[i]) == 0 for i in range(5)), '; factor', sp.factor(ratio))
for i in range(5):
    print('   q_%d =' % i, sp.factor(d[i]))
