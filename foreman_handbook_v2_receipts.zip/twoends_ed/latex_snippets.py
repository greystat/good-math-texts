"""LaTeX of the exact quantities displayed in ex_closingssee.tex (from B_*.pkl of boxes_all.py and the runs)."""
import pickle, sys
import sympy as sp
sys.path.insert(0, '/home/claude/machine')
from rrload import Run
k = sp.Symbol('k')
def L(x): return sp.latex(x).replace(r'\left(', '(').replace(r'\right)', ')')
B = pickle.load(open('B_U25.pkl', 'rb')) if False else None
r = Run('/home/claude/rr_src/rayreader/runs/binom([5],2)_3f812547'); B = r.Bsym()
q = 3*k**3+4*k**2-61*k+130
print('% U25: B rows, entries times q(k)/(k-1) [rows 1,2], times q(k)(k-3)^4/(k-1) [row 3], q(k)(k-3)^3/(k-1) [row 4]')
for i, fac in ((1, q/(k-1)), (2, q/(k-1)), (3, q*(k-3)**4/(k-1)), (4, q*(k-3)**3/(k-1))):
    print('row', i, ' & '.join(L(sp.factor(sp.cancel(B[i, j]*fac))) for j in range(5)))
law = r.law()['c']
for j, cs in enumerate(law):
    print('p_%d =' % j, L(sp.factor(sum(sp.Integer(c)*k**i for i, c in enumerate(cs)))))
r6 = Run('/home/claude/rr_src/rayreader/runs/U36_ea5c1c6a'); B6 = r6.Bsym()
Q6 = sp.lcm([sp.fraction(sp.cancel(B6[i, j]))[1] for i in range(4) for j in range(4)])
print('% U36 Q0 =', L(sp.factor(Q6)))
