"""The boxes of Exercise ex:closingssee, built and eliminated exactly over Q(k) from Definition def:raybox
(boxexact.py), with the spanning set at s and the matrix B, compared with the rayreader's B_exact.pkl.
usage: python3 boxes_all.py NAME [NAME ...]   (names below)"""
import itertools, sys, os, time, pickle
from fractions import Fraction as Fr
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from boxexact import OneTable, Echelon, ZX
import sympy as sp
sys.path.insert(0, '/home/claude/machine')
from rrload import Run

k = sp.Symbol('k')
R = '/home/claude/rr_src/rayreader/runs/'
C = itertools.combinations
K4 = list(C(range(4), 2))
def trees():
    out = []
    for S in C(range(6), 3):
        par = list(range(4)); ok = True
        def f(x):
            while par[x] != x: x = par[x]
            return x
        for i in S:
            a, b = f(K4[i][0]), f(K4[i][1])
            if a == b: ok = False; break
            par[a] = b
        if ok: out.append(S)
    return out
CASES = {
    'three':   (3, [(0,), (1,), (2,)], (1, 1, 1), 1, 1, False, 2, 1, 1, 1, 'three_marks_eb3b44f0'),
    'banana4': (4, [(i,) for i in range(4)], (1,) * 4, 1, 1, False, 2, 1, 1, 1, 'banana_on_four_marks_cd217f19'),
    'banana5': (5, [(i,) for i in range(5)], (1,) * 5, 1, 1, False, 3, 1, 1, 2, 'banana_on_five_marks_96dd27c9'),
    'H':       (4, [T for T in C(range(4), 2) if T != (0, 1)], (1,) * 4, 1, 1, False, 2, 1, 1, 1, 'H_4c256682'),
    'Hlean':   (4, [T for T in C(range(4), 2) if T != (0, 1)], (1, 1, 3, 3), 3, 1, False, 2, 1, 1, 1, 'H_572b498a'),
    'W3':      (6, trees(), (1,) * 6, 1, 1, False, 2, 1, 1, 1, 'MK4_centre'),
    'W3x':     (6, trees(), (1,) * 6, 1, 1, True, 2, 1, 1, 1, 'MK4_centre_x'),
    'U25':     (5, list(C(range(5), 2)), (1,) * 5, 1, 1, False, 3, 1, 1, 2, 'binom([5],2)_3f812547'),
    'U36':     (6, list(C(range(6), 3)), (1,) * 6, 1, 1, False, 3, 1, 1, 2, 'U36_ea5c1c6a'),
    'Nx':      (6, [T for T in C(range(6), 3) if T != (0, 1, 2)], (1,) * 6, 1, 1, True, 3, 1, 1, 2, 'N_centre_x'),
    'N':       (6, [T for T in C(range(6), 3) if T != (0, 1, 2)], (1,) * 6, 1, 1, False, 3, 1, 1, 2, 'N_centre'),
}


def tosym(p):
    return sum(sp.Integer(int(c)) * k**i for i, c in enumerate(p.coeffs())) if p != 0 else sp.Integer(0)


def one(name):
    n, bases, m, s, t, xch, T, ab, bb, sspan, rundir = CASES[name]
    t0 = time.time()
    L = OneTable(n, bases, m, s, t, exchanges=xch)
    syms, stems, rels = L.box(T, ab, bb)
    avg = [L.average(Rr) for Rr in rels]
    cols = sorted({z for Rr in avg for z in Rr})
    key = lambda z: (z[1] + z[2], L.wdeg(*z), z)
    E = Echelon(key)
    rk = sum(1 for Rr in avg if E.add(Rr))
    free = [z for z in cols if z not in E.piv]
    span = sorted([z for z in free if z[1] == z[2] == 0 and L.wdeg(*z) <= sspan], key=key)
    # f^{-1} = alpha^{-m} K^s Psi^t
    finv = {(0,) * n: 1}
    for _ in range(s):
        new = {}
        for x, c in finv.items():
            for v in L.Kmon:
                y = tuple(p + q for p, q in zip(x, v)); new[y] = new.get(y, 0) + c
        finv = new
    for _ in range(t):
        new = {}
        for x, c in finv.items():
            for v in L.Pmon:
                y = tuple(p + q for p, q in zip(x, v)); new[y] = new.get(y, 0) + c
        finv = new
    finv = {tuple(p - q for p, q in zip(x, m)): c for x, c in finv.items()}
    Bm = []; ok = True
    for z in span:
        orb = L.orbit(z); N = len(orb); row = {}
        for (u, a, b) in orb:
            for x, cx in finv.items():
                y = L.canon((tuple(p + q for p, q in zip(u, x)), 0, 0)); row[y] = row.get(y, 0) + cx
        row = {y: ZX([v]) for y, v in row.items() if v}
        nf, d = E.reduce(row, ZX([N]))
        if not set(nf) <= set(span): ok = False
        Bm.append([sp.cancel(tosym(nf.get(zz, ZX(0))) / tosym(d)) for zz in span])
    B = sp.Matrix(Bm)
    run = Run(R + rundir)
    keys_rr = [x[0] for x in run.master_keys]; keys = [z[0] for z in span]
    same = None
    if sorted(keys_rr) == sorted(keys):
        Brr = run.Bsym(); perm = [keys.index(x) for x in keys_rr]
        same = all(sp.cancel(B[perm[i], perm[j]] - Brr[i, j]) == 0 for i in range(len(keys)) for j in range(len(keys)))
    print(f'{name}: box ({T};{ab},{bb}), |G| = {len(L.perms) * (2 if L.cremona else 1) * (2 if L.xperms else 1)}, '
          f'{len(syms)} symbols, {len(rels)} relations, {len(cols)} orbit columns, rank {rk}; '
          f'spanning set at s={sspan}: {keys}; accepted: {ok}; same spanning set and B as the rayreader: {same} '
          f'({time.time() - t0:.0f}s)', flush=True)
    pickle.dump({'span': keys, 'B': [[str(B[i, j]) for j in range(len(keys))] for i in range(len(keys))]},
                open(os.path.join(os.path.dirname(os.path.abspath(__file__)), f'B_{name}.pkl'), 'wb'))
    return B, span, L


if __name__ == '__main__':
    for nm in sys.argv[1:]:
        one(nm)
