"""Exact boxes of a ray of one table (Definitions def:raybox and def:box-reduction of ch:twoends), over Q(k).

A list is given by its marks 0..n-1 and its bases; the ray by its origin 0 and its direction (m; s, t).
Symbols (u; a, b) with u_E = a r + b r*, evaluation alpha^u K^-a Psi^-b.  The box B_T(abar, bbar) holds the
symbols of wall degree <= T at levels (a, b) <= (abar, bbar); its stems are its symbols at the level
(max(abar-1,0), max(bbar-1,0)); its relations are the letter identities of its symbols below the bounds and the
mark relations of its stems at every mark (Definition def:raybox (iii), (iv)).  A finite group G of symmetries
(permutations of the marks that carry the list and keep the masses, the Cremona, the exchanges) acts on the
symbols (Proposition prop:raysym (iii)); everything is averaged over G: a column is an orbit average.

The elimination is exact: rows are dicts column -> fmpz_poly in k, and every row is kept primitive (divided by
the gcd of its entries in Z[k]).  The reduction of a target is returned as (numerators, denominator) in Z[k],
exactly congruent to the target modulo the relations of the box over Q(k)."""
import itertools, math
from fractions import Fraction as Fr
from functools import reduce
import flint

ZX = flint.fmpz_poly


def P(c0, c1=0):
    return ZX([c0, c1]) if c1 else ZX([c0])


class OneTable:
    def __init__(self, n, bases, m, s, t, cremona=True, exchanges=False, perms=None):
        self.n = n; self.bases = sorted(tuple(sorted(T)) for T in bases)
        self.r = len(self.bases[0]); self.rs = n - self.r
        self.m = tuple(m); self.s = s; self.t = t
        E = range(n)
        self.Kmon = [tuple(1 if e in T else 0 for e in E) for T in self.bases]
        self.Pmon = [tuple(0 if e in T else 1 for e in E) for T in self.bases]
        U = [S for k in range(1, n) for S in itertools.combinations(E, k)]
        self.U = U
        self.d = {S: min(len(set(S) & set(T)) for T in self.bases) for S in U}
        self.ds = {S: min(len(set(S) - set(T)) for T in self.bases) for S in U}
        self.kap1 = {S: sum(m[e] for e in S) - s * self.d[S] - t * self.ds[S] for S in U}
        assert all(v > 0 for v in self.kap1.values()), 'a wall of the direction is not positive'
        Bset = set(self.bases)
        if perms is None:
            perms = [p for p in itertools.permutations(E)
                     if all(tuple(sorted(p[x] for x in T)) in Bset for T in self.bases)
                     and all(m[p[e]] == m[e] for e in E)]
        self.perms = perms
        self.cremona = cremona and all(x == m[0] for x in m) and s == t
        self.xperms = []
        if exchanges:
            assert 2 * self.r == n and s == t
            Cset = {tuple(sorted(set(E) - set(T))) for T in self.bases}
            self.xperms = [p for p in itertools.permutations(E)
                           if all(tuple(sorted(p[x] for x in T)) in Cset for T in self.bases)
                           and all(m[p[e]] == m[e] for e in E)]

    # ---- symbols
    def walls(self, u, a, b):
        return {S: sum(u[e] for e in S) - a * self.d[S] - b * self.ds[S] for S in self.U}

    def wdeg(self, u, a, b):
        w = self.walls(u, a, b)
        return max(Fr(-w[S], self.kap1[S]) for S in self.U)

    def level_symbols(self, a, b, T):
        """all u with u_E = a r + b r* and wall degree <= T"""
        n = self.n; tot = a * self.r + b * self.rs
        lo = [math.ceil(-T * self.kap1[(e,)] + a * self.d[(e,)] + b * self.ds[(e,)]) for e in range(n)]
        out = []
        def rec(i, acc, rest):
            if i == n - 1:
                if rest >= lo[i]:
                    u = acc + [rest]
                    if self.wdeg(u, a, b) <= T:
                        out.append(tuple(u))
                return
            hi = rest - sum(lo[i + 1:])
            for x in range(lo[i], hi + 1):
                rec(i + 1, acc + [x], rest - x)
        rec(0, [], tot)
        return out

    def images(self, x):
        u, a, b = x; n = self.n; out = []
        for p in self.perms:
            v = [0] * n
            for i in range(n): v[p[i]] = u[i]
            out.append((tuple(v), a, b))
            if self.cremona:
                out.append((tuple(-y + a + b for y in v), b, a))
        for p in self.xperms:
            v = [0] * n
            for i in range(n): v[p[i]] = u[i]
            out.append((tuple(v), b, a))
            out.append((tuple(-y + a + b for y in v), a, b))
        return out

    def canon(self, x):
        c = self._canon.get(x) if hasattr(self, '_canon') else None
        if c is None:
            if not hasattr(self, '_canon'):
                self._canon = {}
            c = min(self.images(x)); self._canon[x] = c
        return c

    def orbit(self, x):
        return sorted(set(self.images(x)))

    # ---- relations, before averaging: dicts symbol -> (c0, c1), the coefficient c0 + c1 k
    def letter_K(self, x):
        u, a, b = x; out = {x: (1, 0)}
        for v in self.Kmon:
            y = (tuple(p + q for p, q in zip(u, v)), a + 1, b); c = out.get(y, (0, 0)); out[y] = (c[0] - 1, c[1])
        return out

    def letter_P(self, x):
        u, a, b = x; out = {x: (1, 0)}
        for v in self.Pmon:
            y = (tuple(p + q for p, q in zip(u, v)), a, b + 1); c = out.get(y, (0, 0)); out[y] = (c[0] - 1, c[1])
        return out

    def mark_rel(self, x, e):
        """MR_e(g) for origin 0: (k m_e + u_e) g - (k s + a) sum_{T ni e} (u+1_T; a+1, b) - (k t + b) sum_{T not ni e} ..."""
        u, a, b = x; out = {}
        def add(y, c0, c1):
            c = out.get(y, (0, 0)); out[y] = (c[0] + c0, c[1] + c1)
        add(x, u[e], self.m[e])
        if self.s or a:
            for v in self.Kmon:
                if v[e]: add((tuple(p + q for p, q in zip(u, v)), a + 1, b), -a, -self.s)
        if self.t or b:
            for v in self.Pmon:
                if v[e]: add((tuple(p + q for p, q in zip(u, v)), a, b + 1), -b, -self.t)
        return {y: c for y, c in out.items() if c != (0, 0)}

    def box(self, T, abar, bbar, reps_only=True):
        """the symbols, the stems and the relations of the box.  With reps_only, the letter identities and the
        mark relations are taken at one symbol of each orbit of G only: their averages span e_G R_B, since
        phi^* of a relation of the box is a relation of the box up to letter identities (proof of Proposition
        prop:box-relations (iv)) and e_G phi^* = e_G."""
        syms = {}
        for a in range(abar + 1):
            for b in range(bbar + 1):
                for u in self.level_symbols(a, b, T):
                    syms[(u, a, b)] = True
        am, bm = max(abar - 1, 0), max(bbar - 1, 0)
        if reps_only:
            src = sorted({self.canon(x) for x in syms})
        else:
            src = list(syms)
        rels = []
        for x in src:
            u, a, b = x
            if a < abar: rels.append(self.letter_K(x))
            if b < bbar: rels.append(self.letter_P(x))
        stems = [x for x in src if x[1] == am and x[2] == bm]
        for x in stems:
            for e in range(self.n):
                rels.append(self.mark_rel(x, e))
        for R in rels:
            assert all(y in syms for y in R), 'a relation leaves the box'
        return syms, stems, rels

    def average(self, R):
        """e_G of a formal combination, as a dict over orbit representatives (column = orbit average)"""
        out = {}
        for y, (c0, c1) in R.items():
            z = self.canon(y)
            c = out.get(z, (0, 0)); out[z] = (c[0] + c0, c[1] + c1)
        return {z: P(*c) for z, c in out.items() if c != (0, 0)}


def primitive(row, den=None):
    g = None
    for v in row.values():
        g = v if g is None else g.gcd(v)
    if den is not None:
        g = den if g is None else g.gcd(den)
    if g is None or g == 1:
        return row, den
    if g.degree() == 0 and abs(int(g[0])) == 1:
        return row, den
    row = {c: v // g for c, v in row.items()}
    return row, (den // g if den is not None else None)


class Echelon:
    """an echelon form of the relations over Q(k): pivot rows (primitive in Z[k]) with distinct leading columns,
    leading = highest in the ranking"""
    def __init__(self, rankkey):
        self.key = rankkey; self.piv = {}

    def lead(self, row):
        return max(row, key=self.key)

    def add(self, row):
        row = {c: v for c, v in row.items() if v != 0}
        while row:
            c = self.lead(row)
            p = self.piv.get(c)
            if p is None:
                row, _ = primitive(row); self.piv[c] = row; return True
            a, b = p[c], row[c]
            new = {x: a * v for x, v in row.items()}
            for x, v in p.items():
                new[x] = new.get(x, ZX(0)) - b * v
            row = {x: v for x, v in new.items() if v != 0}
            row, _ = primitive(row)
        return False

    def reduce(self, row, den=ZX(1)):
        """exact reduction: (row', den') with row/den = row'/den' modulo the relations, no pivot column in row'"""
        row = {c: v for c, v in row.items() if v != 0}
        while True:
            cols = [c for c in row if c in self.piv]
            if not cols:
                return row, den
            c = max(cols, key=self.key)
            p = self.piv[c]; a, b = p[c], row[c]
            new = {x: a * v for x, v in row.items()}
            for x, v in p.items():
                new[x] = new.get(x, ZX(0)) - b * v
            row = {x: v for x, v in new.items() if v != 0}
            den = den * a
            row, den = primitive(row, den)
