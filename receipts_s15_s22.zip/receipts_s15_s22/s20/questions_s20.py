"""
Checks for notebook section 20 (python-flint, plus the standard library's random for one sampling check).
Section 20 poses questions; these are the few numbers it quotes.  Run:  python questions_s20.py
"""
import random, math
from itertools import combinations, permutations
from fractions import Fraction
from flint import arb, acb, ctx, fmpz_mat

print('1. Proposition 20.1: Cor = (n-1)! vol{phi <= 1}, phi(y) = max_T <1_T,y> - min_T <1_T,y> on the chart (sampling)')
def corner_check(n, bases, name, samples=400000, R=3.0):
    bases = [frozenset(b) for b in bases]
    phi = lambda y: max(sum(y[e] for e in T) for T in bases) - min(sum(y[e] for e in T) for T in bases)
    rnd = random.Random(1)
    hit = sum(1 for _ in range(samples) if phi([rnd.uniform(-R, R) for _ in range(n - 1)] + [0.0]) <= 1)
    vol = hit / samples * (2 * R) ** (n - 1)
    kap = lambda S: len(S) - min(len(T & S) for T in bases) - min(len(S - T) for T in bases)
    cor = sum(math.prod(Fraction(1, kap(frozenset(pi[i:]))) for i in range(1, n)) for pi in permutations(range(n)))
    print(f'   {name:8s} (n-1)! vol ~ {math.factorial(n - 1) * vol:7.3f}    Cor (Prop 18.1) = {cor}')
corner_check(3, [{0}, {1}, {2}], 'U(1,3)')
corner_check(4, [set(c) for c in combinations(range(4), 2)], 'U(2,4)')
corner_check(4, [set(c) for c in combinations(range(4), 2) if set(c) != {0, 1}], 'H')
corner_check(4, [{0}, {1}, {2}, {3}], 'U(1,4)')

ctx.prec = 200
print('2. Proposition 20.2 on two marks: the law of the stride is 2 dt/(t sqrt(1-4t)) on (0, 1/4], moments Gamma(k)^2/Gamma(2k)')
for k in (1, 2, 3):
    # t = (1 - cos u)/8 ... use t = sin^2(v)/4, dt = sin(v)cos(v)/2 dv, sqrt(1-4t) = cos v:  2 t^(k-1) dt / sqrt(1-4t) = t^(k-1) sin v dv
    f = lambda v, an: ((v.sin() ** 2) / 4) ** (k - 1) * v.sin()
    mom = acb.integral(f, 0, acb.pi() / 2).real
    print(f'   k={k}: moment = {mom.str(20)}   Gamma(k)^2/Gamma(2k) = {(arb(k).gamma() ** 2 / arb(2 * k).gamma()).str(20)}')

print('3. Proposition 20.4: log(k P(k)/2) = sum_m (-1)^m (2 - 2^m) zeta(m) k^m / m on two marks')
k = arb('0.1')
lhs = (k * arb(k).gamma() ** 2 / arb(2 * k).gamma() / 2).log()
rhs = sum(arb(-1) ** m * (2 - 2 ** m) * arb(m).zeta() * k ** m / m for m in range(2, 160))
print('   at k = 1/10: difference =', (lhs - rhs).str(5))

print('4. Question 20.7: the slopes of the three-mark centre (share side, Proposition 15.2)')
ctx.prec = 260
tol = 2 ** -220; T = 330
def mom(kk, logpow):
    def g(u, an):
        G = 2 * (2 * u).bessel_k(0); y = u * u
        return y ** (kk - 1) * (y.log()) ** logpow * G ** 3 * 2 * u
    def g0(t, an):
        u = (-t).exp(); G = 2 * (2 * u).bessel_k(0); y = u * u
        return y ** (kk - 1) * (y.log()) ** logpow * G ** 3 * 2 * u * u
    return (acb.integral(g0, 0, T, rel_tol=tol) + acb.integral(g, 1, 50, rel_tol=tol)).real
def P_dP(kk):
    kk = arb(kk); M0, M1 = mom(kk, 0), mom(kk, 1); g = kk.gamma()
    return M0 / g ** 2, (M1 - 2 * kk.digamma() * M0) / g ** 2
l, dP1 = P_dP(1)
P2, dP2 = P_dP(2)
print("   P'(1) =", dP1.str(40))
print("   3P'(1) - 9P'(2) + 4l + 12 =", (3 * dP1 - 9 * dP2 + 4 * l + 12).str(5))
digits = 58; sc = arb(10) ** digits
vec = [dP1, arb(1), l]
rows = [[1 if j == i else 0 for j in range(3)] + [int((v * sc).mid().floor().unique_fmpz())] for i, v in enumerate(vec)]
M = fmpz_mat(rows).lll()
best = min(([int(M[i, j]) for j in range(3)] for i in range(3)), key=lambda r: max(abs(x) for x in r))
print(f"   smallest integer relation among P'(1), 1, l at {digits} digits: coefficients ~ 10^{len(str(max(abs(x) for x in best))) - 1}, "
      f"residual {sum(arb(c) * v for c, v in zip(best, vec)).str(3)}  (no relation below 10^18)")
