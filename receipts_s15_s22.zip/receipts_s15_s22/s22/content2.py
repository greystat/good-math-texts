import sys, pickle; sys.path.insert(0,'./s20')
exec(open('content_lll.py').read().split("for name, masters")[0])
def all_small(vals, DIG, names):
    scale=fmpz(10)**DIG
    rows=[]
    for i,v in enumerate(vals):
        row=[0]*len(vals); row[i]=1
        rows.append(row+[(v*scale).mid().floor().unique_fmpz()])
    Lm=fmpz_mat(rows).lll()
    out=[]
    for i in range(Lm.nrows()):
        r=[int(Lm[i,j]) for j in range(len(vals))]
        res=sum((c*v for c,v in zip(r,vals)),arb(0))
        if abs(res.mid()) < arb(10)**(-DIG-50):
            out.append((max(abs(c) for c in r), show(r,names)))
    return out
# lean: full lattice with all constants of basis A
names=['1','P1','P2','P3','z3','pi2','ell','pi2l2','pi2l3','ell l3','ell l2','L-7','L-8','L-84','L-24','pi/s3','l2','l3']
vals=[arb(1)]+lean[:3]+consts_lean
print('lean, genuine relations with basis A:', all_small(vals, 470, names))
# lean: products of three-mark numbers
vals2=[arb(1)]+lean[:3]+[ell, ell**2, pi**2, ell*pi**2, z3, pi**4, ell*z3]
names2=['1','P1','P2','P3','ell','ell^2','pi2','ell pi2','z3','pi4','ell z3']
print('lean, with products:', all_small(vals2, 470, names2))
# centre: masters + ell and friends
valsc=[arb(1)]+cen[:8]+[ell]
namesc=['1']+['P%d'%i for i in range(1,9)]+['ell']
print('centre + ell:', all_small(valsc, 520, namesc))
valsc=[arb(1)]+cen[:8]+[ell, ell**2, pi**2, z3]
namesc=['1']+['P%d'%i for i in range(1,9)]+['ell','ell^2','pi2','z3']
print('centre + ell, ell^2, pi2, z3:', all_small(valsc, 520, namesc))
