exec(open('connect3.py').read().split("for k in ['0.25'")[0])
def Tshift(k):
    # T(k), T(k+1) with T(k+1) from the law at k-1
    Tm = T_at(k-1); T0 = T_at(k)
    T1 = -(ceval(cp[0], k-1)*Tm + ceval(cp[1], k-1)*T0)/ceval(cp[2], k-1)
    return T0, T1
def Sshift(k):
    return S_at(k), S_at(k+1)
import math
res = []
for kk in ['0.1','0.2','0.3','0.4','0.5','0.6','0.7','0.8','0.9']:
    k = arb(kk)
    P0 = P_at(k); P1 = P_at(k+1)
    T0, T1 = Tshift(k)
    S0, S1 = Sshift(k)
    det = P0*S1 - P1*S0
    al = (T0*S1 - T1*S0)/det
    be = (P0*T1 - P1*T0)/det
    s = (pi*k).sin()
    print('k=%s alpha=%s beta=%s  alpha*sin^2(pi k)=%s  beta*sin(pi k)=%s  beta*sin^2=%s'%(kk, al.str(12), be.str(12), (al*s*s).str(10), (be*s).str(10), (be*s*s).str(10)), flush=True)
