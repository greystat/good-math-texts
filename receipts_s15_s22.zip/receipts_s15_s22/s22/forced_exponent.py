import sys, pickle, math; sys.path.insert(0,'.'); sys.path.insert(0,'./s20')
from gauge import *
from fmray import law_polys, guess_rec, peval
from flint import fmpq_poly, arb, acb, ctx
ctx.prec = 400
def to_q(cp): return [[fmpq(x) for x in c] for c in cp]
def mu_at_roots(cp):
    D, a = density_operator(cp)
    chi, _ = symbol_poly(cp)
    out = []
    # exact rational roots
    fac = chi.factor()[1]
    for f, mult in fac:
        if f.degree() == 1:
            c = f.coeffs(); t0 = -c[0]/c[1]
            b = shifted_ops(a, t0)
            if coef(b[D],1) == 0: out.append((t0, mult, 'degenerate')); continue
            out.append((t0, mult, indicial_extra(b, D)))
        else:
            for r, m in f.complex_roots():
                # numeric: mu = D-1 - a_{D-1}(t0)/a_D'(t0)
                aD = a[D]; aDm1 = a[D-1]
                def ev(p, z):
                    s = acb(0)
                    for k in range(p.degree(), -1, -1): s = s*z + acb(arb(p[k].p)/p[k].q)
                    return s
                dD = aD.derivative()
                mu = acb(D-1) - ev(aDm1, r)/ev(dD, r)
                out.append((r, mult, mu))
    return D, out
laws = {}
laws['three-mark centre (n=3)'] = (3, to_q([[0,0,1],[-3,-10,-10],[9,18,9]]))
laws['four-mark centre (n=4)'] = (4, to_q([[0,0,0,1], [-4,-18,-30,-20], [64,192,192,64]]))
# check four: -2(2k+1)(5k^2+5k+2) = -2(10k^3+10k^2+4k+5k^2+5k+2) = -2(10k^3+15k^2+9k+2) = -20k^3-30k^2-18k-4
laws['five-mark centre (n=5)'] = (5, to_q([[0,0,0,0,-1],[5,28,63,70,35],
     [-285, -(518+2*285), -(259+2*518+285), -(2*259+518), -259], 
     [900, 225*12, 225*13, 225*6, 225]]))
fx = [[720, 4176, 9280, 9920, 5120, 1024], [-2076, -6784, -8910, -5880, -1950, -260], [32, 80, 80, 40, 10, 1]]
laws['fixture (1;0,2) (n=6)'] = (6, law_polys(fx))
polys, cp = pickle.load(open('./s20/clos_H_1-1-3-3_3_1.txt.law.pkl','rb'))
laws['H at (1,1,3,3;3,1) (n=4)'] = (4, cp)
polys, cp = pickle.load(open('./s20/clos_N6_02_220.txt.law.pkl','rb'))
laws['N at (1;0,2) (n=6)'] = (6, cp)
polys, cp = pickle.load(open('./s20/n6c_law12.pkl','rb'))
laws['N centre, order 12 (n=6)'] = (6, cp)
# H centre from closings
xs = [fmpz(int(l)) for l in open('./s20/clos_H_1-1-1-1_1_1.txt').read().split()]
for d in range(2,5):
    found=False
    for Dg in range(1,12):
        if (d+1)*(Dg+1)+3 > len(xs)-d: break
        p, nul = guess_rec(xs, d, Dg)
        if p is not None: found=True; break
    if found: break
laws['H centre (n=4)'] = (4, law_polys(p))
if __name__ == '__main__':
    for name, (n, cp) in laws.items():
        D, out = mu_at_roots(cp)
        chi,_ = symbol_poly(cp)
        print('==', name, ' D =', D, ' (n-3)/2 =', fmpq(n-3,2))
        for t0, mult, mu in out:
            ts = str(t0) if isinstance(t0, fmpq) else t0.real.str(10)+('' if abs(t0.imag)<1e-30 else '%+.4gi'%float(t0.imag.mid()))
            ms = str(mu) if isinstance(mu, fmpq) else (mu if isinstance(mu,str) else (mu.real.str(12) + ('' if mu.imag.contains(0) else ' + i'+mu.imag.str(5))))
            print('   root t0 =', ts, ' mult', mult, ' extra exponent mu =', ms)
