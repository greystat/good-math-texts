"""Check (quadrature): at three marks the chart density is (2pi)^2 times the torus density continued through 1/9.
The torus density uses the closed form recalled in the aliases of s22 (three-step walk); a check only."""
import sys; sys.path.insert(0,'.')
from flint import arb, acb, ctx, fmpq
from tanhsinh import tanh_sinh
ctx.prec = 300
pi = arb.pi(); s3 = arb(3).sqrt()
A = acb(arb(fmpq(1,3))); B = acb(arb(fmpq(2,3)))
def p3(x):
    z = x**2*(9-x**2)**2/(3+x**2)**3
    return (2*s3/pi)*x/(3+x**2)*acb(z).hypgeom_2f1(A, B, acb(1), abc=True).real
def rhoT(t):
    x = t**(-arb(1)/2)
    return p3(x)*(t**(-arb(3)/2))/2
f = arb(1)/9
print('rho_T(1/9+) =', rhoT(f*(1+arb(10)**-40)).str(20), ' 27 sqrt3/(4 pi) =', (27*s3/(4*pi)).str(20))
eps = arb(10)**-20
for k in (1, 2, 3):
    def g(u):
        if u < eps or (1-u) < eps: return arb(0)
        return 4*pi**2*(arb(3)/u)**(-2*k)*p3(arb(3)/u)*3/u**2
    print('k=%d: (2pi)^2 * moment of the continued torus density on (0,1/9) ='%k, tanh_sinh(g, 0, 1, levels=9, h0=0.5).str(25))
ell = 3*(arb(2).zeta(arb(1)/3)-arb(2).zeta(arb(2)/3))/9
print('chart: P(1) =', ell.str(25), ' P(2) =', ((ell-2)/3).str(25), ' P(3) =', ((23*(ell-2)/3 - ell)/36).str(25))
