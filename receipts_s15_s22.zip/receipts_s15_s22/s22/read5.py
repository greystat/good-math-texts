import sys, time; sys.path.insert(0,'.')
from gauge import *
from forced_exponent import laws
ctx.prec = 1400
n, cp = laws['five-mark centre (n=5)']
D, a = density_operator(cp)
fs = fmpq(1,25)
b = shifted_ops(a, fs)
mu = indicial_extra(b, D); print('D', D, 'mu', mu)
t0=time.time()
M = 1400
e = germ_series(b, D, mu, M)
print('series built', time.time()-t0, 'first coeffs', [str(x) for x in e[:4]])
# Morse constant: g(0) = (2 pi / f*)^{(n-1)/2} / (Gamma((n-1)/2) sqrt(det H)),  det H = 2^{n-1} n^{-n}
detH = fmpq(2**(n-1), n**n)
g0 = (2*arb.pi()/to_arb(fs))**(arb(n-1)/2)/(arb.gamma(arb(n-1)/2)*to_arb(detH).sqrt())
print('g(0) =', g0.str(20))
ea = [g0*to_arb(x) for x in e]
print('growth check e_m f*^m:', [ (ea[m]*to_arb(fs)**m).str(8) for m in (100, 400, 1000, 1400)])
for K in (90, 130):
    vals = {k: beta_sum(ea, mu, fs, k) for k in range(K, K+3)}
    x = run_back(cp, vals, K)
    print('K=%d P(1) ='%K, x[1].str(60), ' P(2) =', x[2].str(30), ' time %.1f'%(time.time()-t0))
print('ref  (s15)  39.94558801199624569894402849842399589184978292477')
