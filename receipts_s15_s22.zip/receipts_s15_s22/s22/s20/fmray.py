"""Toolkit for reading rays of families (Foreman notebook, entry 20).
python-flint only: exact arithmetic (fmpz, fmpq, matrices), ball arithmetic (arb/acb)."""
from flint import fmpz, fmpq, fmpz_mat, fmpq_mat, nmod_mat, arb, acb, ctx, fmpz_poly, fmpq_poly
import itertools, math, functools

# ---------------------------------------------------------------- lists
def popcount(S): return bin(S).count('1')

def rank_function(bases, n):
    """bases: list of bitmasks. returns r(S) = max_T |T & S| for all S (list of size 2^n)."""
    r = [0]*(1<<n)
    for S in range(1<<n):
        r[S] = max(popcount(T & S) for T in bases)
    return r

def walls(bases, n, m, s, t):
    """kappa_S = m(S) - s d(S) - t d*(S), d(S) = r - r(E\\S), d*(S)=|S|-r(S). m: list of masses (fmpq ok)."""
    r = rank_function(bases, n); full = (1<<n)-1; R = r[full]
    kap = [None]*(1<<n)
    for S in range(1<<n):
        mS = sum((m[e] for e in range(n) if S>>e & 1), fmpq(0))
        d = R - r[full ^ S]; ds = popcount(S) - r[S]
        kap[S] = fmpq(mS) - s*d - t*ds
    return kap

def corner(kap, n):
    """Cor = sum over orders pi of prod_{i=2}^n 1/kappa(U_i), U_i tails = maximal chains of nonempty proper subsets."""
    D = {}
    for S in range(1, 1<<n):
        if popcount(S) == n: continue
        if popcount(S) == 1:
            D[S] = fmpq(1)/kap[S]; continue
        acc = fmpq(0)
        for e in range(n):
            if S>>e & 1: acc += D[S ^ (1<<e)]
        D[S] = acc/kap[S]
    full=(1<<n)-1
    return sum((D[full ^ (1<<e)] for e in range(n)), fmpq(0))

# ---------------------------------------------------------------- recurrences
def guess_rec(x, d, D, j0=0):
    """Find p_0..p_d (deg<=D) with sum_i p_i(j) x[j+i] = 0 for all j with j+d < len(x).
    Returns list of coefficient lists (fmpz) [p_i[a] = coeff of j^a], or None. Also returns nullity."""
    N = len(x)
    rows = []
    for j in range(N-d):
        jj = j + j0
        row = []
        for i in range(d+1):
            pw = fmpz(1)
            for a in range(D+1):
                row.append(pw * x[j+i]); pw *= jj
        rows.append(row)
    if len(rows) < (d+1)*(D+1) + 2:
        raise ValueError('not enough equations: %d for %d unknowns' % (len(rows), (d+1)*(D+1)))
    # clear denominators if fmpq
    A = fmpq_mat(rows)
    rref, rank = A.rref()
    ncols = (d+1)*(D+1)
    nullity = ncols - rank
    if nullity == 0: return None, 0
    # extract one nullspace vector from rref
    piv = []
    rr = rref.tolist()
    for i in range(rank):
        for c in range(ncols):
            if rr[i][c] != 0: piv.append(c); break
    free = [c for c in range(ncols) if c not in piv]
    sols = []
    for f in free:
        v = [fmpq(0)]*ncols; v[f] = fmpq(1)
        for i,pc in enumerate(piv): v[pc] = -rr[i][f]
        sols.append(v)
    # take first, normalize to integers
    v = sols[0]
    den = 1
    for c in v: den = den * c.q // math.gcd(den, int(c.q))
    vi = [int(c*den) for c in v]
    g = 0
    for c in vi: g = math.gcd(g, c)
    vi = [c//g for c in vi]
    polys = [vi[i*(D+1):(i+1)*(D+1)] for i in range(d+1)]
    return polys, nullity

def peval(p, k):
    acc = fmpq(0) if isinstance(k, fmpq) else 0
    for a in reversed(p): acc = acc*k + a
    return acc

def reflect(polys):
    """closings recurrence sum_i p_i(j) x_{j+i}=0 -> ray law c_i(k)=p_{d-i}(-k-d) as functions."""
    d = len(polys)-1
    def c(i, k): return peval(polys[d-i], -k-d)
    return c, d

def poly_compose_shift(p, a, b):
    """coefficients of q(k)=p(a*k+b) for integer a,b"""
    res = [fmpq(0)]*len(p)
    # q(k) = sum p_m (a k + b)^m
    for m, pm in enumerate(p):
        # expand (a k + b)^m
        for r in range(m+1):
            res[r] += fmpq(pm) * math.comb(m, r) * (fmpq(a)**r) * (fmpq(b)**(m-r))
    return res

def law_polys(polys):
    """return list of c_i as coefficient lists (fmpq) in k."""
    d = len(polys)-1
    return [poly_compose_shift(polys[d-i], -1, -d) for i in range(d+1)]

def pstr(p, var='k'):
    terms=[]
    for a,c in enumerate(p):
        if c!=0: terms.append('(%s)%s^%d'%(c,var,a))
    return ' + '.join(terms) if terms else '0'

def poly_from_coeffs(cs):
    return fmpq_poly([fmpq(c) for c in cs])

def symbol(cpolys):
    D = max(len([c for c in p]) for p in cpolys) - 1
    # leading degree overall
    deg = max(max([a for a,c in enumerate(p) if c!=0] or [-1]) for p in cpolys)
    return [ (p[deg] if deg < len(p) else 0) for p in cpolys ], deg

def run_law(cpolys, init, K):
    """iterate sum_i c_i(k) x(k+i)=0 forward from k=1 with init = [x(1),...,x(h)] (fmpq)."""
    h = len(cpolys)-1
    x = {i+1: fmpq(init[i]) for i in range(h)}
    for k in range(1, K-h+1):
        s = fmpq(0)
        for i in range(h):
            s += peval(cpolys[i], fmpq(k)) * x[k+i]
        ch = peval(cpolys[h], fmpq(k))
        x[k+h] = -s/ch
    return x
