import sys, math, itertools, time; sys.path.insert(0,'./s20')
from fmray import *
from findrec_mod import rank_mod
from math import comb
from flint import arb, ctx, fmpq_poly
ctx.prec=600
def multinom(n, ks):
    if any(k<0 for k in ks): return 0
    r=math.factorial(n)
    for k in ks: r//=math.factorial(k)
    return r
def closings3(m, s, t, J):
    """x_j = [alpha^{j m}] e1^{j s} e2^{j t} on three marks"""
    xs=[]
    for j in range(J+1):
        A=j*s; B=j*t; T=[j*mm for mm in m]
        tot=0
        for u in range(B+1):
            for v in range(B+1-u):
                w=B-u-v
                k1=T[0]-v-w; k2=T[1]-u-w; k3=T[2]-u-v
                if k1<0 or k2<0 or k3<0 or k1+k2+k3!=A: continue
                tot+=multinom(B,(u,v,w))*multinom(A,(k1,k2,k3))
        xs.append(tot)
    return xs
def find_rec_exact(xs, maxorder=4, maxdeg=24):
    for d in range(1,maxorder+1):
        for D in range(0,maxdeg+1):
            if (d+1)*(D+1)+4 > len(xs)-d: break
            r,u,e=rank_mod(xs,d,D)
            if r<u:
                polys,nul=guess_rec([fmpz(x) for x in xs],d,D)
                if polys: return d,D,polys
    return None
def lcm(a,b): return a*b//math.gcd(a,b)
def dK(n):
    L=1
    for i in range(1,n+1): L=lcm(L,i)
    return L
