from flint import fmpz_mat, fmpz, arb, ctx
def intrel(vals, digits, maxcoef=None, names=None):
    """LLL integer relation among arb values (real). Returns best relation vector and its residual."""
    n=len(vals)
    scale=fmpz(10)**digits
    rows=[]
    for i,v in enumerate(vals):
        row=[0]*n; row[i]=1
        x=(v*scale).mid().floor().unique_fmpz()
        rows.append(row+[x])
    M=fmpz_mat(rows)
    L=M.lll()
    best=None
    for i in range(L.nrows()):
        rel=[int(L[i,j]) for j in range(n)]
        if all(c==0 for c in rel): continue
        res=sum((c*v for c,v in zip(rel,vals)), arb(0))
        size=max(abs(c) for c in rel)
        if best is None or size<best[1]: best=(rel,size,res)
    return best
def show(rel,names):
    return ' + '.join('%d*%s'%(c,nm) for c,nm in zip(rel,names) if c!=0)
