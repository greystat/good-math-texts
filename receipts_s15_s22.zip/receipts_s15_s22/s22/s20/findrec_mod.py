import sys; sys.path.insert(0,'./s20')
from flint import nmod_mat, nmod
P=(1<<61)-1
def rank_mod(xs, d, D, p=P, j0=0):
    N=len(xs)
    rows=[]
    for j in range(N-d):
        jj=(j+j0)%p
        row=[]
        for i in range(d+1):
            pw=1
            xv=xs[j+i]%p
            for a in range(D+1):
                row.append(pw*xv%p); pw=pw*jj%p
        rows.append(row)
    M=nmod_mat(rows,p)
    return M.rank(), (d+1)*(D+1), len(rows)
def search(xs, maxorder=12, maxdeg=80, p=P):
    found=[]
    for d in range(1,maxorder+1):
        for D in range(0,maxdeg+1):
            unk=(d+1)*(D+1)
            if unk+5 > len(xs)-d: break
            r,u,e=rank_mod(xs,d,D,p)
            if r<u:
                found.append((d,D,u-r)); break
    return found
if __name__=='__main__':
    fn=sys.argv[1]
    xs=[int(l) for l in open(fn).read().split()]
    print(fn, len(xs)); sys.stdout.flush()
    for f in search(xs): print('  order %d degree %d nullity %d'%f); sys.stdout.flush()
