import subprocess, sys, math
sys.path.insert(0,'./s20')
from fmray import *
PRIMES=[4611686018427387847, 4611686018427387733, 4611686018427387631, 4611686018427387517,
        4611686018427387409, 4611686018427387403, 4611686018427387361, 4611686018427387319,
        4611686018427387271, 4611686018427387203, 4611686018427387137, 4611686018427387091]
def is_prime(n):
    if n<2: return False
    for p in [2,3,5,7,11,13,17,19,23,29,31,37]:
        if n%p==0: return n==p
    d=n-1; s=0
    while d%2==0: d//=2; s+=1
    for a in [2,3,5,7,11,13,17,19,23,29,31,37]:
        x=pow(a,d,n)
        if x in (1,n-1): continue
        for _ in range(s-1):
            x=x*x%n
            if x==n-1: break
        else: return False
    return True
def primes(k, start=(1<<62)):
    out=[]; c=start-1
    while len(out)<k:
        if is_prime(c): out.append(c)
        c-=2 if c%2 else 1
    return out
def run_closings(mons, n, r, J, T, nprimes):
    ps=primes(nprimes)
    res={}
    for p in ps:
        inp="%d %d %d %d %d\n"%(n,r,J,p,len(mons)) + "\n".join(" ".join(str(x) for x in m) for m in mons) + "\n" + " ".join(str(t) for t in T)+"\n"
        out=subprocess.run(['./s20/c/closings'],input=inp,capture_output=True,text=True).stdout
        for line in out.strip().split('\n'):
            m,v=line.split(); res.setdefault(int(m),[]).append((p,int(v)))
    # CRT
    xs=[1]
    for m in range(1,J+1):
        acc=0; mod=1
        for p,v in res[m]:
            # combine
            t=((v-acc)*pow(mod,-1,p))%p
            acc=acc+mod*t; mod*=p
        if acc>mod//2: acc-=mod
        xs.append(acc)
    return xs, math.prod(ps)

def run_closings2(monsA, monsB, n, rA, rB, J, T, nprimes):
    ps=primes(nprimes)
    res={}
    for p in ps:
        inp="%d %d %d %d %d %d %d\n"%(n,rA,rB,J,p,len(monsA),len(monsB)) + "\n".join(" ".join(str(x) for x in m) for m in monsA) + "\n" + "\n".join(" ".join(str(x) for x in m) for m in monsB)+"\n" + " ".join(str(t) for t in T)+"\n"
        out=subprocess.run(['./s20/c/closings2'],input=inp,capture_output=True,text=True).stdout
        for line in out.strip().split('\n'):
            m,v=line.split(); res.setdefault(int(m),[]).append((p,int(v)))
    xs=[1]
    for m in range(1,J+1):
        acc=0; mod=1
        for p,v in res[m]:
            t=((v-acc)*pow(mod,-1,p))%p
            acc=acc+mod*t; mod*=p
        if acc>mod//2: acc-=mod
        xs.append(acc)
    return xs
def letters_mons(bases,n):
    K=[[ (T>>e)&1 for e in range(n)] for T in bases]
    Ps=[[ 1-((T>>e)&1) for e in range(n)] for T in bases]
    return K,Ps
