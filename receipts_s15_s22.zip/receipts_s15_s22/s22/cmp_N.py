import sys, time, itertools, pickle; sys.path.insert(0,'.'); sys.path.insert(0,'./s20')
exec(open('read_N2.py').read().split("which = sys.argv[1]")[0])
which = sys.argv[1]; ctx.prec = int(sys.argv[2]); M = int(sys.argv[3]); K = int(sys.argv[4])
t0=time.time()
trip = list(itertools.combinations(range(6),3))
basesN = [S for S in trip if set(S) != {0,1,2}]
cobN = [S for S in trip if set(S) != {3,4,5}]
Kv = [[1 if e in S else 0 for e in range(6)] for S in basesN]
Pv = [[1 if e in S else 0 for e in range(6)] for S in cobN]
if which == 'lean':
    s21 = arb(21).sqrt(); x = (s21-3)/2
    alpha = [x,x,x,arb(1),arb(1),arb(1)]
    detH = hessian_det([(2, Pv, alpha)], None, 5, 6); fs = (7*s21-27)/1800
    n, cp = laws['N at (1;0,2) (n=6)']
    ref = arb(open('./s20/n6_02_P.txt').read().split('\n')[0].strip())
else:
    alpha1 = [arb(1)]*6
    detH = hessian_det([(1, Kv, alpha1), (1, Pv, alpha1)], None, 5, 6); fs = fmpq(1,361)
    n, cp = laws['N centre, order 12 (n=6)']
    ref = arb(pickle.load(open('./s20/n6c_vals_K350.pkl','rb'))[0])
out = read_mid(6, cp, fs, detH, fmpq(3,2), M, [K])
p1 = out[0][1]
d = abs(p1 - ref.mid())
print(which, 'K', K, 'M', M, 'P(1) =', p1.str(30), ' |gauge - positivity| =', d.str(5), ' time %.1f'%(time.time()-t0))
pickle.dump(p1.str(600), open('gauge_%s_P1.pkl'%which,'wb'))
