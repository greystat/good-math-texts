from flint import arb, ctx
def tanh_sinh(f, a, b, levels=7, h0=1.0):
    """integrate real function f on (a,b) with arb points (check-level numerics)"""
    a = arb(a); b = arb(b)
    c = (a+b)/2; d = (b-a)/2
    pi2 = arb.pi()/2
    h = arb(h0)
    total = None
    for lev in range(levels):
        s = arb(0)
        step = 1 if lev == 0 else 2
        start = 0 if lev == 0 else 1
        N = int(6/float(h.mid()))+1
        for k in range(-N if lev==0 else -N, N+1):
            if lev > 0 and k % 2 == 0: continue
            t = h*k
            u = pi2*t.sinh()
            x = u.tanh()
            w = pi2*t.cosh()/(u.cosh()**2)
            xx = c + d*x
            if not (xx > a and xx < b): continue
            v = f(xx)
            s += w*v
        if total is None: total = s*h*d
        else: total = total/2 + s*h*d
        h = h/2
    return total
