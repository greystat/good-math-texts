import sys, pickle; sys.path.insert(0,'./s20')
from flint import arb, ctx
from pslq import intrel, show
ctx.prec = 2200
Ps = [arb(s) for s in pickle.load(open('lean_gauge_420_6000.pkl','rb'))]
P1 = Ps[0]
DIG = 480
rel,size,res = intrel([arb(1)]+Ps[:5], DIG)
print('masters 1,P1..P5 at %d digits: smallest relation height %.3g'%(DIG,size))
pi=arb.pi(); l2=arb(2).log(); l3=arb(3).log(); l7=arb(7).log(); z3=arb(3).zeta(); s3=arb(3).sqrt()
ell=3*(arb(2).zeta(arb(1)/3)-arb(2).zeta(arb(2)/3))/9
def Lchi(d):
    D=abs(d)
    def kron(n):
        def jac(a,n):
            a%=n; r=1
            while a:
                while a%2==0:
                    a//=2
                    if n%8 in (3,5): r=-r
                a,n=n,a
                if a%4==3 and n%4==3: r=-r
                a%=n
            return r if n==1 else 0
        r=1; m=n
        while m%2==0:
            m//=2
            if d%2==0: return 0
            if d%8 in (3,5): r=-r
        return r*jac(d,m) if m>1 else r
    return sum((kron(a)*arb(2).zeta(arb(a)/D) for a in range(1,D+1) if kron(a)),arb(0))/arb(D)**2
L7=Lchi(-7); L8=Lchi(-8); L24=Lchi(-24); L84=Lchi(-84)
names=['P1','1','z3','pi2','ell','pi2l2','pi2l3','ell l3','ell l2','L-7','L-8','L-84','L-24','pi/s3','l2','l3']
vals=[P1,arb(1),z3,pi**2,ell,pi**2*l2,pi**2*l3,ell*l3,ell*l2,L7,L8,L84,L24,pi/s3,l2,l3]
rel,size,res=intrel(vals,DIG)
print('basis A (16 numbers) at %d digits: smallest relation height %.3g'%(DIG,size))
s21=arb(21).sqrt(); L=((5+s21)/2).log()
names2=['P1','1','s21','z3','s21z3','pi2','s21pi2','L','s21L','pi2L','s21pi2L','L2','s21L2','L3','s21L3','l2','l3','l7']
vals2=[P1,arb(1),s21,z3,s21*z3,pi**2,s21*pi**2,L,s21*L,pi**2*L,s21*pi**2*L,L**2,s21*L**2,L**3,s21*L**3,l2,l3,l7]
rel,size,res=intrel(vals2,DIG)
print('basis B (18 numbers) at %d digits: smallest relation height %.3g'%(DIG,size))
