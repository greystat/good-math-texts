exec(open('connect3.py').read().split("for k in ['0.25'")[0])
s3 = arb(3).sqrt()
for kk in ['0.15','0.35','0.5','0.8']:
    k = arb(kk)
    Sk = S_at(k)
    v = (2*pi/(3*s3))*arb(9)**(1-k)*T_at(1-k)
    Pk = P_at(k)
    conn = 2*pi**2*T_at(k) + (2*pi**2/s3)*(1/(pi*k).tan())*arb(9)**(1-k)*T_at(1-k)
    print('k=%s  S(k)=%s  (2pi/3sqrt3) 9^{1-k} T(1-k)=%s   P(k)=%s  2pi^2[T(k)+cot(pi k)9^{1-k}T(1-k)/sqrt3]=%s'%(kk, Sk.str(14), v.str(14), Pk.str(14), conn.str(14)), flush=True)
