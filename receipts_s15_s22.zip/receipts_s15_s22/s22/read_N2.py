import sys, time, itertools, pickle; sys.path.insert(0,'.'); sys.path.insert(0,'./s20')
from gauge import *
from forced_exponent import laws
from flint import arb_mat
def morse_g0(n, fstar, detH):
    return (2*arb.pi()/to_arb(fstar))**(arb(n-1)/2)/(arb.gamma(arb(n-1)/2)*to_arb(detH).sqrt())
def read_mid(n, cp, fs, detH, mu, M, Ks):
    D, a = density_operator(cp)
    b = shifted_ops_arb(a, to_arb(fs))
    e = germ_series_mid(b, D, mu, M)
    g0 = morse_g0(n, fs, detH)
    ea = [g0*x for x in e]
    h = len(cp)-1
    out = []
    for K in Ks:
        vals = {k: beta_sum(ea, mu, fs, k) for k in range(K, K+h)}
        x = run_back(cp, vals, K)
        out.append((K, x[1].mid(), x[2].mid()))
    return out
which = sys.argv[1]; prec = int(sys.argv[2]); M = int(sys.argv[3])
ctx.prec = prec
t0 = time.time()
trip = list(itertools.combinations(range(6),3))
basesN = [S for S in trip if set(S) != {0,1,2}]
cobN = [S for S in trip if set(S) != {3,4,5}]
Kv = [[1 if e in S else 0 for e in range(6)] for S in basesN]
Pv = [[1 if e in S else 0 for e in range(6)] for S in cobN]
if which == 'lean':
    s21 = arb(21).sqrt(); x = (s21-3)/2
    alpha = [x,x,x,arb(1),arb(1),arb(1)]
    detH = hessian_det([(2, Pv, alpha)], None, 5, 6)
    fs = (7*s21-27)/1800
    n, cp = laws['N at (1;0,2) (n=6)']
else:
    alpha1 = [arb(1)]*6
    detH = hessian_det([(1, Kv, alpha1), (1, Pv, alpha1)], None, 5, 6)
    fs = fmpq(1,361)
    n, cp = laws['N centre, order 12 (n=6)']
out = read_mid(6, cp, fs, detH, fmpq(3,2), M, [110, 150])
for K, p1, p2 in out: print(which, 'prec', prec, 'M', M, 'K=%d P(1) ='%K, p1.str(70), ' %.1fs'%(time.time()-t0), flush=True)
