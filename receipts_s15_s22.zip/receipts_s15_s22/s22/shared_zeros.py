import sys, pickle; sys.path.insert(0,'.'); sys.path.insert(0,'./s20')
from forced_exponent import laws
from flint import fmpq_poly, fmpq
for name in ['three-mark centre (n=3)','four-mark centre (n=4)','five-mark centre (n=5)','fixture (1;0,2) (n=6)','H at (1,1,3,3;3,1) (n=4)','H centre (n=4)','N at (1;0,2) (n=6)','N centre, order 12 (n=6)']:
    n, cp = laws[name]
    c0 = fmpq_poly([fmpq(x) for x in cp[0]]); c1 = fmpq_poly([fmpq(x) for x in cp[1]])
    g = c0.gcd(c1)
    # integer roots of c0 with multiplicities, and of gcd
    def introots(p):
        out=[]
        for r in range(-12, 3):
            m=0; q=p
            while q.degree()>=0 and q(fmpq(r))==0:
                m+=1; q = q.derivative()
            # multiplicity via derivatives
            if m: out.append((r,m))
        return out
    print(name, '| c0 integer roots (k, mult):', introots(c0), '| gcd(c0,c1) integer roots:', introots(g), '| deg gcd', g.degree())
