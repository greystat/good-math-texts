import sys; sys.path.insert(0,'.')
from flint import arb, acb, ctx
from tanhsinh import tanh_sinh
ctx.prec = 300
pi = arb.pi(); s3 = arb(3).sqrt(); l3 = arb(3).log()
def Li2(x): return acb(x).polylog(2).real if False else acb.polylog(acb(x), 2).real
# Mahler moments of K = 1+x+y on the torus via the Jensen split over one mark
def avg_log(R):      # average over phi of log|a+e^{i phi}|, |a|^2=R
    return R.log()/2 if R > 1 else arb(0)
def avg_log2(R):
    if R > 1: return (R.log()/2)**2 + acb(1/R).polylog(2).real/2
    return acb(R).polylog(2).real/2
def m(j):
    f = (lambda th: avg_log(4*(th/2).cos()**2)) if j == 1 else (lambda th: avg_log2(4*(th/2).cos()**2))
    a1 = tanh_sinh(f, 0, 2*pi/3, levels=9, h0=0.5)
    a2 = tanh_sinh(f, 2*pi/3, pi, levels=9, h0=0.5)
    return (a1+a2)/pi
m1 = m(1); m2 = m(2)
ell = 3*(arb(2).zeta(arb(1)/3)-arb(2).zeta(arb(2)/3))/9
print('m1 =', m1.str(30), '  sqrt3*ell/(4pi) =', (s3*ell/(4*pi)).str(30))
S3 = -tanh_sinh(lambda th: (2*(th/2).sin()).log()**2, 0, 2*pi/3, levels=9, h0=0.5)
print('m2 =', m2.str(30), '  (3/pi) S3 + pi^2/4 =', (3*S3/pi + pi**2/4).str(30), '  S3 =', S3.str(25))
