import sys, pickle; sys.path.insert(0,'./s20')
exec(open('content2.py').read().split("# lean: full lattice")[0])
namesc=['1']+['P%d'%i for i in range(1,9)]
base=[arb(1)]+cen[:8]
for extra_names, extra in [(['z3'],[z3]), (['ell','z3'],[ell,z3]),
                           (['ell','z3','pi2','pi4','ell^2','ell pi2'],[ell,z3,pi**2,pi**4,ell**2,ell*pi**2]),
                           (['ell','z3','L-7','pi s7','l2','l3','l7'],[ell,z3,Lchi(-7),pi*s7,l2,l3,l7])]:
    vals=base+extra; names=namesc+extra_names
    rels=all_small(vals, 520, names)
    print(extra_names, ': %d genuine relations, heights'%len(rels), ['%.2g'%h for h,_ in rels])
