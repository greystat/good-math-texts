import sys, time; sys.path.insert(0,'.'); sys.path.insert(0,'./s20')
from gauge import *
from forced_exponent import laws
import itertools
ctx.prec = 2600
pi = arb.pi()
def read(cp, n, fs, detH, M, Ks):
    D, a = density_operator(cp); b = shifted_ops(a, fs); mu = indicial_extra(b, D)
    e = germ_series(b, D, mu, M)
    g0 = (2*pi/to_arb(fs))**(arb(n-1)/2)/(arb.gamma(arb(n-1)/2)*to_arb(detH).sqrt())
    ea = [g0*to_arb(x) for x in e]
    h = len(cp)-1; res = []
    for K in Ks:
        vals = {k: beta_sum(ea, mu, fs, k) for k in range(K, K+h)}
        res.append(run_back(cp, vals, K)[1])
    return res
ell = 3*(arb(2).zeta(arb(1)/3)-arb(2).zeta(arb(2)/3))/9
z3 = arb(3).zeta()
edges = [(0,1),(0,2),(0,3),(1,2),(1,3),(2,3)]
def acyclic(S):
    parent=list(range(4))
    def find(x):
        while parent[x]!=x: x=parent[x]
        return x
    for i in S:
        u,v=edges[i]; ru,rv=find(u),find(v)
        if ru==rv: return False
        parent[ru]=rv
    return True
cob=[[0 if e in S else 1 for e in range(6)] for S in itertools.combinations(range(6),3) if acyclic(S)]
detHf = hessian_det([(2, cob, [arb(1)]*6)], None, 5, 6)
cases = [('three-mark centre', laws['three-mark centre (n=3)'], fmpq(1,9), fmpq(4,27), ell),
         ('four-mark centre', laws['four-mark centre (n=4)'], fmpq(1,16), fmpq(1,32), 7*z3),
         ('five-mark centre', laws['five-mark centre (n=5)'], fmpq(1,25), fmpq(16,3125), None),
         ('fixture (1;0,2)', laws['fixture (1;0,2) (n=6)'], fmpq(1,256), detHf, 6*z3)]
for name, (n, cp), fs, dH, ref in cases:
    t0 = time.time()
    v = read(cp, n, fs, dH, 3000, [260, 360])
    s = 'self |K260-K360| = %s'%abs(v[0]-v[1]).mid().str(3)
    if ref is not None: s += '   |gauge - reference| = %s'%abs(v[1]-ref).mid().str(3)
    print(name, v[1].mid().str(30), s, ' %.1fs'%(time.time()-t0), flush=True)
