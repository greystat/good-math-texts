import sys, time, itertools, pickle; sys.path.insert(0,'.'); sys.path.insert(0,'./s20')
from gauge import *
from forced_exponent import laws
from flint import arb_mat
ctx.prec = 1600
results = {}
def morse_g0(n, fstar, detH):
    return (2*arb.pi()/to_arb(fstar))**(arb(n-1)/2)/(arb.gamma(arb(n-1)/2)*to_arb(detH).sqrt())
def read_exact(name, n, cp, fs, detH, M, Ks):
    D, a = density_operator(cp)
    b = shifted_ops(a, fs)
    mu = indicial_extra(b, D)
    e = germ_series(b, D, mu, M)
    g0 = morse_g0(n, fs, detH)
    ea = [g0*to_arb(x) for x in e]
    h = len(cp)-1
    out = []
    for K in Ks:
        vals = {k: beta_sum(ea, mu, fs, k) for k in range(K, K+h)}
        x = run_back(cp, vals, K)
        out.append((K, x[1], x[2]))
    return D, mu, out
t0 = time.time()
# three-mark centre: det H = 4/27
n, cp = laws['three-mark centre (n=3)']
print('three', read_exact('three', n, cp, fmpq(1,9), fmpq(4,27), 900, [120, 160])[2][1][1].str(50), time.time()-t0, flush=True)
# four-mark centre: det H = 2^3/4^4 = 1/32
n, cp = laws['four-mark centre (n=4)']
D, mu, out = read_exact('four', n, cp, fmpq(1,16), fmpq(8,256), 900, [120, 160])
print('four', mu, out[0][1].str(50), out[1][1].str(50), ' 7*zeta(3) =', (7*arb(3).zeta()).str(50), flush=True)
# fixture: K4 cobases, det H of 2 Cov_Psi at alpha=1
edges = [(0,1),(0,2),(0,3),(1,2),(1,3),(2,3)]
def acyclic(S):
    parent=list(range(4))
    def find(x):
        while parent[x]!=x: x=parent[x]
        return x
    for i in S:
        u,v=edges[i]; ru,rv=find(u),find(v)
        if ru==rv: return False
        parent[ru]=rv
    return True
bases=[S for S in itertools.combinations(range(6),3) if acyclic(S)]
assert len(bases)==16
cob=[[0 if e in S else 1 for e in range(6)] for S in bases]
detHf = hessian_det([(2, cob, [arb(1)]*6)], None, 5, 6)
print('fixture det H =', detHf.str(30), flush=True)
n, cp = laws['fixture (1;0,2) (n=6)']
D, mu, out = read_exact('fixture', n, cp, fmpq(1,256), detHf, 900, [120, 160])
print('fixture mu', mu, out[0][1].str(50), out[1][1].str(50), ' 6 zeta(3) =', (6*arb(3).zeta()).str(50), flush=True)
pickle.dump({'detHf': detHf.str(200)}, open('detH_fixture.pkl','wb'))
print('time', time.time()-t0)
