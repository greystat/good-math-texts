import sys; sys.path.insert(0,'.'); sys.path.insert(0,'./s20')
from flint import arb, acb, ctx, fmpq
from tanhsinh import tanh_sinh
from gauge import *
from forced_exponent import laws
ctx.prec = 400
pi = arb.pi()
# ---- chart values P(k) at real k via gauge-end Beta sums at k+K and the law backwards ----
n, cp = laws['three-mark centre (n=3)']
D, a = density_operator(cp)
fs = fmpq(1,9)
b = shifted_ops(a, fs)
e = germ_series(b, D, fmpq(0), 1500)
g0 = 2*pi/(arb(1)/9*arb(fmpq(4,27)).sqrt())     # (2pi/f*)^{1}/(Gamma(1) sqrt(detH))
ea = [g0*to_arb(x) for x in e]
def ceval(c, k):  # c_i(k) for arb k
    acc = arb(0)
    for co in reversed(c): acc = acc*k + to_arb(fmpq(co))
    return acc
def P_at(k, K=120):
    k = arb(k)
    v1 = beta_sum(ea, fmpq(0), fs, k+K)
    v2 = beta_sum(ea, fmpq(0), fs, k+K+1)
    x = {K: v1, K+1: v2}
    for j in range(K-1, -1, -1):
        kk = k + j
        x[j] = -(ceval(cp[1], kk)*x[j+1] + ceval(cp[2], kk)*x[j+2])/ceval(cp[0], kk)
    return x[0]
print('check P(1) =', P_at(1).str(25))
# ---- torus values T(k) = average over the 2-torus of |1+x+y|^{-2k}, Jensen split over one mark ----
def G(k, R):
    # average over phi of |a+e^{i phi}|^{-2k} with |a|^2 = R
    if R < 1: return acb(R).hypgeom_2f1(acb(k), acb(k), acb(1)).real
    return R**(-k)*acb(1/R).hypgeom_2f1(acb(k), acb(k), acb(1)).real
def T_at(k):
    k = arb(k)
    # T = (1/pi) int_0^pi G(k, 4cos^2(theta/2)) dtheta ; split at theta = 2pi/3
    f = lambda th: G(k, 4*(th/2).cos()**2)
    t1 = tanh_sinh(f, 0, 2*pi/3, levels=8, h0=0.5)
    t2 = tanh_sinh(f, 2*pi/3, pi, levels=8, h0=0.5)
    return (t1+t2)/pi
print('check T(-1) = x_1 = 3:', T_at(-1).str(15), '  T(-2) = 15:', T_at(-2).str(15))
# ---- sign-class solution S(k) = x1(k)/Gamma(k)^2, x1(k) = 2*4^{1-k} int x^{2k-1} K0^2 I0 ----
def S_at(k):
    k = arb(k)
    f = lambda u: (lambda x: x**(2*k-1)*acb(x).bessel_k(0).real**2*acb(x).bessel_i(0).real/(u*u))(1/u - 1 + u*0) if False else None
    def g(x):
        return x**(2*k-1)*acb(x).bessel_k(0).real**2*acb(x).bessel_i(0).real
    # split (0,1) and (1, 40)
    i1 = tanh_sinh(g, 0, 1, levels=8, h0=0.5)
    i2 = tanh_sinh(g, 1, 60, levels=8, h0=0.5)
    return 2*arb(4)**(1-k)*(i1+i2)/arb.gamma(k)**2
print('check S(1) = 2 pi/(3 sqrt3) * u3(1)= 2pi/(3sqrt3) =', S_at(1).str(15), (2*pi/(3*arb(3).sqrt())).str(15))
for k in ['0.25', '0.5', '0.75', '0.6']:
    Pk = P_at(arb(k)); Tk = T_at(arb(k)); Sk = S_at(arb(k))
    M = Pk + 4*pi**2*Tk
    print('k=%s  P=%s  T=%s  S=%s   (P+4pi^2 T)/S = %s'%(k, Pk.str(15), Tk.str(15), Sk.str(15), (M/Sk).str(15)))
