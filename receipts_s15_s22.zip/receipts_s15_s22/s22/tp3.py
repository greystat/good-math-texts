import sys; sys.path.insert(0,'.')
from flint import arb, acb, ctx, arb_mat
from tanhsinh import tanh_sinh
ctx.prec = 600
pi = arb.pi(); s3 = arb(3).sqrt(); l3 = arb(3).log()
th0 = 2*pi/3
def G_arc(k, th):      # theta in (0, th0): R = 4cos^2(th/2) > 1
    R = 4*(th/2).cos()**2
    w = 4*((th0+th)/2).sin()*((th0-th)/2).sin()/R     # 1 - 1/R
    if not (w > 0) or not (w < 1): return arb(0)
    A = arb.gamma(1-2*k)/arb.gamma(1-k)**2; B = arb.gamma(2*k-1)/arb.gamma(k)**2
    F1 = acb(w).hypgeom_2f1(acb(k), acb(k), acb(2*k), abc=True).real
    F2 = acb(w).hypgeom_2f1(acb(1-k), acb(1-k), acb(2-2*k), abc=True).real
    return R**(-k)*(A*F1 + w**(1-2*k)*B*F2)
def G_off(k, th):      # theta in (th0, pi): R < 1
    w = 4*((th+th0)/2).sin()*((th-th0)/2).sin()       # 1 - R
    if not (w > 0): return arb(0)
    if not (w < 1): w = arb(1)-arb(10)**-150
    A = arb.gamma(1-2*k)/arb.gamma(1-k)**2; B = arb.gamma(2*k-1)/arb.gamma(k)**2
    F1 = acb(w).hypgeom_2f1(acb(k), acb(k), acb(2*k), abc=True).real
    F2 = acb(w).hypgeom_2f1(acb(1-k), acb(1-k), acb(2-2*k), abc=True).real
    return A*F1 + w**(1-2*k)*B*F2
def T_at(k):
    t1 = tanh_sinh(lambda th: G_arc(k, th), 0, th0, levels=9, h0=0.5)
    t2 = tanh_sinh(lambda th: G_off(k, th), th0, pi, levels=9, h0=0.5)
    return (t1+t2)/pi
print('check T(0.3) vs earlier 0.889700... at k=0.25:', T_at(arb('0.25')).str(20))
Rres = -1/(pi*s3)
ks = [arb(1) - arb(j)/100 for j in (3,5,7,9,11,13,15,17,19,21,23,25,27,29)]
vals = []
for k in ks:
    v = (T_at(k) - Rres/(k-1))
    vals.append(v.mid())
    print(k.str(4), v.str(30), flush=True)
deg = len(ks)-1
A = arb_mat([[ (k-1)**j for j in range(deg+1)] for k in ks])
b = arb_mat([[v] for v in vals])
sol = A.solve(b)
print('T0 fit =', sol[0,0].mid().str(18), '  predicted 2 log3/(pi sqrt3) =', (2*l3/(pi*s3)).str(18))
print('T1 fit =', sol[1,0].mid().str(15), '  predicted pi/(6 sqrt3) - 2 log^2 3/(pi sqrt3) =', (pi/(6*s3) - 2*l3**2/(pi*s3)).str(15))
