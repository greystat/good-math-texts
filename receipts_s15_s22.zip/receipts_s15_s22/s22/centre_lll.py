import sys, pickle; sys.path.insert(0,'./s20')
from flint import arb, ctx, fmpz_mat, fmpz
ctx.prec=9000
a=[arb(s) for s in pickle.load(open('centre_gauge_340_5000.pkl','rb'))]
b=[arb(s) for s in pickle.load(open('centre_gauge_440_6500.pkl','rb'))]
for i in range(12):
    print('P(%d) |340-440| = %s'%(i+1, abs(a[i]-b[i]).mid().str(3)))
def small_relations(vals, DIG):
    scale=fmpz(10)**DIG
    rows=[]
    for i,v in enumerate(vals):
        row=[0]*len(vals); row[i]=1
        rows.append(row+[(v*scale).mid().floor().unique_fmpz()])
    L=fmpz_mat(rows).lll()
    out=[]
    for i in range(L.nrows()):
        r=[int(L[i,j]) for j in range(len(vals))]
        res=sum((c*v for c,v in zip(r,vals)),arb(0))
        out.append((max(abs(c) for c in r), r, res))
    return out
DIG=int(sys.argv[1])
vals=[arb(1)]+b[:12]
rels=small_relations(vals, DIG)
for h,r,res in sorted(rels, key=lambda z:z[0]):
    print('height %.3g'%h, ' residual', res.mid().str(3))
print('--- prefixes ---')
for m in range(6, 13):
    vals=[arb(1)]+b[:m]
    rels=small_relations(vals, 520)
    good=[(h,r) for h,r,res in rels if abs(res.mid()) < arb(10)**(-600)]
    print('1,P1..P%d: %d genuine relations; heights'%(m, len(good)), ['%.2g'%h for h,r in good])
    if m in (9,10) and good:
        for h,r in good: print('    ', r)
