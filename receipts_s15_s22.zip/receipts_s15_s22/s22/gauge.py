"""Gauge-end reading of a ray from its law: one control flow for every n.
Law: sum_i c_i(k) P(k+i) = 0, c_i given as coefficient lists (fmpq) in k.
Density operator L = sum_i t^i c_i(-1-i-theta), theta = t d/dt  (Prop. 20.17)."""
import sys, math
from flint import fmpq, fmpz, fmpq_poly, fmpq_mat, arb, acb, ctx

def stirling2(r, j):
    # S(r,j)
    if r == j: return 1
    if j == 0 or j > r: return 0
    # recursive table
    S = [[0]*(r+1) for _ in range(r+1)]
    S[0][0] = 1
    for a in range(1, r+1):
        for b in range(1, a+1):
            S[a][b] = b*S[a-1][b] + S[a-1][b-1]
    return S[r][j]

def density_operator(cp):
    """returns D and list a[j] (fmpq_poly in t) with L = sum_j a_j(t) d^j/dt^j"""
    D = max(len(c)-1 for c in cp)
    # precompute stirling table
    S = [[0]*(D+1) for _ in range(D+1)]
    S[0][0] = 1
    for a in range(1, D+1):
        for b in range(1, a+1):
            S[a][b] = b*S[a-1][b] + S[a-1][b-1]
    a = [fmpq_poly([]) for _ in range(D+1)]
    th = fmpq_poly([0, 1])  # placeholder variable x for theta
    for i, c in enumerate(cp):
        # c_i(-1-i-x) as polynomial in x
        q = fmpq_poly([fmpq(-1-i), fmpq(-1)])  # -1-i-x
        poly = fmpq_poly([])
        pw = fmpq_poly([1])
        for m, gm in enumerate(c):
            if gm != 0: poly += fmpq(gm)*pw
            pw *= q
        coeffs = [poly[r] for r in range(poly.degree()+1)] if poly.degree() >= 0 else []
        for r, beta in enumerate(coeffs):
            if beta == 0: continue
            for j in range(r+1):
                if S[r][j]:
                    a[j] += fmpq_poly([0]*(i+j) + [beta*S[r][j]])
    return D, a

def symbol_poly(cp):
    D = max(len(c)-1 for c in cp)
    return fmpq_poly([ (fmpq(c[D]) if len(c) > D else fmpq(0)) for c in cp ]), D

# ---------- local analysis at a point t0, exact (fmpq) ----------
def shifted_ops(a, t0):
    """b_j(s) = (-1)^j a_j(t0 - s), as coefficient lists in s (fmpq), for rational t0"""
    b = []
    for j, aj in enumerate(a):
        # compose aj(t0 - s)
        res = fmpq_poly([])
        pw = fmpq_poly([1])
        lin = fmpq_poly([t0, -1])
        for r in range(aj.degree()+1):
            if aj[r] != 0: res += aj[r]*pw
            pw *= lin
        sign = -1 if j % 2 else 1
        b.append([sign*res[r] for r in range(res.degree()+1)] if res.degree() >= 0 else [])
    return b

def coef(lst, l):
    return lst[l] if 0 <= l < len(lst) else 0

def falling(x, j):
    r = 1
    for i in range(j): r *= (x - i)
    return r

def R(b, D, m, x):
    """R_m(x) = sum_j b_{j, m-D+1+j} x^{falling j}"""
    tot = 0
    for j in range(D+1):
        l = m - D + 1 + j
        if l < 0: continue
        bj = coef(b[j], l)
        if bj != 0: tot += bj*falling(x, j)
    return tot

def indicial_extra(b, D):
    """mu = D-1 - b_{D-1,0}/b_{D,1}"""
    return fmpq(D-1) - fmpq(coef(b[D-1], 0))/fmpq(coef(b[D], 1))

# ---------- generic gauge-end reader (one control flow) ----------
def to_arb(x):
    if isinstance(x, arb): return x
    if isinstance(x, fmpq): return arb(x.p)/arb(x.q)
    return arb(x)

def boundary_deltas(b, D, u):
    """coefficients gamma_k of delta^{(k)} in L(u H), u = list of Taylor coeffs (exact or arb)"""
    # u^{(i)} Taylor coeffs: [s^r] u^{(i)} = u_{r+i} (r+i)^{falling i}
    def deriv_coeffs(i, nmax):
        return [ (u[r+i]*falling(r+i, i) if r+i < len(u) else 0) for r in range(nmax+1)]
    gam = [0]*(D)
    for j in range(1, D+1):
        for p in range(1, j+1):
            cjp = math.comb(j, p)
            di = deriv_coeffs(j-p, p)
            # series of b_j * u^{(j-p)} up to s^{p-1}
            for q in range(0, p):
                # [s^q](b_j u^{(j-p)})
                sq = 0
                for l in range(q+1):
                    bl = coef(b[j], l)
                    if bl != 0 and q-l < len(di): sq += bl*di[q-l]
                k = p-1-q
                gam[k] += cjp*((-1)**q)*math.comb(p-1, q)*math.factorial(q)*sq
    return gam

def germ_series(b, D, mu, M):
    """Taylor/Frobenius coefficients of the extension-by-zero solution at s=0 normalized to leading coeff 1.
    Returns list e with rho ~ sum_m e_m s^{mu+m} (mu integer: the holomorphic solution with u_r = e_{r-mu})."""
    if mu.q != 1:   # non-integer exponent: plain recursion
        e = [fmpq(1)]
        for N in range(1, M+1):
            s = 0
            for jj in range(1, N+1):
                Rv = R(b, D, jj, mu+N-jj)
                if Rv != 0: s += Rv*e[N-jj]
            e.append(-s/R(b, D, 0, mu+N))
        return e
    mu = int(mu)
    free = list(range(mu+1, D-1))         # jets u_{mu+1..D-2}
    def build(fv):
        u = [fmpq(0)]*mu + [fmpq(1)] + [fmpq(x) for x in fv]
        while len(u) < D-1: u.append(fmpq(0))
        for N in range(D-1, mu+M+1):
            s = 0
            for jj in range(1, N+1):
                Rv = R(b, D, jj, N-jj)
                if Rv != 0: s += Rv*u[N-jj]
            u.append(-s/R(b, D, 0, N))
        return u
    if free:
        base = build([0]*len(free))
        g0 = boundary_deltas(b, D, base[:D+2])
        cols = []
        for i in range(len(free)):
            fv = [0]*len(free); fv[i] = 1
            ui = build(fv)
            gi = boundary_deltas(b, D, ui[:D+2])
            cols.append([gi[k]-g0[k] for k in range(D)])
        # solve sum_i x_i cols[i] = -g0 (least squares exact: use all equations, check consistency)
        A = fmpq_mat(D, len(free), [cols[i][k] for k in range(D) for i in range(len(free))])
        bb = fmpq_mat(D, 1, [-g0[k] for k in range(D)])
        # normal equations solve then verify
        At = A.transpose()
        x = (At*A).solve(At*bb)
        resid = A*x - bb
        assert all(resid[k,0] == 0 for k in range(D)), 'inconsistent boundary conditions'
        fv = [x[i,0] for i in range(len(free))]
        u = build(fv)
    else:
        u = build([])
        gb = boundary_deltas(b, D, u[:D+2])
        assert all(g == 0 for g in gb), 'boundary deltas nonzero'
    return u[mu:]   # e_m = u_{mu+m}

def beta_sum(e_arb, mu, fstar, K):
    """P(K) = sum_m e_m fstar^{K+mu+m+1} B(K+1, mu+m+1)"""
    mu_a = to_arb(mu); f = to_arb(fstar)
    B = arb.gamma(arb(K+1))*arb.gamma(mu_a+1)/arb.gamma(arb(K+1)+mu_a+1)
    fp = f**(arb(K+1)+mu_a)
    tot = arb(0)
    for m, em in enumerate(e_arb):
        tot += em*fp*B
        B *= (mu_a+m+1)/(arb(K+1)+mu_a+m+1)
        fp *= f
    return tot

def run_back(cp, vals, K):
    """vals: dict k->arb for k=K..K+h-1; run the law backwards to k=1"""
    h = len(cp)-1
    x = dict(vals)
    for k in range(K-1, 0, -1):
        s = arb(0)
        for i in range(1, h+1):
            ci = peval_q(cp[i], k)
            s += to_arb(ci)*x[k+i]
        c0 = peval_q(cp[0], k)
        x[k] = -s/to_arb(c0)
    return x

def peval_q(c, k):
    acc = fmpq(0)
    for a in reversed(c): acc = acc*k + fmpq(a)
    return acc

def shifted_ops_arb(a, t0):
    """b_j(s) = (-1)^j a_j(t0 - s) with arb t0: coefficient lists in s (arb)"""
    b = []
    for j, aj in enumerate(a):
        deg = aj.degree()
        coeffs = [to_arb(aj[r]) for r in range(deg+1)] if deg >= 0 else []
        # Taylor coefficients of aj at t0: c_l = sum_r coeffs[r] C(r,l) t0^{r-l}
        out = []
        for l in range(deg+1):
            c = arb(0)
            for r in range(l, deg+1):
                if coeffs[r] != 0:
                    c += coeffs[r]*math.comb(r, l)*t0**(r-l)
            out.append(c*((-1)**l))
        sign = -1 if j % 2 else 1
        b.append([sign*c for c in out])
    return b

def germ_series_arb(b, D, mu, M):
    """non-integer mu only; arb arithmetic"""
    mu_a = to_arb(mu)
    e = [arb(1)]
    for N in range(1, M+1):
        s = arb(0)
        for jj in range(1, N+1):
            Rv = R_arb(b, D, jj, mu_a+N-jj)
            if Rv is not None: s += Rv*e[N-jj]
        e.append(-s/R_arb(b, D, 0, mu_a+N))
    return e

def R_arb(b, D, m, x):
    tot = None
    for j in range(D+1):
        l = m - D + 1 + j
        if l < 0 or l >= len(b[j]): continue
        bj = b[j][l]
        term = bj*falling(x, j)
        tot = term if tot is None else tot + term
    return tot

def hessian_det(monos_list, weights_list, chart_drop, nmarks):
    """det of sum over letters (weight factor s_L) of Cov of exponent vectors under weights, chart coords = all but chart_drop.
    monos_list: list of (factor, list of exponent vectors); weights given by alpha (arb list)."""
    from flint import arb_mat
    coords = [e for e in range(nmarks) if e != chart_drop]
    d = len(coords)
    Hm = [[arb(0)]*d for _ in range(d)]
    for factor, monos, alpha in monos_list:
        ws = []
        for v in monos:
            w = arb(1)
            for e in range(nmarks):
                if v[e]: w *= alpha[e]**v[e]
            ws.append(w)
        W = sum(ws, arb(0))
        mean = [sum((ws[i]*v[coords[a]] for i, v in enumerate(monos)), arb(0))/W for a in range(d)]
        for a_ in range(d):
            for b_ in range(d):
                cov = sum((ws[i]*v[coords[a_]]*v[coords[b_]] for i, v in enumerate(monos)), arb(0))/W - mean[a_]*mean[b_]
                Hm[a_][b_] += factor*cov
    return arb_mat(Hm).det()

def germ_series_mid(b, D, mu, M):
    """non-integer mu; midpoint arithmetic (radii dropped each step); accuracy judged by comparing precisions"""
    mu_a = to_arb(mu)
    # precompute which (m, j) contribute
    terms = {}
    maxm = 0
    for m in range(0, 200):
        lst = []
        for j in range(D+1):
            l = m - D + 1 + j
            if 0 <= l < len(b[j]) and b[j][l] != 0:
                lst.append((j, b[j][l].mid()))
        if lst: terms[m] = lst; maxm = m
    def Rm(m, x):
        tot = arb(0)
        for j, bj in terms.get(m, []):
            tot += bj*falling(x, j)
        return tot
    e = [arb(1)]
    for N in range(1, M+1):
        s = arb(0)
        for jj in range(1, min(N, maxm)+1):
            if jj in terms:
                s += Rm(jj, mu_a+N-jj)*e[N-jj]
        e.append((-s/Rm(0, mu_a+N)).mid())
    return e
