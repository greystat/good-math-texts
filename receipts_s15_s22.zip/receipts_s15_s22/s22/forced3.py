import sys, re; sys.path.insert(0,'.'); sys.path.insert(0,'./s20')
from q8_survey_lib import closings3, find_rec_exact
from fmray import law_polys
from forced_exponent import mu_at_roots
from flint import fmpq
rays = []
for line in open('./s20/log_q8.txt'):
    m = re.match(r'\((\d+), (\d+), (\d+)\) s=(\d+) t=(\d+) order (\d)', line)
    if m:
        g = list(map(int, m.groups()))
        rays.append((tuple(g[:3]), g[3], g[4]))
print(len(rays), 'rays with laws')
bad = 0; total = 0; deg = 0
for (mm, s, t) in rays:
    xs = closings3(mm, s, t, 80)
    r = find_rec_exact(xs, maxorder=4, maxdeg=24)
    d, D, polys = r
    cp = law_polys(polys)
    Dd, out = mu_at_roots(cp)
    for t0, mult, mu in out:
        if mult == 1:
            total += 1
            ok = (mu == 0) if isinstance(mu, fmpq) else (abs(mu.real.mid()) < 1e-20 and abs(mu.imag.mid()) < 1e-20)
            if not ok: bad += 1; print('  exception', mm, s, t, t0, mu)
        else: deg += 1
print('simple roots checked:', total, ' exceptions:', bad, ' multiple roots:', deg)
