import sys, time, pickle; sys.path.insert(0,'.'); sys.path.insert(0,'./s20')
from gauge import *
from forced_exponent import laws
ctx.prec = 2400
n, cp = laws['H at (1,1,3,3;3,1) (n=4)']
s19 = arb(19).sqrt(); x0 = (s19-4)/3
alpha = [x0, x0, arb(1), arb(1)]
Kv = [[1,0,1,0],[1,0,0,1],[0,1,1,0],[0,1,0,1],[0,0,1,1]]
Pv = [[1,0,1,0],[1,0,0,1],[0,1,1,0],[0,1,0,1],[1,1,0,0]]
detH = hessian_det([(3, Kv, alpha), (1, Pv, alpha)], None, 3, 4)
print('det H =', detH.str(20), ' (s21: (376096 sqrt19 - 1614848)/151875 =', ((376096*s19-1614848)/151875).str(20), ')')
fs = (7643 + 1064*s19)/1366875
D, a = density_operator(cp)
b = shifted_ops_arb(a, fs)
t0 = time.time()
e = germ_series_mid(b, D, fmpq(1,2), 2500)
g0 = (2*arb.pi()/fs)**(arb(3)/2)/(arb.gamma(arb(3)/2)*detH.sqrt())
ea = [g0*x for x in e]
h = len(cp)-1
for K in (160, 220):
    vals = {k: beta_sum(ea, fmpq(1,2), fs, k) for k in range(K, K+h)}
    x = run_back(cp, vals, K)
    print('K', K, 'P(1) =', x[1].mid().str(62), ' time %.1f'%(time.time()-t0), flush=True)
print('share side (s20, Ex 20.7(iii)): 0.48830319489526888388541464396010900874354031922042897524562')
