import sys, time, itertools, pickle; sys.path.insert(0,'.'); sys.path.insert(0,'./s20')
exec(open('read_N2.py').read().split("which = sys.argv[1]")[0])
ctx.prec = int(sys.argv[1]); M = int(sys.argv[2]); K = int(sys.argv[3])
t0=time.time()
trip = list(itertools.combinations(range(6),3))
basesN = [S for S in trip if set(S) != {0,1,2}]
cobN = [S for S in trip if set(S) != {3,4,5}]
Kv = [[1 if e in S else 0 for e in range(6)] for S in basesN]
Pv = [[1 if e in S else 0 for e in range(6)] for S in cobN]
alpha1 = [arb(1)]*6
detH = hessian_det([(1, Kv, alpha1), (1, Pv, alpha1)], None, 5, 6); fs = fmpq(1,361)
n, cp = laws['N centre, order 12 (n=6)']
D, a = density_operator(cp)
b = shifted_ops_arb(a, to_arb(fs))
e = germ_series_mid(b, D, fmpq(3,2), M)
g0 = morse_g0(6, fs, detH)
ea = [g0*xx for xx in e]
h = len(cp)-1
vals = {k: beta_sum(ea, fmpq(3,2), fs, k) for k in range(K, K+h)}
xv = run_back(cp, vals, K)
Ps = [xv[k].mid() for k in range(1,13)]
pickle.dump([p.str(1000) for p in Ps], open('centre_gauge_%d_%d.pkl'%(K,M),'wb'))
print('K',K,'M',M,'P(1)=',Ps[0].str(40),' time %.1f'%(time.time()-t0))
