import sys, itertools; sys.path.insert(0,'.'); sys.path.insert(0,'./s20')
from fmray import *
from closings_drv import run_closings2, letters_mons
from gauge import *
from pslq import intrel, show
from flint import arb, ctx
ctx.prec = 3000
bases = [sum(1<<e for e in c) for c in itertools.combinations(range(4),2)]
K, Ps = letters_mons(bases, 4)
from math import factorial
def xj(j):
    tot = 0
    for p in range(j+1):
        for q in range(j+1-p):
            r = j-p-q
            tot += factorial(2*j)//(factorial(p)**2*factorial(q)**2*factorial(r)**2)
    return tot
xs = [xj(j) for j in range(121)]
print('closings', xs[:6])
from findrec_mod import rank_mod
for d in range(1,5):
    found=None
    for Dg in range(1,30):
        if (d+1)*(Dg+1)+5 > len(xs)-d: break
        r,u,e = rank_mod(xs, d, Dg)
        if r < u: found=Dg; break
    if found:
        polys, nul = guess_rec([fmpz(x) for x in xs], d, found)
        if polys: print('order', d, 'degree', found); break
cp = law_polys(polys)
sym, deg = symbol(cp)
print('symbol', fmpq_poly(sym).factor())
kap = walls(bases, 4, [fmpq(1)]*4, 0, 2); Cor = corner(kap, 4); print('Cor', Cor, 'min wall', min(kap[S] for S in range(1,15)))
# gauge end: alpha*=1, f* = 1/6^2 = 1/36, det H = 2 Cov_Psi at 1 (chart drops mark 3)
Pv = [[1 if (T>>e)&1 else 0 for e in range(4)] for T in bases]   # cobases of U24 are complements of pairs = pairs
detH = hessian_det([(2, Pv, [arb(1)]*4)], None, 3, 4)
fs = fmpq(1,36)
D, a = density_operator(cp); b = shifted_ops(a, fs); mu = indicial_extra(b, D); print('D', D, 'mu', mu, 'det H', detH.str(15))
e = germ_series(b, D, mu, 1500)
g0 = (2*arb.pi()/to_arb(fs))**(arb(3)/2)/(arb.gamma(arb(3)/2)*detH.sqrt())
ea = [g0*to_arb(x) for x in e]
h = len(cp)-1
vals = {k: beta_sum(ea, mu, fs, k) for k in range(250, 250+h)}
x = run_back(cp, vals, 250)
P1 = x[1]
print('P_{U24}(1;0,2) =', P1.str(50))
ell = 3*(arb(2).zeta(arb(1)/3)-arb(2).zeta(arb(2)/3))/9
print("|P1 - ell| =", abs(P1-ell).mid().str(4))
rel, size, res = intrel([P1, arb(1), ell], 300)
print('relation with 1, ell:', size, show(rel, ['P1','1','ell']))
