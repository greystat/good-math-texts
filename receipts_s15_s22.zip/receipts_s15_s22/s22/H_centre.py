import sys, time, pickle; sys.path.insert(0,'.'); sys.path.insert(0,'./s20')
from gauge import *
from forced_exponent import laws
from pslq import intrel, show
ctx.prec = 4000
n, cp = laws['H centre (n=4)']
# H marks (a,b,2,3) -> 0,1,2,3; bases {a2,a3,b2,b3,23}, cobases {a2,a3,b2,b3,ab}
Kv = [[1,0,1,0],[1,0,0,1],[0,1,1,0],[0,1,0,1],[0,0,1,1]]
Pv = [[1,0,1,0],[1,0,0,1],[0,1,1,0],[0,1,0,1],[1,1,0,0]]
alpha1 = [arb(1)]*4
detH = hessian_det([(1, Kv, alpha1), (1, Pv, alpha1)], None, 3, 4)
print('H centre det H =', detH.str(20), flush=True)
fs = fmpq(1,25)
D, a = density_operator(cp)
b = shifted_ops(a, fs)
mu = indicial_extra(b, D); print('D', D, 'mu', mu)
t0 = time.time()
e = germ_series(b, D, mu, 2500)
g0 = (2*arb.pi()/to_arb(fs))**(arb(n-1)/2)/(arb.gamma(arb(n-1)/2)*detH.sqrt())
ea = [g0*to_arb(x) for x in e]
h = len(cp)-1
out = {}
for K in (300, 380):
    vals = {k: beta_sum(ea, mu, fs, k) for k in range(K, K+h)}
    x = run_back(cp, vals, K)
    out[K] = [x[k] for k in range(1, h+2)]
    print('K', K, 'P_H(1) =', x[1].str(45), ' time %.1f'%(time.time()-t0), flush=True)
print('|diff K300-K380| P(1):', abs(out[300][0]-out[380][0]).mid().str(4))
print('ref s15: 4.096236998337882850055553228351268637634670896')
P = out[380]
ell = 3*(arb(2).zeta(arb(1)/3)-arb(2).zeta(arb(2)/3))/9
pi = arb.pi(); z3 = arb(3).zeta()
for names, vals, DIG in [(['1','P1','P2','ell'], [arb(1),P[0],P[1],ell], 380),
                         (['1','P1','P2','ell','z3','pi2'], [arb(1),P[0],P[1],ell,z3,pi**2], 380),
                         (['1','P1','P2','P3'], [arb(1),P[0],P[1],P[2]], 380)]:
    rel,size,res = intrel(vals, DIG)
    print(names, 'height %.3g'%size, show(rel,names) if size < 1e40 else '', ' residual', res.mid().str(3))
pickle.dump([p.str(1000) for p in P], open('H_centre_vals.pkl','wb'))
