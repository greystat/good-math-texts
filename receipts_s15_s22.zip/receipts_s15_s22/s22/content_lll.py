import sys, pickle; sys.path.insert(0,'./s20')
from flint import arb, ctx, fmpz_mat, fmpz
from pslq import intrel, show
ctx.prec=2400
lean=[arb(s) for s in pickle.load(open('lean_gauge_420_6000.pkl','rb'))]
cen=[arb(s) for s in pickle.load(open('centre_gauge_440_6500.pkl','rb'))]
pi=arb.pi(); l2=arb(2).log(); l3=arb(3).log(); l7=arb(7).log(); z3=arb(3).zeta(); s3=arb(3).sqrt(); s7=arb(7).sqrt()
ell=3*(arb(2).zeta(arb(1)/3)-arb(2).zeta(arb(2)/3))/9
def Lchi(d):
    D=abs(d)
    def kron(n):
        def jac(a,n):
            a%=n; r=1
            while a:
                while a%2==0:
                    a//=2
                    if n%8 in (3,5): r=-r
                a,n=n,a
                if a%4==3 and n%4==3: r=-r
                a%=n
            return r if n==1 else 0
        r=1; m=n
        while m%2==0:
            m//=2
            if d%2==0: return 0
            if d%8 in (3,5): r=-r
        return r*jac(d,m) if m>1 else r
    return sum((kron(a)*arb(2).zeta(arb(a)/D) for a in range(1,D+1) if kron(a)),arb(0))/arb(D)**2
consts_lean = [z3,pi**2,ell,pi**2*l2,pi**2*l3,ell*l3,ell*l2,Lchi(-7),Lchi(-8),Lchi(-84),Lchi(-24),pi/s3,l2,l3]
s21=arb(21).sqrt(); L=((5+s21)/2).log()
consts_lean_B = [s21,z3,s21*z3,pi**2,s21*pi**2,L,s21*L,pi**2*L,s21*pi**2*L,L**2,s21*L**2,L**3,s21*L**3,l2,l3,l7]
consts_cen = [z3,pi**2,ell,pi**2*l2,pi**2*l3,pi**2*l7,ell*l2,ell*l3,Lchi(-4),Lchi(-7),Lchi(-8),pi*s7,l2,l3,l7]
for name, masters, consts, DIG in [('lean A', lean[:3], consts_lean, 470), ('lean B', lean[:3], consts_lean_B, 470), ('centre', cen[:8], consts_cen, 520)]:
    vals=[arb(1)]+masters+consts
    rel,size,res=intrel(vals,DIG)
    print('%s: %d numbers at %d digits, smallest relation height %.3g (generic %.3g), involves masters: %s'%(name, len(vals), DIG, size, 10**(DIG/len(vals)), any(rel[1+i]!=0 for i in range(len(masters)))))
names = ['1','P1','P2','P3','z3','pi2','ell','pi2l2','pi2l3','ell l3','ell l2','L-7','L-8','L-84','L-24','pi/s3','l2','l3']
vals=[arb(1)]+lean[:3]+consts_lean
for DIG in (200, 300, 470):
    rel,size,res=intrel(vals,DIG)
    print(DIG, '%.4g'%size, show(rel,names), ' residual', res.mid().str(4))
