"""
Receipts for notebook section 19: the reading of the three-mark centre ray, set as an examination.
python-flint only.  Run:  python exam_s19.py
Every number printed here appears in section 19.  Parts 1-9 are the solution (exact arithmetic);
part 10 is the independent check (ball arithmetic, one-variable integrals), which is not part of the solution.
"""
import flint
from flint import fmpq, fmpz_mat, fmpq_mat, arb, acb, ctx
from math import factorial as F

R = flint.fmpq_mpoly_ctx.get(('a1', 'a2', 'a3', 'k'), 'deglex')
a1, a2, a3, k = R.gens()
A = [a1, a2, a3]
e1 = a1 + a2 + a3
e2 = a1 * a2 + a1 * a3 + a2 * a3
e3 = a1 * a2 * a3
ZERO = R.from_dict({})

def exchange(P, e):
    """image under the exchange of the marks 1 and e (e = 0, 1, 2)"""
    if e == 0:
        return P
    g = list(R.gens()); g[0], g[e] = g[e], g[0]
    return P.compose(*g)

def to_e(P, d=7):
    """a symmetric polynomial of degree d in a1,a2,a3 (no k) in the basis e1^i e2^j e3^l"""
    basis = [(d - 2 * j - 3 * l, j, l) for l in range(d // 3 + 1) for j in range((d - 3 * l) // 2 + 1)]
    polys = [e1 ** i * e2 ** j * e3 ** l for (i, j, l) in basis]
    mons = sorted(set(tuple(m) for q in polys + [P] for m in q.monoms()))
    M = fmpq_mat(len(mons), len(basis)); b = fmpq_mat(len(mons), 1)
    for c, q in enumerate(polys):
        dq = dict(zip([tuple(m) for m in q.monoms()], q.coeffs()))
        for r, m in enumerate(mons): M[r, c] = dq.get(m, 0)
    dP = dict(zip([tuple(m) for m in P.monoms()], P.coeffs()))
    for r, m in enumerate(mons): b[r, 0] = dP.get(m, 0)
    x = (M.transpose() * M).solve(M.transpose() * b)
    assert sum((x[c, 0] * polys[c] for c in range(len(basis))), ZERO) == P
    return ' + '.join(f'({x[c,0]}) e1^{i} e2^{j} e3^{l}' for c, (i, j, l) in enumerate(basis) if x[c, 0] != 0)

print('=' * 100)
print('1. The stride f = e3/(e1 e2) and the sum of squares')
sos = a1 * (a2 - a3) ** 2 + a2 * (a3 - a1) ** 2 + a3 * (a1 - a2) ** 2
print('   e1 e2 - 9 e3 == a1(a2-a3)^2 + a2(a3-a1)^2 + a3(a1-a2)^2 :', e1 * e2 - 9 * e3 == sos)

print('=' * 100)
print('2. Closings x_j = [alpha^0] (e1 e2/e3)^j = sum over a1+a2+a3=j of (j!/(a1! a2! a3!))^2')
J = 16
x = [sum((F(j) // (F(p) * F(q) * F(j - p - q))) ** 2 for p in range(j + 1) for q in range(j + 1 - p)) for j in range(J)]
print('  ', x)
# least recurrence of order 2 and degree 2: sum_i p_i(j) x_{j+i} = 0
rows = [[x[j + i] * j ** d for i in range(3) for d in range(3)] for j in range(J - 2)]
N, nul = fmpz_mat(rows).nullspace()
v = [int(N[r, 0]) for r in range(9)]
from math import gcd
g = 0
for t in v: g = gcd(g, t)
v = [t // g for t in v]
if v[8] < 0: v = [-t for t in v]
print(f'   order 2, degree 2: {J-2} equations, 9 unknowns, nullity {nul}')
p = [flint.fmpq_poly(v[3 * i:3 * i + 3]) for i in range(3)]
print('   p_0(j) =', p[0], ';  p_1(j) =', p[1], ';  p_2(j) =', p[2])
c_law = [p[2 - i](flint.fmpq_poly([-2, -1])) for i in range(3)]
print('   reflected, c_i(k) = p_{2-i}(-k-2):  c_0 =', c_law[0], ';  c_1 =', c_law[1], ';  c_2 =', c_law[2])

print('=' * 100)
print('3. The certificate of Thm 35.3: g_e = N_e/(e1^2 e2), g_e the exchange image of g_1')
N1 = -a1 ** 2 * (k * a1 * (a2 + a3) + (2 + 3 * k) * (a2 ** 2 + a3 ** 2) - (1 - k) * a2 * a3)
print('   N_1 =', N1)
Ns = [exchange(N1, e) for e in range(3)]
def Dpart(P, e):   # e1^3 e2^2 * D_e (P/(e1^2 e2)),  D_e = alpha_e d/d alpha_e
    return e1 * e2 * A[e] * P.derivative(e) - P * (2 * A[e] * e2 + A[e] * (e1 - A[e]) * e1)
def Cpart(P, e):   # e1^3 e2^2 * (P/(e1^2 e2)) * c_e,   c_e = 1 - alpha_e/e1 - alpha_e(e1-alpha_e)/e2
    return P * (e1 * e2 - A[e] * e2 - A[e] * (e1 - A[e]) * e1)
rhs = sum((Dpart(Ns[e], e) + k * Cpart(Ns[e], e) for e in range(3)), ZERO)
lhs = k ** 2 * e1 ** 3 * e2 ** 2 - (10 * k ** 2 + 10 * k + 3) * e1 ** 2 * e2 * e3 + 9 * (k + 1) ** 2 * e1 * e3 ** 2
print('   e1^3 e2^2 [k^2 - (10k^2+10k+3) f + 9(k+1)^2 f^2] == e1^3 e2^2 sum_e (D_e g_e + k c_e g_e) :', lhs == rhs)
# split by powers of k
N0 = [exchange(-a1 ** 2 * (2 * (a2 ** 2 + a3 ** 2) - a2 * a3), e) for e in range(3)]
N1k = [exchange(-a1 ** 2 * (a1 * (a2 + a3) + 3 * (a2 ** 2 + a3 ** 2) + a2 * a3), e) for e in range(3)]
assert all(Ns[e] == N0[e] + k * N1k[e] for e in range(3))
print('   k^2:  sum_e e1^3e2^2 c_e g1_e   =', to_e(sum((Cpart(N1k[e], e) for e in range(3)), ZERO)))
print('   k^1:  sum_e e1^3e2^2 D_e g1_e   =', to_e(sum((Dpart(N1k[e], e) for e in range(3)), ZERO)))
print('         sum_e e1^3e2^2 c_e g0_e   =', to_e(sum((Cpart(N0[e], e) for e in range(3)), ZERO)))
print('   k^0:  sum_e e1^3e2^2 D_e g0_e   =', to_e(sum((Dpart(N0[e], e) for e in range(3)), ZERO)))
# the ansatz: symmetric in the two other marks, degree 4, linear in k
mons4 = [(i, j, 4 - i - j) for i in range(4, -1, -1) for j in range(4 - i, -1, -1)]
orbits, seen = [], set()
for m in mons4:
    if m not in seen:
        o = sorted({m, (m[0], m[2], m[1])}); seen |= set(o); orbits.append(o)
cols = []
for o in orbits:
    for pk in range(2):
        tot = ZERO
        for m in o:
            mono = R.term(exp_vec=list(m) + [pk], coeff=1)
            for e in range(3):
                me = exchange(mono, e)
                tot += Dpart(me, e) + k * Cpart(me, e)
        cols.append(dict(zip([tuple(t) for t in tot.monoms()], tot.coeffs())))
keys = sorted(set(t for c in cols for t in c) | set(tuple(t) for t in lhs.monoms()))
M = fmpq_mat(len(keys), len(cols))
for j, c in enumerate(cols):
    for i, t in enumerate(keys):
        if t in c: M[i, j] = c[t]
print(f'   symmetric ansatz: {len(cols)} unknowns, {len(keys)} equations, rank {M.rank()}; '
      f'the solutions differ by the {len(cols) - M.rank()} symmetric numerators (one insertion added to every mark)')
# boundedness: every monomial of N_e occurs in e1^2 e2
E = R.from_dict({}) + e1 ** 2 * e2
supp = set(tuple(m[:3]) for m in E.monoms())
ok = all(tuple(m[:3]) in supp for e in range(3) for m in Ns[e].monoms())
print('   every monomial of every N_e occurs in e1^2 e2 (positive coefficients):', ok)
# grader's spot check at alpha = (1,2,4), k = 1/3
pt = [fmpq(1), fmpq(2), fmpq(4), fmpq(1, 3)]
E1, E2 = e1(*pt), e2(*pt)
print('   spot check at alpha=(1,2,4), k=1/3:  left side =', lhs(*pt) / (E1 ** 3 * E2 ** 2),
      '  right side =', rhs(*pt) / (E1 ** 3 * E2 ** 2))
gvals = [(Ns[e] / 1)(*pt) / (E1 ** 2 * E2) for e in range(3)]
print('   g_1, g_2, g_3 there =', gvals)

print('=' * 100)
print('4. Native values: the symbol and the signs')
sym = flint.fmpq_poly([c.coeffs()[2] if c.degree() == 2 else 0 for c in c_law])
print('   symbol =', sym, '=', sym.factor())
for eta in [(1, 1, 1), (-1, 1, 1), (1, -1, 1), (-1, -1, 1)]:
    Kv = sum(eta); Pv = eta[0] * eta[1] + eta[0] * eta[2] + eta[1] * eta[2]; e3v = eta[0] * eta[1] * eta[2]
    # Thm 35.12(ii): Hessian of -log f at the sign = 2 (covariances of the indicators X_1, X_2 under P_eta({e}) = eta_e/K(eta))
    Pe = [fmpq(t, Kv) for t in eta]
    cov = [[(Pe[i] if i == j else 0) - Pe[i] * Pe[j] for j in range(2)] for i in range(2)]
    detH = 4 * (cov[0][0] * cov[1][1] - cov[0][1] * cov[1][0])
    print(f'   sign {eta}: K = {Kv}, f = e3/(K Psi) = {fmpq(e3v, Kv * Pv)}, det Hessian = {detH}')

print('=' * 100)
print('5. The corner: Cor = sum over the 3! orders of prod kappa^{-1}, all walls 1;  6 - 3 P(1) + 9 P(2) = 0')
from itertools import permutations, combinations
walls = {}
for s in range(1, 3):
    for S in combinations(range(3), s):
        S = set(S)
        d = min(len({e} & S) for e in range(3))           # bases are the singletons
        rmax = max(len({e} & S) for e in range(3))
        walls[tuple(sorted(S))] = len(S) - d - (len(S) - rmax)   # m(S) - s d(S) - t(|S| - r(S)), m = s = t = 1
print('   walls kappa_{1,S}:', walls)
Cor = sum(fmpq(1) / (walls[tuple(sorted(pi[1:]))] * walls[tuple(sorted(pi[2:]))]) for pi in permutations(range(3)))
print('   Cor =', Cor)

print('=' * 100)
print('6. The rational solutions: P(K) = c(K) l + r(K)')
c = {1: fmpq(1), 2: fmpq(1, 3)}
r = {1: fmpq(0), 2: fmpq(-2, 3)}
KMAX = 16
for kk in range(1, KMAX - 1):
    c[kk + 2] = ((10 * kk * kk + 10 * kk + 3) * c[kk + 1] - kk * kk * c[kk]) / (9 * (kk + 1) ** 2)
    r[kk + 2] = ((10 * kk * kk + 10 * kk + 3) * r[kk + 1] - kk * kk * r[kk]) / (9 * (kk + 1) ** 2)
aK = {K: -r[K] / c[K] for K in c}
bK = {K: (r[K - 1] - 9 * r[K]) / (9 * c[K] - c[K - 1]) for K in c if K >= 2}
sK = {K: -r[K] / (c[K] - fmpq(1, 9 ** (K - 1))) for K in c if K >= 2 and c[K] > fmpq(1, 9 ** (K - 1))}
for K in range(1, 11):
    line = f'   K={K:2d}  c={str(c[K]):>20s}  r={str(r[K]):>26s}  a_K={str(aK[K]):>28s}'
    if K >= 2:
        line += f'  b_K={str(bK[K]):>28s}  b_K-a_K={float(bK[K]-aK[K]):.4e}  simple={float(sK[K]-aK[K]):.4e}'
    print(line)
print(f'   for K <= {KMAX}: c(K) >= 3^(1-K) > 0 and 9c(K) >= 3c(K-1):',
      all(c[K] >= fmpq(1, 3 ** (K - 1)) for K in c) and all(9 * c[K] >= 3 * c[K - 1] for K in c if K >= 2))
print(f'   for K <= {KMAX}: 9^(K-1) c(K) = x_(K-1), the closings:', all(c[K] * 9 ** (K - 1) == x[K - 1] for K in c))
print(f'   for k < {KMAX}: frame c(k) r(k+1) - c(k+1) r(k) = -(2/3) 9^(1-k)/k^2 (Prop 35.8):',
      all(c[K] * r[K + 1] - c[K + 1] * r[K] == fmpq(-2, 3) * fmpq(1, 9 ** (K - 1)) / (K * K) for K in range(1, KMAX)))
print(f'   for 2 <= K <= {KMAX}: b_K - a_K = 2 9^(2-K)/(3 (K-1)^2 c(K)(9c(K)-c(K-1))) = 2 9^(K-1)/(3 (K-1)^2 x_(K-1)(x_(K-1)-x_(K-2))) <= 1/(K-1)^2:',
      all(bK[K] - aK[K] == fmpq(2, 3) / fmpq(9 ** (K - 2)) / ((K - 1) ** 2 * c[K] * (9 * c[K] - c[K - 1]))
          == fmpq(2, 3) * fmpq(9 ** (K - 1)) / ((K - 1) ** 2 * x[K - 1] * (x[K - 1] - x[K - 2])) for K in range(2, KMAX + 1))
      and all(bK[K] - aK[K] <= fmpq(1, (K - 1) ** 2) for K in range(2, KMAX + 1)))
print('   the unproved bound P(K) <= 9^(-K) l at K=9 would give the width', float(-r[9] / (c[9] - fmpq(1, 9 ** 9)) - aK[9]))
print('   a_9 - a_8 =', float(aK[9] - aK[8]))
print('=' * 100)
print('7. The answer')
q = aK[9]
print('   q = a_9 =', q, ' ;  0 < l - q < b_9 - a_9 =', bK[9] - aK[9], '<', 1.11e-7, ':', bK[9] - aK[9] < fmpq(111, 10 ** 9))
print('   a_9 > 2343907/10^6 :', aK[9] > fmpq(2343907, 10 ** 6), ';  b_9 - 2343907/10^6 =', float(bK[9] - fmpq(2343907, 10 ** 6)))
print('   a_8 is certified by b_9:  b_9 - a_8 =', float(bK[9] - aK[8]))

print('=' * 100)
print('8. Check, not part of the solution: l by two independent one-variable integrals in ball arithmetic')
ctx.prec = 200
tol = 2 ** -150
T = 240
def lo(t, an):
    xx = (-t).exp(); return (2 * (1 + xx).log() + t) / (1 + xx + xx * xx) * xx
def hi(t, an):
    xx = t.exp(); return (2 * (1 + xx).log() - t) / (1 + xx + xx * xx) * xx
chart = (acb.integral(lo, 0, T, rel_tol=tol) + acb.integral(hi, 0, T, rel_tol=tol)).real
print('   chart, one variable integrated: int_0^oo log((1+x)^2/x)/(1+x+x^2) dx =', chart.str(40))
def share(kk):
    def g(u, an):
        G = 2 * (2 * u).bessel_k(0); return (u * u) ** (kk - 1) * G ** 3 * 2 * u
    def g0(t, an):
        u = (-t).exp(); G = 2 * (2 * u).bessel_k(0); return (u * u) ** (kk - 1) * G ** 3 * 2 * u * u
    return (acb.integral(g0, 0, T, rel_tol=tol) + acb.integral(g, 1, 30, rel_tol=tol)).real / arb(kk).gamma() ** 2
P = {kk: share(kk) for kk in (1, 2, 9)}
print('   share side, Gamma(k)^2 P(k) = int_0^oo y^(k-1) G_0(1,y)^3 dy:  P(1) =', P[1].str(40))
print('   P(2) - (P(1)-2)/3 =', (P[2] - (P[1] - 2) / 3).str(5))
qa = lambda t: arb(t.p) / arb(t.q)
print('   P(9) =', P[9].str(20), ';  c(9) l + r(9) =', (qa(c[9]) * chart + qa(r[9])).str(20))
print('   l - a_8 =', (chart - qa(aK[8])).str(6), ';  l - a_9 =', (chart - qa(aK[9])).str(6), ';  b_9 - l =', (qa(bK[9]) - chart).str(6))
print('   9^K P(K)/l, with P(K) = c(K) l + r(K):', [(K, (arb(9) ** K * (qa(c[K]) * chart + qa(r[K])) / chart).str(6)) for K in (6, 7, 8, 9)])
print('   (the cut-off integrals: the tails beyond t = 240 and u = 30 are below 1e-70)')
