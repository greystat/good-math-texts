"""
Receipts for notebook section 18: the reading of a ray through the origin.
python-flint only (exact integers/rationals, ball arithmetic).  Run:  python ray_reading_s18.py
Every step is a verb of Procedure 18.6:
  closings x_j = [alpha^0](1/f)^j  ->  least recurrence  ->  reflected law  ->  corner  ->  positive selection
  ->  integer relations.
"""
import math
from math import comb, factorial as F
from flint import fmpz, fmpq, fmpq_mat, fmpz_mat, fmpq_poly, arb, ctx

# ---------------------------------------------------------------- the verbs
def recurrence_of_order(x, h, dmax=30, margin=8):
    """least degree D of a recurrence sum_i p_i(j) x_{j+i} = 0 of order h (exact nullspace over Z)."""
    J = len(x)
    for D in range(dmax + 1):
        nunk, neq = (h + 1) * (D + 1), J - h
        if neq < nunk + margin:
            return None
        rows = [[int(x[j + i]) * j ** e for i in range(h + 1) for e in range(D + 1)] for j in range(neq)]
        N, nul = fmpz_mat(rows).nullspace()
        if nul >= 1:
            v = [int(N[k, 0]) for k in range(nunk)]
            g = 0
            for c in v: g = math.gcd(g, c)
            v = [c // g for c in v]
            return D, [v[i * (D + 1):(i + 1) * (D + 1)] for i in range(h + 1)]
    return None

def reflect(p):
    """Corollary 18.2: c_i(k) = p_{h-i}(-k-h)."""
    h = len(p) - 1
    return [fmpq_poly(p[h - i])(fmpq_poly([-h, -1])) for i in range(h + 1)]

def symbol(c):
    D = max(ci.degree() for ci in c)
    return fmpq_poly([ci.coeffs()[D] if ci.degree() == D else 0 for ci in c])

def corner(bases, n, m, s, t):
    """Cor = sum over orders of prod kappa_{1,U}^{-1} (Proposition 18.1); m a list of masses."""
    from itertools import permutations
    d = lambda S: min(len(T & S) for T in bases)
    r = lambda S: max(len(T & S) for T in bases)
    kap = lambda S: sum(m[e] for e in S) - s * d(S) - t * (len(S) - r(S))
    tot = fmpq(0)
    for pi in permutations(range(n)):
        pr = fmpq(1)
        for k in range(1, n):
            pr /= kap(frozenset(pi[k:]))
        tot += pr
    return tot

def coordinates(c, n, cor, steps):
    """P(k) on the basis (1, P(1), ..., P(h-1)), the corner (Corollary 18.2) fixing P(h)."""
    h = len(c) - 1
    lead = c[0].coeffs()[n - 1]
    c0 = [ci(0) for ci in c]
    vec = {}
    for i in range(1, h):
        v = [fmpq(0)] * h; v[i] = fmpq(1); vec[i] = v
    v = [fmpq(0)] * h; v[0] = -lead * cor / c0[h]
    for i in range(1, h):
        for k in range(h): v[k] -= c0[i] * vec[i][k] / c0[h]
    vec[h] = v
    for s_ in range(1, steps):
        ch = c[h](s_)
        v = [fmpq(0)] * h
        for i in range(h):
            ci = c[i](s_)
            for k in range(h): v[k] -= ci * vec[s_ + i][k] / ch
        vec[s_ + h] = v
    return vec

def select(vec, h, K):
    """Theorem 18.5(iv): P(K+l) = 0 for l < h-1 (the values are exponentially smaller than the coordinates)."""
    A = fmpq_mat([[vec[K + l][i] for i in range(1, h)] for l in range(h - 1)])
    b = fmpq_mat([[-vec[K + l][0]] for l in range(h - 1)])
    sol = A.solve(b)
    return [sol[i, 0] for i in range(h - 1)]

def relation(vals, digits):
    """integer relation by LLL; returns (coefficients, residual)."""
    N = len(vals); sc = arb(10) ** digits
    rows = []
    for i, v in enumerate(vals):
        row = [0] * N; row[i] = 1
        row.append(int((v * sc).mid().floor().unique_fmpz()))
        rows.append(row)
    M = fmpz_mat(rows).lll()
    best = min((([int(M[i, j]) for j in range(N)]) for i in range(N)), key=lambda r: max(abs(x) for x in r))
    return best, sum(arb(a) * v for a, v in zip(best, vals))

q2a = lambda x: arb(x.p) / arb(x.q)

# ---------------------------------------------------------------- closings of the lists of the entry
def closings_banana(n, m, s, t, J):
    """[n] choose 1 in the direction (m 1; s, t): x_j = sum_{|b|=jt} (js)!(jt)!/prod(b_f!(b_f+nu)!), nu=j(m-t)."""
    out = []
    for j in range(J):
        A, B, nu = j * s, j * t, j * (m - t)
        lo = max(0, -nu); tot = fmpq(0)
        def rec(k, rem, acc):
            nonlocal tot
            if k == n - 1:
                if rem >= lo: tot += acc / (F(rem) * F(rem + nu))
                return
            for b in range(lo, rem + 1):
                rec(k + 1, rem - b, acc / (F(b) * F(b + nu)))
        rec(0, B, fmpq(1))
        out.append(tot * F(A) * F(B))
    return out

def closings_H(J, s, t, m):
    """H = triangle with one mark doubled, K = AB + a2 a3, Psi = AB + aa ab, uniform masses m:
       x_j = [alpha^{jm 1}] K^{js} Psi^{jt}."""
    out = []
    for j in range(J):
        S, T, M = j * s, j * t, j * m
        tot = 0
        for u in range(S + 1):
            q = S - u; v = T - q
            if 0 <= v <= T and M - q >= 0 and u + v == 2 * (M - q):
                tot += comb(S, u) * comb(T, v) * comb(u + v, M - q) ** 2
        out.append(fmpq(tot))
    return out

def read_ray(name, xs, h, n, cor, K):
    D, p = recurrence_of_order(xs, h)
    c = reflect(p)
    print(f'{name}: law of order {h}, degree {D}; symbol {symbol(c).factor()}; Cor = {cor}')
    vec = coordinates(c, n, cor, K + h + 2)
    return [q2a(v) for v in select(vec, h, K)]

if __name__ == '__main__':
    ctx.prec = 1400
    B3 = [frozenset([e]) for e in range(3)]
    BH = [frozenset(s) for s in [(0, 2), (0, 3), (1, 2), (1, 3), (2, 3)]]   # marks a=0, b=1, 2, 3
    # three marks: centre and the lean (2 1; 4, 1)
    Pth, = read_ray('[3]1 centre', closings_banana(3, 1, 1, 1, 40), 2, 3, corner(B3, 3, [1]*3, 1, 1), 500)
    lean, = read_ray('[3]1 lean (2;4,1)', closings_banana(3, 2, 4, 1, 60), 2, 3, corner(B3, 3, [2]*3, 4, 1), 220)
    print('  54 P_lean = 11 - 4 Pth ? ', relation([arb(1), Pth, lean], 150))
    # H: centre and the lean (2 1; 3, 1)
    P1, P2, P3 = read_ray('H centre', closings_H(160, 1, 1, 1), 4, 4, corner(BH, 4, [1]*4, 1, 1), 700)
    print('  P_H(1) =', P1.str(40), '  P_H(2) =', P2.str(40))
    print('  second corner:', relation([arb(1), P1, P2, P3], 250))
    L1, L2, L3 = read_ray('H lean (2;3,1)', closings_H(200, 3, 1, 2), 4, 4, corner(BH, 4, [2]*4, 3, 1), 520)
    print('  one content, two rays:', relation([arb(1), P1, P2, L1], 250))
