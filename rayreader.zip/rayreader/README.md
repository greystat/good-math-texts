# rayreader

Reads a ray from its list and its direction: the masters, the one-step matrix over Q(k), the law of
`<1>_k` over Z, and the value `<1>_1 = P(m; s, t)`, with nothing guessed and every stage saved as it
finishes. It is the procedure of notebook section 23.5 (Procedure 23.12), steps (1) to (5).

```
python3 rayreader.py LIST "m_1 ... m_n ; s t" [--digits D] [--workers W] [--run DIR]
```

## Requirements

- Python 3.9 or later, with `python-flint` (0.6 or later; tested with 0.9.0), `numpy` and `mpmath`:
  `pip install python-flint numpy mpmath`
- A C compiler on the path as `cc` (or named by the `CC` environment variable). The eliminator
  `rr/c/elimr.c` is compiled on first use, next to its source or, if that folder is not writable, in the
  system's temporary folder.

## Examples

```
python3 rayreader.py three "1 1 1 ; 1 1"                    # the three-mark centre, about a second
python3 rayreader.py N "1 1 1 1 1 1 ; 1 1" --digits 50      # N at its centre, about ten seconds
python3 rayreader.py three "1/2 1 3/2 ; 1 1"               # rational masses, read through an origin
python3 rayreader.py V "1 1 1 1 1 1 1 1 ; 0 2" --workers 8  # V at its lean, the long one (see Cost)
python3 tests/known_rays.py                                 # the eight rays with independently known values
python3 tests/rational_masses.py                            # rational masses against a quadrature
python3 tests/corner.py V "1 1 1 1 1 1 1 1 ; 0 2" runs/<run directory> 300   # the corner relation
python3 tests/check_run.py runs/<run directory>             # re-check a finished run at fresh random points
```

From Python, `rayreader.read_ray('V', '1 1 1 1 1 1 1 1 ; 0 2', digits=30, workers=8)` does the same and
returns a dict with the value (a ball), its estimated error, `f*`, `det H`, the law's order and degree, and
the values at the first strengths.

`LIST` is one of `three`, `banana4`, `banana5`, `H`, `MK4`, `U25`, `N`, `V`, `prism`, or a JSON file:
`{"n": 4, "bases": [[0, 2], [0, 3], [1, 2], [1, 3], [2, 3]], "name": "H"}` (marks numbered from 0), or
`{"graph": {"vertices": 4, "edges": [[0, 1], [0, 2], ...]}}` for the list of spanning trees of a graph.

The direction is `m_1 ... m_n ; s t`: masses, then the two letter exponents. It must lie on the balance wall,
`sum(m) = s r + t (n - r)`, and strictly inside every wall, `s r(S) + t r*(S) - m(S) > 0` for every nonempty
proper `S`; the program says which wall fails otherwise. The masses may be rational (`3/2`): the direction is
then read as an integral direction next to it, strictly inside the walls, with an origin of degree zero, at
strength 1 (Remark 23.13).

Options:

| option | meaning |
|---|---|
| `--digits D` | digits of the value (default 30) |
| `--workers W` | processes for the primes of stages 3 and 4 (default: all processors) |
| `--run DIR` | run directory (default `runs/<list>_<hash of the ray>`) |
| `--strength K` | read `<1>_K` instead of `<1>_1` (a rational K) |
| `--origin "u ; a b"` | an origin of degree zero added to the one rational masses imply |
| `--stop-after S` | stop after `walls`, `masters`, `matrix`, `law` or `value` |

## Stages

Each stage writes its result to the run directory and is skipped when the result is there. Stopping the
program (Ctrl-C, a closed laptop, a killed job) loses at most the strengths in progress: run the same
command again and it continues. Inside stages 3 and 4 every prime is saved as it finishes, and inside a
prime every few strengths.

1. **walls**: the walls of the direction, the automorphisms of the list that fix the masses (and the
   origin), Cremona at the centre.
2. **masters** (`masters.pkl`, `system.pkl`): boxes `(T; A, B)` in order of size; in each, the relations of
   the box (letter identities, and mark relations of the seeds), one elimination modulo `2^61 - 1` at a
   random strength, and for each master degree `D = T-1, ..., 0` whether every target `L b` reduces to the
   free Laurent insertions of wall degree at most `D`. The first that does is kept. This search stops
   (Theorem 23.10); in every case met it stops at `T = 2` or `3`.
3. **matrix** (`B_exact.pkl`): the relations the targets need are found and the rest dropped
   (`system_reduced.*`); then eliminations modulo random 62-bit primes at random strengths. On the first
   prime every entry of `B` is reconstructed as a rational function of `k`, which gives the common
   denominator `Qc` of all entries and the degree of the numerators over it; on every further prime `Qc`
   and all the numerators at once, from that degree plus 6 strengths. Over Q: Chinese remaindering and
   rational reconstruction with one common denominator, until two rounds agree. Accepted when it agrees
   with an elimination of the whole box at a prime and a strength drawn at random. Entries are stored as
   (numerator, `Qc`), coefficients lowest degree first.
4. **law** (`law_exact.pkl`, `law.txt`): the first dependence of the rows `e_0 B(k-i+1) ... B(k)`, modulo
   primes at consecutive points, reconstructed over Q, made integral and primitive, checked at a random
   prime and point. `law.txt` lists `c_0, ..., c_h` (coefficients lowest degree first) with
   `sum_j c_j(k) <1>_(k+j) = 0`.
5. **value** (`value.txt`): the gauge end (Theorem 21.1): the native gauge on the orthant and its Hessian, the
   germ of the density at `f*`, Beta sums at a large strength, the law run back to strength 1; in ball
   arithmetic, from two starting strengths, the precision doubled until both agree to the digits asked.

`log.txt` records every step with times.

## What is certain, and what is checked

- Every relation is an identity with integer coefficients; every computation modulo a prime is exact.
- The random strengths and primes give the answer over Q(k) except on the zeros of finitely many nonzero
  polynomials; the final checks of stages 3 and 4 are at a prime and a point drawn from the operating
  system's random source, so a wrong matrix or law passes only by landing on such a zero.
  `tests/check_run.py` repeats them at as many fresh points as asked.
- `tests/corner.py` checks a reading against a number the program never uses: the corner of the ray
  (notebook, Corollary 18.2), `[k^(n-1)] c_0 Cor + sum_(i>=1) c_i(0) P(i) = 0`.
- The value: every rounding is in ball arithmetic. The truncation of the germ series and of the Beta sums
  is controlled by the size of the last terms, and the error printed is the difference of two starting
  strengths: an estimate, not a proved bound.

## Cost

Measured on one machine with two processors (`tests/known_rays.py`, 30 digits asked):

| ray | masters | law (order, degree) | seconds | distance to the known value |
|---|---|---|---|---|
| three-mark centre | 2 | (2, 2) | < 1 | 1.8e-67 |
| banana on four marks, centre | 2 | (2, 3) | < 1 | 1.7e-65 |
| M(K4) at (1; 0, 2) | 2 | (2, 5) | < 1 | 2.6e-63 |
| banana on five marks, centre | 3 | (3, 4) | < 1 | 3.8e-59 |
| H at its centre | 4 | (4, 7) | < 1 | 9.3e-66 |
| H at ((1,1,3,3); 3, 1) | 4 | (4, 25) | 2 | 1.4e-61 |
| N at its lean | 7 | (6, 24) | 1 | 1.5e-63 |
| N at its centre | 15 | (11, 52) | 5 | 1.3e-63 |
| three marks at (1/2, 1, 3/2; 1, 1) | 4 | (3, 4) | < 1 | 3.8e-66 (quadrature) |
| V at its lean | 60 | (24, 377) | 2715 | none known; tropical 7.124 +- 0.009 |

V at its lean reads `<1>_1 = 7.12823937562968675472229135353893457156078898940720766490704...` (60 digits
asked). Of its 45 minutes, 2 go to the masters, 39 to B over Q(k) (178 strengths on the first prime, 94 on
each of 8 more), 3 to the law (63 primes) and seconds to the value; the corner relation with Cor = 300
holds to 73 digits (`tests/corner.py`).

What grows with the ray:

- stage 3: one elimination per strength (V at its lean: 19581 relations, 4.5 s per strength on one core);
  about `deg P + deg Q` strengths for the first prime and the numerators' degree over the common
  denominator plus 6 for the rest (V: 178, then 94); the number of primes is about the height of the
  coefficients (numerators and common denominator together) divided by 62 bits.
- stage 4: no elimination; per prime about `2D + 2h` points, each one product of an `h x mu` and a
  `mu x mu` matrix modulo the prime; the number of primes is about the height of the law's coefficients
  and of their common denominator together, over 62 bits (V: coefficients of 753 digits, 63 primes).
- stage 5: precision about 3.3 bits per digit, plus what running the law back loses; the law's
  coefficients are evaluated exactly at the integer strengths it is run through.

More workers divide stages 3 and 4 by their number, up to the number of primes in a round.

## Files

```
rayreader.py        the driver
rr/lists.py         lists: named ones, JSON, graphs
rr/ray.py           walls, wall degree, the box's lattice points, symmetries, rational masses split
rr/boxenum.py       lattice points of a box
rr/system.py        the relations of a box with integer coefficients c0 + c1 k
rr/masters.py       the search for masters (Theorem 23.10)
rr/elim.py          the eliminator's wrapper; rr/c/elimr.c the eliminator
rr/matrix.py        stage 3
rr/law.py           stage 4
rr/gauge.py         stage 5
rr/arith.py         primes, Chinese remaindering, rational reconstruction
tests/known_rays.py the eight rays with known values
tests/rational_masses.py  a direction with rational masses against a one-dimensional quadrature
tests/corner.py     the corner relation of a reading against an independently computed corner
tests/check_run.py  re-check of a finished run at fresh random points
```
