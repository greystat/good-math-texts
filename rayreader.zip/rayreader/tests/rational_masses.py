"""A direction with rational masses, read through an origin, against a quadrature that does not use the
program: the three-mark list at (1/2, 1, 3/2; 1, 1).  On the chart alpha_3 = 1, with alpha_1 = u^2 and
alpha_2 = v,
    P = int_0^oo int_0^oo 2 du dv / ((u^2 + v + 1)(u^2 + v + u^2 v)),
and the integral over v is ln(bA/c)/(bA - c) for 1/((v + A)(b v + c)), A = b = 1 + u^2, c = u^2:
    P = int_0^oo 2 ln((1 + u^2)^2 / u^2) / (1 + u^2 + u^4) du.

Usage: python3 tests/rational_masses.py [RUNROOT]"""
import os, sys, time
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))
import mpmath as mp
import rayreader

if __name__ == '__main__':
    root = sys.argv[1] if len(sys.argv) > 1 else os.path.join('runs', 'rational')
    res = rayreader.main(['three', '1/2 1 3/2 ; 1 1', '--digits', '30', '--run', os.path.join(root, 'three_half')])
    mp.mp.dps = 80
    t0 = time.time()
    f = lambda u: 2 * mp.log((1 + u * u) ** 2 / (u * u)) / (1 + u * u + u ** 4)
    Q = mp.quad(f, [0, 0.5, 1, 2, mp.inf])
    v = mp.mpf(res['value'].mid().str(70, radius=False))
    print(f'program    {mp.nstr(v, 25)}')
    print(f'quadrature {mp.nstr(Q, 25)}   ({time.time() - t0:.0f}s)')
    print(f'difference {mp.nstr(abs(v - Q), 3)}')
