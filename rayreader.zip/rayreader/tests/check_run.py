"""An independent re-check of a finished run: the one-step matrix against eliminations of the whole box, and
the law against the matrix, each at primes and strengths drawn at random (none of them used by the run).

    python3 tests/check_run.py RUN_DIR [N]

N is the number of random points for each check (default 3)."""
import os, pickle, random, sys, time
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))
import flint
from rr.elim import run_cp
from rr.matrix import evaluate_exact_mod
from rr.law import BModQ, random_prime


def load(run, name):
    with open(os.path.join(run, name), 'rb') as fh:
        return pickle.load(fh)


def main(run, N=3):
    rng = random.SystemRandom()
    full = load(run, 'system.pkl'); B = load(run, 'B_exact.pkl')['B']; mu = len(full['masters'])
    ok = True
    for i in range(N):
        t0 = time.time()
        q = random_prime(rng); k = rng.randrange(10 ** 6, q)
        rr = run_cp(full['rels'], full['cols'], full['targets'], [k], q, run)[0]
        same = all(set(nf) <= set(full['masters']) for nf in rr['nf']) and \
            [[nf.get(x, 0) for x in full['masters']] for nf in rr['nf']] == evaluate_exact_mod(B, k, q, mu)
        ok &= same
        print(f'matrix: the whole box at q = {q}, k = {k}: {"agrees" if same else "DISAGREES"} ({time.time() - t0:.0f}s)')
    lawpath = os.path.join(run, 'law_exact.pkl')
    if os.path.exists(lawpath):
        law = load(run, 'law_exact.pkl'); h = law['order']; c = law['c']
        for i in range(N):
            q = random_prime(rng); x = rng.randrange(10 ** 6, q)
            Bm = BModQ(B, mu, q)
            # sum_j c_j(x) <1>_(x+j) = 0 with <1>_(x+j) = w_(h-j)(x+h) V(x+h)
            R = flint.nmod_mat(mu, mu, [1 if a == b else 0 for a in range(mu) for b in range(mu)], q)
            rows = [[1] + [0] * (mu - 1)]
            for i2 in range(1, h + 1):
                R = Bm(x + h - i2 + 1) * R
                rows.append([int(R[0, l]) for l in range(mu)])
            tot = [0] * mu
            for j in range(h + 1):
                cj = 0
                for a in reversed(c[j]):
                    cj = (cj * x + a) % q
                tot = [(t + cj * w) % q for t, w in zip(tot, rows[h - j])]
            same = not any(tot); ok &= same
            print(f'law: at q = {q}, k = {x}: {"holds" if same else "FAILS"}')
    print('all checks pass' if ok else 'A CHECK FAILED')
    return ok


if __name__ == '__main__':
    sys.exit(0 if main(sys.argv[1], int(sys.argv[2]) if len(sys.argv) > 2 else 3) else 1)
