"""The corner relation as a check of a reading against a number the program never sees: if
sum_i c_i(k) P(k+i) = 0 identically, then c_0 vanishes to order n-1 at k = 0 and

    [k^(n-1)] c_0 * Cor + sum_(i >= 1) c_i(0) P(i) = 0

(notebook, Corollary 18.2), with Cor the corner of the ray, a count computed independently.  The law is the
run's, the values P(1), ..., P(h) are read by the gauge end.

    python3 tests/corner.py LIST "m_1 ... m_n ; s t" RUN_DIR COR [DIGITS]

Examples: V "1 1 1 1 1 1 1 1 ; 0 2" with Cor = 300, MK4 "1 1 1 1 1 1 ; 0 2" with Cor = 84."""
import os, pickle, sys
from fractions import Fraction as Fr
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))
from flint import arb
import rayreader
from rr.lists import load_list

if __name__ == '__main__':
    lst, d, run, cor = sys.argv[1], sys.argv[2], sys.argv[3], int(sys.argv[4])
    digits = int(sys.argv[5]) if len(sys.argv) > 5 else 30
    n = load_list(lst).n
    res = rayreader.main([lst, d, '--digits', str(digits), '--run', run])
    with open(os.path.join(run, 'law_exact.pkl'), 'rb') as fh:
        c = pickle.load(fh)['c']
    low = [x for x in c[0][:n - 1]]
    print(f'c_0 vanishes to order {n - 1} at 0: {all(x == 0 for x in low)}')
    P = res['values']
    terms = [arb(c[0][n - 1]) * cor] + [arb(c[i][0]) * P[Fr(1) + i - 1] for i in range(1, len(c))]
    tot = sum(terms, arb(0)); big = max(abs(t).mid() for t in terms)
    print(f'[k^{n - 1}] c_0 * {cor} + sum_i c_i(0) P(i) = {tot.mid().str(5, radius=False)}, '
          f'the largest term {arb(big).str(5, radius=False)}')
