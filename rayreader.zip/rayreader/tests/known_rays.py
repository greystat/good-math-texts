"""The driver on every ray whose value is known independently (notebook sections 18-22): the value read by
the driver against the reference.  Usage: python3 tests/known_rays.py [RUNROOT] [DIGITS]"""
import os, sys, time
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))
from flint import arb, ctx
import rayreader

ctx.prec = 600
ell = 3 * (arb(2).zeta(arb(1) / 3) - arb(2).zeta(arb(2) / 3)) / 9
z3 = arb(3).zeta()
CASES = [
    ('three', '1 1 1 ; 1 1', ell, 'three-mark centre, ell (section 19)'),
    ('banana4', '1 1 1 1 ; 1 1', 7 * z3, 'four-mark centre, 7 zeta(3)'),
    ('MK4', '1 1 1 1 1 1 ; 0 2', 6 * z3, 'the fixture, 6 zeta(3) (Theorem 20.15)'),
    ('banana5', '1 1 1 1 1 ; 1 1', arb('39.9455880119962456989440284984239958918497829247698595723666'),
     'five-mark centre (section 22, share side)'),
    ('H', '1 1 1 1 ; 1 1', arb('4.09623699833788285005555322835126863763467089557118852982109538511623755787'),
     'H at its centre (section 22, gauge end)'),
    ('H', '1 1 3 3 ; 3 1', arb('0.4883031948952688838854146439601090087435403192204289752456214192664684'),
     'H on the ray of Example 20.12 (a native value on the slit)'),
    ('N', '1 1 1 1 1 1 ; 0 2', arb('4.75680256375822944340803728605708480533517181028275669568732032161931988849'),
     'N at its lean (section 22, gauge end)'),
    ('N', '1 1 1 1 1 1 ; 1 1', arb('4.57891247888240480638020373022855744921869580872760320929687575903522507540'),
     'N at its centre (Proposition 20.36(vi))'),
]

if __name__ == '__main__':
    root = sys.argv[1] if len(sys.argv) > 1 else os.path.join('runs', 'known')
    digits = int(sys.argv[2]) if len(sys.argv) > 2 else 30
    rows = []
    for name, d, ref, label in CASES:
        t0 = time.time()
        run = os.path.join(root, f'{name}_{d.replace(" ", "").replace(";", "_")}')
        res = rayreader.main([name, d, '--digits', str(digits), '--run', run, '--workers', '2'])
        diff = abs(res['value'] - ref)
        rows.append((label, res['value'].mid().str(25, radius=False), diff.mid().str(3, radius=False),
                     res['order'], res['degree'], time.time() - t0))
    print()
    print(f'{"ray":62s} {"value":28s} {"|value - reference|":20s} law (order, degree)  seconds')
    for label, v, dd, h, D, sec in rows:
        print(f'{label:62s} {v:28s} {dd:20s} ({h}, {D}) {sec:10.0f}')
