#!/usr/bin/env python3
"""Read a ray: from a list and a direction strictly inside its walls to its law and its value.

    python3 rayreader.py LIST "m_1 ... m_n ; s t" [--digits D] [--workers W] [--run DIR]

LIST is a name (three, banana4, banana5, H, MK4, U25, N, V, prism) or a JSON file with "n" and "bases"
(or "graph" with "vertices" and "edges").  The direction may have rational m_i (e.g. 64/65); it is then
split into an integral direction strictly inside the walls and an origin of degree zero, and the period
is <1>_1 on that ray.  Stages, each saved in the run directory and skipped when its result is there:

  1. walls       every wall h(S) = s r(S) + t r*(S) - m(S) positive
  2. masters     boxes searched by size until every target L b reduces to the masters (Theorem 23.10)
  3. matrix      the one-step matrix B over Q(k): the relations the targets need, eliminations modulo
                 primes at random strengths, every entry over one common denominator, Chinese
                 remaindering, checked against the whole box at a random prime and strength
  4. law         the law of <1>_k over Z from B (cyclic vector), checked at a random prime and point
  5. value       the gauge end (Theorem 21.1): native gauge, Hessian, germ of the density, Beta sums at a
                 large strength, the law run backwards to the strength wanted; two starts for the error

Options:
  --digits D        digits of the value (default 30)
  --strength K      the strength to read, a rational (default 1)
  --origin "u_1 ... u_n ; a b"   an origin of degree zero added to the one the direction implies
  --workers W       processes for the primes of stages 3 and 4 (default: the number of cores)
  --run DIR         run directory (default runs/<list>_<hash of the ray>)
  --stop-after S    one of walls, masters, matrix, law, value
"""
import argparse, hashlib, json, os, pickle, sys, time
from fractions import Fraction as Fr

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from rr.lists import load_list
from rr.ray import Ray, split_direction, parse_vector
from rr.masters import find_masters
from rr.matrix import one_step_matrix
from rr.law import law_over_Q
from rr import gauge

STAGES = ['walls', 'masters', 'matrix', 'law', 'value']


def parse_dir(text, n):
    if ';' not in text:
        raise ValueError('write the direction as "m_1 ... m_n ; s t"')
    left, right = text.split(';')
    m = parse_vector(left); st = parse_vector(right)
    if len(m) != n or len(st) != 2:
        raise ValueError(f'the direction needs {n} masses and two letter exponents')
    return m, st[0], st[1]


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('list'); ap.add_argument('direction')
    ap.add_argument('--digits', type=int, default=30)
    ap.add_argument('--strength', default='1')
    ap.add_argument('--origin', default=None)
    ap.add_argument('--workers', type=int, default=os.cpu_count() or 1)
    ap.add_argument('--run', default=None)
    ap.add_argument('--stop-after', default='value', choices=STAGES)
    args = ap.parse_args(argv)

    lst = load_list(args.list)
    m, s, t = parse_dir(args.direction, lst.n)
    mp_, s_, t_, u_extra = split_direction(lst, m, s, t)
    u0 = list(u_extra); a0 = Fr(0); b0 = Fr(0)
    if args.origin:
        um, ab = parse_dir(args.origin, lst.n)
        u0 = [x + y for x, y in zip(u0, um)]; a0, b0 = ab
    k_target = Fr(args.strength)
    spec = {'list': lst.to_json(), 'direction': [str(x) for x in m] + [str(s), str(t)],
            'origin': [str(x) for x in u0] + [str(a0), str(b0)], 'strength': str(k_target)}
    tag = hashlib.sha1(json.dumps(spec, sort_keys=True).encode()).hexdigest()[:8]
    run = args.run or os.path.join('runs', f'{lst.name.replace(" ", "_").replace("/", "_")}_{tag}')
    os.makedirs(run, exist_ok=True)
    spath = os.path.join(run, 'run.json')
    if os.path.exists(spath):
        with open(spath) as fh:
            old = json.load(fh)
        if old != spec:
            raise SystemExit(f'{run} holds a different ray; choose another --run directory')
    else:
        with open(spath, 'w') as fh:
            json.dump(spec, fh, indent=1)
    logf = open(os.path.join(run, 'log.txt'), 'a')
    T0 = time.time()
    def log(msg):
        line = f'[{time.strftime("%H:%M:%S")} +{time.time() - T0:7.0f}s] {msg}'
        print(line, flush=True); logf.write(line + '\n'); logf.flush()

    # 1. walls
    ray = Ray(lst, mp_, s_, t_, origin=(u0, a0, b0))
    log(f'ray: {ray.describe()}')
    if any(x != 0 for x in u_extra):
        log(f'   the direction ({" ".join(map(str, m))}; {s}, {t}) is read as the ray of ({" ".join(map(str, mp_))}; '
            f'{s_}, {t_}) with origin u0 = ({" ".join(map(str, u_extra))})')
    if args.stop_after == 'walls':
        return
    # 2. masters
    mpath = os.path.join(run, 'masters.pkl'); syspath = os.path.join(run, 'system.pkl')
    if os.path.exists(mpath) and os.path.exists(syspath):
        with open(mpath, 'rb') as fh:
            mres = pickle.load(fh)
        log(f'masters: from the checkpoint, box {mres["box"]}, {len(mres["masters"])} masters')
    else:
        log('masters: searching boxes')
        found = find_masters(ray, log)
        mres = {'box': found['box'], 'masters': found['masters'], 'info': found['info']}
        with open(syspath + '.tmp', 'wb') as fh:
            pickle.dump({'rels': found['rels'], 'cols': found['cols'], 'masters': found['masters'],
                         'targets': found['targets']}, fh, protocol=pickle.HIGHEST_PROTOCOL)
        os.replace(syspath + '.tmp', syspath)
        with open(mpath, 'wb') as fh:
            pickle.dump(mres, fh)
    mu = len(mres['masters'])
    if args.stop_after == 'masters':
        return
    # 3. the one-step matrix over Q(k)
    log(f'matrix: B over Q(k) on {mu} masters, {args.workers} worker(s)')
    B = one_step_matrix(syspath, run, args.workers, log)
    if args.stop_after == 'matrix':
        return
    # 4. the law
    log('law: the law of <1> over Z')
    law = law_over_Q(B, mu, run, log, workers=args.workers)
    if args.stop_after == 'law':
        return
    # 5. the value
    log(f'value: the gauge end at the strength {k_target}, {args.digits} digits')
    res = gauge.read(lst, ray.m, ray.s, ray.t, (ray.u0, ray.a0, ray.b0), law['c'], k_target, args.digits, log)
    val = res['value'].mid().str(args.digits + 2, radius=False)
    err = res['error'].mid().str(3, radius=False)
    log(f'VALUE <1>_{k_target} = {val}   (two starting strengths differ by {err})')
    with open(os.path.join(run, 'value.txt'), 'w') as fh:
        fh.write(f'list {lst.name}; direction ({" ".join(map(str, m))}; {s}, {t}); strength {k_target}\n')
        fh.write(f'value {val}\nestimated error {err}\n')
        fh.write(f'law: order {law["order"]}, degree {max(len(c) for c in law["c"]) - 1}; masters {mu}, box {mres["box"]}\n')
        fh.write(f'f* = {res["fstar"]}\ndet H = {res["detH"]}\n')
    log(f'done in {time.time() - T0:.0f}s; results in {run}')
    return res


def read_ray(lst, direction, digits=30, workers=None, run=None, strength='1', origin=None):
    """the same as the command line, from Python: read_ray('V', '1 1 1 1 1 1 1 1 ; 0 2', 30) returns a dict
    with the value (an arb ball), its estimated error, f*, det H, the law's order and degree, and the values
    at the first strengths"""
    argv = [lst, direction, '--digits', str(digits), '--strength', str(strength)]
    if workers:
        argv += ['--workers', str(workers)]
    if run:
        argv += ['--run', run]
    if origin:
        argv += ['--origin', origin]
    return main(argv)


if __name__ == '__main__':
    main()
