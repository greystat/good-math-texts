"""The law of <1>_k (Theorem 23.5(iii)): the first dependence among the rows w_i(x) = e_0 B(x-i+1) ... B(x),
for which <1>_(x-i) = w_i(x) . V(x).  A dependence sum_i d_i(x) w_i(x) = 0 is the law
    sum_j c_j(k) <1>_(k+j) = 0,   c_j(k) = d_(h-j)(k + h).
Modulo each prime: B from its exact form over one common denominator, evaluated at consecutive points in
batches; the rows carried along by w_i(x) = w_(i-1)(x-1) B(x); the dependence normalized at d_h at each point;
each ratio d_i/d_h reconstructed as a rational function (interpolation on a subproduct tree, then the
Euclidean remainder sequence, checked on held-out points); denominators cleared.  Over Q: Chinese remaindering
and rational reconstruction until two rounds agree, primes in parallel, each saved as it finishes; then a
check at a prime and a point drawn at random, and integer coefficients made primitive."""
import os, pickle, random, time
from math import gcd, lcm
import flint
from .arith import prime_number, vec_ratrec, to_mod, coeffs, is_prime

SEED_PRIMES = 211


def _save(obj, path):
    tmp = path + '.tmp'
    with open(tmp, 'wb') as fh:
        pickle.dump(obj, fh, protocol=pickle.HIGHEST_PROTOCOL)
    os.replace(tmp, path)


def _load(path):
    with open(path, 'rb') as fh:
        return pickle.load(fh)


class BModQ:
    """the exact one-step matrix reduced modulo q over a common denominator, evaluated in batches"""
    def __init__(self, Bq, mu, q):
        self.mu, self.q = mu, q
        ent = {}
        for x, (P, Q) in Bq.items():
            Pm = [to_mod(c, q) for c in P]; Qm = [to_mod(c, q) for c in Q]
            if any(c is None for c in Pm + Qm) or Qm[-1] == 0:
                raise ZeroDivisionError('unlucky prime')
            ent[x] = (flint.nmod_poly(Pm, q), flint.nmod_poly(Qm, q))
        Qc = flint.nmod_poly([1], q)
        for P, Q in ent.values():
            Qc = Qc * (Q // Qc.gcd(Q))
        self.Qc = Qc
        num = [ent[(j, l)][0] * (Qc // ent[(j, l)][1]) for j in range(mu) for l in range(mu)]
        self.d = max(max(P.degree() for P in num), 0)
        self.C = flint.nmod_mat([[int(c) for c in P.coeffs()] + [0] * (self.d + 1 - len(P.coeffs())) for P in num], q)
        self.cache = {}

    def fill(self, xs):
        """B(x) for the points xs not yet cached (None at a pole)"""
        q, d, mu = self.q, self.d, self.mu
        xs = [x % q for x in xs if x % q not in self.cache]
        for i in range(0, len(xs), 256):
            part = xs[i:i + 256]
            X = flint.nmod_mat(d + 1, len(part), [pow(x, e, q) for e in range(d + 1) for x in part], q)
            R = (self.C * X).transpose().tolist()
            for x, row in zip(part, R):
                den = int(self.Qc(x))
                if den == 0:
                    self.cache[x] = None
                    continue
                self.cache[x] = flint.nmod_mat(mu, mu, row, q) * pow(den, -1, q)

    def __call__(self, x):
        x %= self.q
        if x not in self.cache:
            self.fill([x])
        M = self.cache[x]
        if M is None:
            raise ZeroDivisionError('pole')
        return M


def order_at(Bm, x):
    mu, q = Bm.mu, Bm.q
    R = flint.nmod_mat(mu, mu, [1 if i == j else 0 for i in range(mu) for j in range(mu)], q)
    rows = [[1] + [0] * (mu - 1)]
    for i in range(1, mu + 1):
        R = Bm(x - i + 1) * R
        rows.append([int(R[0, j]) for j in range(mu)])
        if flint.nmod_mat(rows, q).rank() < len(rows):
            return i
    return None


def dependence_mat(Wfull, h, q):
    """the dependence d_0..d_h (d_h = 1) of the h+1 rows of Wfull, or None"""
    N, nul = Wfull.transpose().nullspace()
    if nul != 1:
        return None
    d = [int(N[i, 0]) for i in range(h + 1)]
    if d[h] == 0:
        return None
    inv = pow(d[h], -1, q)
    return [c * inv % q for c in d]


# ---- rational functions through consecutive points ----

class Consecutive:
    """the points x0, x0 + 1, ..., x0 + n - 1 modulo q: subproduct tree and Lagrange weights"""
    def __init__(self, x0, n, q):
        self.x0, self.n, self.q = x0 % q, n, q
        level = [flint.nmod_poly([(-(x0 + i)) % q, 1], q) for i in range(n)]
        self.tree = [level]
        while len(level) > 1:
            level = [level[i] * level[i + 1] if i + 1 < len(level) else level[i] for i in range(0, len(level), 2)]
            self.tree.append(level)
        fact = [1] * n
        for i in range(1, n):
            fact[i] = fact[i - 1] * i % q
        inv = [pow(f, -1, q) for f in fact]
        # 1 / prod_{j != i} (i - j) = (-1)^(n-1-i) / (i! (n-1-i)!)
        self.w = [(-1) ** (n - 1 - i) * inv[i] * inv[n - 1 - i] % q for i in range(n)]

    def interpolate(self, ys):
        q = self.q
        vals = [flint.nmod_poly([y * w % q], q) for y, w in zip(ys, self.w)]
        for lev in range(len(self.tree) - 1):
            polys = self.tree[lev]; new = []
            for i in range(0, len(vals), 2):
                if i + 1 < len(vals):
                    new.append(vals[i] * polys[i + 1] + vals[i + 1] * polys[i])
                else:
                    new.append(vals[i])
            vals = new
        return vals[0]

    def vanishing(self):
        return self.tree[-1][0]


def ratfun_consecutive(pts, ys, holdout=3):
    """P/Q (Q monic) through (x0 + i, ys[i]) modulo q, the last `holdout` points held out; or None"""
    q = pts.q; n = pts.n
    if all(y == 0 for y in ys):
        return flint.nmod_poly([], q), flint.nmod_poly([1], q)
    F = pts.interpolate(ys[:n])
    r0, r1 = pts.vanishing(), F
    t0, t1 = flint.nmod_poly([], q), flint.nmod_poly([1], q)
    best = None; bestdeg = -1
    while not r1.is_zero():
        qq, rr = divmod(r0, r1)
        dq = qq.degree()
        if dq > bestdeg and r1.degree() + t1.degree() < n:
            bestdeg = dq; best = (r1, t1)
        r0, r1 = r1, rr
        t0, t1 = t1, t0 - qq * t1
    if best is None:
        return None
    P, Q = best
    if Q.is_zero():
        return None
    inv = pow(int(Q.leading_coefficient()), -1, q); P = P * inv; Q = Q * inv
    g = P.gcd(Q)
    if g.degree() > 0:
        P = P // g; Q = Q // g
        inv = pow(int(Q.leading_coefficient()), -1, q); P = P * inv; Q = Q * inv
    if P.degree() + Q.degree() + 2 > n - 1:
        return None
    for i, y in enumerate(ys):
        x = pts.x0 + i
        qx = int(Q(x))
        if qx == 0 or int(P(x)) != y * qx % q:
            return None
    return P, Q


def law_mod(Bq, mu, q, npts, x0, h=None, holdout=3):
    """(h, [d_0 .. d_h]) modulo q (d_h monic), d None if npts consecutive points do not determine it.
    The rows are carried as W(x) = [w_0(x); ..; w_(h-1)(x)] = S W(x-1) B(x) + E, with S the shift down by
    one row and E the row e_0 on top; after h steps from any start every row is right."""
    Bm = BModQ(Bq, mu, q)
    if h is None:
        h = order_at(Bm, x0 + 7)
    S = flint.nmod_mat(h, h, [1 if i == j + 1 else 0 for i in range(h) for j in range(h)], q)
    E = flint.nmod_mat(h, mu, [1 if (i == 0 and j == 0) else 0 for i in range(h) for j in range(mu)], q)
    S1 = flint.nmod_mat(h + 1, h, [1 if i == j + 1 else 0 for i in range(h + 1) for j in range(h)], q)
    E1 = flint.nmod_mat(h + 1, mu, [1 if (i == 0 and j == 0) else 0 for i in range(h + 1) for j in range(mu)], q)
    Bm.fill(range(x0 - h, x0 + npts + 8))
    W = E; good_from = x0; xs_start = None; vals = []
    x = x0 - h
    while len(vals) < npts:
        if x % q not in Bm.cache:
            Bm.fill(range(x, x + 256))
        Bx = Bm.cache[x % q]
        if Bx is None:                      # a pole: the rows through it are lost for h steps
            W = E; good_from = x + 1 + h; vals = []; xs_start = None; x += 1
            continue
        WB = W * Bx                         # rows w_1(x) .. w_h(x)
        if x >= good_from:
            d = dependence_mat(S1 * WB + E1, h, q)
            if d is None:
                vals = []; xs_start = None
            else:
                if xs_start is None:
                    xs_start = x
                vals.append(d)
        W = S * WB + E
        x += 1
    pts = Consecutive(xs_start, npts - holdout, q)
    rats = []
    for i in range(h):
        r = ratfun_consecutive(pts, [v[i] for v in vals], holdout)
        if r is None:
            return h, None
        rats.append(r)
    Lc = flint.nmod_poly([1], q)
    for P, Q in rats:
        Lc = Lc * Q // Lc.gcd(Q)
    Lc = Lc * pow(int(Lc.leading_coefficient()), -1, q)
    d = [coeffs(P * (Lc // Q)) for P, Q in rats] + [coeffs(Lc)]
    return h, d


def _law_job(args):
    Bpath, mu, pdir, idx, npts, x0, h, shape = args
    ppath = os.path.join(pdir, f'prime_{idx:04d}.pkl')
    if os.path.exists(ppath):
        return ppath
    q = prime_number(idx, SEED_PRIMES)
    Bq = _load(Bpath)['B']
    try:
        hh, dd = law_mod(Bq, mu, q, npts, x0, h)
    except ZeroDivisionError:
        hh, dd = h, None
    _save({'q': q, 'h': hh, 'd': dd}, ppath)
    return ppath


def _rec_all(acc, mod):
    """every coefficient of the law over Q, read with one common denominator (vec_ratrec), or None"""
    flat = [u for a in acc for u in a]
    got = vec_ratrec(flat, mod)
    if got is None:
        return None
    out = []; i = 0
    for a in acc:
        out.append(got[i:i + len(a)]); i += len(a)
    return out


def random_prime(rng, bits=62):
    while True:
        q = rng.randrange(2 ** (bits - 1), 2 ** bits) | 1
        if is_prime(q):
            return q


def law_over_Q(Bq, mu, run_dir, log, workers=1, start_pts=48, max_primes=4000):
    """the law of <1>_k with integer coefficients: list c_0 .. c_h of coefficient lists (lowest degree first)"""
    path = os.path.join(run_dir, 'law_exact.pkl')
    if os.path.exists(path):
        log('   law: from the checkpoint')
        return _load(path)
    pdir = os.path.join(run_dir, 'law_primes'); os.makedirs(pdir, exist_ok=True)
    Bpath = os.path.join(run_dir, 'B_exact.pkl')
    t0 = time.time()
    # first prime: the order and the number of points
    fpath = os.path.join(pdir, 'first.pkl')
    x0 = random.Random(7).randrange(10 ** 6, 10 ** 9)
    if os.path.exists(fpath):
        first = _load(fpath)
    else:
        q = prime_number(0, SEED_PRIMES)
        npts = start_pts
        while True:
            h, d = law_mod(Bq, mu, q, npts, x0)
            if d is not None:
                break
            log(f'      law modulo the first prime: {npts} points do not determine it ({time.time() - t0:.0f}s)')
            npts = 2 * npts
        first = {'q': q, 'h': h, 'd': d, 'npts': npts}
        _save(first, fpath)
    h, d = first['h'], first['d']
    shape = [len(c) for c in d]
    log(f'   law of <1>: order {h}, degree {max(shape) - 1} (from {first["npts"]} points modulo one prime, '
        f'{time.time() - t0:.0f}s)')
    npts = 2 * (max(shape) + 2) + 2 * h + 12
    acc = [list(c) for c in d]; mod = first['q']; prev = None; used = 1; idx = 1
    from multiprocessing import get_context
    pool = (get_context('fork') if hasattr(os, 'fork') else get_context()).Pool(workers) if workers > 1 else None
    try:
        while used < max_primes:
            batch = list(range(idx, idx + max(1, workers))); idx += len(batch)
            jobs = [(Bpath, mu, pdir, i, npts, x0 + i * 100003, h, shape) for i in batch]
            paths = pool.map(_law_job, jobs) if pool else [_law_job(j) for j in jobs]
            for p in paths:
                r = _load(p)
                if r['d'] is None or [len(c) for c in r['d']] != shape:
                    continue
                q = r['q']
                inv = pow(mod % q, -1, q)
                acc = [[u + mod * ((v - u) * inv % q) for u, v in zip(a, c)] for a, c in zip(acc, r['d'])]
                mod *= q; used += 1
            if used < 3:
                continue
            rec = _rec_all(acc, mod)
            if used % 16 < len(batch) or rec is not None:
                log(f'      {used} primes ({mod.bit_length()} bits): {"reconstructible" if rec else "not yet"} '
                    f'({time.time() - t0:.0f}s)')
            if rec is not None and rec == prev:
                break
            prev = rec
        else:
            raise RuntimeError('the law is not stable after %d primes' % max_primes)
    finally:
        if pool:
            pool.close(); pool.join()
    # integers, primitive
    L = 1
    for a in rec:
        for c in a:
            L = lcm(L, c.denominator)
    dint = [[int(c * L) for c in a] for a in rec]
    g = 0
    for a in dint:
        for c in a:
            g = gcd(g, c)
    dint = [[c // g for c in a] for a in dint]
    # c_j(k) = d_(h-j)(k + h)
    cpolys = []
    for j in range(h + 1):
        P = flint.fmpz_poly(dint[h - j])(flint.fmpz_poly([h, 1]))
        cpolys.append([int(c) for c in P.coeffs()])
    # check at a prime and a point drawn at random: the dependence of the rows
    rng = random.SystemRandom()
    while True:
        qf = random_prime(rng)
        try:
            Bm = BModQ(Bq, mu, qf)
            break
        except ZeroDivisionError:
            continue
    xf = rng.randrange(10 ** 6, qf)
    R = flint.nmod_mat(mu, mu, [1 if i == j else 0 for i in range(mu) for j in range(mu)], qf)
    rows = [[1] + [0] * (mu - 1)]
    for i in range(1, h + 1):
        R = Bm(xf - i + 1) * R
        rows.append([int(R[0, j]) for j in range(mu)])
    tot = [0] * mu
    for i in range(h + 1):
        di = 0
        for c in reversed(dint[i]):
            di = (di * xf + c) % qf
        tot = [(a + di * b) % qf for a, b in zip(tot, rows[i])]
    if any(tot):
        raise RuntimeError('the law fails at a random prime and point')
    digits = max(len(str(abs(c))) for a in cpolys for c in a)
    log(f'   law over Q: order {h}, degree {max(len(c) for c in cpolys) - 1}, coefficients up to {digits} digits, '
        f'{used} primes; checked at a random prime and point ({time.time() - t0:.0f}s)')
    out = {'order': h, 'c': cpolys, 'primes': used}
    _save(out, path)
    with open(os.path.join(run_dir, 'law.txt'), 'w') as fh:
        fh.write(f'# sum_j c_j(k) <1>_(k+j) = 0, j = 0..{h}; coefficients of c_j, lowest degree first\n')
        for j, c in enumerate(cpolys):
            fh.write(f'c_{j}: ' + ' '.join(map(str, c)) + '\n')
    return out
