"""The sparse eliminator (c/elimr.c): the relations with coefficients c0 + c1 k reduced modulo a prime q at
given strengths, each unknown traded only for simpler ones (columns are ordered simplest first, and the
pivot of a row is its most complex column); returns the normal forms of the targets at each strength."""
import os, struct, subprocess, tempfile, shutil

HERE = os.path.dirname(os.path.abspath(__file__))
I63 = 1 << 63


def eliminator(name='elimr'):
    """path of the compiled eliminator, compiled on first use (next to the source, else in the temp dir)"""
    src = os.path.join(HERE, 'c', name + '.c')
    places = (os.path.join(HERE, 'c'), os.path.join(tempfile.gettempdir(), 'rayreader_bin'))
    for d in places:
        exe = os.path.join(d, name)
        if os.path.exists(exe) and os.path.getmtime(exe) >= os.path.getmtime(src):
            return exe
    for d in places:
        try:
            os.makedirs(d, exist_ok=True)
            exe = os.path.join(d, name)
            cc = os.environ.get('CC', 'cc')
            subprocess.run([cc, '-O3', '-o', exe, src], check=True, capture_output=True)
            return exe
        except (OSError, subprocess.CalledProcessError):
            continue
    raise RuntimeError(f'could not compile rr/c/{name}.c: a C compiler (cc) is needed')


def sort_relations(rels, cols):
    idx = {x: i for i, x in enumerate(cols)}
    return sorted(rels, key=lambda r: max(idx[x] for x in r))


def write_system(rels, cols, targets, path, q=None):
    """the eliminator's input file (rels in the order given); coefficients reduced mod q if q is given,
    otherwise written as they are (False is returned if some coefficient does not fit in 64 bits)"""
    idx = {x: i for i, x in enumerate(cols)}
    red = (lambda c: c % q) if q else (lambda c: c)
    if not q and any(not -I63 <= c < I63 for r in rels for cc in r.values() for c in cc):
        return False
    if not q and any(not -I63 <= c < I63 for t in targets for c in t.values()):
        return False
    tmp = path + '.tmp'
    with open(tmp, 'wb') as f:
        f.write(struct.pack('<3Q', len(cols), len(rels), len(targets)))
        for rel in rels:
            f.write(struct.pack('<Q', len(rel)))
            for x, (c0, c1) in rel.items():
                f.write(struct.pack('<Qqq', idx[x], red(c0), red(c1)))
        for tg in targets:
            f.write(struct.pack('<Q', len(tg)))
            for x, c in tg.items():
                f.write(struct.pack('<Qq', idx[x], red(c)))
    os.replace(tmp, path)
    return True


def run_bin(path, cols, ks, q, want_pivots=False, want_needed=False):
    """the eliminator on a file written by write_system; see run_cp for the result"""
    cmd = [eliminator(), path, str(q), ','.join(str(k % q) for k in ks)]
    cmd += (['pivots'] if want_pivots else []) + (['needed'] if want_needed else [])
    out = subprocess.run(cmd, capture_output=True, text=True, check=True).stdout
    res = []; cur = None; extra = {}
    for line in out.splitlines():
        parts = line.split()
        if parts[0] == 'P':
            extra['pivots'] = [int(x) for x in parts[1:]]
        elif parts[0] == 'N':
            extra['needed'] = [int(x) for x in parts[1:]]
        elif parts[0] == 'K':
            cur = {'k': int(parts[1]), 'rank': int(parts[3]), 'nf': []}; res.append(cur)
        else:
            on = int(parts[2]); vals = parts[3:]
            cur['nf'].append({cols[int(vals[2 * j])]: int(vals[2 * j + 1]) for j in range(on)})
    return (res, extra) if (want_pivots or want_needed) else res


def run_cp(rels, cols, targets, ks, q, workdir=None, presorted=False, want_pivots=False, want_needed=False):
    """rels: list of dicts col -> (c0, c1) (integers); targets: list of dicts col -> c (integers);
    ks: strengths (integers mod q), q a prime in (2^40, 2^62).  Returns one dict per strength:
    {'k', 'rank', 'nf': [dict col -> c]}.  With want_pivots / want_needed, returns (results, extra) where
    extra['pivots'] lists the relations (indices in the sorted order) that produced pivot rows at the first
    strength and extra['needed'] those whose pivot rows the reduction of the targets uses."""
    if not presorted:
        rels = sort_relations(rels, cols)
    tmpdir = tempfile.mkdtemp(dir=workdir)
    path = os.path.join(tmpdir, 'sys.bin')
    try:
        write_system(rels, cols, targets, path, q)
        return run_bin(path, cols, ks, q, want_pivots, want_needed)
    finally:
        shutil.rmtree(tmpdir, ignore_errors=True)
