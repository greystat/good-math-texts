"""The relations of a box (Definitions 23.1 and 23.8, Proposition 23.3), with integer coefficients c0 + c1 k.

Box (T; A, B): insertions at letter levels a <= A, b <= B.  Letter identities (K/K = Psi/Psi = 1) from every
insertion of wall degree <= T at a level below the top; mark relations for the seeds g = H L, the insertions of
wall degree <= T at the seed level (max(A - 1, 0), max(B - 1, 0)), written through
H = alpha^w K^-a Psi^-b, (a, b) = (max(A - 1, 0) + s, max(B - 1, 0) + t), of wall degree <= T - 1:
    d_e( H alpha^u0 K^-a0 Psi^-b0 f^(k-1) ) integrates to zero, written at strength k:
    (w_e + u0_e - m_e + k m_e) X(w - m; a - s, b - t)
      - (a + a0 - s + k s) sum_{T in e} X(w - m + 1_T; a - s + 1, b - t)
      - (b + b0 - t + k t) sum_{T not in e} X(w - m + 1_(E-T); a - s, b - t + 1)  = 0,
multiplied by the common denominator of the origin."""
import time
from collections import defaultdict
import numpy as np
from .ray import vadd


def ibp_raw(ray, w, a, b, e):
    s, t, m, d = ray.s, ray.t, ray.m, ray.den
    o0, o1 = {}, {}
    u0 = tuple(x - y for x, y in zip(w, m))
    main0 = (w[e] - m[e] + ray.u0[e]) * d
    ray.put_raw(o0, u0, a - s, b - t, int(main0)); ray.put_raw(o1, u0, a - s, b - t, m[e] * d)
    ka = (a + ray.a0 - s) * d
    if s or ka:
        for v, c in ray.L.DK[e].items():
            ray.put_raw(o0, vadd(u0, v), a + 1 - s, b - t, -int(ka) * c)
            ray.put_raw(o1, vadd(u0, v), a + 1 - s, b - t, -s * d * c)
    pb = (b + ray.b0 - t) * d
    if t or pb:
        for v, c in ray.L.DPsi[e].items():
            ray.put_raw(o0, vadd(u0, v), a - s, b + 1 - t, -int(pb) * c)
            ray.put_raw(o1, vadd(u0, v), a - s, b + 1 - t, -t * d * c)
    keys = set(o0) | set(o1)
    return {x: (o0.get(x, 0), o1.get(x, 0)) for x in keys}


def letter_raw(ray, u, a, b, which):
    out = {}
    ray.put_raw(out, u, a, b, -1)
    base = ray.L.K if which == 'K' else ray.L.Psi
    for v, c in base.items():
        ray.put_raw(out, vadd(u, v), a + (which == 'K'), b + (which == 'P'), c)
    return {x: (c, 0) for x, c in out.items()}


def build_system(ray, T, A, B, log=None):
    """relations (list of dicts col -> (c0, c1), integers) and columns (sorted, simplest first)"""
    n = ray.n; s_, t_ = ray.s, ray.t
    t0 = time.time()
    a_top = max(A - 1, 0) + s_
    b_top = max(B - 1, 0) + t_
    raw = []; nseed = 0
    for a in range(A + 1):
        for b in range(B + 1):
            if a + 1 > A and b + 1 > B:
                continue
            U = ray.box(a, b, T)
            for w in (set(ray.canon_many(U, a, b)) if len(U) else ()):
                w = w[0]; nseed += 1
                if a + 1 <= A:
                    raw.append(letter_raw(ray, w, a, b, 'K'))
                if b + 1 <= B:
                    raw.append(letter_raw(ray, w, a, b, 'P'))
    U = ray.box(a_top, b_top, T - 1)
    tops = set(ray.canon_many(U, a_top, b_top)) if len(U) else set()
    for (w, a, b) in sorted(tops):
        for e in range(n):
            raw.append(ibp_raw(ray, w, a, b, e))
    bylev = defaultdict(set)
    for rel in raw:
        for (u, a, b) in rel:
            bylev[(a, b)].add(u)
    cmap = {}
    for (a, b), us in bylev.items():
        us = sorted(us); reps = ray.canon_many(np.array(us, dtype=np.int64), a, b)
        for u, rep in zip(us, reps):
            cmap[(u, a, b)] = rep
    rels = []
    for rel in raw:
        out = {}
        for x, (c0, c1) in rel.items():
            y = cmap[x]; o = out.get(y, (0, 0)); out[y] = (o[0] + c0, o[1] + c1)
        out = {y: c for y, c in out.items() if c[0] or c[1]}
        if out:
            rels.append(out)
    degs = {}
    def key(x):
        d = degs.get(x)
        if d is None:
            d = round(ray.deg(*x), 9); degs[x] = d
        return (x[1] + x[2], d, x)
    cols = sorted({x for rel in rels for x in rel}, key=key)
    info = {'box': (T, A, B), 'seeds': nseed, 'top seeds': len(tops), 'relations': len(rels),
            'unknowns': len(cols), 'seconds': round(time.time() - t0, 1)}
    if log:
        log(f'   box ({T};{A},{B}): {nseed} letter seeds, {len(tops)} top seeds, {len(rels)} relations on '
            f'{len(cols)} insertions ({time.time() - t0:.1f}s)')
    return rels, cols, info
