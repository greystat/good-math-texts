"""Lists by their bases: the letters K = sum_T alpha^T and Psi = sum_T alpha^(E-T), ranks, automorphisms,
and the named lists used as test cases.  A list file is JSON: {"n": 6, "bases": [[0,1,2], ...]} or
{"graph": {"vertices": 4, "edges": [[0,1], ...]}} (the bases are then the spanning trees)."""
import itertools, json
from collections import defaultdict


class List:
    def __init__(self, n, bases, name=None):
        self.n = n
        self.bases = sorted({tuple(sorted(T)) for T in bases})
        if not self.bases:
            raise ValueError('a list needs at least one basis')
        self.r = len(self.bases[0])
        if any(len(T) != self.r for T in self.bases):
            raise ValueError('bases of different sizes')
        self.name = name or f'list on {n} marks'
        K = defaultdict(int); Psi = defaultdict(int)
        for T in self.bases:
            K[tuple(1 if i in T else 0 for i in range(n))] += 1
            Psi[tuple(0 if i in T else 1 for i in range(n))] += 1
        self.K = dict(K); self.Psi = dict(Psi)
        self.DK = [{v: c for v, c in self.K.items() if v[e]} for e in range(n)]
        self.DPsi = [{v: c for v, c in self.Psi.items() if v[e]} for e in range(n)]

    def rank(self, S):
        """largest trace of a basis on S"""
        S = set(S)
        return max(len(S.intersection(T)) for T in self.bases)

    def corank(self, S):
        """largest trace of a cobasis on S: |S| - r + r(E - S)"""
        S = set(S)
        return len(S) - self.r + self.rank(set(range(self.n)) - S)

    def automorphisms(self):
        """permutations p of the marks with p(basis) a basis, by backtracking on incidence counts"""
        n = self.n; B = set(self.bases); out = []
        deg1 = [sum(1 for T in self.bases if e in T) for e in range(n)]
        deg2 = {(e, f): sum(1 for T in self.bases if e in T and f in T) for e in range(n) for f in range(n)}
        def rec(p):
            i = len(p)
            if i == n:
                if all(tuple(sorted(p[x] for x in T)) in B for T in self.bases):
                    out.append(tuple(p))
                return
            for c in range(n):
                if c in p or deg1[c] != deg1[i]:
                    continue
                if any(deg2[(j, i)] != deg2[(p[j], c)] for j in range(i)):
                    continue
                p.append(c); rec(p); p.pop()
        rec([])
        return out

    def to_json(self):
        return {'n': self.n, 'bases': [list(T) for T in self.bases], 'name': self.name}


def graphic(nv, edges, name=None):
    """the list of a connected graph: bases are spanning trees (edge index sets)"""
    def is_tree(S):
        par = list(range(nv))
        def f(x):
            while par[x] != x:
                x = par[x]
            return x
        for i in S:
            u, v = edges[i]; a, b = f(u), f(v)
            if a == b:
                return False
            par[a] = b
        return True
    return List(len(edges), [S for S in itertools.combinations(range(len(edges)), nv - 1) if is_tree(S)], name)


def uniform(r, n, name=None):
    return List(n, list(itertools.combinations(range(n), r)), name or f'binom([{n}],{r})')


def vamos():
    P = [(0, 1), (2, 3), (4, 5), (6, 7)]
    bad = {tuple(sorted(P[i] + P[j])) for i, j in itertools.combinations(range(4), 2) if {i, j} != {2, 3}}
    return List(8, [T for T in itertools.combinations(range(8), 4) if T not in bad], 'V')


NAMED = {
    'three': lambda: uniform(1, 3, 'three marks'),
    'banana4': lambda: uniform(1, 4, 'banana on four marks'),
    'banana5': lambda: uniform(1, 5, 'banana on five marks'),
    'H': lambda: List(4, [T for T in itertools.combinations(range(4), 2) if T != (0, 1)], 'H'),
    'MK4': lambda: graphic(4, list(itertools.combinations(range(4), 2)), 'M(K4)'),
    'U25': lambda: uniform(2, 5),
    'N': lambda: List(6, [T for T in itertools.combinations(range(6), 3) if T != (0, 1, 2)], 'N'),
    'V': vamos,
    'prism': lambda: graphic(6, [(0, 1), (0, 2), (1, 2), (3, 4), (3, 5), (4, 5), (0, 3), (1, 4), (2, 5)], 'prism'),
}


def load_list(spec):
    """a name from NAMED, or a JSON file"""
    if spec in NAMED:
        return NAMED[spec]()
    with open(spec) as fh:
        d = json.load(fh)
    if 'graph' in d:
        g = d['graph']
        return graphic(g['vertices'], [tuple(e) for e in g['edges']], d.get('name'))
    return List(d['n'], [tuple(T) for T in d['bases']], d.get('name'))
