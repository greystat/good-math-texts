"""A ray: a list, an integral direction (m; s, t) strictly inside its walls, and an origin (a rational exponent
u0 of the marks and a0, b0 of the letters), so that the values are
    <g>_k = int_{y_e0 = 0}  g * alpha^u0 K^-a0 Psi^-b0 * f^k  dy,     f = alpha^m K^-s Psi^-t.
Insertions alpha^u K^-a Psi^-b are keyed (u, a, b) with |u| = a r + b (n - r); the wall degree is
    deg(u; a, b) = max over nonempty proper S of (u(S) - a r(S) - b r*(S)) / h(S),
h(S) = s r(S) + t r*(S) - m(S) the wall of S, all positive strictly inside the walls."""
import itertools
from collections import defaultdict
from fractions import Fraction as Fr
import numpy as np
from .boxenum import enum_box


def vadd(u, v):
    return tuple(a + b for a, b in zip(u, v))


def parse_vector(text):
    return [Fr(x) for x in text.replace(',', ' ').split()]


def walls(lst, m, s, t):
    """h(S) for every nonempty proper S, as a dict S -> Fraction"""
    n = lst.n
    out = {}
    for k in range(1, n):
        for S in itertools.combinations(range(n), k):
            out[S] = s * lst.rank(S) + t * lst.corank(S) - sum(Fr(m[i]) for i in S)
    return out


def split_direction(lst, m, s, t):
    """(m; s, t) with rational m and integral s, t on the balance wall -> an integral direction m' strictly
    inside the walls with the same letters, and the origin u0 = m - m' (degree zero).  The period of the
    rational direction at strength 1 is then <1>_1 on the ray of m' with origin u0."""
    n, r = lst.n, lst.r
    m = [Fr(x) for x in m]
    if Fr(s).denominator != 1 or Fr(t).denominator != 1:
        raise ValueError('the letters of the direction must have integral exponents')
    s, t = int(s), int(t)
    tot = s * r + t * (n - r)
    if sum(m) != tot:
        raise ValueError(f'not on the balance wall: |m| = {sum(m)}, s r + t (n - r) = {tot}')
    h = walls(lst, m, s, t)
    bad = [S for S, v in h.items() if v <= 0]
    if bad:
        raise ValueError(f'the direction is not strictly inside its walls: h(S) <= 0 for S = {bad[:4]}')
    if all(x.denominator == 1 for x in m):
        return [int(x) for x in m], s, t, [Fr(0)] * n
    fl = [x.numerator // x.denominator for x in m]
    fr = [x - f for x, f in zip(m, fl)]
    R = tot - sum(fl)                         # how many coordinates to round up
    order = sorted(range(n), key=lambda i: (-fr[i], i))
    # try roundings in order of closeness: the R largest fractional parts first, then swaps
    cands = [set(order[:R])]
    for i in order[:R]:
        for j in order[R:]:
            cands.append((set(order[:R]) - {i}) | {j})
    for up in cands:
        mp = [fl[i] + (1 if i in up else 0) for i in range(n)]
        hp = walls(lst, mp, s, t)
        if all(v > 0 for v in hp.values()):
            return mp, s, t, [m[i] - mp[i] for i in range(n)]
    raise ValueError('no integral direction strictly inside the walls was found next to this one')


class Ray:
    def __init__(self, lst, m, s, t, origin=None, use_group=True):
        self.L, self.n = lst, lst.n
        self.m, self.s, self.t = tuple(int(x) for x in m), int(s), int(t)
        n = self.n
        u0, a0, b0 = origin if origin is not None else ([Fr(0)] * n, Fr(0), Fr(0))
        self.u0 = tuple(Fr(x) for x in u0); self.a0, self.b0 = Fr(a0), Fr(b0)
        if sum(self.u0) != self.a0 * lst.r + self.b0 * (n - lst.r):
            raise ValueError('the origin must have degree zero')
        # one common denominator for the origin, so that relations have integer coefficients
        self.den = 1
        for x in list(self.u0) + [self.a0, self.b0]:
            self.den = self.den * x.denominator // np.gcd(self.den, x.denominator)
        self.subsets = [S for k in range(1, n) for S in itertools.combinations(range(n), k)]
        self.Smat = np.array([[1 if i in S else 0 for i in range(n)] for S in self.subsets], dtype=np.int64)
        self.rS = np.array([lst.rank(S) for S in self.subsets], dtype=np.int64)
        self.rsS = np.array([lst.corank(S) for S in self.subsets], dtype=np.int64)
        self.hS = self.s * self.rS + self.t * self.rsS - self.Smat @ np.array(self.m, dtype=np.int64)
        if not (self.hS > 0).all():
            raise ValueError('a wall is not positive')
        # symmetries: automorphisms fixing m and the origin; Cremona at a self-dual direction without origin
        if use_group:
            G = [g for g in lst.automorphisms()
                 if all(self.m[g[i]] == self.m[i] and self.u0[g[i]] == self.u0[i] for i in range(n))]
        else:
            G = [tuple(range(n))]
        self.group = G
        self.cremona = use_group and self.s == self.t and all(x == self.s for x in self.m) \
            and all(x == 0 for x in self.u0) and self.a0 == 0 and self.b0 == 0
        self.perms = np.array(self.group, dtype=np.int64)
        self._canon = {}
        self.Kpow = {0: {tuple([0] * n): 1}}; self.Ppow = {0: {tuple([0] * n): 1}}

    # ---- measure ----
    def deg(self, u, a, b):
        u = np.asarray(u, dtype=np.int64)
        return float(np.max((self.Smat @ u - a * self.rS - b * self.rsS) / self.hS))

    def box(self, a, b, tmax):
        """all u with |u| = a r + b (n - r) and deg(u; a, b) <= tmax"""
        n, r = self.n, self.L.r
        tot = a * r + b * (n - r)
        bound = {}
        for i, S in enumerate(self.subsets):
            bound[frozenset(S)] = int(np.floor(a * self.rS[i] + b * self.rsS[i] + tmax * self.hS[i] + 1e-9))
        U = enum_box(n, tot, bound)
        return np.array(U, dtype=np.int64).reshape(-1, n)

    # ---- symmetry ----
    def canon_many(self, U, a, b):
        out = []
        for i in range(0, len(U), 20000):
            out.extend(self._canon_many(U[i:i + 20000], a, b))
        return out

    def _canon_many(self, U, a, b):
        G = self.perms; N = U.shape[0]; n = self.n
        W = np.empty((G.shape[0], N, n), dtype=np.int64)
        for gi, g in enumerate(G):
            W[gi][:, g] = U
        cands = [(W, a, b)]
        if self.cremona:
            cands.append((-W + (a + b), b, a))
        best = None
        for (Wc, aa, bb) in cands:
            off = Wc.min(); base = int(Wc.max() - off + 1)
            if base ** n < 2 ** 62:
                code = np.zeros(Wc.shape[:2], dtype=np.int64)
                for i in range(n):
                    code = code * base + (Wc[:, :, i] - off)
                idx = np.argmin(code, axis=0)
            else:
                idx = np.array([min(range(Wc.shape[0]), key=lambda g: tuple(Wc[g, j])) for j in range(N)])
            rep = Wc[idx, np.arange(N)]
            key = [(tuple(x), aa, bb) for x in rep.tolist()]
            best = key if best is None else [min(x, y) for x, y in zip(best, key)]
        return best

    def canon(self, x):
        c = self._canon.get(x)
        if c is None:
            u, a, b = x
            c = self.canon_many(np.array([u], dtype=np.int64), a, b)[0]
            self._canon[x] = c
        return c

    # ---- letters multiplied out ----
    def pw(self, which, j):
        tab = self.Kpow if which == 'K' else self.Ppow
        base = self.L.K if which == 'K' else self.L.Psi
        while max(tab) < j:
            j0 = max(tab); new = defaultdict(int)
            for u, c in tab[j0].items():
                for v, d in base.items():
                    new[vadd(u, v)] += c * d
            tab[j0 + 1] = dict(new)
        return tab[j]

    def put_raw(self, out, u, a, b, coef):
        """coef * alpha^u K^-a Psi^-b, letters with a nonpositive exponent multiplied out (integers)"""
        if coef == 0:
            return
        terms = {u: coef}
        if a < 0:
            Pk = self.pw('K', -a)
            terms = {vadd(x, v): c * d for x, c in terms.items() for v, d in Pk.items()}
            a = 0
        if b < 0:
            Pp = self.pw('P', -b); new = defaultdict(int)
            for x, c in terms.items():
                for v, d in Pp.items():
                    new[vadd(x, v)] += c * d
            terms = new; b = 0
        for x, c in terms.items():
            key = (x, a, b); out[key] = out.get(key, 0) + c

    def target(self, u):
        """L * alpha^u = alpha^(u - m) K^s Psi^t, canonicalized: the insertion whose value at k is <alpha^u>_(k-1)"""
        tg = {}
        self.put_raw(tg, tuple(x - y for x, y in zip(u, self.m)), -self.s, -self.t, 1)
        out = {}
        for x, c in tg.items():
            y = self.canon(x); out[y] = out.get(y, 0) + c
        return {y: c for y, c in out.items() if c}

    def describe(self):
        o = '' if all(x == 0 for x in self.u0) and self.a0 == 0 and self.b0 == 0 else \
            f', origin ({" ".join(str(x) for x in self.u0)}; {self.a0}, {self.b0})'
        return (f'{self.L.name}: n = {self.n}, rank {self.L.r}, {len(self.L.bases)} bases; direction '
                f'({" ".join(map(str, self.m))}; {self.s}, {self.t}){o}; {len(self.group)} symmetries'
                f'{" and Cremona" if self.cremona else ""}; smallest wall {int(self.hS.min())}')
