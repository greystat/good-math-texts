"""The gauge end (Theorem 21.1): the value <1>_k from the law and local data at the native gauge.

alpha* is the critical point of f on the orthant (the only one, Thm. 35.10(i)), found by Newton's method on
the chart y_(n-1) = 0; H is the Hessian of -log f there.  The density rho of the stride's law solves the
density operator of the law, L = sum_i t^i c_i(-1-i-theta), theta = t d/dt, and near f* it is
    rho(t) = (f* - t)^((n-3)/2) g(f* - t),   g(0) = G(alpha*) (2 pi / f*)^((n-1)/2) / (Gamma((n-1)/2) sqrt(det H)),
G the origin's insertion; its germ is the solution of L that extends by zero across f*, so
    <1>_k = sum_m g(0) e_m f*^(k+mu+m+1) B(k+1, mu+m+1),   mu = (n-3)/2,
summed at a large strength K, and the law run backwards to the strength wanted."""
import math
from fractions import Fraction as Fr
import mpmath as mp
from flint import fmpq, fmpq_poly, fmpz_poly, fmpz_mat, arb, arb_mat, ctx


# ---------------- native gauge on the orthant ----------------
def native_gauge(lst, m, s, t, origin, digits):
    """alpha* (chart alpha_(n-1) = 1), f*, det H, G(alpha*) as mpmath numbers"""
    n = lst.n
    mp.mp.dps = digits + 60
    Kmon = [(v, c) for v, c in lst.K.items()]
    Pmon = [(v, c) for v, c in lst.Psi.items()]
    def moments(y):
        a = [mp.e ** yy for yy in y] + [mp.mpf(1)]
        out = []
        for mons, wgt in ((Kmon, s), (Pmon, t)):
            if wgt == 0:
                out.append(None); continue
            ws = [c * mp.fprod(a[i] ** v[i] for i in range(n) if v[i]) for v, c in mons]
            W = mp.fsum(ws)
            mean = [mp.fsum(w * v[e] for w, (v, c) in zip(ws, mons)) / W for e in range(n - 1)]
            cov = [[mp.fsum(w * v[e] * v[f] for w, (v, c) in zip(ws, mons)) / W - mean[e] * mean[f]
                    for f in range(n - 1)] for e in range(n - 1)]
            out.append((W, mean, cov))
        return out
    y = [mp.mpf(0)] * (n - 1)
    for it in range(400):
        mo = moments(y)
        g = [mp.mpf(m[e]) for e in range(n - 1)]
        H = mp.matrix(n - 1, n - 1)
        for wgt, M in ((s, mo[0]), (t, mo[1])):
            if M is None:
                continue
            W, mean, cov = M
            for e in range(n - 1):
                g[e] -= wgt * mean[e]
                for f in range(n - 1):
                    H[e, f] += wgt * cov[e][f]
        step = mp.lu_solve(H, mp.matrix(g))
        nrm = max(abs(step[i]) for i in range(n - 1))
        damp = 1 if nrm < 1 else 1 / nrm
        y = [y[i] + damp * step[i] for i in range(n - 1)]
        if nrm < mp.mpf(10) ** (-(digits + 50)):
            break
    else:
        raise RuntimeError('Newton did not converge to the native gauge')
    mo = moments(y)
    H = mp.matrix(n - 1, n - 1)
    for wgt, M in ((s, mo[0]), (t, mo[1])):
        if M is not None:
            for e in range(n - 1):
                for f in range(n - 1):
                    H[e, f] += wgt * M[2][e][f]
    detH = mp.det(H)
    a = [mp.e ** yy for yy in y] + [mp.mpf(1)]
    Kv = mp.fsum(c * mp.fprod(a[i] ** v[i] for i in range(n) if v[i]) for v, c in Kmon)
    Pv = mp.fsum(c * mp.fprod(a[i] ** v[i] for i in range(n) if v[i]) for v, c in Pmon)
    fstar = mp.fprod(a[i] ** m[i] for i in range(n)) / (Kv ** s * Pv ** t)
    u0, a0, b0 = origin
    def q(x):
        x = Fr(x); return mp.mpf(x.numerator) / x.denominator
    G = mp.fprod(a[i] ** q(u0[i]) for i in range(n)) / (Kv ** q(a0) * Pv ** q(b0))
    return a, fstar, detH, G


def log10(x):
    """log10 of |x| for an arb, as a float (the midpoint; -inf for zero)"""
    v = mp.mpf(abs(x).mid().str(30, radius=False))
    return float(mp.log10(v)) if v != 0 else float('-inf')


def to_arb(x):
    if isinstance(x, arb):
        return x
    if isinstance(x, fmpq):
        return arb(x.p) / arb(x.q)
    if isinstance(x, (int,)):
        return arb(x)
    if type(x).__name__ == 'fmpz':
        return arb(int(x))
    if isinstance(x, Fr):
        return arb(x.numerator) / arb(x.denominator)
    return arb(mp.nstr(x, mp.mp.dps, strip_zeros=False))


# ---------------- the density operator ----------------
def density_operator(cp):
    """L = sum_j a_j(t) d^j/dt^j from the law sum_i c_i(k) P(k+i) = 0 (c_i integer coefficient lists).
    t^i theta^r = sum_j S(r, j) t^(i+j) d^j (Stirling numbers of the second kind), so with
    beta_(i,r) = [x^r] c_i(-1-i-x):  a_j(t) = t^j sum_i A_(i,j) t^i,  A = beta S."""
    D = max(len(c) - 1 for c in cp)
    S = [[0] * (D + 1) for _ in range(D + 1)]
    S[0][0] = 1
    for a_ in range(1, D + 1):
        for b_ in range(1, a_ + 1):
            S[a_][b_] = b_ * S[a_ - 1][b_] + S[a_ - 1][b_ - 1]
    rows = []
    for i, c in enumerate(cp):
        P = fmpz_poly([int(x) for x in c])(fmpz_poly([-1 - i, -1]))
        co = [int(x) for x in P.coeffs()] if P.degree() >= 0 else []
        rows.append(co + [0] * (D + 1 - len(co)))
    A = fmpz_mat(rows) * fmpz_mat(S)
    h = len(cp) - 1
    a = []
    for j in range(D + 1):
        a.append(fmpq_poly([0] * j + [int(A[i, j]) for i in range(h + 1)]))
    return D, a


def symbol_at(cp, x):
    D = max(len(c) - 1 for c in cp)
    tot = arb(0)
    for i, c in enumerate(cp):
        if len(c) > D:
            tot += arb(c[D]) * x ** i
    return tot


def shifted_ops(a, t0, D, M):
    """b_j(s) = (-1)^j a_j(t0 - s): its Taylor coefficients in s up to the order the Frobenius recursion
    reaches with M terms (l <= M - D + 2 + j); a_j = t^j p_j(t), so each coefficient is a short sum"""
    b = []
    for j, aj in enumerate(a):
        deg = aj.degree()
        L = min(deg, M - D + 2 + j)
        if deg < 0 or L < 0:
            b.append([]); continue
        nz = [(r, to_arb(aj[r])) for r in range(j, deg + 1) if aj[r] != 0]
        pw = {0: arb(1)}
        out = []
        for l in range(L + 1):
            c = arb(0)
            for r, cr in nz:
                if r < l:
                    continue
                e = r - l
                if e not in pw:
                    pw[e] = t0 ** e
                c += cr * math.comb(r, l) * pw[e]
            out.append(c * (-1) ** l)
        sign = -1 if j % 2 else 1
        b.append([sign * c for c in out])
    return b


class Recurrence:
    """R_m(x) = sum_j b_(j, m-D+1+j) x^(falling j), the recurrence of the Frobenius coefficients at s = 0"""
    def __init__(self, b, D):
        self.D = D
        self.terms = {}
        maxm = max(len(bj) for bj in b) + D
        for m in range(0, maxm + 1):
            lst = []
            for j in range(D + 1):
                l = m - D + 1 + j
                if 0 <= l < len(b[j]):
                    lst.append((j, b[j][l]))
            if lst:
                self.terms[m] = lst
        self.ms = sorted(self.terms)

    def R(self, m, x):
        lst = self.terms.get(m)
        if not lst:
            return None
        jmax = lst[-1][0]
        fall = [arb(1)]
        for i in range(jmax):
            fall.append(fall[-1] * (x - i))
        tot = arb(0)
        for j, bj in lst:
            tot += bj * fall[j]
        return tot


def germ(b, D, mu2, M):
    """Frobenius coefficients e_0 = 1, e_1, ... of the solution that extends by zero (mu = mu2/2)"""
    rec = Recurrence(b, D)
    if mu2 % 2:                                    # mu a half-integer: s^mu (1 + ...)
        mu = arb(mu2) / 2
        # R_m is evaluated only at mu + r, 0 <= r <= M: the falling factorials once for each r
        F = []
        for r in range(M + 1):
            x = mu + r; row = [arb(1)]
            for i in range(D):
                row.append(row[-1] * (x - i))
            F.append(row)
        def R(m, r):
            tot = arb(0)
            for j, bj in rec.terms[m]:
                tot += bj * F[r][j]
            return tot
        e = [arb(1)]
        for N in range(1, M + 1):
            s_ = arb(0)
            for m in rec.ms:
                if m == 0 or m > N:
                    continue
                s_ += R(m, N - m) * e[N - m]
            e.append(-s_ / R(0, N))
        return e
    mu = mu2 // 2                                  # an integer: the holomorphic solution of order exactly mu
    free = list(range(mu + 1, D - 1))
    def build(fv):
        u = [arb(0)] * mu + [arb(1)] + list(fv)
        while len(u) < D - 1:
            u.append(arb(0))
        for N in range(D - 1, mu + M + 1):
            s_ = arb(0)
            for m in rec.ms:
                if m == 0 or m > N:
                    continue
                s_ += rec.R(m, arb(N - m)) * u[N - m]
            u.append(-s_ / rec.R(0, arb(N)))
        return u
    if free:
        base = build([arb(0)] * len(free))
        g0 = boundary_deltas(b, D, base[:D + 2])
        cols = []
        for i in range(len(free)):
            fv = [arb(0)] * len(free); fv[i] = arb(1)
            gi = boundary_deltas(b, D, build(fv)[:D + 2])
            cols.append([gi[k] - g0[k] for k in range(D)])
        A = arb_mat([[cols[i][k] for i in range(len(free))] for k in range(D)])
        rhs = arb_mat([[-g0[k]] for k in range(D)])
        At = A.transpose()
        x = (At * A).solve(At * rhs)
        fv = [x[i, 0] for i in range(len(free))]
        u = build(fv)
    else:
        u = build([])
    return u[mu:]


def boundary_deltas(b, D, u):
    def deriv_coeffs(i, nmax):
        out = []
        for r in range(nmax + 1):
            if r + i < len(u):
                f = 1
                for z in range(i):
                    f *= (r + i - z)
                out.append(u[r + i] * f)
            else:
                out.append(arb(0))
        return out
    gam = [arb(0)] * D
    for j in range(1, D + 1):
        for p in range(1, j + 1):
            cjp = math.comb(j, p)
            di = deriv_coeffs(j - p, p)
            for q in range(0, p):
                sq = arb(0)
                for l in range(q + 1):
                    if l < len(b[j]) and q - l < len(di):
                        sq += b[j][l] * di[q - l]
                k = p - 1 - q
                gam[k] += cjp * ((-1) ** q) * math.comb(p - 1, q) * math.factorial(q) * sq
    return gam


def beta_sum(e, mu, fstar, K):
    """sum_m e_m f*^(K+mu+m+1) B(K+1, mu+m+1), with the size of the last term relative to the sum"""
    Kp = to_arb(K)
    B = arb.gamma(Kp + 1) * arb.gamma(mu + 1) / arb.gamma(Kp + mu + 2)
    fp = fstar ** (Kp + mu + 1)
    tot = arb(0); last = arb(0)
    for m, em in enumerate(e):
        last = em * fp * B
        tot += last
        B *= (mu + m + 1) / (Kp + mu + m + 2)
        fp *= fstar
    return tot, last


def peval(c, k):
    acc = arb(0)
    for a in reversed(c):
        acc = acc * k + a
    return acc


def law_values(cp, ks):
    """c_0(k) .. c_h(k) exactly (integers, or Fractions at rational k) at the strengths ks: the law's
    coefficients are large and its values at small strengths much smaller, so they are not evaluated in
    floating point"""
    out = {}
    for k in ks:
        k = Fr(k); p, r = k.numerator, k.denominator
        row = []
        for c in cp:
            D = len(c) - 1
            acc = c[D]; rp = 1
            for i in range(D - 1, -1, -1):          # sum_i c_i p^i r^(D-i), from the top
                rp *= r
                acc = acc * p + c[i] * rp
            row.append(acc if r == 1 else Fr(acc, r ** D))
        out[k] = row
    return out


def run_back(cv, vals, K, k_end):
    """vals: k -> value for k = K .. K+h-1; the law run backwards to k_end (K - k_end an integer), with the
    exact values cv[k] of its coefficients"""
    x = {Fr(k): v for k, v in vals.items()}
    k = Fr(K) - 1; k_end = Fr(k_end)
    while k >= k_end:
        c = cv[k]; h = len(c) - 1
        if c[0] == 0:
            raise RuntimeError(f'c_0 vanishes at the strength {k}: the law cannot be run back through it')
        s_ = arb(0)
        for i in range(1, h + 1):
            if c[i] != 0:
                s_ += to_arb(c[i]) * x[k + i]
        x[k] = -s_ / to_arb(c[0])
        k -= 1
    return x


def amplification(cv, vals, K, k_end):
    """log10 of the factor by which running the law back from K to k_end magnifies a relative error in the
    starting values (each starting value perturbed in turn)"""
    base = run_back(cv, vals, K, k_end)[Fr(k_end)]
    worst = 0.0
    eps = arb(10) ** (-20)
    for key in vals:
        pv = dict(vals); pv[key] = vals[key] * (1 + eps)
        x = run_back(cv, pv, K, k_end)[Fr(k_end)]
        worst = max(worst, log10(x - base) - log10(base) + 20)
    return max(0.0, worst)


def read(lst, ray_m, s, t, origin, cp, k_target, digits, log, max_prec=60000):
    """<1> at the strength k_target to about `digits` digits.  Ball arithmetic throughout; the working
    precision doubles until both starting strengths give the value to the digits asked and agree."""
    n = lst.n
    h = len(cp) - 1
    D, a = density_operator(cp)
    need_bits = int(3.33 * digits) + 16
    prec = int(3.33 * (digits + 40)) + 64
    mu2 = n - 3
    K = max(30, int(1.2 * digits) + 20)
    M = max(40, 3 * K)
    cv = law_values(cp, [Fr(k_target) + i for i in range(K + 26)])
    gauge_data = None
    first = True
    first_amp = True
    while True:
        ctx.prec = prec
        mp_digits = int(prec / 3.32) + 30
        if gauge_data is None or gauge_data[0] < mp_digits:
            _, fstar_mp, detH_mp, G_mp = native_gauge(lst, ray_m, s, t, origin, mp_digits)
            gauge_data = (mp_digits, fstar_mp, detH_mp, G_mp)
            if first:
                log(f'   native gauge on the orthant: f* = {mp.nstr(fstar_mp, 20)}, det H = {mp.nstr(detH_mp, 15)}')
        mp.mp.dps = gauge_data[0] + 10
        fstar = to_arb(gauge_data[1]); detH = to_arb(gauge_data[2]); G = to_arb(gauge_data[3])
        b = shifted_ops(a, fstar, D, M); bM = M
        mu = arb(mu2) / 2
        if first:
            chi = symbol_at(cp, fstar)
            Dl = max(len(c) - 1 for c in cp)
            scale = arb(0)
            for i, c in enumerate(cp):
                if len(c) > Dl:
                    scale += abs(arb(c[Dl])) * fstar ** i
            chi = chi / scale
            mu_law = arb(D - 1) - b[D - 1][0] / b[D][1]
            log(f'   density operator of order {D}; symbol at f*, relative to its terms: {chi.mid().str(3)}; exponent at f*: '
                f'{mu_law.mid().str(12)} against (n-3)/2 = {mu2 / 2}')
            if abs(float((mu_law - mu).mid())) > 1e-8:
                raise RuntimeError('the law does not have the exponent (n-3)/2 at f*: '
                                   'f* is not a simple root of its symbol')
            first = False
        g0 = G * (2 * arb.pi() / fstar) ** (arb(n - 1) / 2) / (arb.gamma(arb(n - 1) / 2) * detH.sqrt())
        results = []
        ok = True
        for trial in range(2):
            Kt = K + 25 * trial
            amp = None
            while True:
                if bM < M:
                    b = shifted_ops(a, fstar, D, M); bM = M
                e = germ(b, D, mu2, M)
                ea = [g0 * x for x in e]
                vals = {}; worst = float('-inf')
                for j in range(h):
                    v, last = beta_sum(ea, mu, fstar, k_target + Kt + j)
                    vals[k_target + Kt + j] = v
                    worst = max(worst, log10(last) - log10(v))
                if amp is None:
                    amp = amplification(cv, vals, k_target + Kt, k_target)
                    if amp > 0 and first_amp:
                        log(f'      running the law back from {k_target + Kt} amplifies errors by 10^{amp:.0f}')
                        first_amp = False
                if worst < -(digits + 15 + amp):
                    break
                M = int(M * 1.6)
                if M > 40000:
                    raise RuntimeError('the germ series does not converge fast enough at this starting strength')
            try:
                x = run_back(cv, vals, k_target + Kt, k_target)
            except ZeroDivisionError:
                ok = False
                break
            results.append((Kt, M, x[Fr(k_target)], x))
        if ok:
            v1, v2 = results[0][2], results[1][2]
            acc = min(v1.rel_accuracy_bits(), v2.rel_accuracy_bits())
            gap = log10(v1 - v2) - log10(v2) if v2.mid() != 0 else 0
            if acc >= need_bits and gap < -digits:
                for (Kt, Mt, v, _) in results:
                    log(f'      from the strength {k_target + Kt} with {Mt} terms of the germ, {prec} bits: '
                        f'{v.mid().str(digits + 5, radius=False)}')
                xs = results[1][3]
                return {'value': v2, 'error': abs(v1 - v2), 'fstar': gauge_data[1], 'detH': gauge_data[2],
                        'starts': [(r[0], r[1]) for r in results], 'order': h, 'degree': D, 'prec': prec,
                        'values': {k: xs[k] for k in sorted(xs) if k <= Fr(k_target) + h}}
            have = f'{acc} correct bits' if acc > 0 else 'no correct bits'
            log(f'      {prec} bits: {have}, the two starts agree to {max(0, -gap):.0f} digits; doubling')
        else:
            log(f'      {prec} bits: a leading coefficient of the law is not separated from zero; doubling')
        prec *= 2
        if prec > max_prec:
            raise RuntimeError('the reading needs more than %d bits' % max_prec)
