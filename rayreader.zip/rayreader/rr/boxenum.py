"""Enumerate {u : |u| = tot, u(S) <= bound(S) for all nonempty proper S} by recursion with subset-sum pruning.
Optional blocks: within each block (a tuple of marks, consecutive), coordinates are nonincreasing (symmetry cut)."""
import itertools

def enum_box(n, tot, bound, blocks=()):
    """bound: dict frozenset(S) -> upper bound for u(S) (S nonempty proper); lower bounds via complements."""
    full = frozenset(range(n))
    ub = {S: bound[S] for S in bound}
    lb = {S: tot - bound[full - S] for S in bound}
    # per prefix i: subsets S of {0..i} containing i
    pref_subsets = []
    for i in range(n):
        lst = []
        for k in range(0, i + 1):
            for R in itertools.combinations(range(i), k):
                S = frozenset(R + (i,))
                if S != full: lst.append((S, frozenset(R)))
        pref_subsets.append(lst)
    blk_prev = {}
    for b in blocks:
        for x, y in zip(b, b[1:]): blk_prev[y] = x
    out = []
    lo_i = [lb[frozenset([i])] for i in range(n)]; hi_i = [ub[frozenset([i])] for i in range(n)]
    def rec(i, u, sums):
        if i == n - 1:
            x = tot - sum(u)
            if not (lo_i[i] <= x <= hi_i[i]): return
            if i in blk_prev and x > u[blk_prev[i]]: return
            ok = True; new = dict(sums)
            for S, R in pref_subsets[i]:
                v = new[R] + x
                if v > ub[S] or v < lb[S]: ok = False; break
                new[S] = v
            if ok: out.append(tuple(u + [x]))
            return
        hi = hi_i[i]
        if i in blk_prev: hi = min(hi, u[blk_prev[i]])
        for x in range(lo_i[i], hi + 1):
            ok = True; new = dict(sums)
            for S, R in pref_subsets[i]:
                v = new[R] + x
                if v > ub[S] or v < lb[S]: ok = False; break
                new[S] = v
            if ok: rec(i + 1, u + [x], new)
    rec(0, [], {frozenset(): 0})
    return out
