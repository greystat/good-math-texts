"""Exact arithmetic helpers: primes, Chinese remaindering, rational reconstruction of numbers and of
rational functions of k modulo a prime (interpolation, then the Euclidean remainder sequence with the
largest quotient, checked on points held out of the fit)."""
import math, random
from fractions import Fraction as Fr
import flint


def is_prime(n):
    if n < 2:
        return False
    for q in (2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37):
        if n % q == 0:
            return n == q
    d, s = n - 1, 0
    while d % 2 == 0:
        d //= 2; s += 1
    for a in (2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37):
        x = pow(a, d, n)
        if x in (1, n - 1):
            continue
        for _ in range(s - 1):
            x = x * x % n
            if x == n - 1:
                break
        else:
            return False
    return True


_PRIMES = {}


def primes(count, seed=5, start=0):
    """the primes number start .. start+count-1 of a fixed sequence of random primes in (2^61, 2^62)"""
    rnd, out = _PRIMES.setdefault(seed, (random.Random(seed), []))
    while len(out) < start + count:
        q = rnd.randrange(2 ** 61, 2 ** 62) | 1
        if is_prime(q):
            out.append(q)
    return out[start:start + count]


def prime_number(i, seed=5):
    return primes(1, seed, start=i)[0]


def crt_pair(r1, m1, r2, m2):
    t = (r2 - r1) * pow(m1, -1, m2) % m2
    return r1 + m1 * t, m1 * m2


def ratrec(a, m):
    """the fraction num/den = a mod m with |num|, den <= sqrt(m/2), or None"""
    a %= m
    if a == 0:
        return Fr(0)
    r0, r1, s0, s1 = m, a, 0, 1; B = math.isqrt(m // 2)
    while r1 > B:
        qq = r0 // r1; r0, r1 = r1, r0 - qq * r1; s0, s1 = s1, s0 - qq * s1
    if s1 == 0 or abs(s1) > B:
        return None
    return Fr(r1, s1) if s1 > 0 else Fr(-r1, -s1)


def ratrec_nd(a, m, N, D):
    """(n, d) with n/d = a mod m, |n| <= N, 0 < d <= D (unique when 2 N D < m), or None"""
    a %= m
    if a == 0:
        return 0, 1
    r0, r1, s0, s1 = m, a, 0, 1
    while r1 > N:
        qq = r0 // r1; r0, r1 = r1, r0 - qq * r1; s0, s1 = s1, s0 - qq * s1
    if s1 == 0 or abs(s1) > D:
        return None
    return (r1, s1) if s1 > 0 else (-r1, -s1)


def vec_ratrec(vals, m, margin=24):
    """the rationals n_i/d_i = vals_i mod m, read with a growing common denominator d: each value times d is
    taken as an integer when it is small, 2 |n| d 2^margin < m, and otherwise gives d a new factor by an
    unbalanced reconstruction (denominator up to m^(1/4)).  Needs about the bits of the largest numerator
    plus those of the common denominator, against twice the larger of the two for each value alone.
    Returns the list of Fractions, or None."""
    bits = m.bit_length()
    Dmax = 1 << max(8, bits // 4)
    Nmax = m // (4 * Dmax)
    half = m // 2
    d = 1; out = []
    for a in vals:
        b = a * d % m
        if b > half:
            b -= m
        if (2 * abs(b) * d) << margin < m:
            out.append(Fr(b, d)); continue
        r = ratrec_nd(b, m, Nmax, Dmax)
        if r is None:
            return None
        d *= r[1]
        b = a * d % m
        if b > half:
            b -= m
        if (2 * abs(b) * d) << margin >= m:
            return None
        out.append(Fr(b, d))
    return out


def to_mod(c, q):
    """a Fraction or integer modulo q (None if the denominator vanishes)"""
    c = Fr(c)
    d = c.denominator % q
    if d == 0:
        return None
    return c.numerator % q * pow(d, -1, q) % q


def interpolate(xs, ys, q):
    """the polynomial of degree < len(xs) through the points, modulo q (Newton's divided differences)"""
    n = len(xs); c = [y % q for y in ys]
    consecutive = all(xs[i + 1] - xs[i] == 1 for i in range(n - 1))
    if consecutive:
        inv = [0] + [pow(j, -1, q) for j in range(1, n)]
    for j in range(1, n):
        if consecutive:
            ij = inv[j]
            for i in range(n - 1, j - 1, -1):
                c[i] = (c[i] - c[i - 1]) * ij % q
        else:
            for i in range(n - 1, j - 1, -1):
                c[i] = (c[i] - c[i - 1]) * pow((xs[i] - xs[i - j]) % q, -1, q) % q
    P = flint.nmod_poly([c[n - 1]], q)
    for i in range(n - 2, -1, -1):
        P = P * flint.nmod_poly([(-xs[i]) % q, 1], q) + c[i]
    return P


def vanishing(xs, q):
    M = flint.nmod_poly([1], q)
    for x in xs:
        M = M * flint.nmod_poly([(-x) % q, 1], q)
    return M


def ratfun(xs, ys, q, holdout=3):
    """P/Q (Q monic) through the points modulo q: interpolate on all but `holdout` points, take the remainder
    pair of the Euclidean sequence of (prod(k - x), F) before the largest quotient, check the held-out points.
    Returns (P, Q) as nmod_polys, or None when the points do not determine a rational function."""
    n = len(xs) - holdout
    if n < 2:
        return None
    fx, fy = xs[:n], ys[:n]
    if all(y % q == 0 for y in ys):
        return flint.nmod_poly([], q), flint.nmod_poly([1], q)
    F = interpolate(fx, fy, q)
    r0, r1 = vanishing(fx, q), F
    t0, t1 = flint.nmod_poly([], q), flint.nmod_poly([1], q)
    best = None; bestdeg = -1
    while not r1.is_zero():
        qq, rr = divmod(r0, r1)
        dq = qq.degree()
        if dq > bestdeg and r1.degree() + t1.degree() < n:
            bestdeg = dq; best = (r1, t1)     # candidate before this quotient: F = r1/t1 mod M
        r0, r1 = r1, rr
        t0, t1 = t1, t0 - qq * t1
    if best is None:
        return None
    P, Q = best
    if Q.is_zero():
        return None
    lc = int(Q.leading_coefficient()); inv = pow(lc, -1, q)
    P = P * inv; Q = Q * inv
    g = P.gcd(Q)
    if g.degree() > 0:
        P = P // g; Q = Q // g
        lc = int(Q.leading_coefficient()); inv = pow(lc, -1, q); P = P * inv; Q = Q * inv
    if P.degree() + Q.degree() + 2 > n - 1:          # not determined with a margin
        return None
    for x, y in zip(xs, ys):
        qx = int(Q(x))
        if qx == 0 or int(P(x)) != y * qx % q:
            return None
    return P, Q


def coeffs(P):
    return [int(c) for c in P.coeffs()] if not P.is_zero() else [0]
