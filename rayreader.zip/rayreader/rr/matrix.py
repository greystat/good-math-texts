"""The one-step matrix over Q(k) (Theorem 23.5(i)): <b_j>_(k-1) = sum_l B_jl(k) <b_l>_k.

Modulo each prime the box is eliminated at random strengths.  Once, the relations whose pivot rows the
reduction of the targets uses (directly or through other such relations) are found, at two random points,
and the others dropped: any system between these relations and the whole box has the same normal forms
(the masters are not leading columns of any part of the row space), and the whole box checks the result.
The first prime: every entry reconstructed as P/Q (Q monic) from as many strengths as that takes, which
gives the common denominator Qc of all entries and the degree of the numerators over it, B = Pt/Qc.
Every further prime: Qc and all the Pt at once from deg Pt + 6 strengths, the denominator being shared by
every entry (each entry gives a linear condition on Qc; then Pt by interpolation, checked on held-out
strengths).  Over Q: Chinese remaindering and rational reconstruction with a common denominator, until two
rounds agree; then a check at a prime and a strength drawn at random against an elimination of the whole
box.  Every prime is saved as it finishes, and every few strengths within a prime."""
import os, pickle, random, time
import flint
from .elim import run_cp, run_bin, write_system, sort_relations
from .arith import prime_number, vec_ratrec, to_mod, coeffs, vanishing, is_prime

SEED_PRIMES = 97
P61 = (1 << 61) - 1


def _load(path):
    with open(path, 'rb') as fh:
        return pickle.load(fh)


def _save(obj, path):
    tmp = path + '.tmp'
    with open(tmp, 'wb') as fh:
        pickle.dump(obj, fh, protocol=pickle.HIGHEST_PROTOCOL)
    os.replace(tmp, path)


def prepare_reduced(sys_path, run_dir, log):
    """the box restricted to the relations the targets need, in the eliminator's order, with its rank"""
    path = os.path.join(run_dir, 'system_reduced.pkl')
    if os.path.exists(path):
        return path
    sysd = _load(sys_path)
    t0 = time.time()
    rels = sort_relations(sysd['rels'], sysd['cols'])
    rnd = random.Random(31)
    keep = set()
    for _ in range(2):
        k = rnd.randrange(10 ** 6, P61)
        res, extra = run_cp(rels, sysd['cols'], sysd['targets'], [k], P61, run_dir, presorted=True, want_needed=True)
        keep |= set(extra['needed'])
    red = {'rels': [rels[i] for i in sorted(keep)], 'cols': sysd['cols'], 'masters': sysd['masters'],
           'targets': sysd['targets']}
    k = rnd.randrange(10 ** 6, P61)
    red['rank'] = run_cp(red['rels'], red['cols'], red['targets'], [k], P61, run_dir, presorted=True)[0]['rank']
    red['bin'] = write_system(red['rels'], red['cols'], red['targets'], os.path.join(run_dir, 'system_reduced.bin'))
    _save(red, path)
    log(f'   the targets need {len(keep)} of the {len(rels)} relations (rank {red["rank"]}); the others are dropped '
        f'({time.time() - t0:.0f}s)')
    return path


def sample_mod(sysd, q, ks, workdir, binpath=None):
    """B(k) mod q at the strengths ks: list of (k, rows), rows None where the strength is degenerate;
    binpath: the eliminator's input for this system, if it was written once for all primes"""
    masters = sysd['masters']; mset = set(masters)
    if binpath and os.path.exists(binpath):
        res = run_bin(binpath, sysd['cols'], ks, q)
    else:
        res = run_cp(sysd['rels'], sysd['cols'], sysd['targets'], ks, q, workdir, presorted=True)
    out = []
    for rr in res:
        rows = None
        if rr['rank'] == sysd['rank'] and all(set(nf) <= mset for nf in rr['nf']):
            rows = [[nf.get(x, 0) for x in masters] for nf in rr['nf']]
        out.append((rr['k'], rows))
    return out


def _euclid_from(F, Mv, n, xs, ys, q):
    r0, r1 = Mv, F
    t0, t1 = flint.nmod_poly([], q), flint.nmod_poly([1], q)
    best = None; bestdeg = -1
    while not r1.is_zero():
        qq, rr = divmod(r0, r1)
        dq = qq.degree()
        if dq > bestdeg:
            bestdeg = dq; best = (r1, t1)
        r0, r1 = r1, rr
        t0, t1 = t1, t0 - qq * t1
    if best is None:
        return None
    P, Q = best
    if Q.is_zero():
        return None
    inv = pow(int(Q.leading_coefficient()), -1, q); P = P * inv; Q = Q * inv
    g = P.gcd(Q)
    if g.degree() > 0:
        P = P // g; Q = Q // g
        inv = pow(int(Q.leading_coefficient()), -1, q); P = P * inv; Q = Q * inv
    if P.degree() + Q.degree() + 2 > n - 1:
        return None
    for x, y in zip(xs, ys):
        qx = int(Q(x))
        if qx == 0 or int(P(x)) != y * qx % q:
            return None
    return P, Q


def reconstruct_full(ks, mats, q, mu, holdout=3):
    """every entry as P/Q mod q (Q monic), or None if some entry is not determined by these strengths"""
    n = len(ks) - holdout
    fk = ks[:n]
    Vm = flint.nmod_mat([[pow(x, i, q) for i in range(n)] for x in fk], q)
    Y = flint.nmod_mat([[M[j][l] % q for j in range(mu) for l in range(mu)] for M in mats[:n]], q)
    Cf = Vm.solve(Y)
    Mv = vanishing(fk, q)
    ent = {}; c = 0
    for j in range(mu):
        for l in range(mu):
            ys = [M[j][l] % q for M in mats]
            if all(y == 0 for y in ys):
                ent[(j, l)] = ([0], [1]); c += 1; continue
            F = flint.nmod_poly([int(Cf[i, c]) for i in range(n)], q)
            r = _euclid_from(F, Mv, n, ks, ys, q)
            c += 1
            if r is None:
                return None
            ent[(j, l)] = (coeffs(r[0]), coeffs(r[1]))
    return ent


def _binpath(red_path, sysd):
    return os.path.join(os.path.dirname(red_path), 'system_reduced.bin') if sysd.get('bin') else None


_CACHE = {}


def _sample_job(args):
    red_path, outdir, q, ks = args
    if red_path not in _CACHE:
        _CACHE.clear(); _CACHE[red_path] = _load(red_path)
    sysd = _CACHE[red_path]
    return sample_mod(sysd, q, ks, outdir, _binpath(red_path, sysd))


def _pool(workers):
    from multiprocessing import get_context
    return (get_context('fork') if hasattr(os, 'fork') else get_context()).Pool(workers)


def to_common(res):
    """a prime's result with every entry P/Q turned into Pt/Qc over the common denominator Qc (monic)"""
    q = res['q']
    if res.get('mode') == 'common':
        return res if res.get('P') is not None else None
    ent = res['entries']
    if ent is None:
        return None
    Qc = flint.nmod_poly([1], q)
    for P, Q in ent.values():
        Qq = flint.nmod_poly(Q, q)
        Qc = Qc * (Qq // Qc.gcd(Qq))
    Pt = {}
    for x, (P, Q) in ent.items():
        Pt[x] = coeffs(flint.nmod_poly(P, q) * (Qc // flint.nmod_poly(Q, q)))
    return {'idx': res['idx'], 'q': q, 'mode': 'common', 'Qc': coeffs(Qc), 'P': Pt}


def reconstruct_common(ks, mats, q, mu, dQc, plen, holdout=3):
    """Qc (monic, degree dQc) and every Pt (plen[x] coefficients) modulo q from the values B(k_i): one
    linear condition on Qc per entry (the values times Qc lie on polynomials of degree < max plen), then
    Pt by interpolation, checked on every point; None if the points do not determine them"""
    n = len(ks)
    keys = [x for x in sorted(plen) if plen[x] > 1 or any(M[x[0]][x[1]] for M in mats)]
    dP = max(plen.values()) - 1
    if n < dP + 2 + holdout or not keys:
        return None
    Y = flint.nmod_mat([[M[j][l] % q for (j, l) in keys] for M in mats], q)            # n x E
    Vp = flint.nmod_mat([[pow(k, e, q) for e in range(dP + 1)] for k in ks], q)        # n x (dP+1)
    N, nul = Vp.transpose().nullspace()
    if nul < 1:
        return None
    rnd = random.Random(q ^ 0x5bd1e995)
    rho = [rnd.randrange(1, q) for _ in range(nul)]
    w = [sum(r * int(N[i, c]) for c, r in enumerate(rho)) % q for i in range(n)]
    Wd = flint.nmod_mat([[w[i] * pow(ks[i], t, q) % q for i in range(n)] for t in range(dQc + 1)], q)
    Nc, nulc = (Wd * Y).transpose().nullspace()                                          # E x (dQc+1)
    if nulc != 1:
        return None
    c = [int(Nc[t, 0]) for t in range(dQc + 1)]
    if c[dQc] == 0:
        return None
    inv = pow(c[dQc], -1, q); c = [x * inv % q for x in c]
    Qc = flint.nmod_poly(c, q)
    qv = [int(Qc(k)) for k in ks]
    if any(v == 0 for v in qv):
        return None
    Dq = flint.nmod_mat(n, n, [qv[i] if i == j else 0 for i in range(n) for j in range(n)], q)
    Z = Dq * Y
    Vs = flint.nmod_mat([[pow(k, e, q) for e in range(dP + 1)] for k in ks[:dP + 1]], q)
    Zs = flint.nmod_mat([[int(Z[i, e]) for e in range(len(keys))] for i in range(dP + 1)], q)
    C = Vs.solve(Zs)                                                                    # (dP+1) x E
    if Vp * C != Z:
        return None
    Pt = {x: [0] for x in plen}
    for e, x in enumerate(keys):
        cs = [int(C[i, e]) for i in range(dP + 1)]
        if any(cs[plen[x]:]):
            return None
        Pt[x] = cs[:plen[x]]
    return c, Pt


def prime_job(args):
    """one prime: strengths in chunks (each saved), then the reconstruction; returns the path of the result"""
    red_path, outdir, idx, nsamp, chunk, mode, form_path = args
    path = os.path.join(outdir, f'prime_{idx:04d}.pkl')
    if os.path.exists(path):
        return path
    sysd = _load(red_path)
    q = prime_number(idx, SEED_PRIMES)
    mu = len(sysd['masters'])
    rnd = random.Random(1000 + idx)
    allks = []
    while len(allks) < 2 * nsamp + 64:
        x = rnd.randrange(10 ** 6, q)
        if x not in allks:
            allks.append(x)
    samples = []
    ci = 0; used = 0
    while len(samples) < nsamp and used < len(allks):
        cpath = os.path.join(outdir, f'chunk_{idx:04d}_{ci:03d}.pkl')
        if os.path.exists(cpath):
            got = _load(cpath)
        else:
            got = sample_mod(sysd, q, allks[used:used + chunk], outdir, _binpath(red_path, sysd))
            _save(got, cpath)
        used += chunk; ci += 1
        samples.extend((k, rows) for k, rows in got if rows is not None)
    samples = samples[:nsamp]
    ks = [s[0] for s in samples]; mats = [s[1] for s in samples]
    t0 = time.time()
    if mode == 'full':
        res = {'idx': idx, 'q': q, 'nsamp': len(ks), 'mode': 'full', 'entries': reconstruct_full(ks, mats, q, mu)}
    else:
        form = _load(form_path)
        got = reconstruct_common(ks, mats, q, mu, form['dQc'], form['plen'])
        res = {'idx': idx, 'q': q, 'nsamp': len(ks), 'mode': 'common',
               'Qc': got[0] if got else None, 'P': got[1] if got else None}
    res['recon_seconds'] = round(time.time() - t0, 1)
    _save(res, path)
    for f in os.listdir(outdir):
        if f.startswith(f'chunk_{idx:04d}_'):
            os.remove(os.path.join(outdir, f))
    return path


def first_prime(red_path, outdir, log, chunk, workers, start=24, cap=6000):
    """prime 0 with an adaptive number of strengths (sampled on all workers): enough to determine every entry"""
    path = os.path.join(outdir, 'prime_0000.pkl')
    if os.path.exists(path):
        return _load(path)
    sysd = _load(red_path)
    q = prime_number(0, SEED_PRIMES); mu = len(sysd['masters'])
    rnd = random.Random(1000)
    spath = os.path.join(outdir, 'first_samples.pkl')
    samples = _load(spath) if os.path.exists(spath) else []
    seen = {s[0] for s in samples}
    target = max(start, len(samples))
    t0 = time.time()
    pool = _pool(workers) if workers > 1 else None
    try:
        while True:
            while len(samples) < target:
                want = []
                while len(want) < min(chunk * workers, target - len(samples)):
                    x = rnd.randrange(10 ** 6, q)
                    if x not in seen:
                        seen.add(x); want.append(x)
                parts = [want[i::workers] for i in range(workers)]
                jobs = [(red_path, outdir, q, ks) for ks in parts if ks]
                got = pool.map(_sample_job, jobs) if pool else [_sample_job(j) for j in jobs]
                for g in got:
                    samples.extend((k, rows) for k, rows in g if rows is not None)
                _save(samples, spath)
            ks = [s[0] for s in samples]; mats = [s[1] for s in samples]
            ent = reconstruct_full(ks, mats, q, mu)
            if ent is not None:
                break
            log(f'      first prime: {len(samples)} strengths do not determine every entry yet ({time.time() - t0:.0f}s)')
            if target >= cap:
                raise RuntimeError('the entries of B need more than %d strengths' % cap)
            target = int(target * 1.25) + 8
    finally:
        if pool:
            pool.close(); pool.join()
    dmax = max(len(P) - 1 + len(Q) - 1 for P, Q in ent.values())
    res = {'idx': 0, 'q': q, 'nsamp': len(ks), 'mode': 'full', 'entries': ent}
    _save(res, path)
    log(f'      first prime: every entry determined by {len(ks)} strengths; largest deg P + deg Q = {dmax} '
        f'({time.time() - t0:.0f}s)')
    return res


class CommonCRT:
    """Qc and the numerators Pt combined over the primes whose degrees are the generic ones; rational
    reconstruction of all coefficients with one common denominator on demand"""
    def __init__(self, dQc, plen):
        self.dQc, self.plen = dQc, plen
        self.keys = sorted(plen)
        self.acc = None; self.mod = 1; self.n = 0

    def add(self, r):
        if r is None or len(r['Qc']) != self.dQc + 1:
            return False
        P = {x: list(r['P'][x]) + [0] * (self.plen[x] - len(r['P'][x])) for x in self.keys}
        if any(len(P[x]) != self.plen[x] for x in self.keys):
            return False
        flat = list(r['Qc']) + [c for x in self.keys for c in P[x]]
        q = r['q']
        if self.acc is None:
            self.acc = flat
        else:
            m = self.mod; inv = pow(m % q, -1, q)
            self.acc = [u + m * ((v - u) * inv % q) for u, v in zip(self.acc, flat)]
        self.mod *= q; self.n += 1
        return True

    def rec(self):
        if self.acc is None:
            return None
        got = vec_ratrec(self.acc, self.mod)
        if got is None:
            return None
        Qc = got[:self.dQc + 1]; out = {}; i = self.dQc + 1
        for x in self.keys:
            out[x] = (got[i:i + self.plen[x]], Qc); i += self.plen[x]
        return out


def evaluate_exact_mod(Bq, x, q, mu):
    rows = []
    for j in range(mu):
        row = []
        for l in range(mu):
            P, Q = Bq[(j, l)]
            num = 0
            for c in reversed(P):
                num = (num * x + to_mod(c, q)) % q
            den = 0
            for c in reversed(Q):
                den = (den * x + to_mod(c, q)) % q
            row.append(num * pow(den, -1, q) % q)
        rows.append(row)
    return rows


def _run_jobs(jobs, workers):
    if workers > 1 and len(jobs) > 1:
        with _pool(min(workers, len(jobs))) as pool:
            return pool.map(prime_job, jobs)
    return [prime_job(j) for j in jobs]


def one_step_matrix(sys_path, run_dir, workers, log, chunk=4, max_primes=400):
    """B over Q(k), resumable; returns dict (j, l) -> (numerator coeffs, denominator coeffs) as Fractions,
    every entry over the common denominator"""
    exact_path = os.path.join(run_dir, 'B_exact.pkl')
    if os.path.exists(exact_path):
        log('   B over Q(k): from the checkpoint')
        return _load(exact_path)['B']
    outdir = os.path.join(run_dir, 'B_primes'); os.makedirs(outdir, exist_ok=True)
    red_path = prepare_reduced(sys_path, run_dir, log)
    sysd = _load(red_path); mu = len(sysd['masters'])
    t0 = time.time()
    first = to_common(first_prime(red_path, outdir, log, chunk, workers))
    dQc = len(first['Qc']) - 1
    plen = {x: len(P) for x, P in first['P'].items()}
    form_path = os.path.join(run_dir, 'B_form.pkl')
    _save({'dQc': dQc, 'plen': plen}, form_path)
    ncom = max(plen.values()) - 1 + 6
    log(f'   one common denominator of degree {dQc}, numerators over it of degree at most {max(plen.values()) - 1}: '
        f'each further prime needs {ncom} strengths')
    crt = CommonCRT(dQc, plen)
    crt.add(first)
    prev = None; idx = 1; rec = None
    while idx < max_primes:
        batch = list(range(idx, idx + max(1, workers))); idx += len(batch)
        jobs = []
        for i in batch:
            path = os.path.join(outdir, f'prime_{i:04d}.pkl')
            mode = _load(path)['mode'] if os.path.exists(path) else 'common'
            jobs.append((red_path, outdir, i, ncom, chunk, mode, form_path))
        for p in _run_jobs(jobs, workers):
            r = to_common(_load(p))
            if r is None or not crt.add(r):
                log(f'      prime {_load(p)["idx"]}: not determined at its strengths, or of other degrees; set aside')
        rec = crt.rec()
        log(f'   {crt.n} primes ({crt.mod.bit_length()} bits): '
            f'{"reconstructible" if rec is not None else "not yet reconstructible"} ({time.time() - t0:.0f}s)')
        if rec is not None and rec == prev:
            break
        prev = rec
    else:
        raise RuntimeError('B over Q(k) not stable after %d primes' % max_primes)
    # the check: the whole box (not the reduced one) at a prime and a strength drawn at random
    full = _load(sys_path)
    rng = random.SystemRandom()
    Qc = rec[next(iter(rec))][1]
    while True:
        q = rng.randrange(2 ** 61, 2 ** 62) | 1
        if is_prime(q) and all(to_mod(c, q) is not None for c in Qc):
            break
    k = rng.randrange(10 ** 6, q)
    rr = run_cp(full['rels'], full['cols'], full['targets'], [k], q, outdir)[0]
    mset = set(full['masters'])
    ok = all(set(nf) <= mset for nf in rr['nf'])
    ok = ok and [[nf.get(x, 0) for x in full['masters']] for nf in rr['nf']] == evaluate_exact_mod(rec, k, q, mu)
    if not ok:
        raise RuntimeError('B over Q(k) disagrees with an elimination of the whole box at a random point')
    dmax = max(len(P) - 1 for P, Q in rec.values())
    hmax = max(max(abs(c.numerator).bit_length(), c.denominator.bit_length())
               for c in list(Qc) + [c for P, Q in rec.values() for c in P])
    log(f'   B over Q(k): {crt.n} primes, numerators of degree up to {dmax} over a common denominator of degree '
        f'{dQc}, coefficients up to {hmax} bits; checked against the whole box at a random prime and strength '
        f'({time.time() - t0:.0f}s)')
    _save({'B': rec, 'primes': crt.n, 'checked': True}, exact_path)
    return rec
