/* Sparse elimination modulo a prime 2^40 < q < 2^62 of relations with coefficients c0 + c1*k, one strength
   per pass.  Columns are numbered by complexity; the pivot of a row is its most complex column, so each
   unknown is traded only for simpler ones.  Rows are taken in input order (simplest leading column first)
   and each is reduced fully against the pivot rows so far.  The accumulator holds 128-bit sums of products
   and is reduced only when its column is read (or when it nears overflow); the touched columns of a row are
   visited in decreasing order by scanning a bitmap.
   Input (binary, little endian 64-bit words): N M T, M rows: nnz, (col, c0, c1)*nnz, T targets: nnz,
   (col, c)*nnz; the coefficients are signed.  Usage: elimr FILE q k1,k2,... [pivots] [needed]
   Output (text), per strength: "K k RANK r", then per target "T t nnz (col val)*".  At the first strength,
   with "pivots": a line "P i1 i2 ..." of the rows (input indices) that produced pivot rows; with "needed": a
   line "N i1 i2 ..." of the rows whose pivot rows enter the reduction of some target, directly or through
   the reduction of another needed row (the other rows can be dropped without changing any normal form). */
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
typedef uint64_t u64; typedef unsigned __int128 u128;
static u64 Q, MU, R64; static int KB;
static inline u64 bar(u128 x) {            /* x mod Q for x < 2^(2 KB) (Barrett) */
    u64 q1 = (u64)(x >> (KB - 1));
    u64 q3 = (u64)(((u128)q1 * MU) >> (KB + 1));
    u64 r = (u64)x - q3 * Q;
    while (r >= Q) r -= Q;
    return r;
}
static inline u64 mulm(u64 a, u64 b) { return bar((u128)a * b); }
static inline u64 addm(u64 a, u64 b) { u64 r = a + b; if (r >= Q) r -= Q; return r; }
static inline u64 red128(u128 x) {         /* x mod Q for x < 2^127 */
    u64 hi = (u64)(x >> 64), lo = (u64)x;
    u64 r = bar(lo);
    if (hi) r = addm(r, mulm(bar(hi), R64));
    return r;
}
static u64 powm(u64 a, u64 e) { u64 r = 1; while (e) { if (e & 1) r = mulm(r, a); a = mulm(a, a); e >>= 1; } return r; }
static u64 invm(u64 a) { return powm(a, Q - 2); }
static u64 rd(FILE *f) { u64 x; if (fread(&x, 8, 1, f) != 1) { fprintf(stderr, "read error\n"); exit(1); } return x; }
static u64 rds(FILE *f) {                   /* a signed coefficient, reduced mod Q */
    int64_t v = (int64_t)rd(f);
    if (v >= 0) return (u64)v % Q;
    u64 r = (u64)(-(v + 1)) % Q;            /* -v - 1 >= 0 */
    r = (r + 1) % Q;
    return r ? Q - r : 0;
}

static long N, M, T;
static int *rnnz; static int **rcol; static u64 **rc0, **rc1;
static int *tnnz; static int **tcol; static u64 **tval;
static int *pn; static int **pcol; static u64 **pneg; static char *haspiv;   /* pivot rows without the lead */
static u128 *acc; static u64 *bm;
static int *outcol; static u64 *outval;
static int track = 0; static int *dep; static long ndep, capdep;      /* substituted columns, for "needed" */

static int reduce_row(int top) {
    int on = 0;
    for (long wi = top >> 6; wi >= 0; wi--) {
        u64 w;
        while ((w = bm[wi]) != 0) {
            int b = 63 - __builtin_clzll(w);
            bm[wi] = w & ~(1ULL << b);
            int c = (int)(wi * 64 + b);
            u64 x = red128(acc[c]); acc[c] = 0;
            if (x == 0) continue;
            if (haspiv[c]) {
                if (track) { if (ndep == capdep) { capdep = 2 * capdep + 4096; dep = realloc(dep, capdep * sizeof(int)); } dep[ndep++] = c; }
                int n = pn[c]; const int *cs = pcol[c]; const u64 *vs = pneg[c];
                for (int j = 0; j < n; j++) {
                    int cc = cs[j];
                    u128 v = acc[cc] + (u128)x * vs[j];
                    if ((u64)(v >> 64) >> 62) v = red128(v);
                    acc[cc] = v;
                    bm[cc >> 6] |= 1ULL << (cc & 63);
                }
            } else {
                outcol[on] = c; outval[on] = x; on++;
            }
        }
    }
    return on;
}

int main(int argc, char **argv) {
    if (argc < 4) { fprintf(stderr, "usage: elimr FILE q k1,k2,... [pivots] [needed]\n"); return 1; }
    Q = strtoull(argv[2], NULL, 10);
    if (Q < (1ULL << 40) || Q >= (1ULL << 62)) { fprintf(stderr, "elimr needs 2^40 < q < 2^62\n"); return 1; }
    int want_piv = 0, want_need = 0;
    for (int a = 4; a < argc; a++) {
        if (!strcmp(argv[a], "pivots")) want_piv = 1;
        else if (!strcmp(argv[a], "needed")) want_need = 1;
        else { fprintf(stderr, "unknown option %s\n", argv[a]); return 1; }
    }
    KB = 64 - __builtin_clzll(Q);
    MU = (u64)(((u128)1 << (2 * KB)) / Q);
    R64 = (u64)((((u128)1) << 64) % Q);
    FILE *f = fopen(argv[1], "rb");
    if (!f) { fprintf(stderr, "cannot open %s\n", argv[1]); return 1; }
    N = rd(f); M = rd(f); T = rd(f);
    rnnz = malloc(M * sizeof(int)); rcol = malloc(M * sizeof(int *)); rc0 = malloc(M * sizeof(u64 *)); rc1 = malloc(M * sizeof(u64 *));
    int *rtop = malloc((M + 1) * sizeof(int));
    for (long i = 0; i < M; i++) {
        int z = (int)rd(f); rnnz[i] = z; rcol[i] = malloc(z * sizeof(int) + 4); rc0[i] = malloc(z * 8 + 8); rc1[i] = malloc(z * 8 + 8);
        int top = 0;
        for (int j = 0; j < z; j++) { rcol[i][j] = (int)rd(f); rc0[i][j] = rds(f); rc1[i][j] = rds(f); if (rcol[i][j] > top) top = rcol[i][j]; }
        rtop[i] = top;
    }
    tnnz = malloc(T * sizeof(int)); tcol = malloc(T * sizeof(int *)); tval = malloc(T * sizeof(u64 *));
    int *ttop = malloc((T + 1) * sizeof(int));
    for (long i = 0; i < T; i++) {
        int z = (int)rd(f); tnnz[i] = z; tcol[i] = malloc(z * sizeof(int) + 4); tval[i] = malloc(z * 8 + 8);
        int top = 0;
        for (int j = 0; j < z; j++) { tcol[i][j] = (int)rd(f); tval[i][j] = rds(f); if (tcol[i][j] > top) top = tcol[i][j]; }
        ttop[i] = top;
    }
    fclose(f);
    long S = 1; for (const char *p = argv[3]; *p; p++) if (*p == ',') S++;
    u64 *ks = malloc((S + 1) * 8);
    { const char *p = argv[3]; for (long i = 0; i < S; i++) { char *e; ks[i] = strtoull(p, &e, 10); p = (*e == ',') ? e + 1 : e; } }
    pn = calloc(N, sizeof(int)); pcol = calloc(N, sizeof(int *)); pneg = calloc(N, sizeof(u64 *)); haspiv = calloc(N, 1);
    acc = calloc((size_t)N, sizeof(u128)); bm = calloc((size_t)(N / 64 + 2), 8);
    outcol = malloc((N + 1) * sizeof(int)); outval = malloc((N + 1) * 8);
    int *pivrows = malloc((M + 1) * sizeof(int)); int *pidx = malloc((N + 1) * sizeof(int));
    long *dstart = NULL, *dend = NULL;
    for (long s = 0; s < S; s++) {
        u64 k = ks[s] % Q;
        track = want_need && s == 0;
        if (track) { dstart = malloc((M + 1) * sizeof(long)); dend = malloc((M + 1) * sizeof(long)); ndep = 0; }
        for (long c = 0; c < N; c++) if (haspiv[c]) { free(pcol[c]); free(pneg[c]); pcol[c] = NULL; pneg[c] = NULL; haspiv[c] = 0; pn[c] = 0; }
        long npiv = 0;
        for (long i = 0; i < M; i++) {
            long d0 = ndep;
            for (int j = 0; j < rnnz[i]; j++) {
                int c = rcol[i][j];
                acc[c] += addm(rc0[i][j], mulm(rc1[i][j], k));
                bm[c >> 6] |= 1ULL << (c & 63);
            }
            int on = reduce_row(rtop[i]);
            if (on == 0) { if (track) ndep = d0; continue; }
            int lead = outcol[0];
            u64 inv = invm(outval[0]);
            pn[lead] = on - 1; pcol[lead] = malloc((size_t)on * sizeof(int)); pneg[lead] = malloc((size_t)on * 8);
            for (int j = 1; j < on; j++) { pcol[lead][j - 1] = outcol[j]; pneg[lead][j - 1] = Q - mulm(outval[j], inv); }
            haspiv[lead] = 1;
            if (track) { dstart[npiv] = d0; dend[npiv] = ndep; pidx[lead] = (int)npiv; }
            pivrows[npiv++] = (int)i;
        }
        if (want_piv && s == 0) {
            printf("P"); for (long i = 0; i < npiv; i++) printf(" %d", pivrows[i]); printf("\n");
        }
        long tdep0 = ndep;
        printf("K %llu RANK %ld\n", (unsigned long long)k, npiv);
        for (long t = 0; t < T; t++) {
            for (int j = 0; j < tnnz[t]; j++) { int c = tcol[t][j]; acc[c] += tval[t][j]; bm[c >> 6] |= 1ULL << (c & 63); }
            int on = reduce_row(ttop[t]);
            printf("T %ld %d", t, on);
            for (int j = 0; j < on; j++) printf(" %d %llu", outcol[j], (unsigned long long)outval[j]);
            printf("\n");
        }
        if (track) {
            char *mark = calloc(npiv + 1, 1);
            for (long d = tdep0; d < ndep; d++) mark[pidx[dep[d]]] = 1;
            for (long p = npiv - 1; p >= 0; p--)
                if (mark[p]) for (long d = dstart[p]; d < dend[p]; d++) mark[pidx[dep[d]]] = 1;
            printf("N"); for (long p = 0; p < npiv; p++) if (mark[p]) printf(" %d", pivrows[p]); printf("\n");
            free(mark); free(dstart); free(dend); free(dep); dep = NULL; capdep = 0; ndep = 0; track = 0;
        }
        fflush(stdout);
    }
    return 0;
}
