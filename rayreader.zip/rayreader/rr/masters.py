"""The masters: boxes searched in order of size until every target reduces.

In a box (T; A, B) the candidates are the Laurent insertions of wall degree at most T - 1; one elimination at a
random strength leaves some of them free.  For a master degree D <= T - 1 the masters are the free candidates of
wall degree at most D, and (box, D) is accepted when each target L b (b a master) lies in the box and reduces to
the masters at a second random strength; D is tried from T - 1 down.  The order of the search reaches every
(T, A, B), and by the finite dimension of the ray (Thm. 35.19(i)) some (box, D) is accepted (Theorem 23.10)."""
import random, time
from .system import build_system
from .elim import run_cp

P61 = (1 << 61) - 1


def _n(k, word):
    return f'{k} {word}' + ('' if k == 1 else 's')


def schedule(ray, max_size=8):
    """(T, A, B) by increasing size (T - 2) + (A - A0) + (B - B0), larger T first; A0 = 1 when the letter K
    occurs in the stride or the origin, else 0, and B0 likewise for Psi"""
    A0 = 1 if (ray.s > 0 or ray.a0 != 0) else 0
    B0 = 1 if (ray.t > 0 or ray.b0 != 0) else 0
    for size in range(max_size + 1):
        for dT in range(size, -1, -1):
            rest = size - dT
            for dA in range(rest + 1):
                yield (2 + dT, A0 + dA, B0 + rest - dA)


def find_masters(ray, log, seed=1, max_size=8):
    rnd = random.Random(seed)
    for (T, A, B) in schedule(ray, max_size):
        t0 = time.time()
        rels, cols, info = build_system(ray, T, A, B, log)
        colset = set(cols)
        cand = [x for x in cols if x[1] == 0 and x[2] == 0 and ray.deg(*x) <= T - 1 + 1e-9]
        k1 = rnd.randrange(10 ** 6, P61)
        res = run_cp(rels, cols, [{x: 1} for x in cand], [k1], P61)
        free = [x for x, nf in zip(cand, res[0]['nf']) if nf == {x: 1}]
        degs = {x: ray.deg(*x) for x in free}
        targets = {x: ray.target(x[0]) for x in free}
        inside = [x for x in free if all(y in colset for y in targets[x])]
        k2 = rnd.randrange(10 ** 6, P61)
        nfs = dict(zip(inside, run_cp(rels, cols, [targets[x] for x in inside], [k2], P61)[0]['nf'])) if inside else {}
        found = None; tried = []
        for D in range(T - 1, -1, -1):
            masters = [x for x in free if degs[x] <= D + 1e-9]
            if not masters:
                continue
            if any(x not in nfs for x in masters):
                tried.append(f'D = {D}: a target leaves the box')
                continue
            mset = set(masters)
            bad = sum(1 for x in masters if not set(nfs[x]) <= mset)
            if bad == 0:
                found = (D, masters); break
            tried.append(f'D = {D}: {_n(len(masters), "master")}, {_n(bad, "target")} not reducing to them')
        if found is None:
            log(f'   box ({T};{A},{B}): ' + '; '.join(tried))
            continue
        D, masters = found
        info.update({'masters': len(masters), 'master degree': D, 'rank': res[0]['rank'],
                     'seconds': round(time.time() - t0, 1)})
        log(f'   box ({T};{A},{B}) accepted with master degree {D}: {_n(len(masters), "master")}, every target reduces '
            f'({time.time() - t0:.1f}s)')
        return {'box': (T, A, B), 'rels': rels, 'cols': cols, 'masters': masters,
                'targets': [targets[x] for x in masters], 'info': info}
    raise RuntimeError('no box up to size %d reduces every target' % max_size)
